# Copilot token kit

A small set of Agent Skills, custom agents, instructions and scripts for VS Code Copilot
that reduce token consumption and, more usefully, let you measure it.

Designed to be added to an existing kit. Nothing here replaces what you have.

## What is in it

```
.github/
  copilot-instructions.md              always-on harness, ~470 tok, deliberately small
  instructions/
    tool-output.instructions.md        scoped to scripts and notebooks
    editing.instructions.md            scoped to source files
    critical-paths.instructions.md     forces T3 on safety and RCA paths
  skills/
    token-budget/                      which lever fits which symptom (+4 references)
    kit-audit/                         measures this workspace  (+ audit_kit.py)
    lean-output/                       output-side discipline
    handoff-contract/                  brief and result schemas  (+ 1 reference)
    skill-hygiene/                     authoring skills          (+ skill_lint.py)
    session-state/                     plans and findings on disk, not in chat
    model-routing/                     tiering by task shape (+ assign_models.py, pricing ref)
    delegate-external/                 push bulky work to Databricks or another agent (+2 refs)
  agents/
    scout.agent.md                     read-only, path:line not contents, pin a cheap model
    lean-orchestrator.agent.md         plans on disk, delegates with pointers, hands off
    token-auditor.agent.md             measures, proposes one diff, hands off to apply
    dbx-worker.agent.md                volume worker pinned to a Databricks BYOK model, zero credits
    critical-reviewer.agent.md         T3, reached only by handoff; the step nothing cheaper may touch
  mcp/databricks-delegate/
    server.py                          MCP server: reads and generates on Databricks, returns abstracts
    requirements.txt
  models.yaml                          tier registry with real Copilot rates, dated
  agent-tiers.yaml                     agent -> tier and skill -> minimum tier
  hooks/
    token-discipline.json              two deterministic hooks, see below
    scripts/guard_read.py              PreToolUse: ask before whole-file reads over 400 lines
    scripts/token_ledger.py            PostToolUse: log every tool call's output size
  prompts/
    token-audit.prompt.md              /token-audit
    context-check.prompt.md            /context-check
evals/
  skill-triggers.json                  38 should/should-not prompts across the 7 skills
.vscode/
  mcp.json                             registers the delegate server; secrets via prompts, never in files
  chatLanguageModels.databricks.example.json   BYOK template for Databricks endpoints
.vscode-settings.snippet.json          settings to enable skills and hooks
.gitignore                             ignores .copilot-state/
```

## Install

Copy the `.github` tree into your workspace root, merging rather than replacing. If you
already have a `copilot-instructions.md`, take the sections you want rather than
overwriting; that file is your cached prefix and its stability matters more than its
content.

Merge `.vscode-settings.snippet.json` into `.vscode/settings.json`. It enables skills
(`chat.useAgentSkills`), hooks (`chat.useCustomAgentHooks`), and points VS Code at
`.github/hooks`.


Optionally `pip install tiktoken` for exact token counts. Without it both scripts fall back
to a character heuristic that is roughly 10 percent off on prose and worse on code. It still
ranks correctly, which is what the scripts are for.

To use the skills across every workspace rather than one, put the skill folders in
`~/.copilot/skills/` instead. The audit script reads both locations.

## Start here

```bash
python .github/skills/kit-audit/scripts/audit_kit.py --root . --calls 42
python .github/skills/skill-hygiene/scripts/skill_lint.py --root .
```

Or in chat, `/token-audit`.

For a multi-agent session, model it directly:

```bash
python .github/skills/kit-audit/scripts/audit_kit.py --agents 4 --turns 8
```

## Model tiers

Copilot Business and Enterprise bill per token in AI credits at per-model rates, and the
rates differ about 50x between the cheapest and the most capable model. Output costs 5 to
6 times input on every model. Routing work to the right tier is therefore a larger lever
than any prompt edit, and the kit treats it as configuration rather than as advice.

`.github/models.yaml` is the registry: four tiers, the models in each with their input,
cached-input, cache-write and output rates, a default pick per tier, and the paths that
force T3. Rates were read from GitHub's pricing page on the date in the file; they change,
so re-check before trusting a cost figure.

`.github/agent-tiers.yaml` assigns a tier to each agent and a minimum tier to each skill.
Skills cannot pin a model, so the orchestrator reads the skill minimum when choosing which
agent to delegate to.

```bash
python .github/skills/model-routing/scripts/assign_models.py --root .            # show diff
python .github/skills/model-routing/scripts/assign_models.py --root . --write    # apply
python .github/skills/model-routing/scripts/assign_models.py --root . --clear --write
```

Applying writes the `model:` line into each agent file and adds an agent-scoped ledger hook
that tags every recorded tool call with the tier. VS Code hooks do not expose the active
model, so the tier has to come from the agent definition; this is how the audit can price
recorded sessions.

The shipped agents are assigned: scout T0, token-auditor T1, lean-orchestrator T2,
critical-reviewer T3, dbx-worker D1 with a Copilot fallback. BYOK-tier agents get
`model:` as a prioritized list so they still load when the BYOK model is absent. If an agent fails to load after install, the model string is not
available in your enterprise's enabled model list; edit `default_pick` in `models.yaml` and
re-run with `--write`, or `--clear --write` to remove the pins.

The audit's cost section prices each agent per call at its tier and shows what the same
call would cost at T3. On the shipped kit that is 0.06 credits for scout against 1.17 at
T3, a 20x difference from a one-line change.

**Escalation runs down, never up.** VS Code will not run a subagent on a model whose cost
tier exceeds the parent's; the call fails. So a coordinator can delegate to any tier at or
below its own, and anything that needs a higher tier is a handoff button the user clicks,
which opens `critical-reviewer` at T3 in a fresh session. If a workflow can touch a
critical path, either the coordinator itself runs at T3 with cheap workers below it, or the
escalation is a visible human decision. Both are fine; a silent upward delegation is not
possible. Related: `lean-orchestrator` has an `agents` allowlist so it cannot pick an
unintended worker, and nested subagents are left off in the settings snippet.

`critical-paths.instructions.md` is the guardrail: any file under a listed path tells a
lower-tier agent to stop and return blocked. Edit the `applyTo` globs to your tree.

## Offloading to Databricks and other agents

Three routes, all keeping tokens off the Copilot bill. The second and third also keep them
out of the Copilot context window.

**Route 1, BYOK.** Register Databricks Model Serving endpoints as Copilot models through
the Custom Endpoint provider (template in `.vscode/chatLanguageModels.databricks.example.json`).
They appear in the model picker and any agent can be pinned to them. Tokens are billed by
Databricks, not in credits. Tiers `D0` and `D1` in `models.yaml` are for this; `dbx-worker`
ships pinned to D1, and scout should move to D0 once the models are registered. Available
on Business and Enterprise since April 2026, subject to the organization policy.

**Route 2, delegate tools.** `.github/mcp/databricks-delegate/server.py` is an MCP server
with five tools that take a path and a question, do the reading on Databricks, and return
only an abstract capped at 300 tokens. A 38,000-token log becomes 140 tokens in the Copilot
window. `lean-orchestrator` has the tools and is instructed to use them before reading
anything over ~5,000 tokens or generating over ~200 lines. The server logs every call to
the ledger with an `offloaded_in_tok` field, so the audit reports how much never entered
context.

**Route 3, specialist agents.** Any agent that exposes MCP tools can take a brief by path
and return a path plus abstract. List it under `external_agents` in `models.yaml`.

Setup for routes 1 and 2:

```bash
pip install -r .github/mcp/databricks-delegate/requirements.txt
```

`.vscode/mcp.json` prompts for the host, token and default endpoint on first use and stores
them in VS Code's secret storage. Nothing secret is written to any file in this kit, and
the server refuses paths outside the workspace root.

Tool names in the agent files follow the current VS Code docs (`read`, `search`, `edit`,
`agent`, and so on). If an agent shows a tool warning after install, open the tools picker
and copy the exact identifiers; names have changed between releases.

Three cautions. Repository content leaves the editor on every route; Databricks inside the
company perimeter is usually acceptable where a public API is not, but confirm before the
first call. Some OpenAI-compatible endpoints reject the exact request shapes VS Code sends;
`references/byok-setup.md` lists the workarounds. And the delegation tool call itself costs
Copilot tokens (schema, arguments, result), so `references/break-even.md` gives the
threshold: roughly 5,000 tokens of avoided reading, or 200 lines of avoided generation.

## Hooks: the deterministic layer

Instructions are probabilistic. Hooks are shell commands that run at lifecycle points and
cannot be forgotten. Two are included.

`guard_read.py` runs before every tool call. If the agent is about to read a file over 400
lines with no line range, it returns an "ask" decision with the file's size and a reason,
so the user sees the cost before paying it. Ranged reads and small files pass silently.
Tune with `COPILOT_READ_GUARD_LINES`.

`token_ledger.py` runs after every tool call and appends one line to
`.copilot-state/ledger.jsonl`: tool name, input size, output size. Nothing leaves the
machine. `audit_kit.py` reads this file when present and adds a section on what tool
output actually cost in recorded sessions, ranked by tool. That section is the only part
of the audit that is measured rather than estimated, and it outranks everything else.

Read both scripts before enabling them. Hooks run with the same permissions as VS Code.

The hook input field names (`tool_name`, `tool_input`, `tool_response`) follow the
documented VS Code format, with camelCase fallbacks. If your VS Code version differs, the
scripts fail silently rather than blocking the agent; check
View > Output > GitHub Copilot Chat Hooks.

## Re-measuring

```bash
python .github/skills/kit-audit/scripts/audit_kit.py --json before.json
# make one change
python .github/skills/kit-audit/scripts/audit_kit.py --compare before.json
```

The `--compare` section reports the movement per scenario and per file. Keep changes that
lowered tokens per call; revert the rest.

## What the kit costs

Measured against itself, which is the only fair test for something like this:

| | tokens |
|---|---|
| Always-on: harness plus scoped instructions when they apply | ~470 per call; plus the MCP server's tool schemas (~2 to 5k, estimated) on agents that list its tools |
| Skill discovery floor, all 8 skills | ~1,100 per call |
| Skill bodies, if all loaded at once | ~6,200 (a comparison point; VS Code loads them on demand) |
| Skill bodies, typical, 1 to 2 triggered | ~700 to 2,000 |
| References, only when a body points at them | ~6,000 available, near zero typical |
| Hooks | 0; they run outside the context |
| Registry and tier files | 0; read by scripts, never by the model |

The largest body is model-routing at about 1,220 tokens. Nothing here is a 6,000-token skill about saving tokens.

Run the audit on your own kit before and after adding this, and drop anything that does not
earn its place.

## What the measurements are, and are not

The audit is a static inventory plus scenarios: it counts what is on disk and models what
would load. It does not observe requests. The ledger is a tool-payload diagnostic: it sizes
tool arguments and result text, which becomes model input, and it does not see prompts,
generated output, reasoning, cache hits or failed calls. Neither is a billing meter, and the
kit no longer describes either one as measured cost.

For billed usage, use VS Code's OpenTelemetry export, which reports the requested and
resolved model plus input, output and cache token counters per model call, and the
provider's usage page. Reconcile the audit against those.

The token counter, when tiktoken loads, is a `cl100k_base` count of static text. It is not
the tokenizer of every model in the picker and it does not include message framing or tool
serialization. Without tiktoken it is a character heuristic. Both are labelled as such in
the output.

The scenario section's "every skill body" row is a hypothetical worst case for comparison.
VS Code already loads skill bodies on demand; the kit does not create that saving.

Adding the `databricks-delegate` MCP server adds its tool schemas to every call of any
agent whose `tools` list includes them. The audit's estimate for that is crude. Give the
tools only to agents that will use them, and measure the real payload.

## Honest numbers

Every figure these scripts produce is an estimate.

The tokenizer may be a heuristic. The MCP schema figure is a crude multiplication and should
be replaced by a real measurement of your serialized request; it is in the report because
MCP schemas are the least visible always-on block, not because the number is good.

The cache multiplier assumes a stable prefix and one write per session. If your prefix drifts
mid-session, the real multiplier is worse and the audit is optimistic.

The counterfactual section is the part worth reading twice. It prices the same fix with and
without caching, and on this kit the gap is about eight times. That gap is why a published
"85 percent reduction" figure will not reproduce in a setup that already caches well.

None of this is a bill.

## On the caveman project

Worth knowing about, and worth reading the caveats before installing.

**The original skill** makes the agent answer in compressed shorthand. Their own README is
straightforward about the limits: it only shrinks output tokens, it adds roughly 1 to 1.5k
input tokens per turn, whole-session savings run smaller than the headline, and on already
terse workloads it can go net negative. The 65 percent benchmark table compares against an
unprompted assistant rather than a terse one, which the authors also flag. If your harness
already says "state what changed and stop", most of that 65 percent is already yours.

**Caveman Proxy** is the more interesting product and a different thing entirely: a local
proxy that compresses what the agent reads before each provider call, with byte-exact
recovery from a content-addressed store. Reported at 33.2 percent fewer provider-reported
input tokens in a pinned 54-run Claude Code benchmark while passing all 18 exact-answer
checks. Per-content-type compressors for JSON, logs, code, diffs and search results. This is
the input side, which is where the money actually is.

**`caveman learn`** scans your agent history and ranks token sinks with a fix behind each
row. That is the same job as `audit_kit.py`, done against real session history rather than
static files. If you run it, run both: history tells you what you actually spent, static
analysis tells you what a new session will cost before you spend it.

**Pixel mode** renders dense text slabs to PNG because images are priced differently from
text, and `caveman convert` applies the same trick to installed SKILL.md bodies, keeping
frontmatter as text so discovery still works. That directly targets the finding that skill
bodies dominate a skill-heavy kit. It is clever and it is a real quality risk: it only runs
for models with measured render legibility, it is honestly unprofitable on sparse
short-line content, and you are asking the model to read instructions through OCR. Test it
on your own workload before trusting it with anything that has to be followed exactly.

**Before installing at GM, check these.** The engine, proxy, browse, MCP server and shrink
are BSL-1.1, source-available but not OSI open source until conversion; only the skill and
CLI are MIT. The proxy sits between your editor and the provider, which is a change to the
data path that a security review will want to see. The CLI sends anonymous usage telemetry
by default; `caveman telemetry off` or `DO_NOT_TRACK=1` disables it. And their own labelling
convention is worth adopting regardless: local results say `inferred`, benchmark results say
`benchmark_counterfactual`, and nothing offline claims `verified`.

**How it relates to this kit.** They are complements, not alternatives. This kit changes what
your setup loads and what your agents emit, at the source. Caveman compresses what crosses
the wire, after the fact. Fix the source first: compressing a bloated always-on block is
worse than not having the bloat. Then, if you still want the wire-level saving, the proxy is
the piece to evaluate.
