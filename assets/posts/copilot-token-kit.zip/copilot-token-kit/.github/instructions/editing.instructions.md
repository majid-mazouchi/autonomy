---
applyTo: "**/*.{py,js,ts,tsx,jsx,java,c,cpp,h,hpp,cs,go,rs,m,rb,php,scala,kt,swift}"
description: Patch-based editing rules
---

# Editing source files

Emit a patch, never a rewrite. Reproduce the changed lines plus the minimum surrounding
context needed for the anchor to be unique. If more than roughly 40 percent of a file is
changing, say so and rewrite deliberately.

Before emitting a replacement, confirm the anchor text appears exactly once. A failed match
costs a full retry, which is more expensive than the reading needed to prevent it.

Refer to code by `path:line`. Do not quote a block to explain a change that the diff already
shows.

After the diff, state only what a reader could not infer from it: assumptions made, anything
left incomplete, and anything that surprised you. No summary of the change itself.

Do not reformat, reorganize imports, or fix unrelated lint findings in a file you are editing
for another reason. Every unrequested change is output tokens plus review burden.
