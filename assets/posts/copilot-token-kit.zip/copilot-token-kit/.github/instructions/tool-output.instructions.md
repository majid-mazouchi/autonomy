---
applyTo: "**/*.{py,ipynb,sql,sh,ps1}"
description: Keep command, query and script output out of the context window
---

# Handling command and data output

When a command, query, or script produces more than about 50 lines, do not let the raw
output stand in the context. State what it showed in two or three lines and keep only the
rows that bear on the task.

For dataframes and result sets, print `shape`, `dtypes`, and `head(5)`, not the frame.
For long logs, keep errors, stack traces, and the first and last few lines; drop INFO and
progress noise.
For test runs, keep failures and the summary line; drop passing test names.

Write large intermediate results to a file and reference the path. A path costs a dozen
tokens; the artifact costs thousands, and it is still there when it is actually needed.

Prefer a filter at the source over a filter after the fact. `grep`, `head`, `--quiet`, a
`LIMIT` clause, and a `WHERE` clause are all cheaper than reading everything and discarding
most of it.

When printing tabular data for inspection, use a delimited format rather than pretty-printed
JSON. JSON repeats every key on every record, which for a wide result set is mostly
punctuation.

Do all of this at the point the output is produced, not afterwards. Once it is in the
transcript it is re-sent on every subsequent turn of the session.
