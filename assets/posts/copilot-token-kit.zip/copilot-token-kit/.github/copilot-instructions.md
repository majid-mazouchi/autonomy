# Workspace conventions

This block is always in context on every request. It is the cached prefix, so it stays
short and stable. Anything that changes per task belongs in a skill, an agent, or a prompt
file, not here.

## Context discipline

Read narrow before reading wide. Grep for a symbol before reading a file; read a line
range before reading a whole file. Do not paste a file into chat that is on disk and
reachable by path.

Cite by location, not by copy. Refer to code as `path:line` rather than quoting the block,
unless the exact text is the thing being discussed.

Edit by patch, not by rewrite. Reproduce only the lines that change plus the anchor context
a match needs.

Summarize tool output at the boundary. When a command, query, or search returns more than
about 50 lines, state what it showed in a few lines and keep only the rows that bear on the
task.

Use the cheapest tool that answers the question. Builtin search before an MCP tool, a
`LIMIT` or `head` before a full result, one targeted call before a broad one. Do not repeat
a call with identical arguments unless something changed in between: an edit, a state
change, or a transient failure. Re-running tests after an edit is not a repeat.

Say what changed and stop. No preamble restating the request, no closing summary of work
already visible in the diff, no unsolicited alternatives.

## State

Multi-turn work keeps its plan and findings under `.copilot-state/<task-slug>/`, one
folder per task so concurrent sessions do not collide, referenced by path rather than
restated in chat. After a compaction or restart, read `plan.md` first and nothing else
until the plan points at it.

## Termination

Stop when the stated task is done. Do not continue exploring or refactoring adjacent
code. Verification that the change works is part of the task; new test files for things
not asked about are not. If the task is larger than stated, say so and ask.

## When unsure

Ask one specific question rather than exploring the repository to guess the answer.
Reading twenty files to avoid one question is a bad trade. If you are running as a
subagent and cannot ask, return blocked with the question stated.
