---
mode: agent
description: Check what is in context right now and what can be dropped
---

Before continuing, take stock of this session.

List, briefly:
- Files read in full that only needed a line range
- Command or tool output sitting in the transcript that has already served its purpose
- Anything pasted into chat that exists on disk and could have been referenced by path
- Whether the current task is actually finished

Then state in one line what you would drop, and continue with the task. Do not restate the
task or summarize the session history.
