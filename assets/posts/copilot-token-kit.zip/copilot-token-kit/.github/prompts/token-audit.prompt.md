---
mode: agent
description: Measure this workspace's Copilot token footprint and rank the sinks
---

Audit the token footprint of this workspace's Copilot customization.

1. Run `python .github/skills/kit-audit/scripts/audit_kit.py --root . --calls 42`
2. Run `python .github/skills/skill-hygiene/scripts/skill_lint.py --root .`
3. Report only: the total per-call always-on cost, the top three sinks with their share,
   and any finding flagged by the linter.
4. For each of the top three, say whether it sits in the cached prefix, and check it against
   `.github/skills/token-budget/references/anti-patterns.md` before suggesting anything.
5. Propose at most one fix, as a diff, with an expected saving and what it costs in
   capability.

Do not edit anything. Do not propose a batch of changes. If nothing is clearly worth
changing, say so.
