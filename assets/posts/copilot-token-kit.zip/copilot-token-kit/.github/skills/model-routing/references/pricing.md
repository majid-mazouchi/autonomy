# Copilot model pricing, as seeded into models.yaml

Source: GitHub Docs, "Models and pricing for GitHub Copilot", read 2026-09-05.
https://docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing

All prices USD per 1M tokens. 1 AI credit = $0.01. Copilot Business and Enterprise include
per-user credit allowances pooled at the billing entity; usage past the allowance bills at
these rates. Legacy annual Pro and Pro+ plans still use request multipliers instead and are
not covered here.

| Model | Input | Cached in | Cache write | Output | Out/In |
|---|---|---|---|---|---|
| GPT-5.4 nano | 0.20 | 0.02 | n/a | 1.25 | 6.3 |
| GPT-5.6 Luna | 0.20 | 0.02 | 0.25 | 1.20 | 6.0 |
| GPT-5 mini | 0.25 | 0.025 | n/a | 2.00 | 8.0 |
| MAI-Code-1.1-Flash | 0.20 | 0.02 | n/a | 1.20 | 6.0 |
| Gemini 3.8 Flash (promo to 2026-12-31) | 0.75 | 0.075 | n/a | 3.75 | 5.0 |
| GPT-5.4 mini | 0.75 | 0.075 | n/a | 4.50 | 6.0 |
| Claude Haiku 4.5 | 1.00 | 0.10 | 1.25 | 5.00 | 5.0 |
| GPT-5.3-Codex | 1.75 | 0.175 | n/a | 14.00 | 8.0 |
| Claude Sonnet 5 | 2.00 | 0.20 | 2.50 | 10.00 | 5.0 |
| GPT-5.6 Terra | 2.00 | 0.20 | 2.50 | 12.00 | 6.0 |
| Grok 4.6 | 2.00 | 0.50 | n/a | 6.00 | 3.0 |
| GPT-5.4 | 2.50 | 0.25 | n/a | 15.00 | 6.0 |
| Claude Sonnet 4.6 | 3.00 | 0.30 | 3.75 | 15.00 | 5.0 |
| Kimi K3 | 3.00 | 0.30 | n/a | 15.00 | 5.0 |
| GPT-5.6 Sol | 4.00 | 0.40 | 5.00 | 20.00 | 5.0 |
| Claude Opus 5 | 5.00 | 0.50 | 6.25 | 25.00 | 5.0 |
| GPT-5.5 | 5.00 | 0.50 | n/a | 30.00 | 6.0 |
| Claude Fable 5.1 | 10.00 | 0.25 | 12.50 | 50.00 | 5.0 |
| GPT-6 Astra | 10.00 | 1.00 | 12.50 | 50.00 | 5.0 |

## What the table says

Output is 5 to 8 times input everywhere. Nothing changes that; it is the reason the
"design high, generate low" pattern works.

Cached input is a tenth of fresh input everywhere, and on Fable 5.1 it is a fortieth. A
stable prefix is cheap even on a frontier model. Tool output is never cached, so it is
always fresh input at the full tier rate.

Cache write on Anthropic and newer OpenAI models is 1.25x input. The first call of a
session pays it; every later call reads at 0.1x. Break-even is the second call.

Long-context tiers on OpenAI double the rates past 200k to 272k input tokens. That is a
hard argument for compaction well below the window limit.

The spread from GPT-5.4 nano to Fable 5.1 or Astra is 50x on input and 40x on output.
Routing a locate-and-extract task from T3 to T0 saves more than every prompt edit on this
page combined.

## Note

Copilot code review selects its own model and does not disclose it, so its per-token cost
varies and cannot be tiered from here. Code completions are not billed in credits.
