---
name: model-routing
description: Match model tier to task so routine work runs on a cheap model and only judgment-heavy or safety-relevant work uses a frontier one, and price the difference in Copilot AI credits. Use when choosing or changing a model for a custom agent, when delegating to a subagent, when a task is lookup, extraction, classification, renaming, formatting or boilerplate generation, when a task touches a critical path, when the user asks which model to use, or when a session or agent is expensive. Rates differ about 50x across tiers and output costs 5 to 6 times input on every model, so this is one of the largest single levers.
---

# Model routing

Copilot Business and Enterprise bill per token in AI credits at per-model rates. Three
asymmetries decide everything here:

- Tiers differ about 50x. A T0 model reads a million tokens for what a T3 model charges
  for twenty thousand.
- Output costs 5 to 6 times input on every model. 400 output tokens cost about as much as
  20,000 cached input tokens.
- Cached input costs a tenth of fresh input. A stable prefix is nearly free at any tier;
  tool output and generated code are not.

So the expensive thing is not "a big model reading a lot". It is "a big model writing a
lot", or any model re-reading uncached tool output. Route by expected output volume first
and by judgment second.

## Tiers

Defined in `.github/models.yaml`, assigned in `.github/agent-tiers.yaml`. Do not put model
names in agent files by hand; run:

```bash
python .github/skills/model-routing/scripts/assign_models.py --root .          # dry run
python .github/skills/model-routing/scripts/assign_models.py --root . --write
python .github/skills/model-routing/scripts/assign_models.py --root . --clear --write  # undo
```

That writes the `model:` line as a prioritized list, the tier's pick first and a Copilot
fallback second so the agent still loads if the BYOK model is unavailable, and adds an
agent-scoped ledger hook tagged with the tier so the audit can price recorded sessions.

T0 lightweight: locate, grep, list usages, extract fields, classify, rename, format,
generate boilerplate from a spec.
T1 economy: bounded single-file edits, test scaffolds, docstrings, summaries where an
abstract already exists.
T2 versatile: multi-file changes, debugging with a hypothesis, orchestration, synthesis
across findings.
T3 frontier: safety-relevant logic, root-cause conclusions, architecture, anything a
human will trust without re-deriving. Also anything under a path in
`critical_paths` in models.yaml, regardless of who picked it up.

## Design high, generate low, verify high

The pattern that captures most of the saving: a T2 or T3 agent writes the plan and the
interface, a T0 or T1 agent produces the volume (boilerplate, tests, docs, mechanical
edits), and a T2 or T3 agent reviews the diff. The expensive model reads a small plan and
a diff; the cheap model writes the many lines. Output volume lands on the cheap tier.

## The deferral rule, and the direction it can run

A cheap model that is unsure escalates; it does not guess. Every brief to a T0 or T1
agent carries: "if the answer is not clear from the sources in scope, return
`status: blocked` with what you found and `confidence: low`." Without this rule a
cascade pays twice on every hard case.

Escalation cannot happen as a subagent call. VS Code refuses to run a subagent on a model
whose cost tier exceeds the parent's; the call fails and reports which models are
available. So the ladder runs down, never up: a coordinator can delegate to any tier at or
below its own, and anything that needs a higher tier goes back to the user as a handoff
button that opens the higher-tier agent in a fresh session.

Two consequences. A coordinator runs at the highest tier of anything it will ever
delegate; if a workflow can touch a critical path, the coordinator is T3 and the workers
are cheap, which is exactly the "design high, generate low" shape. And escalation is
visible: the user clicks it, which is the right amount of friction for a decision that
moves work to the most expensive model in the kit.

Log each escalation to `.copilot-state/decisions.md` with the reason; recurring
escalations from the same task shape mean the tier table is wrong for that shape.

Subagents are also stateless: the parent cannot send a follow-up. Put everything the
worker needs in the brief, because there is no second message.

## Skills and tiers

Skills cannot pin a model. `.github/agent-tiers.yaml` lists a minimum tier per skill; the
orchestrator reads it when choosing which agent to delegate to. A skill that needs T2
delegated to a T0 agent will produce confident wrong output, which is the expensive
failure.

## Reasoning budget

Extended reasoning is billed as output, at the output rate. On a T3 model that is the
most expensive token there is. Match effort to task shape rather than leaving it at
maximum, and never enable it on a T0 or T1 agent doing volume work.

## Do not

Route by urgency or by who asked. Route a task small because it is short; a two-line
change to a concurrency primitive is T3. Trust a tier decision without checking the
ledger for retries from that tier; a cheap model that retries three times is not cheap.

`references/pricing.md` has the rate table the registry was seeded from, with its date.
