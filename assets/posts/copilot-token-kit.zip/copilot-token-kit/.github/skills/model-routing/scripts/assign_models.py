#!/usr/bin/env python3
"""
Apply model tiers to custom agents, editing frontmatter structurally.

Reads .github/models.yaml and .github/agent-tiers.yaml. For each listed agent:
  1. sets `model` to [default_pick, fallback_pick] for the tier (or a scalar if no fallback)
  2. ensures exactly one kit-owned PostToolUse hook that runs token_ledger.py with
     COPILOT_TIER=<tier>, merged into any existing hooks without touching them

Frontmatter is parsed with PyYAML and re-serialized. Existing keys, other hooks and
other lifecycle events are preserved. YAML comments inside the frontmatter are not
preserved by this pass; the body is untouched.

Dry run by default. --write applies. --clear removes only kit-owned entries: the model
line if it matches a registry pick, and hooks whose command runs token_ledger.py.

Requires PyYAML.
"""

from __future__ import annotations

import argparse
import difflib
import re
import sys
from pathlib import Path

try:
    import yaml  # type: ignore
except ImportError:
    print("PyYAML is required: pip install pyyaml")
    sys.exit(1)

FM_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.S)
LEDGER = "token_ledger.py"
LEDGER_CMD = "python .github/hooks/scripts/" + LEDGER


class _NoAliasDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


def dump(d: dict) -> str:
    return yaml.dump(d, Dumper=_NoAliasDumper, sort_keys=False, allow_unicode=True,
                     default_flow_style=False, width=1000).rstrip("\n")


def is_kit_hook(h) -> bool:
    return isinstance(h, dict) and LEDGER in str(h.get("command", ""))


def kit_hook(tier: str) -> dict:
    return {
        "type": "command",
        "command": f"COPILOT_TIER={tier} {LEDGER_CMD}",
        "windows": f"set COPILOT_TIER={tier}&& {LEDGER_CMD}",
        "timeout": 10,
    }


def apply(fm: dict, tier: str, model_value, add_hook: bool) -> dict:
    fm = dict(fm)
    if "model" in fm:
        fm["model"] = model_value
    else:
        items = list(fm.items())
        idx = next((i for i, (k, _) in enumerate(items) if k == "description"), None)
        pos = idx + 1 if idx is not None else len(items)
        items.insert(pos, ("model", model_value))
        fm = dict(items)
    if add_hook:
        hooks = fm.get("hooks")
        if not isinstance(hooks, dict):
            hooks = {}
        post = hooks.get("PostToolUse")
        if not isinstance(post, list):
            post = [] if post is None else [post]
        post = [h for h in post if not is_kit_hook(h)] + [kit_hook(tier)]
        hooks["PostToolUse"] = post
        fm["hooks"] = hooks
    return fm


def clear(fm: dict, all_picks: set) -> dict:
    fm = dict(fm)
    m = fm.get("model")
    picks = set(m) if isinstance(m, list) else ({m} if m else set())
    if picks and picks <= all_picks:
        fm.pop("model", None)
    hooks = fm.get("hooks")
    if isinstance(hooks, dict):
        for ev, lst in list(hooks.items()):
            if isinstance(lst, list):
                kept = [h for h in lst if not is_kit_hook(h)]
                if kept:
                    hooks[ev] = kept
                else:
                    hooks.pop(ev)
        if not hooks:
            fm.pop("hooks", None)
    return fm


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default=".")
    ap.add_argument("--write", action="store_true", help="modify agent files")
    ap.add_argument("--no-hook", action="store_true", help="skip the tier-tagged ledger hook")
    ap.add_argument("--clear", action="store_true", help="remove kit-owned model line and hooks")
    a = ap.parse_args()

    root = Path(a.root).resolve()
    gh = root / ".github"
    models = yaml.safe_load((gh / "models.yaml").read_text(encoding="utf-8")) or {}
    tiers_cfg = yaml.safe_load((gh / "agent-tiers.yaml").read_text(encoding="utf-8")) or {}
    picks = models.get("default_pick", {}) or {}
    fallbacks = models.get("fallback_pick", {}) or {}
    all_picks = set(picks.values()) | set(fallbacks.values())
    assignments = tiers_cfg.get("agents", {}) or {}
    if not assignments:
        print("no agents listed in .github/agent-tiers.yaml")
        return 1

    changed = 0
    for name, tier in assignments.items():
        tier = str(tier).strip()
        pick = picks.get(tier)
        path = gh / "agents" / f"{name}.agent.md"
        if not path.is_file():
            print(f"  ! {name}: {path.relative_to(root)} not found; skipped")
            continue
        if not a.clear and not pick:
            print(f"  ! {name}: tier {tier} has no default_pick in models.yaml; skipped")
            continue
        src = path.read_text(encoding="utf-8")
        m = FM_RE.match(src)
        if not m:
            print(f"  ! {name}: no frontmatter; skipped")
            continue
        try:
            fm = yaml.safe_load(m.group(1)) or {}
        except yaml.YAMLError as e:
            print(f"  ! {name}: frontmatter is not valid YAML ({e}); skipped")
            continue
        if not isinstance(fm, dict):
            print(f"  ! {name}: frontmatter is not a mapping; skipped")
            continue
        body = src[m.end():]

        if a.clear:
            new_fm = clear(fm, all_picks)
            label = "cleared"
        else:
            fb = fallbacks.get(tier)
            value = [pick, fb] if fb and fb != pick else pick
            new_fm = apply(fm, tier, value, not a.no_hook)
            label = f"{tier} -> {pick}" + (f" (fallback {fb})" if fb and fb != pick else "")

        new_src = f"---\n{dump(new_fm)}\n---\n{body}"
        chk = FM_RE.match(new_src)
        if not chk or not isinstance(yaml.safe_load(chk.group(1)), dict):
            print(f"  ! {name}: produced invalid frontmatter; not written")
            continue
        if new_src == src:
            print(f"  = {name}: already {label}")
            continue
        changed += 1
        print(f"  ~ {name}: {label}")
        for line in difflib.unified_diff(src.splitlines(), new_src.splitlines(), lineterm="", n=0):
            if line.startswith(("+", "-")) and not line.startswith(("+++", "---")):
                print("      " + line)
        if a.write:
            path.write_text(new_src, encoding="utf-8")

    print()
    if changed and not a.write:
        print(f"  {changed} file(s) would change. Re-run with --write to apply.")
    elif changed:
        print(f"  {changed} file(s) written. Verify each model string exists in your picker.")
    else:
        print("  nothing to do")
    return 0


if __name__ == "__main__":
    sys.exit(main())
