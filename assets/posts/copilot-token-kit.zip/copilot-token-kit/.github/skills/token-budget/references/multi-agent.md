# Multi-agent systems

The token profile changes shape. In a single agent the dominant term is history
accumulation, quadratic in turns. In a multi-agent system the dominant term is duplication,
multiplicative in agents times turns.

Published figures put orchestrator-worker research architectures at roughly 15x the tokens
of ordinary chat, with plain agentic use around 4x. The same work reports that token usage
alone explains most of the performance variance. Read those together: fan-out is a way to
spend more tokens than one window holds, and performance follows the spending. It is not a
way to get more from the same tokens.

## Decide the topology first

Fan-out earns its multiplier on breadth-first work with independent branches where total
information exceeds one window and the answer is worth real money.

It does not earn it on sequential pipelines or tightly interdependent work, where every
branch needs to see what the others decided. Many production multi-agent systems are
sequential pipelines wearing a costume; converting them back to one agent with staged
prompts is often a 5x to 10x saving with an accuracy improvement attached.

## The six sources, in order of size

Preamble duplication. Every agent carries its own copy of harness prompt, tool schemas and
skill instructions, and re-sends all of it every turn. Scales with agents times turns.
Usually 60 to 80 percent of a session.

Re-contextualization. The orchestrator serializes what it knows into a brief; the subagent
serializes what it found into a summary. Encode and decode, paid twice, lossy at both ends.
The natural response to a misunderstood brief is a longer brief, which makes it worse.

Orchestrator accumulation. The lead agent's window holds every brief it wrote and every
result it received, so it grows quadratically in delegations. Usually the least optimized
agent in the system, because it "is not doing much".

Redundant exploration. Two subagents fetch the same document because neither can see the
other's work. Parallel fan-out makes this structural.

Verification passes. Judges, critics, citation agents, self-consistency samples. Often the
second largest line item and almost never measured separately from the work verified.

Coordination failure. A subagent misreads its brief and a whole session is discarded. This
is the retry unit at multi-agent scale, and it is enormous compared to one failed call.

## Fixes

Tier the skills. Metadata at startup, bodies on activation. In a skill-heavy kit this is
usually the single largest block.

One shared cached preamble, role deltas after the breakpoint. A bespoke system prompt per
agent means a separate cache entry per agent, so the write premium amortizes over fewer
reads. There is a crossing point: shared wins when personas are many and their differences
small; bespoke wins when personas are few and genuinely different. If role blocks approach
the size of the base, the real problem is too many personas.

Pointer returns. The subagent writes findings to a file or store and returns a path plus a
short abstract. The orchestrator reads the full artifact only if it must. This collapses
handoff cost and orchestrator accumulation together.

Structured handoffs. A schema for briefs and results rather than prose. Shorter, and it
fails loudly instead of silently.

Shared store over message passing. Agents read and write a common store. Removes redundant
exploration and removes the need to re-broadcast. If the orchestrator is forwarding agent
A's findings to agent B, that is the store asking to be built.

Heterogeneous models by role. The orchestrator needs judgment; a bounded retrieve-and-extract
worker often does not.

Circuit breakers. A per-run token ceiling, a maximum delegation depth, a cap on concurrent
subagents, and a hard stop on recursive spawning. The multiplier compounds badly when
something misbehaves. This is a reliability control before it is an optimization.

## Metrics that only matter here

Tokens by role. Preamble as a fraction of total. Skill body tokens per call. Handoff tokens
per delegation. Orchestrator context growth. Document fetch overlap across workers.
Discarded subagent sessions. Verification tokens as a fraction of total.
