# Anti-patterns

Each of these has been shipped by a competent team, and each reports as a success on a
per-call dashboard.

Shortening a cached system prompt. It was already billing at a tenth of list price, so
trimming a thousand tokens saves a hundred tokens' worth of money, and the edit invalidates
the cache for every in-flight session. Trim the uncached suffix instead.

Raising k to cover a weak retriever. Buys recall with distractors and pushes the true
passage toward the middle of the context where recall is weakest. Fix the ranker.

Compressing something you could cache. Caching is a large discount with zero information
loss and no extra inference pass. Compression is lossy and costs a model call.

Compacting too early. Each compaction is a call that reads the whole window. Compacting at
30 percent occupancy can cost more than the transcript would have.

Optimizing tokens per call. Any change that increases retries or turn count improves this
number while making the system worse.

Volatile tokens in the prefix. A timestamp at the top of a system prompt means zero cache
hits forever, while the dashboard shows caching enabled.

Progressive tool loading with a small catalog. The published reduction figures come from
catalogs of dozens of servers. With eight tools the discovery overhead can exceed the
schemas avoided, and you have added a failure mode where the agent cannot find a tool.

Subagents as a cost measure. Total tokens go up substantially. Isolation is a capability
and headroom decision.

Batching across trust boundaries. Items in one prompt are not independent; one item's
content can steer the answers for its neighbours, and it mixes tenants' data in one context.

Installing a large token-optimization skill. A 6,000-token skill body about saving tokens,
loaded eagerly, is a bad trade. Check the body size of anything you install for this
purpose, including this one.
