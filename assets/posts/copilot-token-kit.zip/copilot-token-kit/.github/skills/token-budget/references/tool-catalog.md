# Keeping the tool catalog small

Every tool a client exposes is a schema in the system prompt on every call, whether or not
the task needs it. With several MCP servers connected this block is often the largest
always-on cost in the setup and the one nobody sees, because it is assembled by the client
rather than written by anyone.

## Measure it

The audit script estimates MCP cost as servers times six tools times 850 tokens. That is a
placeholder. Get the real number by inspecting the serialized request, or by comparing the
first-call token count with all servers enabled against the same call with them disabled.

## Restrict per agent

The `tools` field in a custom agent is an allowlist. An agent that lists five tools carries
five schemas; an agent with no `tools` field may carry the whole catalog. Every agent in the
kit should have an explicit list, and read-only agents should have short ones.

## Enable per workspace

MCP servers configured at user level are present in every workspace. Move servers that
serve one project into that project's `.vscode/mcp.json` so they do not tax the others.

## Prefer builtins

Before adding an MCP tool, check whether `search`, `usages`, `codebase` or a terminal
command already does the job. A builtin is one schema shared by everything; an MCP tool is a
schema plus a server plus a connection.

## Progressive loading

Where the client supports it, expose tool names and one-line descriptions and load full
schemas only for the tools a step needs. The published reductions from this pattern are
large at high tool counts and can be negative at low ones, because discovery has its own
overhead. Below roughly a dozen tools, restrict the list instead.

## Interaction with caching

Tool schemas are stable, so they cache well. The saving from removing a cached schema is
about a tenth of its raw size. Do not quote the raw size as the expected saving.
