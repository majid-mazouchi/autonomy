# Single-agent levers, in detail

## Prompt caching

Caching is prefix-based. The provider stores the tokenized prefix up to a marked
breakpoint; a later request beginning with a byte-identical prefix is served from that
store. A cache write costs about 25 percent more than a normal input token; a cache read
costs about 90 percent less. Break-even arrives on the second hit.

Order the prompt most stable to least stable: tools, system instructions, few-shot
examples, long reference documents, conversation, current turn.

The most common reason a caching rollout shows no saving is a volatile token in the
prefix. A timestamp, a request ID, or a per-user greeting at the top of the system prompt
invalidates the whole cache on every call.

Log cache read tokens and cache creation tokens per call. A spike in creation tokens means
the prompt template changed.

## Context growth and compaction

In a naive loop the context is the whole transcript, so cumulative billed input grows
quadratically in turns while useful information per turn stays flat.

Three counters, cheapest first.

Tool result clearing. Once a tool has been called deep in history, the raw result rarely
needs to stay visible. Replace it with a short stub, keep the call.

External notes. Push durable state to a file the agent re-reads, so the transcript does not
carry it.

Compaction. Summarize and reinitialize when approaching the window. Note the trade: each
compaction is itself a call that reads the whole window, so compacting early can cost more
than it saves. Tune the compaction prompt for recall first, then tighten for precision,
against real traces rather than synthetic ones.

## Retrieval

Stuffing a corpus into a long window is usually wrong even when it fits. Model performance
follows a U-shaped curve against the position of the relevant passage: strongest at the
start and end, weakest in the middle, and it degrades as context grows even for models
built for long inputs.

Prefer just-in-time retrieval: hold lightweight identifiers, paths, query strings, record
IDs, and pull content only at the moment it is needed.

Raising k to compensate for a weak ranker buys recall with distractors. Fix the ranker.

## Progressive tool loading

Most clients load every connected tool's full schema into the system prompt at session
start. With many connectors this can exceed 50,000 tokens before the agent reads the
request. Load names and one-line descriptions for all tools; load full schemas only for
the tools the current step needs.

This interacts with caching. Schemas are stable, so they cache well, and the on-demand
pattern trades a perfectly cacheable block for a smaller but more variable one. At low tool
counts the discovery overhead can exceed the schemas avoided. Measure both.

## Compression

Extractive compression scores tokens by perplexity under a small model and drops the ones
whose removal barely changes the sequence entropy. Reported ratios reach 2x to 5x on
compressible text with modest quality loss, higher on redundant prose.

Only worth it for content that is large, variable, and therefore uncacheable: retrieved
passages, freshly fetched pages, per-request transcripts. Never for a stable prompt.

## Serialization

JSON repeats every key on every record. CSV states them once. For a 200-row result with 8
fields that is 1,600 redundant key strings plus punctuation.

This applies only to homogeneous flat records. For nested or sparse data, JSON structure is
carrying real information and flattening costs more in confusion than it saves in tokens.

Other habits at the tool boundary: strip nulls, empty arrays and default-valued fields;
truncate and paginate large results, returning a count and a handle rather than 4,000 rows;
reference files by path rather than inlining contents that may not be needed.

## Output side

Output tokens are priced several times higher than input tokens.

An explicit output schema removes the preamble, the restatement of the question and the
closing summary, and it makes the response parseable, which lowers the retry rate.

Diffs over rewrites. Reproducing a 900-line file to change 12 lines costs the whole file in
output tokens and invites transcription errors.

Cap the reasoning budget per task class. Extended reasoning earns its cost on hard problems
and wastes it on classification, extraction and routing.

## Retries

Rework is the largest unmeasured line item in most pipelines. Malformed JSON, a diff whose
anchor does not match, a bad tool argument, a schema violation: each throws away a completed
call and pays for another.

If a fraction r of calls must be repeated, effective cost multiplies by roughly 1/(1-r), and
worse when the retry prompt carries the failed attempt and the error as added context, which
is the usual pattern. A 12 percent failure rate with that added context is comfortably a
20 percent cost increase, which erases most application-level optimizations.

Constrained decoding and stricter schemas are frequently worth more than every prompt edit
combined, and they make every other optimization more reliable rather than less.
