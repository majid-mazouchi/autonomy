---
name: token-budget
description: Diagnose and reduce token consumption in agent workflows, Copilot kits, and LLM pipelines. Use this whenever the user mentions token cost, context bloat, context window pressure, prompt caching, an agent that has become slow or expensive, "too many tokens", "context is full", compaction, or asks which optimization to apply first. Also use when designing a new agent, skill, or MCP integration, since the cheapest time to get this right is before it ships.
---

# Token budget

Pick the lever that matches the symptom. Do not apply everything.

## Diagnose first

Never optimize before measuring. The cost is almost always concentrated in one or two
places, and the intuitive target is usually the wrong one. If the workspace has a Copilot
kit under `.github/`, run the `kit-audit` skill before changing anything.

## The four families

Shrink the input. Prompt caching, retrieval instead of stuffing, compaction, progressive
tool loading, tabular formats over JSON.

Shrink the output. Schema and length constraints, diffs instead of rewrites, capped
reasoning budgets.

Change the architecture. Model cascades, batch prompting, subagent isolation, moving work
into scripts so intermediate data never enters context.

Measure. Per-stage accounting, cache hit rate, retry rate, tokens per solved task.

## Ranked by return on effort

1. Measure per stage. Zero saving, but it finds the real target.
2. Stabilize the cached prefix. Nothing volatile in front of the breakpoint.
3. Constrain output shape and length. Output tokens cost several times input tokens.
4. Truncate and paginate tool results at the tool boundary, not after.
5. Tabular formats for flat records.
6. Clear stale tool results from history.
7. Reduce retries. Stricter schemas beat any prompt shortening.
8. Load tool schemas and skill bodies on demand, not upfront.
9. Retrieve rather than stuff.
10. Compact when approaching the window, not for tidiness.

## Price the tier before the tokens

Copilot bills per token at per-model rates, and the tiers differ about 50x. Before trimming
tokens on an agent, check which tier it runs at (`.github/agent-tiers.yaml`) and whether the
work needs that tier. Moving a locate-and-extract agent from T3 to T0 saves more than every
prompt edit combined. See the `model-routing` skill; the rate table is in
`.github/skills/model-routing/references/pricing.md`.

## Rules that override the ranking

If content is stable across calls, cache it. Do not compress it. Caching is a large
discount with zero information loss; compression is lossy and costs an extra inference pass.
Compression is only for content that changes every request.

If a saving figure was measured against an uncached baseline, it will not survive caching.
Expect published reduction numbers to shrink by roughly an order of magnitude once the
block in question is already cached.

Optimize tokens per solved task, never tokens per call. A change that halves per-call
tokens and doubles retries is a regression that the dashboard will report as a win.

## Deeper material

`references/single-agent.md` for caching mechanics, compaction, retrieval, compression and
serialization detail.

`references/multi-agent.md` for orchestrator and subagent systems: duplication, handoff
cost, cache fragmentation across personas, coordination failure.

`references/tool-catalog.md` for MCP servers and tool schemas: measuring the real cost,
allowlisting per agent, and why removing a cached schema saves a tenth of its size.

`references/anti-patterns.md` for changes that look like optimizations and are not. Read
this before proposing a fix.
