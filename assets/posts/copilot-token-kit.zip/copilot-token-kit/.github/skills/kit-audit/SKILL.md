---
name: kit-audit
description: Measure where tokens actually go in this workspace's Copilot setup and rank the sinks. Use whenever the user asks why Copilot is slow or expensive, mentions context filling up, asks what is eating their tokens, wants to audit or clean up their .github customization kit, or is about to add a skill, agent, MCP server, or instructions file and wants to know what it will cost. Always run this before proposing any token optimization, because the intuitive target is usually the wrong one.
---

# Kit audit

Measure before changing anything. In almost every kit the cost is concentrated in one or
two places, and it is rarely where people look first.

## Run it

```bash
python .github/skills/kit-audit/scripts/audit_kit.py --root . --calls 42
```

Useful flags:

- `--agents 4 --turns 8` model a multi-agent session instead of a flat call count
- `--no-cache` show the uncached baseline, which is what most published figures assume
- `--triggered 2` how many skills you expect to activate per call under tiering
- `--json report.json` machine-readable output for tracking across runs

Install `tiktoken` first if it is not present. Without it the script falls back to a
character heuristic that is roughly 10 percent off on prose and worse on code.

## Read the output

The inventory shows what exists. The per-call breakdown shows what loads on every single
request, which is the number that gets multiplied by call count. The ranked sinks show
where a session's tokens go. The counterfactual section prices each fix.

Pay attention to the last line of the counterfactual block. It shows the same fix measured
with and without caching, and the gap is usually close to an order of magnitude. That is
the number to keep in mind whenever someone quotes a reduction figure.

## What the numbers are, and are not

The audit is a static inventory plus scenarios. It counts what is on disk and models what
would load; it does not observe requests. The ledger is a tool-payload diagnostic: it
sizes tool arguments and results, which become model input, and it does not see prompts,
generated output, reasoning, cache hits, or failed calls. Neither is a billing meter.

For billed usage, use VS Code's OpenTelemetry export, which reports the requested and
resolved model plus input, output and cache token counters per model call, or the
provider's usage page. Reconcile the audit against that, never the other way round.

## What to do with the findings

Take the top sink and check it against
`.github/skills/token-budget/references/anti-patterns.md` before proposing anything. Several of the obvious fixes are counterproductive.

General order: anything flagged always-on gets attention first, because it is multiplied by
every call. Skill bodies come next in a skill-heavy kit. MCP tool schemas are the least
visible large block and the estimate in this script is deliberately crude, so measure the
real payload rather than trusting it.

## Propose changes as diffs

Never edit files as part of an audit. Report findings, propose each change as a diff, apply
only on explicit approval, then re-run the audit and report what actually moved. Revert
anything that did not lower tokens per call. Do not make the setup less capable to make it
cheaper.
