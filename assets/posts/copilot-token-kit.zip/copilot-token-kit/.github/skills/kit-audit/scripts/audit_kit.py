#!/usr/bin/env python3
"""
Audit the token footprint of a GitHub Copilot customization kit.

Walks .github/{copilot-instructions.md,skills,agents,instructions,prompts} plus
AGENTS.md and .vscode/mcp.json, measures what is always-on versus on-demand, and
ranks the sinks by how many tokens they cost across a session.

Usage:
    python audit_kit.py [--root .] [--calls 42] [--agents 4] [--turns 8]
                        [--json out.json] [--no-cache]

Token counts use tiktoken when available and a character heuristic otherwise.
Every number is an estimate. It is for ranking sinks, not for forecasting a bill.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------- tokenizing

def _heuristic(text: str) -> int:
    """~3.6 chars/token for markdown and prose, denser for code and punctuation."""
    if not text:
        return 0
    punct = sum(text.count(c) for c in "{}[]()<>=;:,.\"'/\\|")
    return max(1, round(len(text) / 3.9 + punct * 0.12))


try:
    import tiktoken  # type: ignore

    _ENC = tiktoken.get_encoding("cl100k_base")

    def count_tokens(text: str) -> int:
        return len(_ENC.encode(text, disallowed_special=()))

    TOKENIZER = "cl100k_base count of static text (not provider billing)"
except ImportError:
    count_tokens = _heuristic
    TOKENIZER = "character heuristic - pip install tiktoken for a cl100k_base count"
except Exception as _e:  # installed but the BPE file could not be fetched
    count_tokens = _heuristic
    TOKENIZER = ("heuristic - tiktoken present but its encoding could not load "
                 f"({type(_e).__name__}); offline? set TIKTOKEN_CACHE_DIR to a "
                 "pre-downloaded cache")


# ---------------------------------------------------------------- data model

CACHE_WRITE = 1.25
CACHE_READ = 0.10


@dataclass
class Item:
    kind: str          # skill | agent | instruction | prompt | harness | mcp
    name: str
    path: str
    meta_tokens: int   # frontmatter / description, loaded at discovery
    body_tokens: int   # loaded on activation
    resource_tokens: int = 0   # bundled references, loaded on demand
    always_on: bool = False
    applies_to: Optional[str] = None
    notes: list[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return self.meta_tokens + self.body_tokens + self.resource_tokens


FM_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.S)


def split_frontmatter(text: str) -> tuple[str, str]:
    m = FM_RE.match(text)
    if not m:
        return "", text
    return m.group(1), text[m.end():]


def fm_get(fm: str, key: str) -> Optional[str]:
    m = re.search(rf"^{re.escape(key)}\s*:\s*(.+?)\s*$", fm, re.M)
    if not m:
        return None
    return m.group(1).strip().strip("'\"")


def read(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


# ---------------------------------------------------------------- collectors

def collect(root: Path) -> list[Item]:
    items: list[Item] = []
    gh = root / ".github"

    # Always-on repo instructions
    for cand in [gh / "copilot-instructions.md", root / "AGENTS.md", root / "CLAUDE.md"]:
        if cand.is_file():
            txt = read(cand)
            items.append(Item(
                kind="harness", name=cand.name, path=str(cand.relative_to(root)),
                meta_tokens=0, body_tokens=count_tokens(txt), always_on=True,
                notes=["always in context on every request"],
            ))

    # Skills: .github/skills/<name>/SKILL.md  (+ ~/.copilot/skills for personal)
    for base in [gh / "skills", Path.home() / ".copilot" / "skills"]:
        if not base.is_dir():
            continue
        for skill_md in sorted(base.glob("*/SKILL.md")):
            txt = read(skill_md)
            fm, body = split_frontmatter(txt)
            name = fm_get(fm, "name") or skill_md.parent.name
            desc = fm_get(fm, "description") or ""
            notes = []
            if not desc:
                notes.append("NO DESCRIPTION: this skill can never trigger by matching")
            elif len(desc) < 60:
                notes.append("description is very short; it may under-trigger")
            if not re.search(r"\b(when|whenever|any ?time|if the user)\b", desc, re.I):
                notes.append("description does not say WHEN to use the skill")
            if len(desc) > 1000:
                notes.append(f"description is {len(desc)} chars and is always in context")

            res = 0
            for sub in ("references", "assets"):
                d = skill_md.parent / sub
                if d.is_dir():
                    for f in d.rglob("*"):
                        if f.is_file() and f.suffix.lower() in {".md", ".txt", ".json", ".yaml", ".yml"}:
                            res += count_tokens(read(f))
            scripts = skill_md.parent / "scripts"
            if scripts.is_dir():
                notes.append("has scripts/ (free: source never enters context)")

            body_t = count_tokens(body)
            if body_t > 5000:
                notes.append(f"body is {body_t} tok; factor into references/")

            items.append(Item(
                kind="skill", name=name, path=str(skill_md),
                meta_tokens=count_tokens(fm), body_tokens=body_t,
                resource_tokens=res, notes=notes,
            ))

    # Custom agents: .github/agents/*.agent.md (and legacy .chatmode.md)
    for base in [gh / "agents", gh / "chatmodes"]:
        if not base.is_dir():
            continue
        for f in sorted(list(base.glob("*.agent.md")) + list(base.glob("*.chatmode.md"))):
            txt = read(f)
            fm, body = split_frontmatter(txt)
            notes = []
            if f.name.endswith(".chatmode.md"):
                notes.append("legacy .chatmode.md; rename to .agent.md")
            if not fm_get(fm, "tools"):
                notes.append("no tools list: agent may load the full tool catalog")
            items.append(Item(
                kind="agent", name=f.stem.replace(".agent", ""), path=str(f.relative_to(root)),
                meta_tokens=count_tokens(fm), body_tokens=count_tokens(body), notes=notes,
            ))

    # Scoped instructions: .github/instructions/**/*.instructions.md
    inst = gh / "instructions"
    if inst.is_dir():
        for f in sorted(inst.rglob("*.instructions.md")):
            txt = read(f)
            fm, body = split_frontmatter(txt)
            applies = fm_get(fm, "applyTo") or "(unset)"
            notes = []
            always = applies.strip("'\"") in {"**", "**/*", "*"}
            if always:
                notes.append("applyTo is universal: this is always-on, same as the harness")
            if applies == "(unset)":
                notes.append("no applyTo: attached manually or by the agent, not always-on")
                always = False
            items.append(Item(
                kind="instruction", name=f.stem.replace(".instructions", ""),
                path=str(f.relative_to(root)), meta_tokens=count_tokens(fm),
                body_tokens=count_tokens(body), always_on=always,
                applies_to=applies, notes=notes,
            ))

    # Prompt files: on-demand only
    pr = gh / "prompts"
    if pr.is_dir():
        for f in sorted(pr.rglob("*.prompt.md")):
            txt = read(f)
            fm, body = split_frontmatter(txt)
            items.append(Item(
                kind="prompt", name=f.stem.replace(".prompt", ""),
                path=str(f.relative_to(root)), meta_tokens=count_tokens(fm),
                body_tokens=count_tokens(body),
                notes=["invoked explicitly; costs nothing until used"],
            ))

    # settings.json can carry always-on instructions nobody sees in .github/
    for cand in [root / ".vscode" / "settings.json"]:
        if cand.is_file():
            raw = read(cand)
            raw = re.sub(r"(?<![:\"'\w])//[^\n]*", "", raw)       # line comments, not URLs
            raw = re.sub(r",(\s*[}\]])", r"\1", raw)             # trailing commas
            try:
                cfg = json.loads(raw)
            except json.JSONDecodeError as e:
                cfg = {}
                items.append(Item(kind="harness", name="settings.json (unparsed)",
                                  path=str(cand.relative_to(root)), meta_tokens=0, body_tokens=0,
                                  notes=[f"could not parse as JSONC ({e.msg} at {e.pos}); "
                                         "inline instructions, if any, were not counted"]))
            inline = 0
            for key, val in cfg.items():
                if "instructions" in key.lower() and isinstance(val, list):
                    for entry in val:
                        if isinstance(entry, dict) and "text" in entry:
                            inline += count_tokens(str(entry["text"]))
            if inline:
                items.append(Item(
                    kind="harness", name="settings.json inline instructions",
                    path=str(cand.relative_to(root)), meta_tokens=0,
                    body_tokens=inline, always_on=True,
                    notes=["always-on text in settings.json; easy to forget it exists"],
                ))
            if cfg.get("chat.useAgentSkills") is False:
                items.append(Item(kind="harness", name="chat.useAgentSkills is FALSE",
                                  path=str(cand.relative_to(root)), meta_tokens=0,
                                  body_tokens=0, notes=["skills are disabled in this workspace"]))

    # Hooks: free at context level, but list them so they are visible
    hk = gh / "hooks"
    if hk.is_dir():
        for f in sorted(hk.glob("*.json")):
            try:
                cfg = json.loads(read(f))
            except json.JSONDecodeError:
                continue
            events = list((cfg.get("hooks") or {}).keys())
            items.append(Item(
                kind="hook", name=f.stem, path=str(f.relative_to(root)),
                meta_tokens=0, body_tokens=0,
                notes=["events: " + ", ".join(events) if events else "no events",
                       "runs as a shell command; costs no context"],
            ))

    # MCP servers: schemas are the hidden always-on block
    for cand in [root / ".vscode" / "mcp.json", gh / "mcp.json"]:
        if cand.is_file():
            try:
                cfg = json.loads(read(cand))
            except json.JSONDecodeError:
                continue
            servers = cfg.get("servers") or cfg.get("mcpServers") or {}
            n = len(servers)
            if n:
                est = n * 6 * 850  # rough: ~6 tools/server, ~850 tok/schema
                items.append(Item(
                    kind="mcp", name=f"{n} MCP server(s)", path=str(cand.relative_to(root)),
                    meta_tokens=0, body_tokens=est, always_on=True,
                    notes=[
                        f"ESTIMATE ONLY: {n} servers x ~6 tools x ~850 tok/schema",
                        "measure the real payload; this is the least visible always-on cost",
                        "servers: " + ", ".join(sorted(servers)[:8]),
                    ],
                ))
    return items


# ---------------------------------------------------------------- analysis

def session_cost(items: list[Item], calls: int, cached: bool,
                 tiered: bool, triggered: int) -> dict:
    """Tokens consumed across a session of `calls` model calls."""
    always = sum(i.meta_tokens + i.body_tokens for i in items if i.always_on)
    skill_meta = sum(i.meta_tokens for i in items if i.kind == "skill")
    skill_bodies = [i.body_tokens for i in items if i.kind == "skill"]
    agent_bodies = [i.body_tokens + i.meta_tokens for i in items if i.kind == "agent"]

    if tiered:
        picked = sorted(skill_bodies, reverse=True)[:triggered]
        skills_per_call = skill_meta + sum(picked)
    else:
        skills_per_call = skill_meta + sum(skill_bodies)

    # One agent persona active at a time
    agent_per_call = max(agent_bodies) if agent_bodies else 0

    per_call = always + skills_per_call + agent_per_call
    mult = ((CACHE_WRITE + CACHE_READ * (calls - 1)) / calls) if cached and calls > 1 else 1.0
    return {
        "per_call_raw": per_call,
        "always_on": always,
        "skills_per_call": skills_per_call,
        "agent_per_call": agent_per_call,
        "cache_multiplier": round(mult, 4),
        "session_effective": round(per_call * calls * mult),
    }


def fmt(n: float) -> str:
    n = float(n)
    if n >= 1e6:
        return f"{n/1e6:.2f}M"
    if n >= 1e3:
        return f"{n/1e3:.1f}k"
    return f"{n:.0f}"


def bar(frac: float, width: int = 26) -> str:
    filled = int(round(frac * width))
    return "#" * filled + "." * (width - filled)


def load_registry(path: Path) -> dict | None:
    """Load models.yaml plus agent-tiers.yaml. Returns None if PyYAML is missing."""
    try:
        import yaml  # type: ignore
    except ImportError:
        return None
    if not path.is_file():
        return None
    reg = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    tiers_file = path.parent / "agent-tiers.yaml"
    reg["_agent_tiers"] = {}
    if tiers_file.is_file():
        reg["_agent_tiers"] = (yaml.safe_load(tiers_file.read_text(encoding="utf-8")) or {}).get("agents", {}) or {}
    # flat lookup: picker string -> (tier, rates)
    reg["_by_picker"] = {}
    reg["_no_credits"] = set()
    for tier, spec in (reg.get("tiers") or {}).items():
        if spec.get("credits") is False:
            reg["_no_credits"].add(tier)
        for m in spec.get("models") or []:
            reg["_by_picker"][m["picker"]] = (tier, m)
    return reg


def tier_rates(reg: dict, tier: str) -> dict | None:
    pick = (reg.get("default_pick") or {}).get(tier)
    hit = reg["_by_picker"].get(pick)
    return hit[1] if hit else None


def agent_model_line(path: Path) -> str | None:
    txt = read(path)
    m = FM_RE.match(txt)
    if not m:
        return None
    v = fm_get(m.group(1), "model")
    return v


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default=".", help="workspace root (default: .)")
    ap.add_argument("--calls", type=int, default=42,
                    help="model calls per session (default: 42)")
    ap.add_argument("--agents", type=int, default=1,
                    help="concurrent agents carrying the kit (default: 1)")
    ap.add_argument("--turns", type=int, default=0,
                    help="turns per agent; overrides --calls when set with --agents")
    ap.add_argument("--triggered", type=int, default=2,
                    help="skills expected to activate per call under tiering (default: 2)")
    ap.add_argument("--no-cache", action="store_true",
                    help="model the uncached case")
    ap.add_argument("--json", help="write machine-readable results here")
    ap.add_argument("--compare", help="a previous --json file; report what moved")
    ap.add_argument("--rates", default=".github/models.yaml",
                    help="model tier registry for cost estimates (default .github/models.yaml)")
    ap.add_argument("--out-per-call", type=int, default=400,
                    help="assumed output tokens per call for cost estimates (default 400)")
    ap.add_argument("--ledger", default=".copilot-state/ledger.jsonl",
                    help="PostToolUse ledger to summarize if present")
    a = ap.parse_args()

    root = Path(a.root).resolve()
    calls = a.calls if not a.turns else (a.agents * a.turns + 10)
    cached = not a.no_cache

    items = collect(root)
    if not items:
        print(f"No Copilot customization files found under {root}")
        print("Looked for: .github/copilot-instructions.md, .github/skills/*/SKILL.md,")
        print("            .github/agents/*.agent.md, .github/instructions/*.instructions.md,")
        print("            .github/prompts/*.prompt.md, .vscode/mcp.json, AGENTS.md")
        return 1

    eager = session_cost(items, calls, cached, tiered=False, triggered=a.triggered)
    tiered = session_cost(items, calls, cached, tiered=True, triggered=a.triggered)
    uncached = session_cost(items, calls, False, tiered=False, triggered=a.triggered)

    print()
    print("=" * 74)
    print(f"  COPILOT KIT TOKEN AUDIT   {root}")
    print("=" * 74)
    print(f"  tokenizer : {TOKENIZER}")
    print(f"  model     : {calls} calls/session, "
          f"{'prefix cached' if cached else 'NO CACHE'}, "
          f"{a.triggered} skill(s) triggered per call under tiering")
    print()

    # ---- inventory
    by_kind: dict[str, list[Item]] = {}
    for i in items:
        by_kind.setdefault(i.kind, []).append(i)

    print("-" * 74)
    print("  INVENTORY")
    print("-" * 74)
    for kind in ("harness", "mcp", "instruction", "skill", "agent", "prompt", "hook"):
        group = by_kind.get(kind, [])
        if not group:
            continue
        tot = sum(g.meta_tokens + g.body_tokens for g in group)
        res = sum(g.resource_tokens for g in group)
        extra = f"  (+{fmt(res)} in references, on demand)" if res else ""
        print(f"  {kind:<12} {len(group):>3} file(s)   {fmt(tot):>8} tok{extra}")
    print()

    # ---- per-call breakdown
    print("-" * 74)
    print("  WHAT LOADS ON EVERY CALL")
    print("-" * 74)
    rows = [
        ("always-on instructions + harness", eager["always_on"]),
        ("skill metadata + all bodies (eager)", eager["skills_per_call"]),
        ("active agent definition", eager["agent_per_call"]),
    ]
    tot_pc = max(eager["per_call_raw"], 1)
    for label, v in rows:
        print(f"  {label:<38} {fmt(v):>8}  {bar(v/tot_pc)} {v/tot_pc*100:4.1f}%")
    print(f"  {'TOTAL per call':<38} {fmt(tot_pc):>8}")
    print()

    # ---- ranked sinks
    print("-" * 74)
    print("  RANKED SINKS  (cost across the session, effective after caching)")
    print("-" * 74)
    sinks = []
    for i in items:
        if i.kind == "prompt":
            continue
        per_call = i.meta_tokens + i.body_tokens
        if i.kind == "agent":
            per_call = per_call / max(len(by_kind.get("agent", [1])), 1)
        eff = per_call * calls * (eager["cache_multiplier"] if cached else 1.0)
        sinks.append((eff, i))
    sinks.sort(key=lambda t: -t[0])
    grand = sum(s for s, _ in sinks) or 1
    for eff, i in sinks[:14]:
        tag = "ALWAYS-ON" if i.always_on else i.kind.upper()
        print(f"  {fmt(eff):>8}  {eff/grand*100:4.1f}%  [{tag:<11}] {i.name}")
        if i.kind == "skill" and i.body_tokens:
            print(f"            meta {i.meta_tokens} / body {i.body_tokens}"
                  + (f" / refs {i.resource_tokens}" if i.resource_tokens else ""))
        for n in i.notes[:2]:
            print(f"            - {n}")
    print()

    # ---- counterfactuals
    print("-" * 74)
    print("  SCENARIOS  (static estimates of what loads; not measured requests)")
    print("-" * 74)
    base = uncached["session_effective"]
    print(f"  no caching, every skill body       {fmt(base):>10} tok/session   hypothetical worst case")
    print("     (VS Code already loads skill bodies on demand; this row is a comparison point,")
    print("      not a saving the kit creates)")
    if cached:
        d = eager["session_effective"]
        print(f"  + stable cached prefix            {fmt(d):>10} tok/session   "
              f"-{(1-d/base)*100:.0f}%")
        d2 = tiered["session_effective"]
        print(f"  + tiered skill loading            {fmt(d2):>10} tok/session   "
              f"-{(1-d2/base)*100:.0f}% cumulative")
        marginal = eager["session_effective"] - tiered["session_effective"]
        print()
        print(f"  Marginal value of tiering, given caching: {fmt(marginal)} tok")
        um = (uncached["skills_per_call"] - tiered["skills_per_call"]) * calls
        print(f"  Same fix measured WITHOUT caching:        {fmt(um)} tok"
              f"   ({um/max(marginal,1):.1f}x larger)")
        print("  That gap is why published reduction figures do not survive caching.")
    print()

    # ---- warnings
    warn = [(i, n) for i in items for n in i.notes
            if n.startswith(("NO DESCRIPTION", "no applyTo", "applyTo is universal",
                             "description does not", "body is", "legacy", "no tools"))]
    if warn:
        print("-" * 74)
        print("  FINDINGS")
        print("-" * 74)
        for i, n in warn[:20]:
            print(f"  [{i.kind}] {i.name}: {n}")
        print()

    # ---- cost by tier, if a registry is present
    reg_path = Path(a.rates)
    if not reg_path.is_absolute():
        reg_path = root / reg_path
    reg = load_registry(reg_path)
    if reg is None and reg_path.is_file():
        print("  (install PyYAML to get cost estimates from .github/models.yaml)\n")
    if reg:
        print("-" * 74)
        print(f"  COST PER CALL BY AGENT   scenario, not a measurement. rates as of {reg.get('as_of','?')}, "
              f"{a.out_per_call} output tok/call assumed, prefix {'cached' if cached else 'NOT cached'}")
        print("-" * 74)
        base_in = eager["always_on"] + tiered["skills_per_call"]
        t3 = tier_rates(reg, "T3")
        rows_c = []
        for i in [x for x in items if x.kind == "agent"]:
            tier = str(reg["_agent_tiers"].get(i.name, "")).strip()
            model = agent_model_line(root / i.path) or ""
            if not tier and model in reg["_by_picker"]:
                tier = reg["_by_picker"][model][0]
            r = tier_rates(reg, tier) if tier else None
            if model in reg["_by_picker"]:
                r = reg["_by_picker"][model][1]
            if not r:
                rows_c.append((i.name, tier or "?", model or "(unpinned)", None, None))
                continue
            inp = base_in + i.meta_tokens + i.body_tokens
            in_key = "input" if not cached else "cached_input"
            cost = (inp * r[in_key] + a.out_per_call * r["output"]) / 1e6
            cost3 = ((inp * t3[in_key] + a.out_per_call * t3["output"]) / 1e6) if t3 else None
            rows_c.append((i.name, tier or "?", model, cost, cost3))
        for name, tier, model, cost, cost3 in rows_c:
            if cost is None:
                print(f"  {name:<20} {tier:<3} {model:<28}  no rates; pin a model or add a tier")
                continue
            if tier in reg["_no_credits"]:
                print(f"  {name:<20} {tier:<3} {model:<28}   0.00 credits/call   "
                      f"(provider-billed ~${cost:.4f}; T3 would be {cost3*100:.2f} credits)")
                continue
            vs = f"   T3 would be {cost3*100:6.2f}  ({cost3/cost:4.1f}x)" if cost3 and tier != "T3" else ""
            print(f"  {name:<20} {tier:<3} {model:<28} {cost*100:6.2f} credits/call{vs}")
        print()
        print("  Output dominates at every tier: at these rates 400 output tokens cost as much")
        print("  as roughly 20k cached input tokens. Route by expected output volume.")
        print()

    # ---- recorded sessions, if the PostToolUse hook has been running
    lp = Path(a.ledger)
    if not lp.is_absolute():
        lp = root / lp
    if lp.is_file():
        recs = []
        for line in read(lp).splitlines():
            try:
                recs.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        # de-duplicate: the global hook and an agent-scoped hook can both log one call;
        # keep the tier-tagged copy
        def _tier(r): return r.get("tier_configured") or r.get("tier")
        def _res(r): return int(r.get("result_tok", r.get("out_tok", 0)) or 0)
        seen: dict[tuple, dict] = {}
        for r in recs:
            if r.get("call_id"):
                k = ("id", r.get("session"), r.get("call_id"))
            else:  # legacy records without an id: fall back to coarse identity
                k = ("t", round(float(r.get("t") or 0)), r.get("session"), r.get("tool"),
                     r.get("args_tok", r.get("in_tok")), _res(r))
            if k not in seen or (_tier(r) and not _tier(seen[k])):
                seen[k] = r
        recs = list(seen.values())
        no_id = sum(1 for r in recs if not r.get("call_id"))
        if recs:
            print("-" * 74)
            print(f"  RECORDED TOOL RESULTS  ({len(recs)} calls in {lp.name}; tool-payload diagnostic, not billing)")
            print("-" * 74)
            if no_id:
                print(f"  {no_id} record(s) lack a call id; de-duplication for those is approximate")
            by_tool: dict[str, list[int]] = {}
            for r in recs:
                by_tool.setdefault(str(r.get("tool")), []).append(_res(r))
            tot = sum(sum(v) for v in by_tool.values()) or 1
            for tool, outs in sorted(by_tool.items(), key=lambda kv: -sum(kv[1]))[:10]:
                s_ = sum(outs)
                big = sum(1 for o in outs if o > 2000)
                flag = f"   {big} call(s) over 2k tok" if big else ""
                print(f"  {fmt(s_):>8}  {s_/tot*100:4.1f}%  {tool:<28} "
                      f"n={len(outs):<4} max={fmt(max(outs))}{flag}")
            off = sum(int(r.get("offloaded_in_tok", 0)) for r in recs if _tier(r) == "DBX")
            if off:
                print(f"  offloaded to Databricks and never entered Copilot context: {fmt(off)} tok")
            sessions = {r.get("session") for r in recs if r.get("session")}
            print(f"  total recorded tool result text: {fmt(tot)} tok across "
                  f"{len(sessions) or 1} session(s)")
            print("  Result text becomes model input on the next turn and stays in history until")
            print("  cleared or compacted; later turns may read it at the cached rate.")
            print("  Anything over 2k is a candidate for truncation at the tool boundary.")
            by_tier: dict[str, int] = {}
            for r in recs:
                key = str(_tier(r) or "untagged")
                by_tier[key] = by_tier.get(key, 0) + _res(r)
            if reg and any(k != "untagged" for k in by_tier):
                print()
                print("  by CONFIGURED tier (env tag, not the resolved model), priced once as fresh input:")
                for tier, toks in sorted(by_tier.items()):
                    r = tier_rates(reg, tier) if tier != "untagged" else None
                    if r:
                        print(f"    {tier:<9} {fmt(toks):>8} tok   {toks*r['input']/1e6*100:7.2f} credits"
                              f"   at T3: {toks*tier_rates(reg,'T3')['input']/1e6*100:7.2f}")
                    else:
                        print(f"    {tier:<9} {fmt(toks):>8} tok   (no tier tag; run assign_models.py)")
            print()

    # ---- comparison against a previous run
    if a.compare and Path(a.compare).is_file():
        try:
            prev = json.loads(read(Path(a.compare)))
        except json.JSONDecodeError:
            prev = None
        if prev:
            print("-" * 74)
            print(f"  CHANGE SINCE {Path(a.compare).name}")
            print("-" * 74)
            ps = prev.get("scenarios", {})
            for key, label in (("cached_eager", "cached, eager skills"),
                               ("cached_tiered", "cached, tiered skills"),
                               ("uncached_eager", "uncached baseline")):
                before = (ps.get(key) or {}).get("session_effective")
                now = {"cached_eager": eager, "cached_tiered": tiered,
                       "uncached_eager": uncached}[key]["session_effective"]
                if before:
                    d = now - before
                    sign = "+" if d > 0 else ""
                    print(f"  {label:<26} {fmt(before):>9} -> {fmt(now):<9} "
                          f"{sign}{fmt(d)} ({d/before*100:+.1f}%)")
            prev_items = {(i["kind"], i["name"]): i for i in prev.get("items", [])}
            moved = []
            for i in items:
                pi = prev_items.get((i.kind, i.name))
                if pi:
                    d = (i.meta_tokens + i.body_tokens) - (pi["meta_tokens"] + pi["body_tokens"])
                    if abs(d) >= 20:
                        moved.append((d, i))
                else:
                    moved.append((i.meta_tokens + i.body_tokens, i))
            for d, i in sorted(moved, key=lambda t: -abs(t[0]))[:10]:
                print(f"    {'+' if d>0 else ''}{fmt(d):>7}  [{i.kind}] {i.name}")
            gone = set(prev_items) - {(i.kind, i.name) for i in items}
            for k in sorted(gone)[:5]:
                print(f"    removed  [{k[0]}] {k[1]}")
            print()

    print("-" * 74)
    print("  All figures are estimates. Ranking is the point; the absolute numbers")
    print("  are not a bill. Re-run after each change and keep what actually moved.")
    print("-" * 74)
    print()

    if a.json:
        out = {
            "root": str(root), "tokenizer": TOKENIZER, "calls": calls,
            "cached": cached,
            "scenarios": {"uncached_eager": uncached, "cached_eager": eager,
                          "cached_tiered": tiered},
            "items": [asdict(i) for i in items],
            "ledger_result_tok_by_tool": (dict((k, sum(v)) for k, v in by_tool.items())
                                          if 'by_tool' in dir() else None),
        }
        Path(a.json).write_text(json.dumps(out, indent=2), encoding="utf-8")
        print(f"  wrote {a.json}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
