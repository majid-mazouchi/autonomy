---
name: lean-output
description: Cut output tokens and rework in code and analysis responses. Use when editing existing files, when a response would otherwise restate large amounts of code, when the user says to be concise or asks for less commentary, when a task is routine enough that reasoning is not needed, or when malformed or unparseable responses are causing retries. Output tokens are priced several times higher than input tokens, so apply this by default on editing work.
---

# Lean output

Output tokens cost several times what input tokens cost, and a failed response costs the
whole call again. Both problems have the same shape: emit less, and emit it in a form that
cannot fail to parse.

## Editing files

Emit a patch, never a rewrite. Reproduce only the changed lines plus the minimum anchor
context needed for the match to be unambiguous.

If more than roughly 40 percent of a file is changing, say so and rewrite deliberately
rather than emitting a patch that will not apply cleanly.

Before emitting a replacement, confirm the anchor text is unique in the file. A failed match
costs a full retry, which is more expensive than the reading needed to avoid it.

## Structure of a response

State what changed and where, as `path:line`. Then the diff. Then stop.

Skip: restating the request, narrating the plan when the plan is one step, summarizing a
diff the user can read, listing alternatives that were not asked for, and closing offers of
further help.

Keep: anything that surprised you, anything you assumed, and any place where the change is
incomplete or risky. Those are the only parts of the prose that carry information.

## Format

Prefer plain prose over nested bullets for explanation. Prefer a table only when there are
at least three rows and shared columns.

When returning records, use a delimited or tabular format for flat homogeneous data, and
JSON only when the nesting carries meaning.

When the user asked for a specific format, return only that. No prose wrapper around a JSON
object.

## Reasoning budget

Match effort to the task. Routine edits, renames, formatting, straightforward lookups and
mechanical refactors do not need extended reasoning; hard debugging, design decisions and
unfamiliar code do.

If reasoning is running long on something routine, stop and answer.
