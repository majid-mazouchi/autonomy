---
name: session-state
description: Keep plans, findings and decisions in files under .copilot-state/ instead of in the chat transcript, so they survive compaction and stop being re-sent on every turn. Use at the start of any task that will take more than a few turns, whenever a plan is being made or revised, when findings need to be handed to another agent, when a session has been compacted or restarted, or when the user asks where things stand. Transcript content is billed on every subsequent call; a file is billed only when read.
---

# Session state

The transcript is re-sent on every call. A file is read once, when it is needed. Anything
that will be referred to more than twice belongs in a file.

## Layout

```
.copilot-state/
  ledger.jsonl               written by the PostToolUse hook, do not edit
  <task-slug>/               one folder per task, e.g. thermal-coeff-audit/
    plan.md                  objective, steps with status, current step, next action
    decisions.md             one line per decision: what, why, date
    findings/                one file per investigation, named by topic
    briefs/                  briefs handed to workers, for the record
```

The slug is chosen once at the start of the task and stays fixed. Two concurrent tasks in
one workspace never share a plan file; a worker that receives a brief also receives the
slug so its findings land in the right folder. Remote workers cannot read a local path:
hand them content by artifact URI or by attaching it, plus the repository commit.

Add `.copilot-state/` to `.gitignore` unless the team wants plans versioned.

Saving something to a file does not remove it from context if it has already been read
this session; what it prevents is re-reading, and re-sending after a reset.

## plan.md

Write it before the first action on any multi-step task. Keep it under 40 lines. Update
the status column as steps complete; do not append a log, rewrite the line.

```
# <objective in one sentence>

| # | step | status | artifact |
|---|------|--------|----------|
| 1 | locate thermal model entry points | done | findings/thermal-entry.md |
| 2 | list fitted vs derived coefficients | active | |
| 3 | propose validation test | todo | |

Next: grep for `fit_` in model/thermal.py
```

Reference it by path afterwards. Never paste it back into chat to show progress; say
"plan.md step 2 active" instead.

## findings/

One file per investigation. Abstract first, under 200 tokens, then the detail. When
handing off to another agent, pass the path and let them read the abstract.

## After compaction or restart

Read `plan.md` first. Read `decisions.md` only if the next step touches a decided question.
Read a findings file only when the plan points at it. Do not re-read everything to
"get context back"; that is the cost compaction was meant to avoid.

## What does not go here

Anything derivable from the repository. Do not copy code into findings; cite `path:line`.
Do not summarize files that exist; point at them.
