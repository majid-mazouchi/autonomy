# Registering a Databricks endpoint as a Copilot model

Databricks Model Serving speaks the OpenAI chat-completions protocol at

    https://<workspace-host>/serving-endpoints/chat/completions

with the endpoint name as the `model` field and a personal access token or service
principal token as the bearer. VS Code's Custom Endpoint provider accepts exactly that.

## Steps

1. Confirm the organization policy. For Copilot Business and Enterprise an administrator
   must leave "Bring Your Own Language Model Key in VS Code" enabled in the Copilot policy
   settings. It is on by default since April 2026.
2. In VS Code: Chat: Manage Language Models, Add Models, Custom Endpoint. Group name
   "Databricks", API type Chat Completions. Enter the token when prompted; it goes to the
   OS keychain, never to a file.
3. VS Code opens `chatLanguageModels.json`. Use the template in
   `.vscode/chatLanguageModels.databricks.example.json`. Set `id` to your endpoint names.
   Set `toolCalling: true` only for endpoints whose model supports function calling; an
   agent cannot use a model without it, and it will not show in the picker.
4. Set `chat.utilitySmallModel` to the cheapest of them so title generation and commit
   messages stop using Copilot credits too.
5. Add the endpoint names to `.github/models.yaml` under tiers D0 and D1 with
   `credits: false`, and assign agents in `.github/agent-tiers.yaml`. Run
   `assign_models.py --write`.

## Which endpoints

Databricks Foundation Model APIs offer pay-per-token endpoints for open and partner
models; provisioned-throughput endpoints host anything you deploy, including fine-tuned
models on your own data. For the kit's purposes:

- D0: a small fast instruct model, for scout and volume generation
- D1: a mid-size model with tool calling, for bounded edits and test scaffolds
- Domain: any fine-tuned or RAG-backed endpoint you run, reached through `dbx_ask`

Rates are in the Databricks pricing page for your cloud and region, in DBUs per million
tokens. Fill them into `models.yaml` so the audit can price them.

## Use the URL from a working request

Databricks has more than one OpenAI-compatible surface. Classic Model Serving endpoints,
Foundation Model API pay-per-token endpoints, and the newer AI Gateway routes use different
paths and identifiers. Do not type the URL from memory or from this file. Open the
endpoint in the Databricks UI, copy the working `curl` or OpenAI-client example it shows,
and use that URL and that `model` string in `chatLanguageModels.json` and in the MCP
server's `DBX_DEFAULT_MODEL`. The `/serving-endpoints/chat/completions` form in the
template is the common case, not the only one.

## Known rough edges

Some OpenAI-compatible endpoints reject the exact request shapes VS Code sends, most often
around tool-call formatting or unsupported parameters. If a model appears in the picker but
fails in agent mode, try `editTools: ["find-replace"]` on the model entry, drop
`modelOptions`, or route through a small local proxy that normalizes the request.
