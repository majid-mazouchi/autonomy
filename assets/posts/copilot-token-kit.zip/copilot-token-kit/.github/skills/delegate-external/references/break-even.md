# Delegation break-even

Delegating a task through a tool call costs Copilot tokens three ways, every time:

- the tool's schema, present in every call of the session (roughly 150 to 300 tokens per
  tool, cached, so about a tenth of that in practice)
- the call arguments (a path and a question, roughly 40 to 80 tokens)
- the result (whatever the tool returns, capped by the server at about 300 tokens)

Call it 500 tokens of fresh Copilot input per delegation, plus the external cost.

The delegation avoids: the input Copilot would have read, re-sent on every later turn.

    saving per turn remaining  =  avoided_input * copilot_input_rate
    cost of delegating         =  500 * copilot_input_rate  +  external_cost
    break-even                 =  avoided_input  >  500  +  external_cost / copilot_input_rate

At a T2 Copilot rate of $2 per million and a Databricks endpoint at $0.50 per million for
a 12,000 token log:

    external_cost  =  12,000 * 0.50 / 1e6  =  $0.006
    cost of delegating in Copilot tokens  =  500 + 0.006 / (2/1e6)  =  500 + 3,000  =  3,500 tokens
    avoided  =  12,000 tokens per turn, for every turn the log would have stayed in context

Delegation wins by the second turn and wins by a growing margin after. For a 400 line
file (about 4,400 tokens) read once and never again, it is roughly a wash and the direct
read is simpler.

Two things this leaves out. Delegation adds latency, one extra round trip. And the
external model may be weaker than the Copilot model at the same task, so for judgment
work the comparison is not only cost.

Rule: delegate reading when the input is over roughly 5,000 tokens or will be referenced
across turns; delegate generation when the output is over roughly 200 lines; delegate
batch classification or extraction whenever there are more than a handful of items.
