---
name: delegate-external
description: Push a subtask to a model or agent outside Copilot so it costs no Copilot credits and its bulky input never enters the Copilot context. Use when a task means reading a large file, log or dataset just to answer a small question, when generating a lot of boilerplate from a spec, when classifying or extracting across many items, when the answer needs data that lives in Databricks or another system, or when a specialist agent already exists for the job. The rule of thumb: delegate when the result will be far smaller than the input the work requires.
---

# Delegate to external models and agents

Three routes, cheapest first. All three keep the heavy tokens off the Copilot bill; the
second and third also keep them out of the Copilot context window entirely.

## Route 1: run a whole agent on a BYOK model

If a Databricks or other endpoint is registered in VS Code as a bring-your-own-key model,
any custom agent can be pinned to it with its `model:` line. Tokens are billed by that
provider, not in Copilot credits. This is how `scout` and any other volume-work agent
should run. No code; configure once in `chatLanguageModels.json` and set the tier in
`.github/agent-tiers.yaml`. See `references/byok-setup.md`.

Best for: agents whose whole job is cheap and repetitive. The Copilot context still holds
whatever that agent reads, so this saves credits but not window.

## Route 2: call an external model as a tool

The `databricks-delegate` MCP server exposes tools that take a path and a question, do the
reading on Databricks, and return only a short answer. The 3,000-line log is read there;
Copilot sees 150 tokens.

- `dbx_summarize_file` a path and a question in, an abstract out
- `dbx_extract` a glob and a field list in, a compact CSV out
- `dbx_batch_classify` an items file and labels in, one label per line out
- `dbx_generate_to_file` a spec in, generated code written to disk, only the path back
- `dbx_ask` a question to a specific endpoint, for domain or fine-tuned models

Best for: anything where the input is large and the needed answer is small. This is the
only route that shrinks the Copilot context as well as the bill.

## Route 3: hand a brief to another agent

For a specialist agent that exposes MCP tools, write the brief to
`.copilot-state/briefs/<name>.yaml` in the `handoff-contract` shape, call the agent's tool
with the path, and expect back a path plus an abstract. Never pass the payload in either
direction.

Best for: work a purpose-built agent already does well, physics verification, evidence
analysis, equation generation. Copilot orchestrates; the specialist executes.

## When not to delegate

The tool call itself costs Copilot tokens: the tool schema in every call, the call
arguments, and the result. Delegation pays off when the input it avoids is larger than
that overhead by a wide margin. A 400-line file read once does not need delegating; a
40,000-line log does. `references/break-even.md` has the arithmetic.

Do not delegate anything on a critical path. Route 1 and 3 are fine for T3 work only if
the external model is itself frontier class and the data is allowed to leave.

## Data leaves the editor

Every route sends repository content to another system. Databricks inside the company
perimeter is usually acceptable where a public API is not; check before the first call,
and keep the path allowlist in the MCP server config honest.
