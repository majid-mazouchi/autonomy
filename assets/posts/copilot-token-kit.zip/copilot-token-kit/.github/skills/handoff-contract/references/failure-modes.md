# Delegation failure modes

Empirical work on multi-agent LLM systems has catalogued 14 failure modes across 1,600-plus
annotated traces from seven frameworks, clustered into system design issues, inter-agent
misalignment, and task verification failures. Observed failure rates across those frameworks
ranged from roughly 41 percent to nearly 87 percent. The authors are explicit that better
base models will not close the gap, because these are architectural failures.

The ones that cost the most tokens, and what to do:

## Disobeys the task specification

The brief said one thing, the agent did another. Usually the brief mixed the objective with
context and the objective got buried. Put the objective in the first line, alone.

## Step repetition

The agent redoes work it already did, often because the result of the earlier step was not
recorded anywhere it could see. Write intermediate results to disk and reference them.

## Unaware of termination conditions

The agent does not recognize that the task is complete and keeps going. Every extra turn is
a full-price call. State the stopping condition explicitly in `success` and give a turn
budget. This is one of the most prevalent single failure modes and one of the cheapest to
fix.

## State desynchronization

Two agents hold different interpretations of the same target. Happens whenever the same
concept is described twice in prose rather than referenced once by identifier. Use ids.

## Inadequate output checking

A downstream stage accepts an upstream result without verifying it was substantive, then
builds confident conclusions on nothing. The `success` field exists to be checked; check it.

## Loss of conversation history

Context was compacted or a session restarted and the plan went with it. Keep the plan in a
file, not in the transcript.

## Detection is the lever

A caught failure costs the discarded session plus its replacement. An undetected one costs
nothing extra and corrupts the output. Raising detection converts silent corruption into
visible expense, which is a trade worth making deliberately: the cost dashboard will look
worse and the system will be better.
