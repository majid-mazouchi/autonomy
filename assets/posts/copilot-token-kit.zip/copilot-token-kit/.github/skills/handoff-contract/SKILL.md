---
name: handoff-contract
description: Structure delegation between agents so briefs and results are short, checkable, and hard to misread. Use when spawning a subagent or background task, when writing a brief for another agent, when returning findings to an orchestrator, or when a delegation came back with the wrong artifact. A misread brief discards an entire subagent session, which is the largest single unit of waste in a multi-agent system, so use this whenever work crosses an agent boundary.
---

# Handoff contract

When work crosses an agent boundary the context does not move, only a serialization of it
does. Pay for that encode once, in a fixed shape, and never by pasting payloads.

## Brief going down

```yaml
task:        the task slug; findings go under .copilot-state/<task>/
objective:   one sentence, an outcome not a topic
scope:       paths, files, systems, or time range in bounds
out_of_scope: what not to touch or explore
inputs:      pointers only - path:line, file paths, query strings, record ids
deliver:     the exact artifact expected, and where to write it
success:     how the orchestrator will check the result
budget:      max tool calls or max turns before reporting back
tier:        T0 | T1 | T2 | T3, per the model-routing skill; T3 if scope touches a critical path
```

Every field short. If `inputs` contains file contents rather than paths, the contract is
being violated: write the content to a file and pass the path.

Vague objectives are the main cause of wasted sessions. "Research the thermal model" is not
an objective. "Identify which of the three heat-transfer coefficients in `model/thermal.py`
are fitted rather than derived, and list them with `path:line`" is.

## Result coming up

```yaml
status:      complete | partial | blocked
confidence:  high | medium | low   (low from a T0 or T1 agent means: escalate, do not use)
tier_used:   the tier this ran at, so the ledger and the decision log agree
artifact:    path to the full findings on disk (or an artifact URI for a remote worker)
abstract:    under 200 tokens, what the artifact contains and what it concludes
key_refs:    up to 5 path:line pointers that matter most
assumptions: anything inferred rather than verified
gaps:        what was in scope but not covered, and why
```

Return the abstract, not the payload. The orchestrator reads the artifact only if the
abstract does not settle the question. This is what keeps the orchestrator's context from
growing quadratically in delegations.

## Rules

Never re-broadcast. If the orchestrator finds itself forwarding one subagent's findings into
another subagent's brief, write them to a shared file and pass the path instead.

Two agents needing the same background should both read it, not both receive it.

State a budget in every brief. A subagent with no stopping condition will keep exploring.

Blocked is a valid result and should be returned immediately. So is `confidence: low`: a
cheap tier that is unsure should say so and stop. Escalation then runs through a handoff
to a higher-tier agent, not a subagent call, because VS Code will not run a subagent above
the parent's cost tier.

A subagent invocation is stateless. The parent cannot follow up, and the worker cannot ask
a clarifying question. Everything the worker needs must be in the brief; if it is not,
the worker returns `blocked` with the missing item named, and the orchestrator re-briefs. A subagent that cannot proceed
and keeps trying is the most expensive failure mode there is.

Check the result against `success` before using it. An undetected wrong artifact costs
nothing in tokens and corrupts the answer, which is worse than paying for the retry.

See `references/failure-modes.md` for what actually goes wrong and how to detect it.
