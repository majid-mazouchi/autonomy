---
name: skill-hygiene
description: Write and maintain Agent Skills so they trigger reliably and cost little. Use whenever creating a new skill, editing an existing SKILL.md, reviewing a skill someone else wrote, deciding whether something should be a skill or an instruction file, or when a skill fires too often, never fires, or has grown large. In a kit with many skills the bodies are usually the largest single token block, so treat every skill body as a recurring cost.
---

# Skill hygiene

A skill has two costs. The description is always in context, once per skill, forever. The
body is paid every time the skill fires. Design for both separately.

## Loading tiers

Discovery: the YAML frontmatter name and description, loaded at startup for every installed
skill. Typically under 100 tokens each, so dozens of skills cost less than one activated
body.

Activation: the SKILL.md body, loaded when the description matches. This is the number that
gets multiplied by how often the skill fires.

Execution: files under `references/` and `assets/` are read only when the body points to
them and the task needs them. Files under `scripts/` execute without their source entering
context at all, so only their output costs anything.

## Writing the description

This is the only thing the router matches against, so it does the load-bearing work. Say
both what the skill does and when to use it, in that order, and name the phrases a user
would actually type.

Under-triggering is the more common failure. Be slightly pushy: list the contexts and the
adjacent phrasings, not just the obvious one.

Over-triggering costs on every call it fires wrongly. If two skills would both match the
same request, either merge them or sharpen both descriptions until they separate.

## Sizing the body

Keep it to the instructions needed to do the task. If the body is teaching background, that
background belongs in `references/` behind a one-line pointer.

Anything deterministic and repetitive belongs in `scripts/`. A script is free at context
level, which makes it strictly better than prose describing the same procedure.

Do not put "when to use this" in the body. It arrives too late to matter and it is paid on
every activation.

## Lint it

```bash
python .github/skills/skill-hygiene/scripts/skill_lint.py --root .
```

Reports body sizes, description problems, missing deferral, and pairs of skills whose
descriptions overlap enough that both will fire. Install `tiktoken` for exact counts.

## Skill, instruction, agent, or prompt

Skill: a capability with a procedure, triggered by matching intent. Costs its description
always and its body when it fires.

Instructions file: a rule that applies to a file pattern. Use `applyTo` with a real glob. An
instructions file with a universal glob or no glob at all is always-on and should be treated
as part of the harness, held to the same size discipline.

Custom agent: a persona with a restricted tool set, selected explicitly. Put the shared
material in the harness and keep the agent file to the role delta, otherwise every agent
becomes a separate cache entry.

Prompt file: an explicitly invoked workflow. Costs nothing until used, so this is the
cheapest place to put anything the user will trigger by name.
