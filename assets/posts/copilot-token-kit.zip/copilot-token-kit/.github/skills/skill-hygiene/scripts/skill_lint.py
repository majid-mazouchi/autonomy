#!/usr/bin/env python3
"""
Lint Agent Skills for triggering quality, body size, and description overlap.

A skill's description is the only thing the router matches against, and the body is
what you pay for every time it fires. This checks both, plus the case where two
descriptions are similar enough that both skills activate and you pay twice.

Usage:
    python skill_lint.py [--root .] [--max-body 5000] [--overlap 0.45]
"""

from __future__ import annotations

import argparse
import re
import sys
from itertools import combinations
from pathlib import Path

def _heuristic(text: str) -> int:
    if not text:
        return 0
    punct = sum(text.count(c) for c in "{}[]()<>=;:,.\"'/\\|")
    return max(1, round(len(text) / 3.9 + punct * 0.12))


try:
    import tiktoken  # type: ignore
    _ENC = tiktoken.get_encoding("cl100k_base")
    tok = lambda s: len(_ENC.encode(s, disallowed_special=()))
    TOKENIZER = "tiktoken (exact)"
except ImportError:
    tok = _heuristic
    TOKENIZER = "heuristic (pip install tiktoken for exact)"
except Exception:
    tok = _heuristic
    TOKENIZER = "heuristic (tiktoken encoding unavailable offline)"

FM_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.S)
STOP = set("""a an the and or of to in on at for with from by as is are was were be been
being that which this those these it its into over under than then so but if when while
there here we you they has have had do does did not no yes can could would should may
might will use using used when your you're should""".split())


def fm_val(fm: str, key: str) -> str:
    m = re.search(rf"^{re.escape(key)}\s*:\s*(.+?)\s*$", fm, re.M)
    return m.group(1).strip().strip("'\"") if m else ""


def keywords(text: str) -> set[str]:
    words = re.findall(r"[a-z][a-z0-9-]{2,}", text.lower())
    return {w for w in words if w not in STOP}


def jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default=".")
    ap.add_argument("--max-body", type=int, default=5000,
                    help="warn above this many body tokens (default 5000)")
    ap.add_argument("--overlap", type=float, default=0.45,
                    help="warn above this description similarity (default 0.45)")
    a = ap.parse_args()

    root = Path(a.root).resolve()
    bases = [root / ".github" / "skills", Path.home() / ".copilot" / "skills"]
    skills = []
    for base in bases:
        if base.is_dir():
            skills += sorted(base.glob("*/SKILL.md"))

    if not skills:
        print(f"No SKILL.md files found under {root}/.github/skills or ~/.copilot/skills")
        return 1

    tiers = {}
    tf = root / ".github" / "agent-tiers.yaml"
    if tf.is_file():
        try:
            import yaml  # type: ignore
            tiers = (yaml.safe_load(tf.read_text(encoding="utf-8")) or {}).get("skills", {}) or {}
        except ImportError:
            pass

    print()
    print(f"  SKILL LINT   {len(skills)} skill(s)   tokenizer: {TOKENIZER}")
    print("=" * 74)

    rows, issues = [], 0
    for p in skills:
        txt = p.read_text(encoding="utf-8", errors="replace")
        m = FM_RE.match(txt)
        fm, body = (m.group(1), txt[m.end():]) if m else ("", txt)
        name = fm_val(fm, "name") or p.parent.name
        desc = fm_val(fm, "description")
        meta_t, body_t = tok(fm), tok(body)

        probs = []
        if not desc:
            probs.append("no description; this skill can never trigger by matching")
        else:
            if len(desc) < 60:
                probs.append(f"description is {len(desc)} chars; likely to under-trigger")
            if not re.search(r"\b(when|whenever|any ?time|if the user)\b", desc, re.I):
                probs.append("description says what it does but not WHEN to use it")
            if len(desc) > 900:
                probs.append(f"description is {len(desc)} chars; it is metadata, keep it tight")
        if body_t > a.max_body:
            probs.append(f"body is {body_t} tok; factor detail into references/")
        if body_t < 60:
            probs.append(f"body is only {body_t} tok; may not be worth a separate skill")

        refs = p.parent / "references"
        scripts = p.parent / "scripts"
        has_refs = refs.is_dir() and any(refs.rglob("*"))
        if body_t > 2500 and not has_refs:
            probs.append("large body with no references/; nothing is deferred")
        if re.search(r"\b(run|execute|invoke)\b.*\.(py|sh|js)\b", body) and not scripts.is_dir():
            probs.append("body references a script but scripts/ does not exist")
        # pointers to references/, scripts/, assets/ that do not exist on disk
        for rel in set(re.findall(r"(?<![\w/.])((?:references|scripts|assets)/[\w./-]+)", body)):
            if not (p.parent / rel).exists():
                probs.append(f"body points at {rel} which does not exist")
        for req in ("user-invocable", "disable-model-invocation"):
            v = fm_val(fm, req).lower()
            if v and v not in ("true", "false"):
                probs.append(f"{req} is '{v}'; must be true or false")

        if tiers and name not in tiers:
            probs.append("no minimum tier in agent-tiers.yaml; orchestrator will guess")
        issues += len(probs)
        rows.append((name, meta_t, body_t, probs, keywords(desc)))

    for name, meta_t, body_t, probs, _ in sorted(rows, key=lambda r: -r[2]):
        flag = "!" if probs else " "
        tier = f"  tier {tiers.get(name)}" if tiers.get(name) else ""
        print(f" {flag} {name:<28} meta {meta_t:>4}   body {body_t:>6}{tier}")
        for pr in probs:
            print(f"     - {pr}")

    print()
    print("-" * 74)
    print("  DESCRIPTION OVERLAP")
    print("-" * 74)
    found = False
    for (n1, _, _, _, k1), (n2, _, _, _, k2) in combinations(rows, 2):
        j = jaccard(k1, k2)
        if j >= a.overlap:
            found = True
            shared = ", ".join(sorted(k1 & k2)[:8])
            print(f"  {j:.2f}  {n1}  <->  {n2}")
            print(f"        shared: {shared}")
    if not found:
        print("  none above threshold; descriptions are well separated")
    print()

    total_meta = sum(r[1] for r in rows)
    total_body = sum(r[2] for r in rows)
    print("-" * 74)
    print(f"  Discovery floor (always in context): {total_meta} tok for {len(rows)} skills")
    print(f"  If all bodies loaded eagerly:        {total_body} tok per call")
    print(f"  Ratio:                               {total_body / max(total_meta,1):.1f}x")
    print(f"  Issues found:                        {issues}")
    print("-" * 74)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
