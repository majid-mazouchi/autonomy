#!/usr/bin/env python3
"""
databricks-delegate: an MCP server that does the heavy reading elsewhere.

Each tool takes a path and a small question, sends the file contents to a Databricks
Model Serving endpoint, and returns a short answer. The bulky input never enters the
Copilot context window and never costs Copilot credits.

Configuration is by environment variable only. Nothing secret lives in this file.

    DATABRICKS_HOST     https://<workspace-host>          (required)
    DATABRICKS_TOKEN    personal access token or SP token  (required)
    DBX_DEFAULT_MODEL   endpoint name for tools that do not specify one
    DBX_MAX_RESULT_TOK  cap on tokens returned to Copilot  (default 300)
    DBX_ALLOW_ROOT      directory that reads are confined to (default: cwd)
    COPILOT_LEDGER_DIR  where to log calls (default .copilot-state)

Run with: python server.py     (stdio transport, as .vscode/mcp.json expects)
Requires: mcp, requests
"""

from __future__ import annotations

import glob
import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

import requests
from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, Field

# ---------------------------------------------------------------- config

HOST = os.environ.get("DATABRICKS_HOST", "").rstrip("/")
TOKEN = os.environ.get("DATABRICKS_TOKEN", "")
DEFAULT_MODEL = os.environ.get("DBX_DEFAULT_MODEL", "")
MAX_RESULT_TOK = int(os.environ.get("DBX_MAX_RESULT_TOK", "300"))
ALLOW_ROOT = Path(os.environ.get("DBX_ALLOW_ROOT", os.getcwd())).resolve()
LEDGER_DIR = os.environ.get("COPILOT_LEDGER_DIR", ".copilot-state")
MAX_INPUT_CHARS = 1_500_000  # ~375k tokens; above this, chunk

mcp = FastMCP("databricks-delegate")


def _fail(msg: str) -> str:
    return f"ERROR: {msg}"


def _est_tok(s: str) -> int:
    return max(0, round(len(s) / 3.9))


def _safe_path(p: str) -> Optional[Path]:
    """Resolve and confine to ALLOW_ROOT. Returns None if outside."""
    try:
        rp = (ALLOW_ROOT / p).resolve() if not os.path.isabs(p) else Path(p).resolve()
    except OSError:
        return None
    try:
        rp.relative_to(ALLOW_ROOT)
    except ValueError:
        return None
    return rp


def _ledger(tool: str, in_tok: int, out_tok: int, model: str, path: Optional[str]) -> None:
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        with open(os.path.join(LEDGER_DIR, "ledger.jsonl"), "a", encoding="utf-8") as f:
            f.write(json.dumps({
                "t": round(time.time()), "session": None, "tier": "DBX",
                "model": model, "tool": tool, "in_tok": in_tok, "out_tok": out_tok,
                "out_lines": 0, "path": path, "offloaded_in_tok": in_tok,
            }) + "\n")
    except OSError:
        pass


def _chat(model: str, system: str, user: str, max_tokens: int, temperature: float = 0.1) -> str:
    if not HOST or not TOKEN:
        return _fail("DATABRICKS_HOST and DATABRICKS_TOKEN must be set in the MCP server env")
    model = model or DEFAULT_MODEL
    if not model:
        return _fail("no model given and DBX_DEFAULT_MODEL is unset")
    url = f"{HOST}/serving-endpoints/chat/completions"
    body = {
        "model": model,
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    try:
        r = requests.post(url, headers={"Authorization": f"Bearer {TOKEN}"}, json=body, timeout=180)
    except requests.RequestException as e:
        return _fail(f"request to {HOST} failed: {e}")
    if r.status_code != 200:
        return _fail(f"{r.status_code} from Databricks: {r.text[:300]}")
    try:
        return r.json()["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, ValueError):
        return _fail(f"unexpected response shape: {r.text[:300]}")


def _cap(text: str) -> str:
    """Hard cap on what goes back into the Copilot context."""
    limit = MAX_RESULT_TOK * 4
    if len(text) <= limit:
        return text
    return text[:limit].rsplit(" ", 1)[0] + f"\n[truncated to ~{MAX_RESULT_TOK} tok; ask a narrower question]"


def _read_chunks(p: Path) -> list[str]:
    txt = p.read_text(encoding="utf-8", errors="replace")
    if len(txt) <= MAX_INPUT_CHARS:
        return [txt]
    return [txt[i:i + MAX_INPUT_CHARS] for i in range(0, len(txt), MAX_INPUT_CHARS)]


# ---------------------------------------------------------------- tools

class SummarizeIn(BaseModel):
    path: str = Field(description="File to read, relative to the workspace root")
    question: str = Field(description="What you need from it, one sentence. Narrow questions get better answers.")
    model: str = Field(default="", description="Databricks endpoint name; default from DBX_DEFAULT_MODEL")


@mcp.tool(name="dbx_summarize_file", annotations={"readOnlyHint": True, "openWorldHint": True})
def dbx_summarize_file(params: SummarizeIn) -> str:
    """Read a large file on Databricks and return only the answer to one question.

    Use for logs, dumps, long source files and data files when you need a fact or a
    short summary rather than the contents. The file never enters your context.
    Returns at most ~300 tokens.
    """
    p = _safe_path(params.path)
    if not p or not p.is_file():
        return _fail(f"{params.path} not found or outside the allowed root {ALLOW_ROOT}")
    chunks = _read_chunks(p)
    system = ("You answer one question about a document precisely and briefly. "
              "Quote line numbers or identifiers where useful. If the answer is not in the "
              "document, say so in one sentence. Never restate the document.")
    partials = []
    for i, ch in enumerate(chunks):
        prefix = f"[part {i+1} of {len(chunks)}]\n" if len(chunks) > 1 else ""
        partials.append(_chat(params.model, system, f"{prefix}Question: {params.question}\n\nDocument:\n{ch}", 400))
    ans = partials[0] if len(partials) == 1 else _chat(
        params.model, system,
        f"Question: {params.question}\n\nPartial answers from each part:\n" + "\n---\n".join(partials), 400)
    in_tok = sum(_est_tok(c) for c in chunks)
    _ledger("dbx_summarize_file", in_tok, _est_tok(ans), params.model or DEFAULT_MODEL, str(p))
    return _cap(f"{ans}\n\n[read {in_tok:,} tok off-context from {p.name}]")


class ExtractIn(BaseModel):
    pattern: str = Field(description="Glob relative to workspace root, e.g. 'logs/**/*.log' or 'src/**/*.py'")
    fields: str = Field(description="Comma-separated fields to extract per file, e.g. 'file, error_count, first_error_line'")
    max_files: int = Field(default=50, ge=1, le=500)
    model: str = Field(default="")


@mcp.tool(name="dbx_extract", annotations={"readOnlyHint": True, "openWorldHint": True})
def dbx_extract(params: ExtractIn) -> str:
    """Extract the same fields from many files and return one compact CSV.

    Each file is read on Databricks. You get a header row plus one row per file, never
    the file contents. Use for surveying a directory before deciding where to look.
    """
    root = ALLOW_ROOT
    files = [Path(f) for f in glob.glob(str(root / params.pattern), recursive=True)]
    files = [f for f in files if f.is_file() and _safe_path(str(f))][:params.max_files]
    if not files:
        return _fail(f"no files match {params.pattern} under {root}")
    system = ("Extract exactly the requested fields from the document. Reply with ONE CSV "
              "row, no header, no prose, fields in the given order. Use 'n/a' when absent.")
    rows = []
    in_tok = 0
    for f in files:
        txt = f.read_text(encoding="utf-8", errors="replace")[:MAX_INPUT_CHARS]
        in_tok += _est_tok(txt)
        row = _chat(params.model, system, f"Fields: {params.fields}\nFile: {f.relative_to(root)}\n\n{txt}", 120)
        rows.append(row.replace("\n", " ").strip())
    out = params.fields + "\n" + "\n".join(rows)
    _ledger("dbx_extract", in_tok, _est_tok(out), params.model or DEFAULT_MODEL, params.pattern)
    return _cap(out + f"\n\n[{len(files)} files, {in_tok:,} tok read off-context]")


class ClassifyIn(BaseModel):
    items_path: str = Field(description="Text file with one item per line")
    labels: str = Field(description="Comma-separated allowed labels")
    batch_size: int = Field(default=25, ge=1, le=200, description="Items per model call")
    model: str = Field(default="")


@mcp.tool(name="dbx_batch_classify", annotations={"readOnlyHint": True, "openWorldHint": True})
def dbx_batch_classify(params: ClassifyIn) -> str:
    """Classify every line of a file into one of the given labels, in batches.

    Returns 'line_number,label' per item. Amortizes the instruction across each batch
    and keeps the items out of your context.
    """
    p = _safe_path(params.items_path)
    if not p or not p.is_file():
        return _fail(f"{params.items_path} not found or outside the allowed root")
    items = [l.rstrip("\n") for l in p.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()]
    system = (f"Classify each numbered item into exactly one of these labels: {params.labels}. "
              "Reply with one line per item as 'number,label'. No other text.")
    out_lines, in_tok = [], 0
    for start in range(0, len(items), params.batch_size):
        batch = items[start:start + params.batch_size]
        numbered = "\n".join(f"{start + i + 1}. {it}" for i, it in enumerate(batch))
        in_tok += _est_tok(numbered)
        res = _chat(params.model, system, numbered, 20 * len(batch))
        out_lines.append(res)
    out = "\n".join(out_lines)
    _ledger("dbx_batch_classify", in_tok, _est_tok(out), params.model or DEFAULT_MODEL, str(p))
    if _est_tok(out) > MAX_RESULT_TOK:
        dest = p.with_suffix(".labels.csv")
        dest.write_text("line,label\n" + out, encoding="utf-8")
        counts: dict[str, int] = {}
        for ln in out.splitlines():
            lab = ln.split(",", 1)[-1].strip() if "," in ln else "?"
            counts[lab] = counts.get(lab, 0) + 1
        summary = ", ".join(f"{k}: {v}" for k, v in sorted(counts.items(), key=lambda kv: -kv[1]))
        return f"{len(items)} items classified. Written to {dest.relative_to(ALLOW_ROOT)}\nCounts: {summary}"
    return out


class GenerateIn(BaseModel):
    spec_path: str = Field(description="File containing the specification or template to generate from")
    out_path: str = Field(description="Where to write the generated content, relative to workspace root")
    instruction: str = Field(description="What to generate, one or two sentences")
    model: str = Field(default="")
    max_tokens: int = Field(default=6000, ge=100, le=32000)


@mcp.tool(name="dbx_generate_to_file", annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": True})
def dbx_generate_to_file(params: GenerateIn) -> str:
    """Generate volume output (boilerplate, tests, docs) on Databricks and write it to disk.

    Only the path and a line count come back. Use when the output would be hundreds of
    lines; you review the file, not the transcript. Refuses to overwrite an existing file.
    """
    spec = _safe_path(params.spec_path)
    out = _safe_path(params.out_path)
    if not spec or not spec.is_file():
        return _fail(f"{params.spec_path} not found or outside the allowed root")
    if not out:
        return _fail(f"{params.out_path} is outside the allowed root")
    if out.exists():
        return _fail(f"{params.out_path} exists; choose a new path or delete it first")
    spec_txt = spec.read_text(encoding="utf-8", errors="replace")[:MAX_INPUT_CHARS]
    system = ("You generate code or documents from a specification. Output ONLY the artifact, "
              "no explanation, no markdown fences unless the artifact is markdown.")
    res = _chat(params.model, system, f"{params.instruction}\n\nSpecification:\n{spec_txt}", params.max_tokens, 0.2)
    if res.startswith("ERROR:"):
        return res
    if res.startswith("```"):
        res = res.split("\n", 1)[1].rsplit("```", 1)[0]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(res, encoding="utf-8")
    _ledger("dbx_generate_to_file", _est_tok(spec_txt), _est_tok(res), params.model or DEFAULT_MODEL, str(out))
    return (f"Wrote {out.relative_to(ALLOW_ROOT)}: {res.count(chr(10)) + 1} lines, "
            f"~{_est_tok(res):,} tok generated off-context. Review the file; do not paste it here.")


class AskIn(BaseModel):
    prompt: str = Field(description="The question or task")
    model: str = Field(description="Databricks endpoint name, e.g. a fine-tuned or RAG-backed domain model")
    context_path: str = Field(default="", description="Optional file to attach as context, read on Databricks")
    max_tokens: int = Field(default=600, ge=50, le=8000)


@mcp.tool(name="dbx_ask", annotations={"readOnlyHint": True, "openWorldHint": True})
def dbx_ask(params: AskIn) -> str:
    """Ask a specific Databricks endpoint, for domain, fine-tuned or RAG-backed models.

    Use when a model there knows something the Copilot models do not, such as your own
    data or a specialist fine-tune. Optionally attaches one file as context, read there.
    """
    ctx = ""
    in_tok = _est_tok(params.prompt)
    if params.context_path:
        p = _safe_path(params.context_path)
        if not p or not p.is_file():
            return _fail(f"{params.context_path} not found or outside the allowed root")
        ctx = p.read_text(encoding="utf-8", errors="replace")[:MAX_INPUT_CHARS]
        in_tok += _est_tok(ctx)
    system = "Answer precisely. Say what you are unsure about. Do not pad."
    user = params.prompt + (f"\n\nContext:\n{ctx}" if ctx else "")
    res = _chat(params.model, system, user, params.max_tokens, 0.2)
    _ledger("dbx_ask", in_tok, _est_tok(res), params.model, params.context_path or None)
    return _cap(res)


@mcp.tool(name="dbx_status", annotations={"readOnlyHint": True})
def dbx_status() -> str:
    """Report whether the server is configured, without revealing secrets."""
    return json.dumps({
        "host_set": bool(HOST), "token_set": bool(TOKEN),
        "default_model": DEFAULT_MODEL or "(unset)",
        "max_result_tokens": MAX_RESULT_TOK, "allowed_root": str(ALLOW_ROOT),
    })


if __name__ == "__main__":
    mcp.run(transport="stdio")
