#!/usr/bin/env python3
"""
PostToolUse hook: append one line per tool call to a session ledger.

This is a TOOL-PAYLOAD DIAGNOSTIC, not a billing meter. It records, per tool call, the
estimated size of the arguments and of the result text that will be fed back to the
model as input. It does not see the model's prompt, its generated output, reasoning,
cache categories, or failed calls. For billed usage, use VS Code's OpenTelemetry export
or the provider's usage page; use this file to find oversized tool results.

Writes to .copilot-state/ledger.jsonl. Nothing is sent anywhere.

The audit script reads this ledger, when present, to report what tool output
actually cost in real sessions rather than what static analysis predicts.

When run from an agent-scoped hook written by assign_models.py, COPILOT_TIER is
set and the record is tier-tagged. The global hook writes untagged records; the
audit de-duplicates identical records and keeps the tagged one.

Exit 0 always. Never block the agent.
"""
import json
import os
import sys
import time

LEDGER_DIR = os.environ.get("COPILOT_LEDGER_DIR", ".copilot-state")
LEDGER = os.path.join(LEDGER_DIR, "ledger.jsonl")


def est_tokens(s: str) -> int:
    return max(0, round(len(s) / 3.9))


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return 0
    name = payload.get("tool_name") or payload.get("toolName") or "unknown"
    inp = payload.get("tool_input") or payload.get("toolInput") or {}
    resp = (payload.get("tool_response") or payload.get("toolResponse")
            or payload.get("tool_output") or payload.get("toolOutput") or "")
    if not isinstance(resp, str):
        try:
            resp = json.dumps(resp)
        except Exception:
            resp = str(resp)
    try:
        inp_s = json.dumps(inp) if not isinstance(inp, str) else inp
    except Exception:
        inp_s = str(inp)
    rec = {
        "t": round(time.time(), 3),
        "session": payload.get("sessionId") or payload.get("session_id"),
        "call_id": (payload.get("tool_use_id") or payload.get("toolCallId")
                    or payload.get("tool_call_id") or None),
        "event": payload.get("hook_event_name") or payload.get("hookEventName") or "PostToolUse",
        "tier_configured": os.environ.get("COPILOT_TIER") or None,
        "model_observed": payload.get("model") or payload.get("modelId") or None,
        "tool": name,
        "args_tok": est_tokens(inp_s),
        "result_tok": est_tokens(resp),
        "result_lines": resp.count("\n") + 1 if resp else 0,
        "path": (inp.get("filePath") or inp.get("file_path") or inp.get("path")
                 if isinstance(inp, dict) else None),
    }
    try:
        os.makedirs(LEDGER_DIR, exist_ok=True)
        with open(LEDGER, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
