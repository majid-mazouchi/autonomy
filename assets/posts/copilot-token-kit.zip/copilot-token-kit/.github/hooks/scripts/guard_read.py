#!/usr/bin/env python3
"""
PreToolUse hook: ask before a file read that would put a lot of text into context.

This is an advisory guard, not a budget enforcer. It covers the file-read tools whose
names match READ_TOOLS and estimates the size of what the read would return. It does not
see terminal output, MCP tool results, or reads made by other harnesses; those are
covered by the tool-output instructions and by truncation at the source.

Decision rule: estimate the bytes the read would return. If a valid line range is given,
size that range; otherwise size the whole file. Ask when the estimate exceeds
COPILOT_READ_GUARD_TOKENS (default 4000 tokens, about 15 KB). This catches a 1,000-line
"range" and a single 150 KB line alike.

Relative paths are resolved against the event's `cwd` when present, else the process cwd.
Exit 0 always; a hook that crashes should never block the agent.
"""
import json
import os
import sys

LIMIT_TOK = int(os.environ.get("COPILOT_READ_GUARD_TOKENS", "4000"))
READ_TOOLS = ("read_file", "readfile", "read", "open_file", "view_file", "get_file", "cat")
CHARS_PER_TOK = 3.9


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def main() -> int:
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return 0
    name = str(payload.get("tool_name") or payload.get("toolName") or "").lower()
    if not any(t == name or name.endswith("_" + t) or t in name for t in READ_TOOLS):
        return 0
    inp = payload.get("tool_input") or payload.get("toolInput") or {}
    if not isinstance(inp, dict):
        return 0
    path = inp.get("filePath") or inp.get("file_path") or inp.get("path") or ""
    if not path:
        return 0
    base = payload.get("cwd") or os.getcwd()
    full = path if os.path.isabs(path) else os.path.join(base, path)
    if not os.path.isfile(full):
        return 0

    start = _int(inp.get("startLine") or inp.get("start_line") or inp.get("offset"))
    end = _int(inp.get("endLine") or inp.get("end_line"))
    limit = _int(inp.get("limit"))
    if start is not None and end is None and limit is not None:
        end = start + limit - 1

    try:
        size = os.path.getsize(full)
        with open(full, "rb") as f:
            lines = sum(1 for _ in f) or 1
    except OSError:
        return 0

    if start is not None and end is not None and end >= start >= 1:
        # size the requested span using the file's average line length
        span = min(end, lines) - start + 1
        est_bytes = int(size * span / lines)
        what = f"lines {start}-{end} of {os.path.basename(full)} ({span} lines)"
    else:
        est_bytes = size
        what = f"{os.path.basename(full)} whole ({lines} lines, {size//1024} KB)"

    est_tok = int(est_bytes / CHARS_PER_TOK)
    if est_tok <= LIMIT_TOK:
        return 0
    out = {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "ask",
            "permissionDecisionReason": (
                f"Reading {what} adds about {est_tok//1000}k tokens to context, re-sent on "
                f"every later turn of this session. Prefer grep or a narrower range. Allow anyway?"
            ),
        }
    }
    print(json.dumps(out))
    return 0


if __name__ == "__main__":
    sys.exit(main())
