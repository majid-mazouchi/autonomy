"""
Probabilistic methods for condition monitoring and prognostics.
Pure numpy + scipy. Three families:
  distribution & anomaly  : kde, gmm, robust outlier tests
  bayesian / state        : bayes update, bayesian networks, kalman, particle
  reliability / survival  : weibull, kaplan-meier, cox PH, hazard estimation
Every function has a short autodoc block (plain prose, no markdown).
"""
import numpy as np
from scipy import stats, linalg, optimize


# ===========================================================================
# DISTRIBUTION AND ANOMALY
# ===========================================================================
def kde_pdf(X_train, X_eval, bw=None):
    """
    Purpose
    Kernel density estimate. Place a smooth Gaussian bump on every training point
    and sum them into a continuous density, then evaluate it anywhere. The estimated
    density is the basis of novelty scoring: a new point in a low-density region is
    unlike anything seen before.

    Inputs
    X_train training data, shape (n,) or (n, d); X_eval points to evaluate, same
    dimension; bw an optional bandwidth scale (defaults to Scott's rule).

    Outputs
    The estimated probability density at each evaluation point.
    """
    Xt = np.asarray(X_train, float)
    Xe = np.asarray(X_eval, float)
    if Xt.ndim == 1:
        Xt = Xt[:, None]; Xe = np.atleast_1d(Xe)[:, None] if Xe.ndim == 1 else Xe
    kde = stats.gaussian_kde(Xt.T, bw_method=bw)
    return kde(Xe.T)


def novelty_score(X_train, X_eval, bw=None):
    """
    Purpose
    Turn a kernel density estimate into an anomaly score: the negative log density.
    Points in dense, familiar regions score low; points in sparse regions score
    high, flagging novelty without needing labelled faults.

    Inputs
    X_train training data; X_eval points to score; bw optional bandwidth.

    Outputs
    The negative log density at each evaluation point (higher is more anomalous).
    """
    p = kde_pdf(X_train, X_eval, bw)
    return -np.log(p + 1e-300)


def gmm_fit(X, k, iters=120, seed=0, reg=1e-6):
    """
    Purpose
    Fit a Gaussian mixture by expectation-maximization. The data are modelled as a
    blend of k Gaussian components, which captures several distinct operating
    regimes at once and gives a smooth density for anomaly scoring, a parametric
    cousin of the kernel density estimate.

    Inputs
    X data of shape (n, d); k the number of components; iters EM iterations; seed
    the init seed; reg a covariance regularizer.

    Outputs
    Dict with weights, means, covariances, responsibilities, hard labels, and the
    final log-likelihood.
    """
    X = np.atleast_2d(np.asarray(X, float))
    if X.shape[0] == 1 and X.shape[1] > 1:
        X = X.T
    n, d = X.shape
    rs = np.random.default_rng(seed)
    means = X[rs.choice(n, k, replace=False)].copy()
    covs = np.array([np.cov(X.T) + reg * np.eye(d) for _ in range(k)])
    w = np.ones(k) / k
    ll_old = -np.inf
    for _ in range(iters):
        # E step
        logp = np.zeros((n, k))
        for j in range(k):
            logp[:, j] = np.log(w[j] + 1e-300) + _logmvn(X, means[j], covs[j])
        m = logp.max(axis=1, keepdims=True)
        logsum = m[:, 0] + np.log(np.exp(logp - m).sum(axis=1))
        R = np.exp(logp - logsum[:, None])
        ll = logsum.sum()
        # M step
        Nk = R.sum(axis=0) + 1e-12
        w = Nk / n
        for j in range(k):
            means[j] = (R[:, j, None] * X).sum(axis=0) / Nk[j]
            dx = X - means[j]
            covs[j] = (R[:, j, None, None] * np.einsum("ni,nj->nij", dx, dx)).sum(0) / Nk[j]
            covs[j] += reg * np.eye(d)
        if abs(ll - ll_old) < 1e-6:
            break
        ll_old = ll
    return dict(weights=w, means=means, covs=covs, resp=R,
                labels=R.argmax(axis=1), loglik=ll)


def gmm_score(model, X):
    """
    Purpose
    Score points under a fitted Gaussian mixture: the log-likelihood of each point.
    A low score means the point fits no operating regime well, an anomaly.

    Inputs
    model the dict returned by gmm_fit; X points to score, shape (n, d).

    Outputs
    The per-point log-likelihood under the mixture.
    """
    X = np.atleast_2d(np.asarray(X, float))
    if X.shape[0] == 1 and X.shape[1] > 1 and model["means"].shape[1] != 1:
        X = X.reshape(-1, model["means"].shape[1])
    w, means, covs = model["weights"], model["means"], model["covs"]
    k = len(w); n = X.shape[0]
    logp = np.zeros((n, k))
    for j in range(k):
        logp[:, j] = np.log(w[j] + 1e-300) + _logmvn(X, means[j], covs[j])
    m = logp.max(axis=1, keepdims=True)
    return (m[:, 0] + np.log(np.exp(logp - m).sum(axis=1)))


def _logmvn(X, mean, cov):
    d = X.shape[1]
    L = np.linalg.cholesky(cov)
    dx = X - mean
    sol = linalg.solve_triangular(L, dx.T, lower=True)
    quad = (sol ** 2).sum(axis=0)
    logdet = 2 * np.log(np.diag(L)).sum()
    return -0.5 * (d * np.log(2 * np.pi) + logdet + quad)


def mad_zscore(x):
    """
    Purpose
    The robust modified z-score. The mean and standard deviation are themselves
    distorted by the outliers they are meant to catch; the median and the median
    absolute deviation are not. This score uses them, flagging points whose robust
    z exceeds about 3.5.

    Inputs
    x a one-dimensional sample.

    Outputs
    Dict with the modified z-scores and a boolean mask of flagged outliers.
    """
    x = np.asarray(x, float)
    med = np.median(x)
    mad = np.median(np.abs(x - med))
    z = 0.6745 * (x - med) / (mad + 1e-12)
    return dict(z=z, outlier=np.abs(z) > 3.5, median=med, mad=mad)


def grubbs(x, alpha=0.05):
    """
    Purpose
    Grubbs' test for a single outlier in a roughly normal sample. It compares the
    most extreme deviation from the mean, in standard-deviation units, to a critical
    value from the t-distribution, giving a principled yes or no for one suspect.

    Inputs
    x a one-dimensional sample; alpha the significance level.

    Outputs
    Dict with the test statistic, the critical value, the index of the most extreme
    point, and whether it is a significant outlier.
    """
    x = np.asarray(x, float); n = len(x)
    G = np.max(np.abs(x - x.mean())) / (x.std(ddof=1) + 1e-12)
    t = stats.t.ppf(1 - alpha / (2 * n), n - 2)
    crit = (n - 1) / np.sqrt(n) * np.sqrt(t ** 2 / (n - 2 + t ** 2))
    return dict(G=G, critical=crit, index=int(np.argmax(np.abs(x - x.mean()))),
                is_outlier=bool(G > crit))


def generalized_esd(x, max_out=5, alpha=0.05):
    """
    Purpose
    The generalized extreme studentized deviate test (Rosner). Grubbs finds one
    outlier; many outliers mask one another. Generalized ESD removes the most
    extreme point, recomputes, and repeats up to a stated maximum, then reports how
    many of those removals were statistically significant.

    Inputs
    x a one-dimensional sample; max_out the maximum number of outliers to test for;
    alpha the significance level.

    Outputs
    Dict with the sorted indices of detected outliers and the number found.
    """
    x = np.asarray(x, float); n = len(x)
    idx = np.arange(n); work = x.copy(); widx = idx.copy()
    R, lam, removed = [], [], []
    for i in range(max_out):
        if len(work) < 3:
            break
        mu, sd = work.mean(), work.std(ddof=1) + 1e-12
        j = np.argmax(np.abs(work - mu))
        R.append(np.abs(work[j] - mu) / sd)
        removed.append(widx[j])
        nn = len(work)
        p = 1 - alpha / (2 * nn)
        t = stats.t.ppf(p, nn - 2)
        lam.append((nn - 1) * t / np.sqrt((nn - 2 + t ** 2) * nn))
        work = np.delete(work, j); widx = np.delete(widx, j)
    n_out = 0
    for i in range(len(R)):
        if R[i] > lam[i]:
            n_out = i + 1
    return dict(outliers=sorted(removed[:n_out]), n_found=n_out)


# ===========================================================================
# BAYESIAN AND STATE ESTIMATION
# ===========================================================================
def bayes_update(prior, likelihood):
    """
    Purpose
    One step of Bayes' rule over a set of hypotheses. Multiply the prior belief in
    each hypothesis by how well it explains the new evidence, then renormalize. It
    is the atom of diagnostic reasoning under uncertainty.

    Inputs
    prior the prior probabilities over hypotheses; likelihood the probability of the
    evidence under each hypothesis.

    Outputs
    The posterior probabilities over hypotheses.
    """
    post = np.asarray(prior, float) * np.asarray(likelihood, float)
    return post / (post.sum() + 1e-300)


def sequential_bayes(prior, likelihoods):
    """
    Purpose
    Apply Bayes' rule repeatedly as evidence arrives, carrying the posterior forward
    as the next prior. It shows belief in each fault hypothesis sharpening with each
    new observation.

    Inputs
    prior the starting probabilities; likelihoods a sequence of likelihood vectors,
    one per observation.

    Outputs
    The trajectory of posteriors, shape (steps + 1, hypotheses).
    """
    p = np.asarray(prior, float); traj = [p.copy()]
    for lik in likelihoods:
        p = bayes_update(p, lik); traj.append(p.copy())
    return np.array(traj)


def beta_binomial(a, b, k_success, n_trials):
    """
    Purpose
    Conjugate Bayesian updating of a rate, for example a defect or failure
    probability. Starting from a Beta(a, b) prior and observing k events in n trials,
    the posterior is Beta(a + k, b + n - k) in closed form, with a mean and a
    credible interval.

    Inputs
    a, b the prior Beta parameters; k_success the events observed; n_trials the
    trials observed.

    Outputs
    Dict with the posterior parameters, the posterior mean, and a 95 percent
    credible interval.
    """
    ap, bp = a + k_success, b + n_trials - k_success
    lo, hi = stats.beta.ppf([0.025, 0.975], ap, bp)
    return dict(a_post=ap, b_post=bp, mean=ap / (ap + bp), ci=(lo, hi))


def bayes_net_infer(nodes, evidence, query):
    """
    Purpose
    Exact inference in a discrete Bayesian network of binary nodes, by enumerating
    the joint distribution. A Bayesian network encodes which faults cause which
    symptoms and their conditional independencies; given observed symptoms it returns
    the posterior probability of a hidden fault, isolating the likely cause.

    Inputs
    nodes a dict mapping each node name to a dict with parents (a list of names) and
    cpt (a dict from a tuple of parent values to the probability the node is 1);
    evidence a dict of observed node values; query the node to infer.

    Outputs
    The posterior probability that the query node equals 1 given the evidence.
    """
    names = list(nodes.keys())
    free = [v for v in names if v not in evidence]

    def joint(assign):
        p = 1.0
        for nm in names:
            par = nodes[nm]["parents"]
            key = tuple(assign[pp] for pp in par)
            p1 = nodes[nm]["cpt"][key] if par else nodes[nm]["cpt"][()]
            p *= p1 if assign[nm] == 1 else (1 - p1)
        return p

    num = den = 0.0
    for bits in range(2 ** len(free)):
        assign = dict(evidence)
        for i, nm in enumerate(free):
            assign[nm] = (bits >> i) & 1
        pj = joint(assign)
        den += pj
        if assign[query] == 1:
            num += pj
    return num / (den + 1e-300)


def kalman_filter(z, F, H, Q, R, x0, P0):
    """
    Purpose
    The linear Kalman filter. It tracks a hidden state from noisy measurements by
    alternating a model-based prediction with a measurement correction, weighting
    each by its uncertainty. Its one-step prediction error, the innovation, is the
    whitened residual that model-based fault detection monitors.

    Inputs
    z measurements of shape (T, m); F the state-transition matrix; H the observation
    matrix; Q and R the process and measurement covariances; x0 and P0 the initial
    state and covariance.

    Outputs
    Dict with the filtered states, their covariances, and the innovation sequence.
    """
    z = np.atleast_2d(np.asarray(z, float))
    if z.shape[1] != H.shape[0]:
        z = z.reshape(-1, H.shape[0])
    T = z.shape[0]; n = F.shape[0]
    x = np.asarray(x0, float).reshape(n); P = np.asarray(P0, float)
    xs = np.zeros((T, n)); innov = np.zeros((T, H.shape[0]))
    for t in range(T):
        x = F @ x; P = F @ P @ F.T + Q                  # predict
        y = z[t] - H @ x                                # innovation
        S = H @ P @ H.T + R
        K = P @ H.T @ np.linalg.inv(S)
        x = x + K @ y; P = (np.eye(n) - K @ H) @ P       # update
        xs[t] = x; innov[t] = y
    return dict(x_filt=xs, P=P, innov=innov)


def particle_filter(z, f_trans, h_obs, q_std, r_std, x0, n_particles=2000, seed=0):
    """
    Purpose
    A bootstrap particle filter for a nonlinear, scalar degradation state. It
    represents the belief by a swarm of weighted samples, propagates them through
    the nonlinear dynamics, weights them by how well they explain each measurement,
    and resamples. It estimates a hidden health state where the Kalman filter's
    linear-Gaussian assumptions do not hold.

    Inputs
    z measurements; f_trans the state transition function; h_obs the observation
    function; q_std and r_std the process and measurement noise scales; x0 the
    initial state; n_particles the swarm size; seed the random seed.

    Outputs
    Dict with the posterior mean state per step and the 5th and 95th percentiles.
    """
    rs = np.random.default_rng(seed)
    p = x0 + q_std * rs.normal(size=n_particles)
    T = len(z); mean = np.zeros(T); lo = np.zeros(T); hi = np.zeros(T)
    for t in range(T):
        p = f_trans(p) + q_std * rs.normal(size=n_particles)
        w = np.exp(-0.5 * ((z[t] - h_obs(p)) / r_std) ** 2) + 1e-300
        w /= w.sum()
        mean[t] = (w * p).sum()
        lo[t], hi[t] = _wpercentile(p, w, [5, 95])
        idx = rs.choice(n_particles, n_particles, p=w)     # resample
        p = p[idx]
    return dict(mean=mean, lo=lo, hi=hi)


def _wpercentile(v, w, qs):
    o = np.argsort(v); v = v[o]; cw = np.cumsum(w[o])
    return np.interp(np.array(qs) / 100.0, cw, v)


# ===========================================================================
# RELIABILITY AND SURVIVAL
# ===========================================================================
def weibull_fit(t):
    """
    Purpose
    Fit a two-parameter Weibull distribution to failure times by maximum likelihood.
    The shape parameter says which failure regime governs: below one is infant
    mortality with a falling hazard, one is random failure with a constant hazard,
    above one is wear-out with a rising hazard. The scale is the characteristic life.

    Inputs
    t observed failure times (positive).

    Outputs
    Dict with the shape and scale parameters.
    """
    t = np.asarray(t, float)
    shape, loc, scale = stats.weibull_min.fit(t, floc=0)
    return dict(shape=shape, scale=scale)


def weibull_reliability(t, shape, scale):
    """
    Purpose
    The Weibull reliability and hazard functions. Reliability is the probability of
    surviving past a time; the hazard is the instantaneous failure rate of a unit
    still working, the quantity that shapes the bathtub curve.

    Inputs
    t times to evaluate; shape and scale the Weibull parameters.

    Outputs
    Dict with the reliability R(t) and the hazard h(t).
    """
    t = np.asarray(t, float)
    R = np.exp(-(t / scale) ** shape)
    h = (shape / scale) * (t / scale) ** (shape - 1)
    return dict(R=R, h=h)


def weibull_plot_points(t):
    """
    Purpose
    Coordinates for a Weibull probability plot. Using median-rank plotting
    positions, the transformed data fall on a straight line when the Weibull model
    fits, so the plot is both a fit check and a graphical parameter estimate.

    Inputs
    t observed failure times.

    Outputs
    Dict with the x and y plot coordinates and the fitted-line slope (shape) and
    intercept.
    """
    t = np.sort(np.asarray(t, float)); n = len(t)
    F = (np.arange(1, n + 1) - 0.3) / (n + 0.4)        # median rank
    x = np.log(t); y = np.log(-np.log(1 - F))
    slope, intercept = np.polyfit(x, y, 1)
    return dict(x=x, y=y, slope=slope, intercept=intercept)


def kaplan_meier(durations, events):
    """
    Purpose
    The Kaplan-Meier product-limit estimator of the survival curve. It estimates the
    probability of surviving past each time without assuming any distribution, and it
    correctly handles censoring, units still running or withdrawn before failing.

    Inputs
    durations the observed time for each unit; events 1 if the unit failed, 0 if it
    was censored.

    Outputs
    Dict with the event times and the survival probability at each.
    """
    durations = np.asarray(durations, float); events = np.asarray(events, int)
    order = np.argsort(durations)
    durations, events = durations[order], events[order]
    uniq = np.unique(durations[events == 1])
    S = 1.0; ts = [0.0]; Ss = [1.0]
    for tt in uniq:
        at_risk = np.sum(durations >= tt)
        d = np.sum((durations == tt) & (events == 1))
        S *= (1 - d / at_risk)
        ts.append(tt); Ss.append(S)
    return dict(t=np.array(ts), S=np.array(Ss))


def nelson_aalen(durations, events):
    """
    Purpose
    The Nelson-Aalen estimator of the cumulative hazard, the running total of
    instantaneous failure risk. Its slope is the hazard rate, so a steepening curve
    signals an accelerating failure process such as wear-out.

    Inputs
    durations observed times; events 1 for failure, 0 for censored.

    Outputs
    Dict with the event times and the cumulative hazard at each.
    """
    durations = np.asarray(durations, float); events = np.asarray(events, int)
    uniq = np.unique(durations[events == 1])
    H = 0.0; ts = [0.0]; Hs = [0.0]
    for tt in uniq:
        at_risk = np.sum(durations >= tt)
        d = np.sum((durations == tt) & (events == 1))
        H += d / at_risk
        ts.append(tt); Hs.append(H)
    return dict(t=np.array(ts), H=np.array(Hs))


def cox_ph(X, durations, events):
    """
    Purpose
    Fit a Cox proportional-hazards model by maximizing the Breslow partial
    likelihood. It relates covariates, operating conditions or sensor features, to
    the failure hazard without specifying a baseline distribution, returning a
    hazard ratio per covariate: how much each multiplies the risk of failure.

    Inputs
    X covariates of shape (n, p); durations observed times; events 1 for failure,
    0 for censored.

    Outputs
    Dict with the fitted coefficients, their hazard ratios, and standard errors.
    """
    X = np.atleast_2d(np.asarray(X, float))
    durations = np.asarray(durations, float); events = np.asarray(events, int)
    n, p = X.shape
    order = np.argsort(-durations)            # descending: risk set is a prefix
    Xo, do, eo = X[order], durations[order], events[order]

    def negloglik(beta):
        eta = Xo @ beta
        ll = 0.0
        # risk set for event i (descending sort) is all j with duration >= t_i
        # since sorted descending, cumulative log-sum-exp from the top
        for i in range(n):
            if eo[i] == 1:
                risk = do >= do[i]
                ll += eta[i] - _logsumexp(eta[risk])
        return -ll

    def grad(beta):
        eta = Xo @ beta; g = np.zeros(p)
        for i in range(n):
            if eo[i] == 1:
                risk = do >= do[i]
                w = np.exp(eta[risk] - eta[risk].max()); w /= w.sum()
                g += Xo[i] - (w[:, None] * Xo[risk]).sum(0)
        return -g

    res = optimize.minimize(negloglik, np.zeros(p), jac=grad, method="BFGS")
    beta = res.x
    se = np.sqrt(np.diag(res.hess_inv)) if hasattr(res, "hess_inv") else np.full(p, np.nan)
    return dict(coef=beta, hazard_ratio=np.exp(beta), se=se)


def _logsumexp(a):
    m = np.max(a)
    return m + np.log(np.exp(a - m).sum())


# ===========================================================================
# ===========================================================================
# GOING FURTHER 1: REMAINING USEFUL LIFE AND PROGNOSTIC METRICS
# ===========================================================================
def rul_predict(t, y, threshold, n_boot=500, seed=0):
    """
    Purpose
    Remaining-useful-life prediction by degradation extrapolation. Fit a trend to a
    health indicator observed so far, project it to the failure threshold, and report
    the crossing time as a remaining life with a prediction interval from the fit
    uncertainty. The interval widens the further ahead the extrapolation reaches.

    Inputs
    t observation times; y the health indicator at those times; threshold the failure
    level; n_boot bootstrap resamples for the interval; seed the random seed.

    Outputs
    Dict with the fitted slope and intercept, the projected crossing time, and the
    remaining life with 5th and 95th-percentile bounds.
    """
    t = np.asarray(t, float); y = np.asarray(y, float)
    A = np.c_[t, np.ones_like(t)]
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    resid = y - A @ coef
    s = resid.std(ddof=2) if len(y) > 2 else resid.std() + 1e-6
    rs = np.random.default_rng(seed)
    cross = []
    for _ in range(n_boot):
        cb, *_ = np.linalg.lstsq(A, A @ coef + rs.normal(0, s + 1e-9, len(y)), rcond=None)
        if cb[0] > 1e-9:
            cross.append((threshold - cb[1]) / cb[0])
    cross = np.array(cross) if cross else np.array([np.nan])
    t_last = t[-1]
    tc = (threshold - coef[1]) / coef[0] if coef[0] > 1e-9 else np.inf
    lo, hi = np.nanpercentile(cross, [5, 95])
    return dict(slope=float(coef[0]), intercept=float(coef[1]), t_cross=float(tc),
                rul=max(0.0, tc - t_last),
                rul_lo=max(0.0, lo - t_last), rul_hi=max(0.0, hi - t_last))


def prognostic_metrics(t, rul_pred, rul_true, alpha=0.2):
    """
    Purpose
    Standard prognostic performance metrics. Alpha-lambda accuracy asks whether each
    prediction falls within a shrinking cone around the true remaining life;
    prognostic horizon is how early the predictions enter and stay in that cone; and
    relative accuracy summarizes the average closeness. They judge a remaining-life
    predictor, which raw error does not.

    Inputs
    t prediction times; rul_pred the predicted remaining life at each; rul_true the
    true remaining life at each; alpha the accuracy-cone half-width as a fraction.

    Outputs
    Dict with the in-cone mask, the prognostic horizon, and the relative accuracy.
    """
    t = np.asarray(t, float); rp = np.asarray(rul_pred, float); rt = np.asarray(rul_true, float)
    in_band = np.abs(rp - rt) <= alpha * np.maximum(rt, 1e-9)
    ph = None
    for i in range(len(t)):
        if in_band[i:].all():
            ph = float(t[i]); break
    ra = float(np.mean(1 - np.abs(rp - rt) / (rt + 1e-9)))
    return dict(in_band=in_band, prognostic_horizon=ph, alpha=alpha, rel_accuracy=ra)


# ===========================================================================
# GOING FURTHER 2: SHARPER ANOMALY DETECTION
# ===========================================================================
def mahalanobis(X, robust=True, iters=6):
    """
    Purpose
    Mahalanobis distance for multivariate outliers, optionally with a robust center
    and covariance. The distance accounts for correlation between features, and the
    robust version, estimated by iteratively trimming the most extreme points,
    resists the masking that lets outliers inflate the classical covariance and hide.

    Inputs
    X data of shape (n, d); robust whether to use the trimmed estimate; iters the
    number of reweighting passes.

    Outputs
    Dict with the distances, the center and covariance used, the chi-square threshold,
    and a boolean outlier mask.
    """
    X = np.atleast_2d(np.asarray(X, float)); n, d = X.shape
    mu = X.mean(0); cov = np.cov(X.T) + 1e-9 * np.eye(d)
    if robust:
        for _ in range(iters):
            ic = np.linalg.pinv(cov)
            md = np.sqrt(np.einsum("ni,ij,nj->n", X - mu, ic, X - mu))
            keep = md <= np.quantile(md, 0.75) * 1.4
            if keep.sum() > d + 1:
                mu = X[keep].mean(0); cov = np.cov(X[keep].T) + 1e-9 * np.eye(d)
    ic = np.linalg.pinv(cov)
    md = np.sqrt(np.einsum("ni,ij,nj->n", X - mu, ic, X - mu))
    thr = np.sqrt(stats.chi2.ppf(0.975, d))
    return dict(dist=md, mu=mu, cov=cov, threshold=thr, outlier=md > thr)


def pot_threshold(x, q=0.95, exceed_prob=1e-3):
    """
    Purpose
    A peaks-over-threshold alarm level from extreme value theory. Exceedances over a
    high quantile follow a generalized Pareto distribution; fitting it lets you set
    an alarm at the level a healthy signal exceeds only with a chosen small
    probability, rather than at an arbitrary number of sigmas.

    Inputs
    x a sample of the health index; q the quantile defining the threshold for
    exceedances; exceed_prob the target exceedance probability for the alarm level.

    Outputs
    Dict with the exceedance threshold, the fitted shape and scale, and the alarm
    level for the target exceedance probability.
    """
    x = np.asarray(x, float)
    u = np.quantile(x, q)
    exc = x[x > u] - u
    c, loc, scale = stats.genpareto.fit(exc, floc=0)
    pu = np.mean(x > u)
    if abs(c) > 1e-6:
        z = u + (scale / c) * ((exceed_prob / pu) ** (-c) - 1)
    else:
        z = u - scale * np.log(exceed_prob / pu)
    return dict(u=float(u), shape=float(c), scale=float(scale),
                level=float(z), exceed_prob=exceed_prob)


def conformal_threshold(cal_scores, alpha=0.05):
    """
    Purpose
    A split-conformal anomaly threshold. Given anomaly scores on clean calibration
    data, it returns the cutoff that guarantees, in finite samples and with no
    distributional assumption, that a normal point exceeds it with probability at
    most alpha, turning any score into a calibrated alarm with a coverage guarantee.

    Inputs
    cal_scores anomaly scores on known-normal calibration data; alpha the tolerated
    false-alarm rate.

    Outputs
    Dict with the threshold, the alpha, and the guaranteed normal-coverage level.
    """
    s = np.sort(np.asarray(cal_scores, float)); n = len(s)
    k = min(int(np.ceil((n + 1) * (1 - alpha))), n)
    return dict(threshold=float(s[k - 1]), alpha=alpha, coverage=1 - alpha)


# ===========================================================================
# GOING FURTHER 3: MORE STATE AND INFERENCE TOOLS
# ===========================================================================
def hmm_fit(obs, n_states=3, iters=60, seed=0):
    """
    Purpose
    Fit a Gaussian hidden Markov model by Baum-Welch. It models a system that passes
    through hidden discrete stages, healthy, degraded, failing, each emitting a noisy
    observation, and learns the stage means, variances, and the transition
    probabilities between them. States are returned ordered by mean for readability.

    Inputs
    obs a one-dimensional observation sequence; n_states the number of hidden stages;
    iters the EM iterations; seed unused placeholder for reproducibility.

    Outputs
    Dict with the initial distribution, transition matrix, per-state means and
    variances, and the smoothed state posteriors.
    """
    obs = np.asarray(obs, float); T = len(obs); n = n_states
    pi = np.ones(n) / n
    A = np.full((n, n), 1.0 / n)
    means = np.linspace(obs.min(), obs.max(), n)
    var = np.full(n, obs.var() + 1e-6)
    gamma = np.zeros((T, n))
    for _ in range(iters):
        B = np.exp(-0.5 * (obs[:, None] - means[None, :]) ** 2 / var[None, :]) \
            / np.sqrt(2 * np.pi * var)[None, :] + 1e-300
        al = np.zeros((T, n)); c = np.zeros(T)
        al[0] = pi * B[0]; c[0] = al[0].sum(); al[0] /= c[0]
        for t in range(1, T):
            al[t] = (al[t - 1] @ A) * B[t]; c[t] = al[t].sum() + 1e-300; al[t] /= c[t]
        be = np.zeros((T, n)); be[-1] = 1.0
        for t in range(T - 2, -1, -1):
            be[t] = A @ (B[t + 1] * be[t + 1]) / c[t + 1]
        gamma = al * be; gamma /= gamma.sum(1, keepdims=True) + 1e-300
        xi = np.zeros((n, n))
        for t in range(T - 1):
            m = al[t][:, None] * A * (B[t + 1] * be[t + 1])[None, :]
            xi += m / (m.sum() + 1e-300)
        pi = gamma[0]
        A = xi / (xi.sum(1, keepdims=True) + 1e-300)
        for i in range(n):
            w = gamma[:, i]; sw = w.sum() + 1e-300
            means[i] = (w * obs).sum() / sw
            var[i] = (w * (obs - means[i]) ** 2).sum() / sw + 1e-6
    order = np.argsort(means)
    return dict(pi=pi[order], A=A[np.ix_(order, order)], means=means[order],
                vars=var[order], gamma=gamma[:, order])


def hmm_viterbi(obs, model):
    """
    Purpose
    The Viterbi decoding of a Gaussian hidden Markov model: the single most likely
    sequence of hidden stages given the observations. It turns a noisy health signal
    into a clean stage segmentation, marking when the system transitioned from healthy
    to degraded to failing.

    Inputs
    obs the observation sequence; model the dict returned by hmm_fit.

    Outputs
    The most likely hidden-state index at each time step.
    """
    obs = np.asarray(obs, float); A = model["A"]; means = model["means"]
    var = model["vars"]; pi = model["pi"]; T = len(obs); n = len(pi)
    logB = -0.5 * (obs[:, None] - means) ** 2 / var - 0.5 * np.log(2 * np.pi * var)
    logA = np.log(A + 1e-300); d = np.zeros((T, n)); psi = np.zeros((T, n), int)
    d[0] = np.log(pi + 1e-300) + logB[0]
    for t in range(1, T):
        for j in range(n):
            seq = d[t - 1] + logA[:, j]; psi[t, j] = np.argmax(seq)
            d[t, j] = seq[psi[t, j]] + logB[t, j]
    path = np.zeros(T, int); path[-1] = np.argmax(d[-1])
    for t in range(T - 2, -1, -1):
        path[t] = psi[t + 1, path[t + 1]]
    return path


def ukf_filter(z, f, h, Q, R, x0, P0, alpha=1e-3, beta=2.0, kappa=0.0):
    """
    Purpose
    The unscented Kalman filter for nonlinear state estimation. Rather than
    linearizing, it propagates a small set of deterministically chosen sigma points
    through the true nonlinear dynamics and recovers the mean and covariance from
    them, tracking a hidden state where the linear Kalman filter's assumptions fail
    and without the Jacobians an extended filter needs.

    Inputs
    z measurements of shape (T, m); f the state-transition function; h the observation
    function; Q and R the process and measurement covariances; x0 and P0 the initial
    state and covariance; alpha, beta, kappa the unscented parameters.

    Outputs
    Dict with the filtered state estimates and the innovation sequence.
    """
    x = np.atleast_1d(np.asarray(x0, float)); n = len(x); P = np.asarray(P0, float)
    z = np.atleast_2d(np.asarray(z, float))
    if z.shape[1] != np.atleast_1d(h(x)).shape[0]:
        z = z.reshape(-1, np.atleast_1d(h(x)).shape[0])
    T = z.shape[0]; lam = alpha ** 2 * (n + kappa) - n
    Wm = np.full(2 * n + 1, 1.0 / (2 * (n + lam))); Wc = Wm.copy()
    Wm[0] = lam / (n + lam); Wc[0] = lam / (n + lam) + (1 - alpha ** 2 + beta)

    def sigmas(x, P):
        S = np.linalg.cholesky((n + lam) * (P + 1e-12 * np.eye(n)))
        pts = np.zeros((2 * n + 1, n)); pts[0] = x
        for i in range(n):
            pts[i + 1] = x + S[:, i]; pts[n + i + 1] = x - S[:, i]
        return pts

    xs = np.zeros((T, n)); innov = np.zeros((T, z.shape[1]))
    for t in range(T):
        X = sigmas(x, P)
        Xp = np.array([np.atleast_1d(f(xi)) for xi in X])
        xpred = Wm @ Xp
        Ppred = Q.copy()
        for i in range(2 * n + 1):
            dx = Xp[i] - xpred; Ppred = Ppred + Wc[i] * np.outer(dx, dx)
        Zs = np.array([np.atleast_1d(h(xi)) for xi in Xp])
        zpred = Wm @ Zs
        Pzz = R.copy(); Pxz = np.zeros((n, z.shape[1]))
        for i in range(2 * n + 1):
            dz = Zs[i] - zpred; Pzz = Pzz + Wc[i] * np.outer(dz, dz)
            Pxz = Pxz + Wc[i] * np.outer(Xp[i] - xpred, dz)
        K = Pxz @ np.linalg.inv(Pzz)
        y = z[t] - zpred
        x = xpred + K @ y; P = Ppred - K @ Pzz @ K.T
        xs[t] = x; innov[t] = y
    return dict(x_filt=xs, innov=innov)


def gp_regression(t_train, y_train, t_test, length=1.0, sigma_f=1.0, sigma_n=0.1):
    """
    Purpose
    Gaussian-process regression with a squared-exponential kernel. It fits a smooth
    trend to a degradation signal and, crucially, returns a calibrated uncertainty
    band that widens where data are sparse and as the prediction extrapolates beyond
    the observations, exactly the behavior wanted for projecting a health trend toward
    failure.

    Inputs
    t_train, y_train the observed times and values; t_test the times to predict;
    length the kernel length scale; sigma_f the signal amplitude; sigma_n the noise.

    Outputs
    Dict with the predictive mean and standard deviation at the test times.
    """
    t_train = np.asarray(t_train, float); y_train = np.asarray(y_train, float)
    t_test = np.asarray(t_test, float)

    def kern(a, b):
        return sigma_f ** 2 * np.exp(-0.5 * (a[:, None] - b[None, :]) ** 2 / length ** 2)

    K = kern(t_train, t_train) + sigma_n ** 2 * np.eye(len(t_train))
    Ks = kern(t_train, t_test); Kss = kern(t_test, t_test)
    L = np.linalg.cholesky(K + 1e-9 * np.eye(len(t_train)))
    a = linalg.solve_triangular(L.T, linalg.solve_triangular(L, y_train, lower=True), lower=False)
    mean = Ks.T @ a
    v = linalg.solve_triangular(L, Ks, lower=True)
    var = np.diag(Kss) - np.sum(v ** 2, axis=0)
    return dict(mean=mean, std=np.sqrt(np.maximum(var, 1e-12)))


def bocpd(x, hazard=0.01, mu0=0.0, kappa0=1.0, alpha0=1.0, beta0=1.0):
    """
    Purpose
    Bayesian online changepoint detection (Adams and MacKay). At each step it
    maintains a posterior over the run length, the time since the last changepoint,
    using a Normal-inverse-gamma conjugate model with a Student-t predictive. The
    probability that the run length has reset spikes exactly when the signal's regime
    changes, flagging a fault onset online.

    Inputs
    x the signal; hazard the constant prior probability of a changepoint at each step;
    mu0, kappa0, alpha0, beta0 the Normal-inverse-gamma prior parameters.

    Outputs
    Dict with the changepoint probability at each step and the expected run length.
    """
    x = np.asarray(x, float); T = len(x)
    R = np.zeros((T + 1, T + 1)); R[0, 0] = 1.0
    mu = np.array([mu0]); kappa = np.array([kappa0])
    al = np.array([alpha0]); be = np.array([beta0])
    cp = np.zeros(T); erl = np.zeros(T)
    for t in range(T):
        scale = np.sqrt(be * (kappa + 1) / (al * kappa))
        pred = stats.t.pdf((x[t] - mu) / scale, df=2 * al) / scale + 1e-300
        gr = R[t, :t + 1] * pred * (1 - hazard)
        cp_prob = (R[t, :t + 1] * pred * hazard).sum()
        R[t + 1, 1:t + 2] = gr
        R[t + 1, 0] = cp_prob
        R[t + 1, :t + 2] /= R[t + 1, :t + 2].sum() + 1e-300
        # update sufficient statistics
        mu_new = np.r_[mu0, (kappa * mu + x[t]) / (kappa + 1)]
        kappa_new = np.r_[kappa0, kappa + 1]
        al_new = np.r_[alpha0, al + 0.5]
        be_new = np.r_[beta0, be + (kappa * (x[t] - mu) ** 2) / (2 * (kappa + 1))]
        mu, kappa, al, be = mu_new, kappa_new, al_new, be_new
        cp[t] = R[t + 1, 0]
        erl[t] = np.arange(t + 2) @ R[t + 1, :t + 2]
    return dict(cp_prob=cp, exp_run_length=erl)


# ===========================================================================
# GOING FURTHER 4: FROM PROBABILITIES TO DECISIONS
# ===========================================================================
def calibration_curve(probs, labels, n_bins=10):
    """
    Purpose
    A reliability diagram and Brier score for a probabilistic classifier. It bins
    predictions by their stated probability and compares each bin's mean prediction to
    the observed frequency; a well-calibrated model lands on the diagonal. The Brier
    score summarizes calibration and sharpness in one number.

    Inputs
    probs predicted probabilities; labels the binary outcomes; n_bins the number of
    bins.

    Outputs
    Dict with per-bin mean confidence and observed accuracy, the bin edges, and the
    Brier score.
    """
    probs = np.asarray(probs, float); labels = np.asarray(labels, float)
    edges = np.linspace(0, 1, n_bins + 1)
    idx = np.clip(np.digitize(probs, edges) - 1, 0, n_bins - 1)
    conf = np.array([probs[idx == b].mean() if (idx == b).any() else np.nan for b in range(n_bins)])
    acc = np.array([labels[idx == b].mean() if (idx == b).any() else np.nan for b in range(n_bins)])
    return dict(conf=conf, acc=acc, edges=edges, brier=float(np.mean((probs - labels) ** 2)))


def cost_optimal_threshold(probs, labels, c_fp, c_fn, n=200):
    """
    Purpose
    Turn predicted fault probabilities into a maintenance decision by choosing the
    alarm threshold that minimizes expected cost, given the cost of a false alarm and
    the cost of a missed fault. It replaces an arbitrary cutoff with one tuned to the
    real asymmetry between unnecessary maintenance and unexpected failure.

    Inputs
    probs predicted fault probabilities; labels the true outcomes; c_fp the false-alarm
    cost; c_fn the missed-fault cost; n the number of thresholds scanned.

    Outputs
    Dict with the scanned thresholds and their costs, and the cost-minimizing
    threshold and its cost.
    """
    probs = np.asarray(probs, float); labels = np.asarray(labels, int)
    th = np.linspace(0, 1, n); cost = np.zeros(n)
    for i, t in enumerate(th):
        pred = probs >= t
        fp = np.sum(pred & (labels == 0)); fn = np.sum(~pred & (labels == 1))
        cost[i] = c_fp * fp + c_fn * fn
    j = int(np.argmin(cost))
    return dict(thresholds=th, cost=cost, best=float(th[j]), best_cost=float(cost[j]))


def ds_combine(m1, m2):
    """
    Purpose
    Dempster's rule of combination for evidence fusion. Each source assigns belief
    mass to subsets of the hypotheses, including the whole set as explicit ignorance.
    The rule fuses two sources into one belief, concentrating mass where they agree
    and normalizing away their conflict, a way to combine several detectors that
    represents uncertainty more honestly than a single probability.

    Inputs
    m1, m2 mass functions as dicts mapping a frozenset of hypotheses to its mass.

    Outputs
    Dict mapping each surviving subset to its combined mass.
    """
    comb = {}; conflict = 0.0
    for A, a in m1.items():
        for B, b in m2.items():
            C = A & B
            if len(C) == 0:
                conflict += a * b
            else:
                comb[C] = comb.get(C, 0.0) + a * b
    if conflict >= 1 - 1e-12:
        return {k: 0.0 for k in comb}
    return {k: v / (1 - conflict) for k, v in comb.items()}


def _demo():
    rng = np.random.default_rng(0)

    # ---- distribution & anomaly ----
    x = np.r_[rng.normal(0, 1, 200), rng.normal(5, 1, 120)]   # bimodal regimes
    grid = np.linspace(-4, 9, 50)
    dens = kde_pdf(x, grid)
    print("KDE integrates to ~%.2f" % np.trapezoid(dens, grid))
    Xg = np.c_[x, x + rng.normal(0, 0.5, len(x))]
    gm = gmm_fit(Xg, 2)
    print("GMM weights:", np.round(gm["weights"], 2), "loglik %.0f" % gm["loglik"])
    xo = np.r_[rng.normal(10, 1, 40), [22.0, -3.0]]
    print("MAD flags:", int(mad_zscore(xo)["outlier"].sum()),
          "| Grubbs outlier:", grubbs(xo)["is_outlier"],
          "| ESD found:", generalized_esd(xo, 5)["n_found"])

    # ---- bayesian & state ----
    post = bayes_update([0.9, 0.1], [0.2, 0.8])
    print("posterior fault prob: %.2f" % post[1])
    bb = beta_binomial(1, 1, 3, 20)
    print("defect-rate posterior mean %.3f ci (%.3f, %.3f)" % (bb["mean"], *bb["ci"]))
    # small bayes net: Fault -> Vib, Fault -> Temp
    net = {
        "Fault": dict(parents=[], cpt={(): 0.05}),
        "Vib":   dict(parents=["Fault"], cpt={(0,): 0.1, (1,): 0.85}),
        "Temp":  dict(parents=["Fault"], cpt={(0,): 0.15, (1,): 0.7}),
    }
    pf = bayes_net_infer(net, {"Vib": 1, "Temp": 1}, "Fault")
    print("P(Fault | high vib & temp) = %.2f" % pf)
    # kalman: random-walk level + noisy obs
    T = 60; true = np.cumsum(rng.normal(0, 0.1, T)) + 1
    z = (true + rng.normal(0, 0.5, T)).reshape(-1, 1)
    kf = kalman_filter(z, F=np.array([[1.0]]), H=np.array([[1.0]]),
                       Q=np.array([[0.02]]), R=np.array([[0.25]]),
                       x0=[0.0], P0=np.array([[1.0]]))
    print("KF RMSE %.3f (meas RMSE %.3f)" %
          (np.sqrt(np.mean((kf["x_filt"][:, 0] - true) ** 2)),
           np.sqrt(np.mean((z[:, 0] - true) ** 2))))
    # particle filter: nonlinear degradation
    Tg = 40; st = np.zeros(Tg)
    for i in range(1, Tg):
        st[i] = st[i - 1] + 0.05 + 0.02 * st[i - 1]
    zg = st ** 2 + rng.normal(0, 0.3, Tg)
    pfk = particle_filter(zg, lambda s: s + 0.05 + 0.02 * s, lambda s: s ** 2,
                          0.05, 0.3, x0=0.0)
    print("PF final state %.2f (true %.2f)" % (pfk["mean"][-1], st[-1]))

    # ---- reliability ----
    tf = stats.weibull_min.rvs(2.2, scale=900, size=80, random_state=1)
    wf = weibull_fit(tf)
    print("Weibull shape %.2f scale %.0f" % (wf["shape"], wf["scale"]))
    dur = np.r_[tf[:60], np.full(20, 1200.0)]
    ev = np.r_[np.ones(60), np.zeros(20)]
    km = kaplan_meier(dur, ev)
    print("KM median survival near t =", int(km["t"][np.argmin(np.abs(km["S"] - 0.5))]))
    Xc = np.c_[rng.normal(0, 1, 80), rng.normal(0, 1, 80)]
    cph = cox_ph(Xc, dur, ev)
    print("Cox hazard ratios:", np.round(cph["hazard_ratio"], 2))

    # ---- going further ----
    tt = np.arange(30.0); yy = 0.5 + 0.08 * tt + rng.normal(0, 0.15, 30)
    rl = rul_predict(tt, yy, threshold=4.0)
    print("RUL %.0f [%0.f, %.0f]" % (rl["rul"], rl["rul_lo"], rl["rul_hi"]))
    pm = prognostic_metrics(np.arange(10), np.linspace(40, 5, 10), np.linspace(45, 5, 10))
    print("prognostic horizon:", pm["prognostic_horizon"], "rel acc %.2f" % pm["rel_accuracy"])

    Xm = rng.multivariate_normal([0, 0], [[1, 0.8], [0.8, 1]], 120)
    Xm = np.vstack([Xm, [2.5, -2.5]])     # off-correlation outlier
    mh = mahalanobis(Xm, robust=True)
    print("Mahalanobis outliers (robust):", int(mh["outlier"].sum()))
    hx = np.r_[rng.normal(0, 1, 400), rng.gamma(2, 1.5, 80)]
    pot = pot_threshold(hx, q=0.95, exceed_prob=1e-3)
    print("EVT alarm level %.2f (max seen %.2f)" % (pot["level"], hx.max()))
    cal = rng.normal(0, 1, 500)
    ct = conformal_threshold(np.abs(cal), alpha=0.05)
    print("conformal threshold %.2f (coverage %.2f)" % (ct["threshold"], ct["coverage"]))

    seq = np.r_[rng.normal(0, 0.4, 40), rng.normal(2, 0.4, 35), rng.normal(5, 0.5, 30)]
    hm = hmm_fit(seq, 3); path = hmm_viterbi(seq, hm)
    print("HMM stage means:", np.round(hm["means"], 1), "final stage:", path[-1])
    Tn = 40; xt = np.zeros(Tn)
    for i in range(1, Tn):
        xt[i] = xt[i - 1] + 0.05 + 0.02 * xt[i - 1]
    zn = (xt ** 2 + rng.normal(0, 0.3, Tn)).reshape(-1, 1)
    uk = ukf_filter(zn, lambda s: s + 0.05 + 0.02 * s, lambda s: s ** 2,
                    np.array([[0.0025]]), np.array([[0.09]]), [0.0], np.array([[1.0]]))
    print("UKF final %.2f (true %.2f)" % (uk["x_filt"][-1, 0], xt[-1]))
    gtr = np.linspace(0, 10, 18); gy = 0.1 * gtr ** 1.5 + rng.normal(0, 0.2, 18)
    gp = gp_regression(gtr, gy, np.linspace(0, 14, 40), length=2.5, sigma_f=2.0, sigma_n=0.2)
    print("GP extrapolation std grows: %.2f -> %.2f" % (gp["std"][20], gp["std"][-1]))
    sigc = np.r_[rng.normal(0, 0.5, 60), rng.normal(3, 0.5, 60)]
    bc = bocpd(sigc)
    print("BOCPD changepoint near t =", int(np.argmin(np.diff(bc["exp_run_length"])) + 1))

    p_good = rng.uniform(0, 1, 1000); y_good = (rng.uniform(0, 1, 1000) < p_good).astype(int)
    cc = calibration_curve(p_good, y_good)
    print("calibration Brier (well-calibrated) %.3f" % cc["brier"])
    pf = rng.uniform(0, 1, 500); yf = (rng.uniform(0, 1, 500) < pf).astype(int)
    co = cost_optimal_threshold(pf, yf, c_fp=1.0, c_fn=10.0)
    print("cost-optimal threshold %.2f" % co["best"])
    H, F, U = frozenset(["H"]), frozenset(["F"]), frozenset(["H", "F"])
    m1 = {F: 0.6, U: 0.4}; m2 = {F: 0.5, H: 0.1, U: 0.4}
    fused = ds_combine(m1, m2)
    print("DS fused belief in fault: %.2f" % fused.get(F, 0.0))


if __name__ == "__main__":
    _demo()
