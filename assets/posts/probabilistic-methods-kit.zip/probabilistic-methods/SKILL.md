---
name: probabilistic-methods
description: >
  Probabilistic methods for condition monitoring and prognostics: density estimation
  and anomaly scoring (kernel density, Gaussian mixtures), robust outlier tests
  (MAD z-score, Grubbs, generalized ESD), Bayesian updating and Bayesian networks for
  fault isolation, Kalman and particle filtering for state estimation and residual
  generation, and reliability/survival analysis (Weibull, Kaplan-Meier, Cox
  proportional hazards, hazard-rate estimation), plus a going-further set: remaining-
  useful-life prediction and prognostic metrics, robust Mahalanobis and extreme-value
  and conformal anomaly thresholds, hidden Markov models, unscented Kalman and
  Gaussian-process and Bayesian-changepoint methods, and calibration, cost-optimal
  thresholds, and Dempster-Shafer fusion. Use when the task is to model normal,
  infer a hidden fault from noisy evidence, or estimate time-to-failure and risk, and
  to generate correct numpy + scipy Python.
---

# Probabilistic methods for condition monitoring

A routing layer over a tested engine. Read this file, pick the family, open the
matching reference, and call the engine in `scripts/probstats.py`.

How to route a request
1. What is normal, is this an anomaly, or how many operating regimes? references/01-distribution-and-anomaly.md (kde_pdf, novelty_score, gmm_fit, gmm_score, mad_zscore, grubbs, generalized_esd)
2. What does the evidence imply about a hidden fault or state? references/02-probabilistic-reasoning.md (bayes_update, sequential_bayes, beta_binomial, bayes_net_infer, kalman_filter, particle_filter)
3. How long until failure, and what drives risk? references/03-reliability-and-survival.md (weibull_fit, weibull_reliability, kaplan_meier, cox_ph, nelson_aalen)
4. Remaining useful life and how to judge it? references/04-remaining-useful-life.md (rul_predict, prognostic_metrics)
5. Sharper anomaly detection (correlation-aware, tail-based, or calibrated)? references/05-sharper-anomaly-detection.md (mahalanobis, pot_threshold, conformal_threshold)
6. Discrete stages, nonlinear state, smooth trends, or change onset? references/06-more-state-and-inference.md (hmm_fit, hmm_viterbi, ukf_filter, gp_regression, bocpd)
7. Is the probability honest, what threshold, how to fuse detectors? references/07-from-probabilities-to-decisions.md (calibration_curve, cost_optimal_threshold, ds_combine)
Always consult references/decision-map.md to confirm the choice and
references/pitfalls.md before trusting a score, posterior, or life estimate.

Core functionalities
Estimate densities and score novelty with kde_pdf and novelty_score; model operating
regimes with gmm_fit and gmm_score. Catch outliers robustly with mad_zscore, grubbs,
and generalized_esd. Reason from evidence to fault with bayes_update, sequential_bayes,
beta_binomial, and bayes_net_infer. Estimate hidden states and residuals with
kalman_filter and particle_filter. Model time-to-failure and risk with weibull_fit,
weibull_reliability, kaplan_meier, cox_ph, and nelson_aalen. Predict remaining life
with rul_predict and judge it with prognostic_metrics; sharpen anomaly detection with
mahalanobis, pot_threshold, and conformal_threshold; complete the inference family with
hmm_fit, hmm_viterbi, ukf_filter, gp_regression, and bocpd; and turn probabilities into
decisions with calibration_curve, cost_optimal_threshold, and ds_combine. The engine is
numpy + scipy only, and every function carries a plain-prose autodoc block.

Workflow
Model normal and score novelty, screen single readings with a robust test, isolate a
suspected fault by Bayesian inference, estimate the hidden degradation state with a
filter, fit a life model and read the hazard, then fuse the anomaly score, the state
estimate, and the life model into a fault probability and a remaining-life figure.

Guardrails
Standardize features before density or distance computation. State priors and
likelihoods explicitly. Always include censored units in life estimates. Check
proportional hazards before trusting a Cox model, and use exact Bayesian-network
inference only on small, sparse graphs. Run python scripts/probstats.py to self-test.
