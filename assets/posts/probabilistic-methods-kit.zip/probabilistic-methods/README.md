# Probabilistic methods for condition monitoring

A VS Code Copilot skill in progressive-disclosure layout: a routing `SKILL.md`, topic
reference docs, a tested `probstats.py` engine (numpy + scipy only) implementing every
method, and Copilot integration files.

## Layout

- `SKILL.md` routes a request to the right reference and engine function.
- `references/` holds the per-topic docs, a decision map, rules of thumb, pitfalls,
  an at-a-glance table, references, and a worked case study.
- `scripts/probstats.py` is the engine; run it for a self-test across all three families.
- `copilot/` has a chat mode, two prompts (`/diagnose`, `/characterize`), and instructions.
- `assets/` holds the rendered monograph and the explorer script.

## Reference docs

- `references/01-distribution-and-anomaly.md` covers distribution and anomaly.
- `references/02-probabilistic-reasoning.md` covers probabilistic reasoning.
- `references/03-reliability-and-survival.md` covers reliability and prognostics.
- `references/04-remaining-useful-life.md` covers remaining useful life and prognostic metrics.
- `references/05-sharper-anomaly-detection.md` covers sharper anomaly detection.
- `references/06-more-state-and-inference.md` covers more state and inference tools.
- `references/07-from-probabilities-to-decisions.md` covers from probabilities to decisions.
- `references/decision-map.md`, `references/rules-of-thumb.md`, `references/pitfalls.md`,
  `references/at-a-glance.md`, `references/references.md`, `references/case-study.md`.

## Families

Distribution and anomaly (KDE, GMM, robust outlier tests); probabilistic reasoning
(Bayesian updating, Bayesian networks, Kalman and particle filtering); reliability and
survival (Weibull, Kaplan-Meier, Cox proportional hazards, hazard-rate estimation).
