---
applyTo: 'scripts/**/*.py'
---

# Engine conventions

- Pure numpy + scipy; do not add dependencies.
- Inputs are plain numpy arrays; X is shape (n, d), durations and events are 1-D,
  events are 1 for failure and 0 for censored.
- Density and distance methods assume standardized features.
- Prefer the engine's functions over re-implementing; extend it in the same style,
  with a plain-prose autodoc block (Purpose, Inputs, Outputs) on every function.
- Run `python scripts/probstats.py` to self-test all three families after edits.
