---
mode: agent
description: 'Fit a life model to failure-time data and report risk and remaining life.'
---

# /characterize

Given failure (and censored) times, optionally with covariates:

1. Fit a Weibull model with `weibull_fit`; report the shape (regime), scale, and a
   Weibull probability plot from `weibull_plot_points` as a fit check.
2. Estimate the survival curve nonparametrically with `kaplan_meier`, handling
   censoring, and the cumulative hazard with `nelson_aalen`; read the hazard shape.
3. If covariates are present, fit `cox_ph` and report hazard ratios with intervals.
4. Translate into action: reliability at the current age, B10 life, and a
   remaining-life estimate; note the assumptions (single failure mode, proportional
   hazards, non-informative censoring).

Use only `scripts/probstats.py`. Always include censored units in the fit.
