---
mode: agent
description: 'Isolate a fault from noisy symptoms and estimate the hidden state.'
---

# /diagnose

Given symptom readings or a sensor stream:

1. Score the operating point for novelty with `kde_pdf` / `novelty_score` (or a fitted
   `gmm_fit` model) and screen single readings with `mad_zscore` or `generalized_esd`.
2. If a fault is suspected, fuse the symptoms: build a small `bayes_net_infer` network
   (fault -> symptoms) or apply `sequential_bayes`, and report the posterior over faults.
3. Estimate the hidden degradation state with `kalman_filter` (linear) or
   `particle_filter` (nonlinear), and report the innovation/residual.
4. State the prior and likelihoods used, and list the assumptions from
   `references/pitfalls.md` that the conclusion depends on.

Use only `scripts/probstats.py`. Report probabilities, not just point labels.
