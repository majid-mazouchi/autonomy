(function(){
  var INK="#221d17",MUTE="#7a6f5e",RUST="#b0492f",TEAL="#1f6f6a",
      OCHRE="#c4922b",LINE="#d9cfb8",CREAM="#fbf7ee";

  function fit(c){
    var dpr=window.devicePixelRatio||1, w=c.clientWidth||c.parentElement.clientWidth-2;
    var h=parseInt(c.getAttribute("height"),10)||200;
    c.width=w*dpr; c.height=h*dpr; var ctx=c.getContext("2d");
    ctx.setTransform(dpr,0,0,dpr,0,0); return {ctx:ctx,w:w,h:h};
  }
  function rng(seed){ var s=seed>>>0; return function(){ s=(s*1664525+1013904223)>>>0; return s/4294967296; }; }
  function gauss(n,seed){ var r=rng(seed),a=[],i; for(i=0;i<n;i++){
    var u=1-r(),v=1-r(); a.push(Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)); } return a; }

  // ======================================================================
  // A. KDE bandwidth
  // ======================================================================
  (function kde(){
    var cv=document.getElementById("ex-kde-canvas"); if(!cv) return;
    var sBW=document.getElementById("ex-kde-bw"), read=document.getElementById("ex-kde-read"),
        cap=document.getElementById("ex-kde-cap");
    // fixed bimodal sample
    var g1=gauss(90,11), g2=gauss(70,22), data=[], i;
    for(i=0;i<90;i++)data.push(2.0+1.0*g1[i]);
    for(i=0;i<70;i++)data.push(7.0+1.0*g2[i]);
    var lo=-2, hi=11;
    function draw(){
      var bw=parseFloat(sBW.value)/100*2.4+0.08;   // 0.08 .. 2.48
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=28;ctx.clearRect(0,0,w,h);
      var x0=pad,x1=w-pad,y1=h-pad,yt=16;
      function X(v){return x0+(v-lo)/(hi-lo)*(x1-x0);}
      // histogram
      var nb=26, bins=new Array(nb).fill(0);
      for(i=0;i<data.length;i++){var b=Math.floor((data[i]-lo)/(hi-lo)*nb);if(b>=0&&b<nb)bins[b]++;}
      var bmax=Math.max.apply(null,bins);
      ctx.fillStyle=LINE;
      for(i=0;i<nb;i++){var bx=X(lo+(i)/nb*(hi-lo)),bw2=(x1-x0)/nb;
        var bh=bins[i]/bmax*(y1-yt)*0.55; ctx.fillRect(bx,y1-bh,bw2-1,bh);}
      // KDE curve
      var N=180, mx=0, dens=new Float64Array(N);
      for(i=0;i<N;i++){var xv=lo+i/(N-1)*(hi-lo),s=0,j;
        for(j=0;j<data.length;j++){var u=(xv-data[j])/bw; s+=Math.exp(-0.5*u*u);}
        dens[i]=s/(data.length*bw*Math.sqrt(2*Math.PI)); if(dens[i]>mx)mx=dens[i];}
      ctx.strokeStyle=TEAL;ctx.lineWidth=1.6;ctx.beginPath();
      for(i=0;i<N;i++){var px=X(lo+i/(N-1)*(hi-lo)),py=y1-dens[i]/(mx*1.1)*(y1-yt);
        if(i===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);}ctx.stroke();
      ctx.strokeStyle=MUTE;ctx.lineWidth=0.6;ctx.beginPath();ctx.moveTo(x0,y1);ctx.lineTo(x1,y1);ctx.stroke();
      var state = bw<0.4?"under-smoothed (spiky, fits noise)":bw>1.4?"over-smoothed (the two regimes merge)":"well-balanced (both regimes resolved)";
      var col = (bw<0.4||bw>1.4)?RUST:TEAL;
      read.innerHTML="bandwidth h = <b>"+bw.toFixed(2)+"</b> &rarr; <b style='color:"+col+"'>"+state+"</b>";
      cap.textContent="A kernel density estimate sums a Gaussian bump on every sample. Too small a bandwidth chases noise; too large erases real structure, here the two operating regimes. The bandwidth is the one knob that matters.";
    }
    sBW.addEventListener("input",draw); window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // B. Bayesian updating
  // ======================================================================
  (function bayes(){
    var cv=document.getElementById("ex-bay-canvas"); if(!cv) return;
    var sN=document.getElementById("ex-bay-n"), read=document.getElementById("ex-bay-read"),
        cap=document.getElementById("ex-bay-cap");
    var prior=0.08;                 // prior P(fault)
    var LR=1.6;                     // likelihood ratio per fault-consistent observation
    function draw(){
      var N=parseInt(sN.value,10), i;
      var traj=[prior], odds=prior/(1-prior);
      for(i=0;i<N;i++){ odds*=LR; traj.push(odds/(1+odds)); }
      var post=traj[traj.length-1];
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=30;ctx.clearRect(0,0,w,h);
      var x0=pad,x1=w-pad,y1=h-pad,yt=16, maxN=20;
      // axes
      ctx.strokeStyle=MUTE;ctx.lineWidth=0.6;ctx.beginPath();ctx.moveTo(x0,y1);ctx.lineTo(x1,y1);ctx.stroke();
      ctx.strokeStyle=LINE;ctx.setLineDash([3,3]);ctx.beginPath();
      ctx.moveTo(x0,yt+(y1-yt)*0.5);ctx.lineTo(x1,yt+(y1-yt)*0.5);ctx.stroke();ctx.setLineDash([]);
      ctx.fillStyle=MUTE;ctx.font="10px monospace";ctx.fillText("P(fault)",x0,12);ctx.fillText("0.5",x1-22,yt+(y1-yt)*0.5-3);
      // trajectory
      ctx.strokeStyle=RUST;ctx.lineWidth=1.6;ctx.beginPath();
      for(i=0;i<traj.length;i++){var px=x0+i/maxN*(x1-x0),py=y1-traj[i]*(y1-yt);
        if(i===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);}ctx.stroke();
      for(i=0;i<traj.length;i++){var px=x0+i/maxN*(x1-x0),py=y1-traj[i]*(y1-yt);
        ctx.fillStyle=RUST;ctx.beginPath();ctx.arc(px,py,2.2,0,7);ctx.fill();}
      ctx.fillStyle=MUTE;ctx.fillText("observations",x1-90,y1+18);
      var col = post>0.5?RUST:MUTE;
      read.innerHTML="prior <b>"+prior.toFixed(2)+"</b>, after <b>"+N+"</b> fault-consistent observation"+(N===1?"":"s")+" &rarr; P(fault) = <b style='color:"+col+"'>"+post.toFixed(2)+"</b>";
      cap.textContent="Each observation multiplies the odds of a fault by its likelihood ratio. A weak prior plus a run of consistent evidence compounds into near-certainty; one piece of evidence rarely settles it.";
    }
    sN.addEventListener("input",draw); window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // C. Weibull shape
  // ======================================================================
  (function weib(){
    var cv=document.getElementById("ex-wei-canvas"); if(!cv) return;
    var sK=document.getElementById("ex-wei-k"), read=document.getElementById("ex-wei-read"),
        cap=document.getElementById("ex-wei-cap");
    function draw(){
      var k=parseFloat(sK.value)/100*3.5+0.4;   // 0.4 .. 3.9
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=30;ctx.clearRect(0,0,w,h);
      var x0=pad,x1=w-pad,y1=h-pad,yt=16, tmax=2.5, i, N=160;
      function X(t){return x0+t/tmax*(x1-x0);}
      // hazard
      var haz=new Float64Array(N), hmax=0;
      for(i=0;i<N;i++){var t=0.01+i/(N-1)*tmax; haz[i]=k*Math.pow(t,k-1); if(haz[i]>hmax&&t<tmax)hmax=Math.min(haz[i],6);}
      hmax=Math.min(hmax,6)||1;
      ctx.strokeStyle=MUTE;ctx.lineWidth=0.6;ctx.beginPath();ctx.moveTo(x0,y1);ctx.lineTo(x1,y1);ctx.stroke();
      ctx.fillStyle=OCHRE;ctx.font="10px monospace";ctx.fillText("hazard h(t)",x0,12);
      ctx.strokeStyle=OCHRE;ctx.lineWidth=1.6;ctx.beginPath();
      for(i=0;i<N;i++){var t=0.01+i/(N-1)*tmax,py=y1-Math.min(haz[i],hmax)/hmax*(y1-yt);
        if(i===0)ctx.moveTo(X(t),py);else ctx.lineTo(X(t),py);}ctx.stroke();
      // reliability (overlay scaled to same box)
      ctx.fillStyle=TEAL;ctx.fillText("reliability R(t)",x1-100,12);
      ctx.strokeStyle=TEAL;ctx.lineWidth=1.6;ctx.beginPath();
      for(i=0;i<N;i++){var t=0.01+i/(N-1)*tmax,R=Math.exp(-Math.pow(t,k)),py=y1-R*(y1-yt);
        if(i===0)ctx.moveTo(X(t),py);else ctx.lineTo(X(t),py);}ctx.stroke();
      var regime = k<0.95?"infant mortality (falling hazard)":k<1.05?"random failure (constant hazard)":"wear-out (rising hazard)";
      var col = k<0.95?TEAL:k<1.05?OCHRE:RUST;
      read.innerHTML="shape k = <b>"+k.toFixed(2)+"</b> &rarr; <b style='color:"+col+"'>"+regime+"</b>";
      cap.textContent="The Weibull shape names the failure regime: below one the hazard falls (early-life defects), at one it is constant (random), above one it rises (wear-out). The same parameter sets how reliability decays.";
    }
    sK.addEventListener("input",draw); window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // D. Remaining useful life
  // ======================================================================
  (function rul(){
    var cv=document.getElementById("ex-rul-canvas"); if(!cv) return;
    var sN=document.getElementById("ex-rul-n"), read=document.getElementById("ex-rul-read"),
        cap=document.getElementById("ex-rul-cap");
    var N=44, slope=0.11, b0=0.4, thr=4.5, g=gauss(N,53), i;
    var ytrue=[], yobs=[];
    for(i=0;i<N;i++){ ytrue.push(b0+slope*i); yobs.push(ytrue[i]+0.16*g[i]); }
    var eol=(thr-b0)/slope;
    function draw(){
      var nobs=parseInt(sN.value,10);
      // least squares on first nobs points
      var sx=0,sy=0,sxx=0,sxy=0,k;
      for(k=0;k<nobs;k++){ sx+=k; sy+=yobs[k]; sxx+=k*k; sxy+=k*yobs[k]; }
      var a=(nobs*sxy-sx*sy)/(nobs*sxx-sx*sx+1e-9), bb=(sy-a*sx)/nobs;
      // residual std
      var ss=0; for(k=0;k<nobs;k++){var r=yobs[k]-(a*k+bb); ss+=r*r;}
      var sd=Math.sqrt(ss/Math.max(nobs-2,1));
      var tc=(thr-bb)/Math.max(a,1e-6);
      // crossing uncertainty: propagate slope/intercept sd (approx)
      var se_a=sd/Math.sqrt(Math.max(sxx-sx*sx/nobs,1e-6));
      var tc_lo=(thr-bb)/Math.max(a+1.8*se_a,1e-6), tc_hi=(thr-bb)/Math.max(a-1.8*se_a,1e-6);
      var rulv=Math.max(0,tc-(nobs-1));
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=30;ctx.clearRect(0,0,w,h);
      var x0=pad,x1=w-pad,y1=h-pad,yt=14, tmax=eol+6, ymax=thr+1.2;
      function X(t){return x0+t/tmax*(x1-x0);} function Y(v){return y1-v/ymax*(y1-yt);}
      // threshold
      ctx.strokeStyle=RUST;ctx.setLineDash([3,3]);ctx.beginPath();ctx.moveTo(x0,Y(thr));ctx.lineTo(x1,Y(thr));ctx.stroke();ctx.setLineDash([]);
      ctx.fillStyle=RUST;ctx.font="10px monospace";ctx.fillText("failure threshold",x0+4,Y(thr)-3);
      // crossing band
      if(isFinite(tc_lo)&&isFinite(tc_hi)){ctx.fillStyle="rgba(31,111,106,0.18)";
        ctx.fillRect(X(Math.max(tc_lo,0)),yt,X(tc_hi)-X(Math.max(tc_lo,0)),y1-yt);}
      // true EOL
      ctx.strokeStyle=INK;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(X(eol),yt);ctx.lineTo(X(eol),y1);ctx.stroke();
      ctx.fillStyle=INK;ctx.fillText("true EOL",X(eol)-46,y1-4);
      // projection
      ctx.strokeStyle=TEAL;ctx.lineWidth=1.4;ctx.setLineDash([5,3]);ctx.beginPath();
      ctx.moveTo(X(0),Y(bb));ctx.lineTo(X(tmax),Y(a*tmax+bb));ctx.stroke();ctx.setLineDash([]);
      // observed points
      ctx.fillStyle=INK;for(k=0;k<nobs;k++){ctx.beginPath();ctx.arc(X(k),Y(yobs[k]),2.3,0,7);ctx.fill();}
      read.innerHTML="after <b>"+nobs+"</b> cycles &rarr; RUL <b style='color:"+TEAL+"'>"+rulv.toFixed(0)+"</b> cycles, interval width <b>"+Math.max(0,(tc_hi-tc_lo)).toFixed(0)+"</b> (true EOL "+eol.toFixed(0)+")";
      cap.textContent="A trend fitted to the health index so far is projected to the failure threshold. Early on, few points give a wide, uncertain crossing; as observations accumulate, the estimate converges and the interval tightens.";
    }
    sN.addEventListener("input",draw); window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // E. Calibration
  // ======================================================================
  (function calib(){
    var cv=document.getElementById("ex-cal-canvas"); if(!cv) return;
    var sS=document.getElementById("ex-cal-s"), read=document.getElementById("ex-cal-read"),
        cap=document.getElementById("ex-cal-cap");
    var n=4000, r=rng(61), pt=[], y=[], i;
    for(i=0;i<n;i++){ var p=r(); pt.push(p); y.push(r()<p?1:0); }
    function logit(p){return Math.log(p/(1-p));}
    function sig(z){return 1/(1+Math.exp(-z));}
    function draw(){
      var s=parseFloat(sS.value)/100;          // 0 = calibrated, 1 = very overconfident
      var nb=10, conf=new Array(nb).fill(0), acc=new Array(nb).fill(0), cnt=new Array(nb).fill(0);
      var brier=0;
      for(i=0;i<n;i++){
        var pp=sig(logit(Math.min(Math.max(pt[i],1e-3),1-1e-3))*(1+2.2*s));
        var b=Math.min(Math.floor(pp*nb),nb-1);
        conf[b]+=pp; acc[b]+=y[i]; cnt[b]++; brier+=(pp-y[i])*(pp-y[i]);
      }
      brier/=n;
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=32;ctx.clearRect(0,0,w,h);
      var sz=Math.min(w-2*pad,h-2*pad), x0=pad, y1=h-pad;
      function X(v){return x0+v*sz;} function Y(v){return y1-v*sz;}
      // diagonal
      ctx.strokeStyle=MUTE;ctx.setLineDash([4,3]);ctx.beginPath();ctx.moveTo(X(0),Y(0));ctx.lineTo(X(1),Y(1));ctx.stroke();ctx.setLineDash([]);
      // axes
      ctx.strokeStyle=LINE;ctx.lineWidth=0.8;ctx.beginPath();ctx.moveTo(X(0),Y(0));ctx.lineTo(X(1),Y(0));ctx.moveTo(X(0),Y(0));ctx.lineTo(X(0),Y(1));ctx.stroke();
      ctx.fillStyle=MUTE;ctx.font="10px monospace";ctx.fillText("predicted",X(0.62),Y(-0.02)+14);ctx.save();ctx.translate(X(-0.04)-6,Y(0.5));ctx.rotate(-Math.PI/2);ctx.fillText("observed",0,0);ctx.restore();
      // curve
      var col = s<0.12?TEAL:RUST;
      ctx.strokeStyle=col;ctx.lineWidth=1.7;ctx.beginPath();var started=false;
      for(var b=0;b<nb;b++){ if(cnt[b]>0){var cx=conf[b]/cnt[b],cy=acc[b]/cnt[b];
        if(!started){ctx.moveTo(X(cx),Y(cy));started=true;}else ctx.lineTo(X(cx),Y(cy));
        ctx.fillStyle=col;ctx.fillRect(X(cx)-2,Y(cy)-2,4,4);} }
      ctx.stroke();
      read.innerHTML="miscalibration <b>"+(s*100).toFixed(0)+"%</b> &rarr; Brier score <b style='color:"+col+"'>"+brier.toFixed(3)+"</b>; "+(s<0.12?"on the diagonal (honest)":"bowed off the diagonal (overconfident)");
      cap.textContent="A reliability diagram plots stated probability against observed frequency. A calibrated model lands on the diagonal; an overconfident one bows away from it, and the Brier score rises. A probability is only useful if it is honest.";
    }
    sS.addEventListener("input",draw); window.addEventListener("resize",draw); draw();
  })();
})();
