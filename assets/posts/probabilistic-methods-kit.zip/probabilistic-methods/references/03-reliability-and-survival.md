# Reliability and prognostics, how long until failure, and at what risk?

_Detection and state estimation say what is wrong now; reliability analysis says what it means for the future. From failure times, with censoring handled honestly, it estimates the time-to-failure distribution, the survival curve, the effect of operating conditions, and the current failure rate._

## Weibull analysis

**Essence.** The workhorse life distribution. Its shape parameter names the failure regime, below one infant mortality with a falling hazard, one random failure, above one wear-out with a rising hazard, and its scale is the characteristic life. A probability plot fits and checks it at once.

**In plain words.** The Weibull distribution is the default model for time-to-failure because its two parameters carry physical meaning. The shape parameter distinguishes the three classic regimes: less than one means the hazard, the failure rate among survivors, falls over time, the signature of infant mortality from manufacturing defects; equal to one means a constant hazard, random failure independent of age; greater than one means a rising hazard, wear-out from fatigue or erosion. The scale parameter is the characteristic life, the age by which about 63 percent have failed. Fitting is by maximum likelihood, and a Weibull probability plot, which linearizes the distribution, doubles as a goodness-of-fit check: the points fall on a line when the model fits.

**Diagnostic example.** A fleet of bearings is fitted with a Weibull shape of about 2.3, confirming a wear-out mechanism rather than random failure. The reliability curve then gives the probability a unit survives to any age, and the B10 life, the age at which ten percent have failed, sets a conservative maintenance interval.

**Engine call.** `weibull_fit(t); weibull_reliability(t, shape, scale); weibull_plot_points(t)`

```python
import numpy as np
from scipy import stats

def weibull_fit(t):
    shape, loc, scale = stats.weibull_min.fit(t, floc=0)
    return dict(shape=shape, scale=scale)          # k<1,=1,>1 regimes

def weibull_reliability(t, k, lam):
    return dict(R=np.exp(-(t/lam)**k), h=(k/lam)*(t/lam)**(k-1))
```

**Practical note.** Estimate parameters by maximum likelihood and report confidence intervals, since small failure samples give wide uncertainty. A single Weibull assumes one failure mode; mixed modes, a falling then rising hazard, need a competing-risks or mixture model, visible as a kink in the probability plot. Always include censored units in the fit, since dropping survivors biases the life estimate short.

**Reference.** Weibull (1951), J. Appl. Mech. 18; Meeker & Escobar (1998), Statistical Methods for Reliability.

## Kaplan-Meier estimator

**Essence.** The nonparametric survival curve. It estimates the probability of surviving past each time without assuming any distribution, and it correctly handles censoring, units still running or withdrawn before failing, which naive averages of failure times get wrong.

**In plain words.** Sometimes you do not want to assume a Weibull or any other form; you just want the empirical probability of survival over time. The Kaplan-Meier estimator provides it as a product over observed failure times, at each one multiplying the running survival by the fraction of the at-risk population that survived that instant. Its essential feature is the correct treatment of censoring: units still operating, or removed for unrelated reasons, contribute to the at-risk count up to their last-seen time and then drop out without counting as failures, so the curve uses all the information without the bias that ignoring or mishandling survivors would introduce. Comparing two such curves, for two duty cycles or designs, shows directly which survives longer.

**Diagnostic example.** Two pump populations run under mild and harsh duty, many still operating at study end. Kaplan-Meier curves, with the censored survivors marked, show the harsh-duty population's survival dropping below 50 percent far earlier, quantifying the duty effect without assuming a failure distribution.

**Engine call.** `kaplan_meier(durations, events)`

```python
import numpy as np

def kaplan_meier(durations, events):   # events: 1 fail, 0 censored
    S = 1.0; t_out = [0.0]; S_out = [1.0]
    for tt in np.unique(durations[events == 1]):
        at_risk = np.sum(durations >= tt)
        d = np.sum((durations == tt) & (events == 1))
        S *= (1 - d / at_risk); t_out.append(tt); S_out.append(S)
    return np.array(t_out), np.array(S_out)
```

**Practical note.** Censoring is assumed non-informative; if units are pulled precisely because they look about to fail, the curve is biased, so check why censoring occurred. The estimate is uncertain where few remain at risk, in the long right tail, so show confidence bands and read the tail cautiously. To test whether two curves truly differ, use a log-rank test rather than eyeballing the gap.

**Reference.** Kaplan & Meier (1958), JASA 53; Klein & Moeschberger (2003), Survival Analysis.

## Cox proportional hazards

**Essence.** A regression for failure risk. It relates covariates, operating conditions or sensor features, to the hazard without specifying a baseline distribution, returning a hazard ratio per covariate: the factor by which it multiplies the risk of failure.

**In plain words.** Reliability rarely depends on age alone; load, temperature, and condition indicators all shift the risk. The Cox proportional-hazards model captures that without committing to a life distribution. It assumes each covariate multiplies an unspecified baseline hazard by a constant factor, so the baseline shape cancels out of the estimation and the covariate effects are fitted from the ordering of failures alone, by maximizing a partial likelihood. Each coefficient becomes a hazard ratio: greater than one means the covariate raises failure risk, less than one means it protects, and one means no effect. It is the standard tool for asking which operating conditions or features actually drive failure, and by how much.

**Diagnostic example.** Fitting failure times against vibration, temperature, and load gives hazard ratios of about 2.8 for vibration, 1.7 for temperature, and near one for load. The model thus identifies vibration as the dominant risk driver, each unit increase nearly tripling the hazard, while load shows no significant effect, focusing maintenance attention.

**Engine call.** `cox_ph(X, durations, events)`

```python
# see scripts/probstats.py: cox_ph(X, durations, events)
fit = cox_ph(X, durations, events)
fit["hazard_ratio"]    # exp(coef): >1 raises risk, <1 protects
fit["coef"], fit["se"] # for confidence intervals on the ratios
```

**Practical note.** The core assumption is proportional hazards, that a covariate's effect is constant over time; check it, since a crossing effect violates it and needs a time-varying term or stratification. Hazard ratios describe relative risk, not absolute timing, and the model assumes a log-linear covariate effect, so consider transforms for strongly nonlinear drivers. With many covariates and few failures, regularize to avoid overfitting.

**Reference.** Cox (1972), J. R. Stat. Soc. B 34; Therneau & Grambsch (2000), Modeling Survival Data.

## Hazard-rate estimation

**Essence.** The instantaneous failure rate of a unit still working, and its running total, the cumulative hazard. The Nelson-Aalen estimator gives it nonparametrically; its shape, falling, flat, or rising, locates a population on the bathtub curve.

**In plain words.** The hazard rate is the chance a surviving unit fails in the next instant, the most diagnostic reliability quantity because its shape reveals the failure mechanism. Plotted over a product's life it traces the bathtub curve: a high but falling hazard early on from infant mortality, a low flat middle of random failures, and a rising tail as wear-out sets in. The Nelson-Aalen estimator builds the cumulative hazard nonparametrically by summing the instantaneous failure fractions at each event time, handling censoring like Kaplan-Meier, and the slope of that cumulative curve is the hazard rate. A steepening curve is the clearest sign that a population has entered wear-out and that preventive replacement is due.

**Diagnostic example.** The cumulative hazard of an aging fleet is nearly flat early, then bends sharply upward after a characteristic age, the population entering wear-out. That steepening, rather than any single failure, is what justifies moving from run-to-failure to scheduled replacement before the rising hazard makes failures common.

**Engine call.** `nelson_aalen(durations, events)`

```python
import numpy as np

def nelson_aalen(durations, events):    # cumulative hazard H(t)
    H = 0.0; t_out = [0.0]; H_out = [0.0]
    for tt in np.unique(durations[events == 1]):
        at_risk = np.sum(durations >= tt)
        d = np.sum((durations == tt) & (events == 1))
        H += d / at_risk; t_out.append(tt); H_out.append(H)
    return np.array(t_out), np.array(H_out)   # slope = hazard rate
```

**Practical note.** Nonparametric hazard estimates are noisy, especially the instantaneous rate, so smooth or work with the cumulative hazard whose slope is steadier. The bathtub is a composite of failure modes, not one process, so a real population may show only part of it. Distinguish a rising hazard, genuine wear-out, from a rising failure count driven merely by more units reaching old age; the hazard normalizes by the at-risk population.

**Reference.** Nelson (1972), Technometrics 14; Aalen (1978), Ann. Statist. 6.
