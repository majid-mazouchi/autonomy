# Worked case study: from anomaly to remaining life on a pump bearing

One unit in a fleet of 240 drifts off-nominal. The chain detects it,
estimates its hidden degradation state, and turns that into a failure probability
and a remaining-life figure. All numbers are produced by the engine.

## Step 1 - detect the anomaly with a density model
A kernel density estimate over the healthy fleet's load-temperature operating points
defines normal. The suspect unit, running hot at moderate load, lands in a near-empty
region: novelty score 25.5, against a fleet median of 5.9
and a 95th percentile of 7.8. No fault label is needed.

## Step 2 - estimate the hidden state with a Kalman filter
The unit's noisy vibration-RMS trend feeds a two-state Kalman filter tracking level
and rate. It estimates the current level at 3.32 and a rising rate of
0.061 per cycle. Projecting to the alarm threshold 4.5 gives a
remaining useful life of about 19 cycles.

## Step 3 - quantify the risk with a life model
A Weibull fit on this bearing type gives shape 2.27 (wear-out) and
characteristic life 528. At the current age 300, past the
B10 life of 196, reliability is 0.76 and the hazard is climbing.
Bayesian fusion of the anomaly and the rising trend lifts the fault probability from
a prior of 0.05 to 0.4.

## Verdict
Model normal and score novelty, estimate the hidden state and project it, then
quantify the time-to-failure risk, and fuse the three into one decision. Detection
says something changed; the state estimate says how fast; the life model says how
much time is left.
