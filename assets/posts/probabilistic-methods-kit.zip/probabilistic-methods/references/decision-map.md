# Decision map

Start from the question you have. The family tag is distribution, probabilistic, or reliability.

| If you are asking | Reach for | Family |
| --- | --- | --- |
| Where does normal operation live, across regimes? | KDE / GMM density | distribution |
| Is this point novel or anomalous? | novelty score (neg log density) | distribution |
| How many operating regimes are there? | Gaussian mixture | distribution |
| Is this single reading an outlier? | Grubbs / MAD z-score | distribution |
| Are several outliers masking each other? | generalized ESD | distribution |
| What does this evidence imply about a fault? | Bayesian updating | probabilistic |
| Which fault, given several symptoms? | Bayesian network | probabilistic |
| What is the hidden state from noisy linear data? | Kalman filter | probabilistic |
| What is the hidden state under nonlinear dynamics? | particle filter | probabilistic |
| What is the time-to-failure distribution? | Weibull analysis | reliability |
| Survival with censored data, no distribution? | Kaplan-Meier | reliability |
| How do operating conditions affect failure risk? | Cox proportional hazards | reliability |
| Is the failure rate rising (wear-out)? | hazard / Nelson-Aalen | reliability |

## Order of work for probabilistic prognostics

1. Model normal: `kde_pdf` or `gmm_fit` over healthy, regime-aware data; standardize features.
2. Score novelty with `novelty_score`; screen single readings with `mad_zscore`, `grubbs`, or `generalized_esd`.
3. When a fault is suspected, fuse symptoms with `bayes_update` or `bayes_net_infer` to isolate the cause.
4. Estimate the hidden degradation state with `kalman_filter` (linear) or `particle_filter` (nonlinear); watch the residual.
5. Fit a life model with `weibull_fit` (or `kaplan_meier` to avoid a distribution) and read the hazard with `nelson_aalen`.
6. Rank what drives risk with `cox_ph`, then fuse the anomaly score, the state estimate, and the life model into a fault probability and a remaining-life figure.

## Going further (references 04-07)
Make remaining life first-class with `rul_predict` and judge it with `prognostic_metrics`. Sharpen anomaly detection with `mahalanobis` (robust), `pot_threshold` (extreme value theory), and `conformal_threshold` (calibrated coverage). Complete the inference family with `hmm_fit`/`hmm_viterbi`, `ukf_filter`, `gp_regression`, and `bocpd`. Turn probabilities into decisions with `calibration_curve`, `cost_optimal_threshold`, and `ds_combine`.
