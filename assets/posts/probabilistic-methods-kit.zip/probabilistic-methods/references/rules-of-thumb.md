# Rules of thumb

1. Model normal before hunting anomalies. A density over healthy, regime-aware data turns novelty into a score; without it, every unusual but benign operating point looks like a fault.
2. Standardize features first. Density estimates, mixtures, and distance-based scores are all distorted when one variable's range dwarfs another's.
3. Use robust statistics for outliers. The mean and standard deviation are inflated by the very outliers they should catch; the median and MAD are not.
4. State the prior explicitly. In Bayesian reasoning the prior matters most when evidence is scarce; draw it from base rates and let others challenge it.
5. Do not double-count correlated evidence. Treating dependent observations as independent manufactures false certainty in a posterior.
6. Match the filter to the dynamics. Kalman for linear-Gaussian, extended or unscented for mild nonlinearity, particle for strong nonlinearity or non-Gaussian noise.
7. Always handle censoring. Units still running carry information; dropping them biases every life and survival estimate toward early failure.
8. Read the hazard shape, not just the rate. Falling, flat, or rising places a population on the bathtub curve and tells infant mortality from wear-out.

## Pick by scenario

| Scenario | Pick | Why |
| --- | --- | --- |
| Flag an abnormal operating point | KDE novelty score | density without fault labels |
| Separate multi-modal operating regimes | Gaussian mixture | soft regimes + likelihood |
| Catch outliers that hide each other | generalized ESD | removes masking |
| Isolate a fault from several symptoms | Bayesian network | weighs joint evidence |
| Accumulate evidence over time | sequential Bayesian updating | posterior as next prior |
| Track a hidden level from noisy sensors | Kalman filter | optimal linear-Gaussian estimate |
| Project a nonlinear degradation state | particle filter | full posterior + band |
| Model time-to-failure | Weibull analysis | shape names the regime |
| Survival with many units still running | Kaplan-Meier | handles censoring |
| Rank what drives failure risk | Cox proportional hazards | hazard ratio per covariate |
