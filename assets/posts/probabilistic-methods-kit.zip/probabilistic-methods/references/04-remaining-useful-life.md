# Remaining useful life and prognostic metrics

## Remaining useful life prediction

**Essence.** Project a fitted degradation trend forward to the failure threshold and report the crossing time as a remaining life with a prediction interval. The interval widens the further ahead it reaches, an honest statement of forecast uncertainty.

**In plain words.** A health indicator that drifts toward a failure threshold contains a forecast: extrapolate its trend and the crossing time is the remaining useful life. The value of doing this probabilistically is the interval. Fitting the trend leaves uncertainty in its slope and intercept, and propagating that uncertainty to the crossing gives a band rather than a point, narrow when many consistent observations pin the trend, wide early on or when the signal is noisy. Feeding a filtered state, from the Kalman or particle card, into this projection rather than the raw signal sharpens both the estimate and the band, and the band is what turns a remaining-life number into a maintenance decision with a known confidence.

**Diagnostic example.** A bearing's vibration index has climbed steadily for thirty cycles. Extrapolating the fitted trend to the alarm level gives a remaining life of about five cycles with an interval of four to six, tight enough to schedule the replacement during the next planned downtime rather than reacting to a failure.

**Engine call.** `rul_predict(t, y, threshold)`

```python
# see scripts/probstats.py: rul_predict(t, y, threshold)
rl = rul_predict(t, health_index, threshold=4.5)
rl["rul"]                      # remaining cycles to threshold
rl["rul_lo"], rl["rul_hi"]     # 5-95% prediction interval
```

**Practical note.** The interval is only as honest as the trend model; a linear fit to a nonlinear degradation will be confidently wrong near the end, so check the trend shape and consider a nonlinear or filtered projection. Report the interval, never the point alone, and recompute as new data arrive. Remember the threshold itself is uncertain, so a conservative threshold buys margin.

**Reference.** Si et al. (2011), Eur. J. Oper. Res. 213; Lei et al. (2018), Mech. Syst. Signal Process. 104.

## Prognostic performance metrics

**Essence.** The metrics that judge a remaining-life predictor: alpha-lambda accuracy, whether each prediction sits in a shrinking cone around the truth; prognostic horizon, how early it enters and stays there; and relative accuracy. Raw error alone does not capture what a prognostic needs.

**In plain words.** A remaining-life predictor is not judged like a regressor, because what matters is being right with enough lead time and getting more accurate as failure approaches. The standard metrics encode that. Alpha-lambda accuracy draws a cone of plus-or-minus a fraction around the true remaining life and asks whether the prediction stays inside it as the unit ages. The prognostic horizon is the earliest point after which the predictions remain in that cone, the lead time the method actually delivers. Relative accuracy summarizes the average closeness. Together they reward a predictor that commits early and converges, and penalize one that is only right at the very end when it is too late to act.

**Diagnostic example.** Two predictors have similar average error, but one enters the twenty-percent accuracy cone fifteen cycles before failure and the other only five. The prognostic horizon makes the first clearly better, since it gives three times the lead time to plan maintenance, a distinction raw error hides.

**Engine call.** `prognostic_metrics(t, rul_pred, rul_true, alpha=0.2)`

```python
# see scripts/probstats.py: prognostic_metrics(t, rul_pred, rul_true)
pm = prognostic_metrics(t, rul_pred, rul_true, alpha=0.2)
pm["prognostic_horizon"]   # earliest time predictions stay in the cone
pm["rel_accuracy"]         # average closeness to true RUL
```

**Practical note.** Pick the alpha and the metrics with the maintenance lead time in mind; a tight cone is meaningless if the required horizon is short. Evaluate on run-to-failure data with known end of life, and average over many units, since a single trajectory is anecdote. Report the horizon alongside accuracy, since an accurate but late prediction has little operational value.

**Reference.** Saxena et al. (2008), Int. Conf. Prognostics & Health Management; Saxena et al. (2010), PHM Society.
