# Pitfalls and assumptions

Read before presenting any score, posterior, or life estimate as a verdict.

## Kernel density estimation (KDE)

Everything hinges on the bandwidth; cross-validate it rather than trusting a default, and remember the rule-of-thumb bandwidths assume roughly Gaussian data. KDE degrades in high dimensions, where data become sparse and every point looks novel, so reduce dimensionality or model per-regime. Standardize features first, since one wide-ranging variable will otherwise dominate the distance.

## Gaussian mixture models (GMM)

Choose the number of components by BIC rather than by eye, and regularize the covariances or expectation-maximization can collapse a component onto a single point with infinite likelihood. The fit is only locally optimal and depends on initialization, so restart several times and keep the best. Full covariances are expressive but data-hungry; in high dimensions prefer diagonal or shared covariances.

## Robust outlier tests

Grubbs and ESD assume the bulk of the data is roughly normal, so check that before trusting their p-values; for skewed data prefer the distribution-free MAD score or quantile rules. Set the maximum number of outliers in ESD generously, since under-setting it re-introduces masking. Treat a flagged outlier as a hypothesis, not a verdict; it may be a real transient worth keeping, not noise to discard.

## Bayesian updating

The prior matters when evidence is scarce, so set it from reliability data or fleet base rates rather than reflexively choosing uniform; state it explicitly so others can challenge it. The likelihoods must be calibrated, since a mis-specified likelihood drives the posterior confidently wrong. Beware treating correlated observations as independent, which over-counts evidence and produces false certainty.

## Bayesian networks

Inference is exact only for small or sparse networks; dense graphs need approximate methods, and exact enumeration is exponential in the unobserved nodes. The conditional probability tables must come from data or elicited expertise, and a confidently wrong table corrupts the posterior. The structure encodes causal assumptions; validate them, since a missing edge asserts an independence that may not hold.

## Kalman filtering

The filter is only as good as its models; tune the process and measurement covariances, since too small a process covariance makes it ignore real change and too large makes it chase noise. It is optimal only for linear-Gaussian systems, so use the extended or unscented variants for mild nonlinearity and a particle filter for strong nonlinearity. Check that the innovations are actually white; colored innovations mean the model is mis-specified.

## Particle filtering

Particle filters need enough particles, and the count must grow with state dimension or the filter degenerates, the curse of dimensionality. Watch for weight collapse, where one particle takes all the weight; resampling and a small process-noise jitter mitigate it. The dynamics and measurement models still must be right, and the estimate is stochastic, so fix the seed for reproducibility.

## Weibull analysis

Estimate parameters by maximum likelihood and report confidence intervals, since small failure samples give wide uncertainty. A single Weibull assumes one failure mode; mixed modes, a falling then rising hazard, need a competing-risks or mixture model, visible as a kink in the probability plot. Always include censored units in the fit, since dropping survivors biases the life estimate short.

## Kaplan-Meier estimator

Censoring is assumed non-informative; if units are pulled precisely because they look about to fail, the curve is biased, so check why censoring occurred. The estimate is uncertain where few remain at risk, in the long right tail, so show confidence bands and read the tail cautiously. To test whether two curves truly differ, use a log-rank test rather than eyeballing the gap.

## Cox proportional hazards

The core assumption is proportional hazards, that a covariate's effect is constant over time; check it, since a crossing effect violates it and needs a time-varying term or stratification. Hazard ratios describe relative risk, not absolute timing, and the model assumes a log-linear covariate effect, so consider transforms for strongly nonlinear drivers. With many covariates and few failures, regularize to avoid overfitting.

## Hazard-rate estimation

Nonparametric hazard estimates are noisy, especially the instantaneous rate, so smooth or work with the cumulative hazard whose slope is steadier. The bathtub is a composite of failure modes, not one process, so a real population may show only part of it. Distinguish a rising hazard, genuine wear-out, from a rising failure count driven merely by more units reaching old age; the hazard normalizes by the at-risk population.
