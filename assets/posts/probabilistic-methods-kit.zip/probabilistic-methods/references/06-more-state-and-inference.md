# More state and inference tools

## Hidden Markov models

**Essence.** A model of a system passing through hidden discrete stages, healthy, degraded, failing, each emitting noisy observations. Baum-Welch learns the stages and their transition probabilities; Viterbi decodes the most likely stage sequence, segmenting a noisy signal into a clean degradation history.

**In plain words.** Degradation is often naturally discrete: a machine is healthy, then degraded, then failing, with noisy sensor values that overlap between stages. A hidden Markov model captures this as a Markov chain over hidden stages that you cannot see directly, each emitting observations with its own distribution. The Baum-Welch algorithm, an expectation-maximization, learns the stage means, their spreads, and the probabilities of moving between them, all from unlabelled data. The Viterbi algorithm then finds the single most likely sequence of hidden stages behind the observations, turning a jittery signal into a clean segmentation that says when the system crossed from one stage to the next, the discrete-state counterpart to the continuous filters.

**Diagnostic example.** A gearbox health signal wanders noisily upward over months. A three-state hidden Markov model, fitted without labels, recovers a healthy, a degraded, and a failing stage, and Viterbi decoding marks the two transition times, giving a maintenance planner a clean stage history rather than a noisy trace.

**Engine call.** `hmm_fit(obs, n_states=3); hmm_viterbi(obs, model)`

```python
# see scripts/probstats.py: hmm_fit(obs, n_states); hmm_viterbi(obs, model)
model = hmm_fit(health_signal, n_states=3)   # states sorted by mean
stages = hmm_viterbi(health_signal, model)   # 0=healthy ... 2=failing
```

**Practical note.** Choose the number of stages with care and a physical rationale; too many fragments the history, too few merges distinct regimes. Baum-Welch finds only a local optimum, so initialize sensibly and restart. Label-switching means the learned states are unordered, so sort them by mean before interpreting them as healthy-to-failing.

**Reference.** Rabiner (1989), Proc. IEEE 77; Baum et al. (1970), Ann. Math. Statist. 41.

## Unscented Kalman filter

**Essence.** Nonlinear state estimation without Jacobians. It propagates a small set of deterministically chosen sigma points through the true nonlinear dynamics and recovers the mean and covariance, more accurate than linearizing and bridging the linear Kalman filter and the particle filter.

**In plain words.** Between the linear Kalman filter and the fully general particle filter sits a large class of mildly nonlinear, roughly Gaussian problems. The extended Kalman filter handles them by linearizing the dynamics, which needs Jacobians and degrades when the nonlinearity is sharp. The unscented Kalman filter takes a cleaner route: it picks a handful of sigma points that capture the state's mean and covariance, pushes each through the exact nonlinear function, and reconstructs the transformed mean and covariance from the results. This unscented transform is accurate to higher order than linearization, needs no derivatives, and costs only a few function evaluations, making it the practical default for nonlinear-Gaussian state estimation in diagnostics.

**Diagnostic example.** A sensor reads the square root of a degradation state, a nonlinear observation. The unscented Kalman filter tracks the underlying state cleanly through that nonlinearity, where a linearized filter would bias the estimate, and without the derivative the extended filter would require.

**Engine call.** `ukf_filter(z, f, h, Q, R, x0, P0)`

```python
# see scripts/probstats.py: ukf_filter(z, f, h, Q, R, x0, P0)
uk = ukf_filter(z, f_dynamics, h_observe, Q, R, x0, P0)
uk["x_filt"]     # nonlinear state estimate
uk["innov"]      # innovation residual
```

**Practical note.** It assumes the posterior stays roughly Gaussian, so for strongly multimodal or heavy-tailed problems use a particle filter. The sigma-point spread parameters rarely need tuning but can matter for high dimension. As with any Kalman variant, the process and measurement covariances must be set sensibly and the innovations checked for whiteness.

**Reference.** Julier & Uhlmann (2004), Proc. IEEE 92; Wan & Van Der Merwe (2000), IEEE AS-SPCC.

## Gaussian-process regression

**Essence.** A nonparametric trend model that returns a calibrated uncertainty band. It fits a smooth function to a degradation signal and, crucially, widens its confidence where data are sparse and as it extrapolates, exactly the behavior wanted for projecting a health trend toward failure.

**In plain words.** Fitting a degradation trend with a fixed parametric curve forces a shape and gives no honest uncertainty. A Gaussian process instead places a distribution over smooth functions and conditions it on the data, yielding not just a mean trend but a full predictive distribution at every point. Its defining feature for prognostics is the uncertainty: the band is tight where observations are dense and widens where they are sparse and, most importantly, as the prediction extrapolates beyond the last measurement. That growing band is a faithful statement of how little the data constrain the future, so when the trend is projected toward a failure threshold the crossing time inherits a principled interval rather than a false-confident point.

**Diagnostic example.** A degradation signal is fitted with a Gaussian process whose mean tracks the trend and whose two-sigma band hugs the data, then flares once the prediction extends past the last observation. Projecting the band to the failure threshold gives a remaining-life interval that honestly reflects the thinning evidence.

**Engine call.** `gp_regression(t_train, y_train, t_test, length, sigma_f, sigma_n)`

```python
# see scripts/probstats.py: gp_regression(t_train, y_train, t_test, ...)
gp = gp_regression(t, y, t_future, length=2.5, sigma_f=2.0, sigma_n=0.2)
gp["mean"], gp["std"]    # trend and uncertainty (std grows ahead)
```

**Practical note.** The kernel and its length scale encode the smoothness assumption; choose them by marginal likelihood, not by eye, and a wrong length scale gives over- or under-confident bands. The standard implementation costs cubically in the number of points, so thin or approximate for long histories. Extrapolation reverts to the prior mean far out, so trust the band, not the mean, in the deep future.

**Reference.** Rasmussen & Williams (2006), Gaussian Processes for Machine Learning; Richardson et al. (2017), Mech. Syst. Signal Process.

## Bayesian online changepoint detection

**Essence.** An online estimator of the time since the last regime change. It maintains a posterior over the run length using a conjugate predictive, and the run length collapses to zero exactly when the signal's statistics shift, flagging a fault onset as it happens, the probabilistic timing tool alongside your change-detection methods.

**In plain words.** Knowing that a fault exists is one thing; knowing precisely when it started is another, and it matters for root cause and for resetting baselines. Bayesian online changepoint detection answers it sequentially. At each step it maintains a probability distribution over the run length, the number of steps since the last changepoint, updating it with a conjugate predictive model of the data. While the regime is stable the most likely run length grows steadily; the instant the underlying mean or variance shifts, the new observation fits the grown hypothesis poorly, the run-length posterior collapses toward zero, and a changepoint is declared. Because it is online and probabilistic, it reports not just that a change occurred but when, with a posterior over the timing.

**Diagnostic example.** A vibration level shifts to a new baseline midway through a record. The run-length estimate climbs steadily, then drops sharply to near zero at the shift, pinpointing the onset time so the event can be correlated with a load change or a maintenance action.

**Engine call.** `bocpd(x, hazard=0.01)`

```python
# see scripts/probstats.py: bocpd(x, hazard=0.01)
bc = bocpd(signal, hazard=0.01)
# expected run length resets to ~0 at a changepoint
onset = int(bc["exp_run_length"].argmin())
```

**Practical note.** The hazard rate encodes how often changepoints are expected; set it from domain knowledge, since too high makes the detector jumpy and too low makes it sluggish. The conjugate model assumes a form for the observations (here Gaussian), so transform or generalize it for other data. There is an inherent detection lag, a few samples, while evidence for the change accumulates.

**Reference.** Adams & MacKay (2007), arXiv:0710.3742; Fearnhead & Liu (2007), J. R. Stat. Soc. B 69.
