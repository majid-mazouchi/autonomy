# Distribution and anomaly, what does normal look like, and what is an outlier?

_Before any diagnosis, condition monitoring needs a model of normal: where the healthy data live across operating regimes, so a new point can be scored as familiar or novel, and a single reading can be judged an outlier without distorting the very statistics meant to catch it._

## Kernel density estimation (KDE)

**Essence.** A nonparametric estimate of the data's probability density: place a smooth bump on every observation and sum them. It needs no distributional assumption and yields a novelty score, the negative log density, that flags points unlike anything seen before.

**In plain words.** A histogram answers where the data are, but crudely, with arbitrary bins and hard edges. Kernel density estimation smooths that into a continuous density by centering a small Gaussian on each observation and adding them up, so dense regions rise and empty regions stay near zero. The one real choice is the bandwidth, the width of those bumps: too narrow and the estimate is spiky and chases noise, too wide and real structure like separate operating regimes is blurred away. Once fitted, the density turns into an anomaly detector for free, since the negative log density is high exactly where a new point is unlike the training data, no fault labels required.

**Diagnostic example.** A pump's healthy behavior occupies two clusters in the load-temperature plane, idle and full load. A kernel density estimate over historical healthy data captures both; a new reading at high temperature but low load falls in a near-empty region, earning a high novelty score and flagging an abnormal operating state.

**Engine call.** `kde_pdf(X_train, X_eval, bw=None); novelty_score(X_train, X_eval)`

```python
import numpy as np
from scipy import stats

def kde_pdf(X_train, X_eval, bw=None):
    kde = stats.gaussian_kde(np.atleast_2d(X_train.T), bw_method=bw)
    return kde(np.atleast_2d(X_eval.T))

def novelty_score(X_train, X_eval, bw=None):
    return -np.log(kde_pdf(X_train, X_eval, bw) + 1e-300)
```

**Practical note.** Everything hinges on the bandwidth; cross-validate it rather than trusting a default, and remember the rule-of-thumb bandwidths assume roughly Gaussian data. KDE degrades in high dimensions, where data become sparse and every point looks novel, so reduce dimensionality or model per-regime. Standardize features first, since one wide-ranging variable will otherwise dominate the distance.

**Reference.** Silverman (1986), Density Estimation; Scott (2015), Multivariate Density Estimation.

## Gaussian mixture models (GMM)

**Essence.** A density modelled as a weighted blend of Gaussian components, fitted by expectation-maximization. It captures several distinct operating regimes at once, assigns each point a soft membership, and gives a parametric likelihood for anomaly scoring.

**In plain words.** When healthy operation has several modes, a single Gaussian is wrong and a kernel estimate, while flexible, gives no labels. A Gaussian mixture splits the difference: it models the density as a few Gaussian components, each a regime with its own mean, shape, and weight, and fits them by expectation-maximization, which alternates between softly assigning points to components and re-estimating each component from its assigned points. The result both clusters the data into regimes and provides a smooth likelihood, so a new point gets a regime membership and a likelihood, with low likelihood marking an anomaly. The number of components is chosen by an information criterion.

**Diagnostic example.** A turbine runs in three regimes, startup, steady, and peaking. A three-component mixture recovers them as separate Gaussians, so each new operating point is assigned to its regime and scored; a point that fits no component well, low under all three, is flagged as an off-nominal state worth investigating.

**Engine call.** `gmm_fit(X, k); gmm_score(model, X)`

```python
# see scripts/probstats.py: gmm_fit(X, k) runs EM
model = gmm_fit(X, k=3)            # weights, means, covs, labels
scores = gmm_score(model, X_new)  # per-point log-likelihood
anomaly = scores < threshold      # low likelihood = off-nominal
```

**Practical note.** Choose the number of components by BIC rather than by eye, and regularize the covariances or expectation-maximization can collapse a component onto a single point with infinite likelihood. The fit is only locally optimal and depends on initialization, so restart several times and keep the best. Full covariances are expressive but data-hungry; in high dimensions prefer diagonal or shared covariances.

**Reference.** Bishop (2006), Pattern Recognition and ML, ch. 9; McLachlan & Peel (2000), Finite Mixture Models.

## Robust outlier tests

**Essence.** Tests that flag outliers without being corrupted by them. The MAD-based z-score replaces the mean and standard deviation with the median and median absolute deviation; Grubbs and the generalized ESD test give significance for one or several outliers in a near-normal sample.

**In plain words.** The obvious outlier rule, more than three standard deviations from the mean, has a fatal flaw: a real outlier inflates both the mean and the standard deviation it is measured against, so it hides itself, a problem called masking. Robust statistics fix this by using estimators outliers cannot easily distort. The modified z-score uses the median and the median absolute deviation, which a few extreme points barely move, and flags scores beyond about 3.5. When a formal test is wanted, Grubbs' test judges the single most extreme point against a t-distribution critical value, and the generalized extreme studentized deviate test extends this to several outliers, removing and re-testing so that multiple outliers do not mask one another.

**Diagnostic example.** A temperature channel has two stuck-high spikes and one dropout. The classical three-sigma band, widened by the spikes, misses the dropout; the MAD-based score, anchored on the median, flags all three, and the generalized ESD test confirms three significant outliers rather than one.

**Engine call.** `mad_zscore(x); grubbs(x, alpha=0.05); generalized_esd(x, max_out=5)`

```python
import numpy as np

def mad_zscore(x):
    med = np.median(x); mad = np.median(np.abs(x - med))
    z = 0.6745 * (x - med) / (mad + 1e-12)
    return z, np.abs(z) > 3.5      # robust to masking
# grubbs(x), generalized_esd(x, max_out) in scripts/probstats.py
```

**Practical note.** Grubbs and ESD assume the bulk of the data is roughly normal, so check that before trusting their p-values; for skewed data prefer the distribution-free MAD score or quantile rules. Set the maximum number of outliers in ESD generously, since under-setting it re-introduces masking. Treat a flagged outlier as a hypothesis, not a verdict; it may be a real transient worth keeping, not noise to discard.

**Reference.** Rousseeuw & Hubert (2011), WIREs Data Mining; Rosner (1983), Technometrics 25.
