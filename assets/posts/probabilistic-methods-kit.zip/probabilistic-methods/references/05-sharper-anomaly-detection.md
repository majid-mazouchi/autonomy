# Sharper anomaly detection

## Mahalanobis distance with robust covariance

**Essence.** A multivariate outlier distance that accounts for the correlation between features, with a robust center and covariance so the outliers cannot inflate the very statistics meant to catch them. It is the multivariate, correlation-aware extension of the robust z-score, and the link to the Hotelling chart.

**In plain words.** A point can be unremarkable in every single variable yet impossible in combination, sitting far off the correlation the features normally obey. Euclidean distance misses this; the Mahalanobis distance does not, because it measures distance in units of the data's covariance, stretching and rotating space so the normal cloud becomes a sphere and off-correlation points stand out. The catch is the same masking problem as in one dimension: outliers inflate the covariance and hide. A robust estimate of the center and covariance, computed by down-weighting or trimming the most extreme points, fixes that, and the resulting robust distances expose multivariate outliers a classical Mahalanobis distance would absorb. It is the natural companion to the Hotelling chart in your multivariate-monitoring toolkit.

**Diagnostic example.** Temperature and load are each within their normal range, but the unit is hot for how lightly it is loaded, a combination off the usual correlation. The robust Mahalanobis distance flags it while a classical distance, its covariance stretched toward the very outlier, rates it nearly normal.

**Engine call.** `mahalanobis(X, robust=True)`

```python
# see scripts/probstats.py: mahalanobis(X, robust=True)
m = mahalanobis(X, robust=True)
m["dist"]        # robust Mahalanobis distance per point
m["outlier"]     # flagged against the chi-square threshold
```

**Practical note.** Use a robust covariance (a minimum-covariance-determinant style estimate) whenever the training data may contain outliers, which is almost always. Compare distances to a chi-square quantile with the right degrees of freedom for a threshold. In high dimensions the covariance is hard to estimate; regularize it or reduce dimensionality first.

**Reference.** Rousseeuw & Van Zomeren (1990), JASA 85; Hubert et al. (2018), WIREs Comput. Stat.

## Extreme value theory for thresholds

**Essence.** A principled alarm level from the tail of a health index. Exceedances over a high threshold follow a generalized Pareto distribution; fitting it sets the level a healthy signal crosses only with a chosen small probability, replacing an arbitrary number of sigmas.

**In plain words.** Alarm thresholds are too often set at three sigmas or a round number, neither of which corresponds to a stated false-alarm rate, especially when the health index is not Gaussian. Extreme value theory addresses exactly the tail that matters. Its peaks-over-threshold result says the exceedances above a high threshold converge to a generalized Pareto distribution regardless of the underlying shape, so fitting that distribution to the observed exceedances lets you read off the level that a healthy signal will exceed only with, say, a one-in-a-thousand probability. The alarm is then expressed as a return level with a meaning, rather than a heuristic, and it adapts to heavy tails that a Gaussian assumption would badly underestimate.

**Diagnostic example.** A health index has occasional benign spikes, so a three-sigma alarm fires too often. Fitting a generalized Pareto to its tail and choosing a one-in-a-thousand exceedance level sets a threshold that tolerates the benign spikes while still catching genuinely extreme excursions.

**Engine call.** `pot_threshold(x, q=0.95, exceed_prob=1e-3)`

```python
# see scripts/probstats.py: pot_threshold(x, q=0.95, exceed_prob=1e-3)
pot = pot_threshold(health_index, q=0.95, exceed_prob=1e-3)
pot["level"]     # alarm level for the chosen exceedance probability
pot["shape"]     # GPD shape: >0 heavy tail, <0 bounded
```

**Practical note.** The choice of the threshold for defining exceedances is a bias-variance tradeoff: too low and the asymptotics do not hold, too high and too few exceedances remain to fit; inspect a mean-residual-life plot. The fit needs enough tail data, so it is for well-sampled indices, not rare events with a handful of points. Extrapolating far beyond the data carries real uncertainty, so quote confidence on the return level.

**Reference.** Coles (2001), Introduction to Statistical Modeling of Extreme Values; Pickands (1975), Ann. Statist. 3.

## Conformal anomaly detection

**Essence.** A wrapper that turns any anomaly score into a calibrated alarm with a finite-sample coverage guarantee. Using scores on clean calibration data, it sets the cutoff so a normal point exceeds it with probability at most alpha, no distributional assumption required.

**In plain words.** Any of the scores in this guide, a kernel density novelty, a mixture likelihood, a Mahalanobis distance, leaves one question open: where to put the threshold so the false-alarm rate is actually what you claim. Conformal prediction answers it with a guarantee. Given a set of anomaly scores computed on data known to be normal, it sets the cutoff at the appropriate empirical quantile, with a small finite-sample correction, so that a future normal point exceeds it with probability at most the chosen alpha, exactly, regardless of the score's distribution or the data's. It converts an uncalibrated score into a test with a controlled false-alarm rate, which is what a deployable alarm needs and what most anomaly detectors lack.

**Diagnostic example.** A kernel-density novelty score has no natural threshold. Calibrating it conformally on a month of known-healthy data sets a cutoff guaranteed to false-alarm on at most five percent of normal points, so the alarm rate in deployment matches the stated tolerance rather than drifting with the score's scale.

**Engine call.** `conformal_threshold(cal_scores, alpha=0.05)`

```python
# see scripts/probstats.py: conformal_threshold(cal_scores, alpha=0.05)
ct = conformal_threshold(scores_on_normal_data, alpha=0.05)
alarm = new_score > ct["threshold"]   # <=5% false-alarm guarantee
```

**Practical note.** The guarantee assumes the calibration and future data are exchangeable, so it breaks under distribution shift; re-calibrate when the operating regime changes. It controls the marginal false-alarm rate, not the per-point one, and says nothing about detection power, which still depends on the underlying score. Hold out a clean calibration set separate from training.

**Reference.** Vovk et al. (2005), Algorithmic Learning in a Random World; Angelopoulos & Bates (2023), Found. Trends ML.
