# From probabilities to decisions

## Calibration and proper scoring

**Essence.** The check that a model's stated probabilities mean what they say. A reliability diagram compares predicted probability to observed frequency, and the Brier score summarizes calibration and sharpness. A confident-but-wrong model is worse than an honest one.

**In plain words.** Every probabilistic method in this guide outputs a number between zero and one, but a number is only trustworthy if it is calibrated: of all the times the model says seventy percent, a fault should actually occur about seventy percent of the time. A reliability diagram tests this directly by binning predictions and plotting the stated probability against the observed frequency, with calibration meaning the points lie on the diagonal. The Brier score, the mean squared difference between probability and outcome, condenses both calibration and sharpness into one proper score, one that is optimized only by reporting the true probability. Checking calibration matters because an overconfident model triggers the wrong maintenance decisions even when its rankings are fine, and recalibration can fix it without retraining.

**Diagnostic example.** A fault classifier looks accurate but its reliability diagram bows away from the diagonal: when it says ninety percent, faults occur only seventy percent of the time. Recognizing this overconfidence, and recalibrating, prevents the cost model downstream from over-reacting to inflated probabilities.

**Engine call.** `calibration_curve(probs, labels, n_bins=10)`

```python
# see scripts/probstats.py: calibration_curve(probs, labels)
cc = calibration_curve(fault_probs, outcomes, n_bins=10)
cc["conf"], cc["acc"]    # diagonal = calibrated
cc["brier"]              # proper score: lower is better
```

**Practical note.** Calibration and accuracy are different; a model can rank perfectly yet be badly calibrated, and the fix is recalibration, not retraining. Use enough bins to see structure but enough data per bin to be stable, and prefer a proper score like Brier or log-loss over accuracy for probabilistic models. Recalibrate after any distribution shift.

**Reference.** Brier (1950), Mon. Weather Rev. 78; Guo et al. (2017), ICML (modern calibration).

## Cost-optimal decision thresholds

**Essence.** Turn a fault probability into a maintenance action by choosing the alarm threshold that minimizes expected cost, given the asymmetric costs of a false alarm and a missed fault. It replaces an arbitrary cutoff with one tuned to the real consequences.

**In plain words.** A calibrated fault probability still has to become a yes-or-no decision, and the right threshold is rarely one-half. The costs are asymmetric: an unnecessary inspection wastes a little, an unexpected failure can be catastrophic, so the threshold should reflect that ratio. Casting it as expected-cost minimization makes this explicit: for each candidate threshold, count the false alarms and the missed faults the decisions would produce, weight them by their costs, and choose the threshold with the lowest expected cost. The result moves the alarm lower when misses are expensive, catching more faults at the price of more false alarms, and higher when false alarms dominate. It is the bridge from a probability to an operational policy.

**Diagnostic example.** With a missed bearing failure costing twenty times an unnecessary inspection, the cost-optimal threshold drops to about a quarter rather than a half, so the system alarms earlier and accepts more false positives, because the rare missed failure is what truly hurts.

**Engine call.** `cost_optimal_threshold(probs, labels, c_fp, c_fn)`

```python
# see scripts/probstats.py: cost_optimal_threshold(probs, labels, c_fp, c_fn)
co = cost_optimal_threshold(fault_probs, outcomes, c_fp=1.0, c_fn=20.0)
co["best"]        # cost-minimizing alarm threshold
```

**Practical note.** The decision is only as good as the cost numbers; elicit them honestly and do a sensitivity analysis, since the optimal threshold can move sharply with the cost ratio. It assumes the probabilities are calibrated, so check that first. Costs may vary by unit and over time, so revisit the threshold rather than fixing it once.

**Reference.** Elkan (2001), IJCAI (cost-sensitive learning); Hand (2009), Mach. Learn. 77.

## Evidence fusion (Dempster-Shafer)

**Essence.** A way to combine several detectors into one belief that represents ignorance explicitly. Each source assigns mass to sets of hypotheses, including the whole set as uncertainty, and Dempster's rule fuses them, concentrating belief where they agree, a richer alternative to averaging probabilities.

**In plain words.** Real diagnosis draws on several detectors, a vibration anomaly, a temperature trend, a model residual, and they must be combined. Simply averaging their probabilities discards how confident each one is and cannot represent plain ignorance. Dempster-Shafer theory lets each source distribute belief mass not only over individual hypotheses but over sets of them, assigning leftover mass to the whole frame as explicit uncertainty. Dempster's rule of combination then fuses two sources by intersecting their focal sets and renormalizing away the conflict, so agreement sharpens belief while disagreement is surfaced rather than hidden. The result is a fused belief that grows more committed than any single source when they concur, and an honest measure of conflict when they do not, useful when sensors are partially reliable or sometimes silent.

**Diagnostic example.** A vibration sensor and a temperature sensor each lean toward a fault but reserve some mass for uncertainty. Combining them by Dempster's rule raises the fused belief in the fault above either alone, while a high conflict score would instead warn that the two sensors disagree and should not be naively merged.

**Engine call.** `ds_combine(m1, m2)`

```python
# see scripts/probstats.py: ds_combine(m1, m2)
F, H, U = frozenset(["F"]), frozenset(["H"]), frozenset(["F", "H"])
m1 = {{F: 0.55, H: 0.10, U: 0.35}}   # vibration sensor
m2 = {{F: 0.50, H: 0.15, U: 0.35}}   # temperature sensor
fused = ds_combine(m1, m2)         # fused belief in the fault
```

**Practical note.** High conflict between sources makes Dempster's rule behave counterintuitively, the classic Zadeh paradox, so monitor the conflict and consider alternative combination rules when it is large. Eliciting the mass functions is the hard part and encodes each sensor's reliability. When all sources give well-calibrated probabilities, Bayesian model averaging is often the simpler and more defensible choice.

**Reference.** Shafer (1976), A Mathematical Theory of Evidence; Dempster (1967), Ann. Math. Statist. 38.
