# At a glance

| Method | Family | Answers | Output | Key assumption |
| --- | --- | --- | --- | --- |
| KDE | distribution | where data live, novelty | density + novelty score | bandwidth choice |
| GMM | distribution | operating regimes | soft clusters + likelihood | number of components |
| Robust tests | distribution | is this an outlier | flag + significance | near-normal bulk |
| Bayesian updating | probabilistic | fault given evidence | posterior probabilities | calibrated likelihoods |
| Bayesian network | probabilistic | which fault isolates | posterior over faults | graph + CPTs |
| Kalman filter | probabilistic | hidden state, residual | state + innovation | linear-Gaussian |
| Particle filter | probabilistic | nonlinear hidden state | state + uncertainty band | enough particles |
| Weibull | reliability | time-to-failure regime | shape, scale, R(t), h(t) | single failure mode |
| Kaplan-Meier | reliability | survival over time | survival curve | non-informative censoring |
| Cox PH | reliability | what drives risk | hazard ratio per covariate | proportional hazards |
| Hazard / N-A | reliability | is the rate rising | cumulative hazard | non-informative censoring |

## Which tool for which question

| Question | First tool | Confirm / extend with |
| --- | --- | --- |
| Is this operating point abnormal? | KDE novelty score | GMM per-regime likelihood |
| Several outliers masking each other? | generalized ESD | MAD z-score |
| Which fault explains the symptoms? | Bayesian network | sequential Bayesian updating |
| What is the hidden degradation state? | Kalman filter | particle filter (if nonlinear) |
| How long until failure? | Weibull analysis | Kaplan-Meier, Nelson-Aalen hazard |
| What drives failure risk? | Cox proportional hazards | hazard-ratio confidence intervals |
