# References

- Silverman (1986), Density Estimation; Scott (2015), Multivariate Density Estimation.
- Bishop (2006), Pattern Recognition and ML, ch. 9; McLachlan & Peel (2000), Finite Mixture Models.
- Rousseeuw & Hubert (2011), WIREs Data Mining; Rosner (1983), Technometrics 25.
- Gelman et al. (2013), Bayesian Data Analysis; Jaynes (2003), Probability Theory.
- Pearl (1988), Probabilistic Reasoning; Koller & Friedman (2009), Probabilistic Graphical Models.
- Kalman (1960), J. Basic Eng. 82; Simon (2006), Optimal State Estimation.
- Gordon, Salmond & Smith (1993), IEE Proc. F 140; Arulampalam et al. (2002), IEEE TSP 50.
- Weibull (1951), J. Appl. Mech. 18; Meeker & Escobar (1998), Statistical Methods for Reliability.
- Kaplan & Meier (1958), JASA 53; Klein & Moeschberger (2003), Survival Analysis.
- Cox (1972), J. R. Stat. Soc. B 34; Therneau & Grambsch (2000), Modeling Survival Data.
- Nelson (1972), Technometrics 14; Aalen (1978), Ann. Statist. 6.