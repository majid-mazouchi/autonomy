# Probabilistic reasoning, what does the evidence imply about a hidden fault?

_A fault is hidden; only noisy symptoms are seen. Probabilistic inference runs the logic backward from evidence to cause, carries belief forward as data accumulate, and estimates a hidden state from a stream of measurements, the input to model-based residual generation._

## Bayesian updating

**Essence.** Bayes' rule as the engine of diagnosis: combine a prior belief with the likelihood of the evidence to get a posterior, and repeat as evidence arrives. Belief in each fault hypothesis sharpens with every observation.

**In plain words.** Diagnosis is inference from effect to cause, exactly what Bayes' rule formalizes. It multiplies the prior probability of each hypothesis by how likely the observed evidence would be if that hypothesis were true, then renormalizes, giving the posterior probability of each cause given the evidence. Applied repeatedly, with each posterior becoming the next prior, it accumulates evidence over time, so a weak prior plus a run of consistent observations compounds into near-certainty while a single ambiguous reading shifts belief only a little. For conjugate cases like estimating a defect rate, the update is a closed-form Beta-Binomial step with a credible interval, no simulation needed.

**Diagnostic example.** A bearing is healthy with prior probability 0.9. Each vibration snapshot is more consistent with an outer-race fault than with health; after a dozen such snapshots the posterior for the outer-race hypothesis rises from 0.1 toward 0.97, isolating the fault from its competitors as evidence accumulates.

**Engine call.** `bayes_update(prior, likelihood); sequential_bayes(prior, likelihoods); beta_binomial(a, b, k, n)`

```python
import numpy as np

def bayes_update(prior, likelihood):
    post = np.asarray(prior) * np.asarray(likelihood)
    return post / post.sum()

post = prior
for lik in evidence_stream:        # accumulate evidence
    post = bayes_update(post, lik)
```

**Practical note.** The prior matters when evidence is scarce, so set it from reliability data or fleet base rates rather than reflexively choosing uniform; state it explicitly so others can challenge it. The likelihoods must be calibrated, since a mis-specified likelihood drives the posterior confidently wrong. Beware treating correlated observations as independent, which over-counts evidence and produces false certainty.

**Reference.** Gelman et al. (2013), Bayesian Data Analysis; Jaynes (2003), Probability Theory.

## Bayesian networks

**Essence.** A graph whose nodes are faults and symptoms and whose edges encode causal and conditional-independence structure. Given observed symptoms it infers the posterior over hidden faults, isolating the likely cause, the probabilistic cousin of partial-correlation reasoning.

**In plain words.** When many faults and symptoms interact, flat Bayesian updating becomes unwieldy and ignores structure. A Bayesian network draws that structure as a directed graph: each fault points to the symptoms it causes, and the graph's missing edges assert conditional independencies that make the joint distribution compact and inference tractable. Each node carries a conditional probability table, the chance it is present given its parents. Clamping the observed symptoms and inferring the unobserved fault nodes yields the posterior probability of each fault, so the network performs fault isolation: it weighs competing causes against the full pattern of evidence, naturally explaining away one fault when another better accounts for the symptoms.

**Diagnostic example.** A network links a bearing fault to both high vibration and high temperature. Observing high vibration alone raises the fault probability from 0.05 to 0.31; adding high temperature, which the same fault explains, pushes it to 0.68, while a competing cause that would explain only temperature is down-weighted by the joint evidence.

**Engine call.** `bayes_net_infer(nodes, evidence, query)`

```python
# nodes: name -> {parents, cpt: parent-tuple -> P(node=1)}
net = {
  "Fault": {"parents": [], "cpt": {(): 0.05}},
  "Vib":   {"parents": ["Fault"], "cpt": {(0,): 0.1, (1,): 0.85}},
  "Temp":  {"parents": ["Fault"], "cpt": {(0,): 0.15, (1,): 0.7}},
}
p = bayes_net_infer(net, {"Vib": 1, "Temp": 1}, "Fault")  # -> 0.68
```

**Practical note.** Inference is exact only for small or sparse networks; dense graphs need approximate methods, and exact enumeration is exponential in the unobserved nodes. The conditional probability tables must come from data or elicited expertise, and a confidently wrong table corrupts the posterior. The structure encodes causal assumptions; validate them, since a missing edge asserts an independence that may not hold.

**Reference.** Pearl (1988), Probabilistic Reasoning; Koller & Friedman (2009), Probabilistic Graphical Models.

## Kalman filtering

**Essence.** Recursive Bayesian state estimation for linear-Gaussian systems. It fuses a model-based prediction with each noisy measurement, weighting by uncertainty, to track a hidden state. Its one-step prediction error, the innovation, is the whitened residual that fault detection monitors.

**In plain words.** Many health variables are hidden states observed only through noise: a true vibration level, a degradation index, a temperature behind a lagging sensor. The Kalman filter estimates them recursively in two steps. It predicts the next state from a dynamics model, inflating its uncertainty, then corrects that prediction with the new measurement, trusting the measurement more when it is precise and the model more when it is not, an optimal blend for linear-Gaussian systems. The byproduct that matters for monitoring is the innovation, the difference between the measurement and its prediction: on a healthy system it is zero-mean white noise, so a persistent or growing innovation is a model-based residual signalling that the system has departed from its assumed behavior.

**Diagnostic example.** A degradation index is measured noisily each cycle. The Kalman filter smooths the noisy readings into a clean estimate of the underlying level and its rate of change, and its innovation sequence stays flat while the system tracks the model, then drifts when degradation accelerates beyond the assumed dynamics, raising a residual alarm.

**Engine call.** `kalman_filter(z, F, H, Q, R, x0, P0)`

```python
# see scripts/probstats.py: kalman_filter(z, F, H, Q, R, x0, P0)
kf = kalman_filter(z, F, H, Q, R, x0, P0)
state = kf["x_filt"]          # filtered hidden state
resid = kf["innov"]           # innovation = whitened residual
```

**Practical note.** The filter is only as good as its models; tune the process and measurement covariances, since too small a process covariance makes it ignore real change and too large makes it chase noise. It is optimal only for linear-Gaussian systems, so use the extended or unscented variants for mild nonlinearity and a particle filter for strong nonlinearity. Check that the innovations are actually white; colored innovations mean the model is mis-specified.

**Reference.** Kalman (1960), J. Basic Eng. 82; Simon (2006), Optimal State Estimation.

## Particle filtering

**Essence.** Recursive Bayesian estimation for nonlinear, non-Gaussian systems. It represents the belief by a swarm of weighted samples, propagates them through the true dynamics, weights them by each measurement, and resamples, tracking a hidden health state where the Kalman filter's assumptions fail.

**In plain words.** Degradation is often nonlinear, a crack that grows faster as it lengthens, a wear process that accelerates, and the Kalman filter's linear-Gaussian assumptions break down. A particle filter drops those assumptions by representing the belief about the state not as a single Gaussian but as a cloud of weighted samples, the particles. Each step it pushes every particle through the actual nonlinear dynamics, reweights them by how well they predict the new measurement, and resamples to concentrate particles where the belief is high. The weighted cloud approximates the full posterior, so it captures skew and multiple modes, and its spread is an honest uncertainty band, valuable for projecting a degradation state and its confidence forward to a remaining-useful-life estimate.

**Diagnostic example.** A fatigue crack grows nonlinearly and is measured indirectly and noisily. A particle filter tracks the hidden crack length, its particle cloud widening as uncertainty grows between inspections and tightening at each measurement, and the 5th-to-95th-percentile band projected forward gives a probabilistic remaining-useful-life estimate.

**Engine call.** `particle_filter(z, f_trans, h_obs, q_std, r_std, x0)`

```python
# see scripts/probstats.py: particle_filter(z, f_trans, h_obs, ...)
pf = particle_filter(z, f_trans, h_obs, q_std, r_std, x0)
est = pf["mean"]              # posterior mean health state
band = (pf["lo"], pf["hi"])   # 5-95% band -> RUL uncertainty
```

**Practical note.** Particle filters need enough particles, and the count must grow with state dimension or the filter degenerates, the curse of dimensionality. Watch for weight collapse, where one particle takes all the weight; resampling and a small process-noise jitter mitigate it. The dynamics and measurement models still must be right, and the estimate is stochastic, so fix the seed for reproducibility.

**Reference.** Gordon, Salmond & Smith (1993), IEE Proc. F 140; Arulampalam et al. (2002), IEEE TSP 50.
