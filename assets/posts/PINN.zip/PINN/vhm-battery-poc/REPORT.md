# Results Report — Physics-Informed NN Battery VHM Proof of Concept

**Date:** 2026-07-06 · **Data:** XJTU battery aging dataset, 2C + 3C batches (23 cells, real laboratory cycling data from the PINN4SOH repository, Wang et al., Nat. Commun. 2024) · **Split:** 17 train / 2 validation / 4 test batteries, split at battery level (no leakage) · **Hardware:** CPU only, JAX; each training stage < 40 s.

## 1. Model

Two coupled networks, in the spirit of PINN4SOH but with one structural change borrowed from the Thermal Neural Network philosophy:

- **Solution network** `u(x, t)`: MLP [17→64→64→32→1], estimates SOH from 16 statistical features of a partial charge window plus normalized cycle index.
- **Degradation law** `f(C-rate, t, SOH)`: MLP [3→32→32→1] whose output is passed through `−softplus`, making the predicted degradation rate **non-positive by construction** rather than by loss penalty. This structural constraint proved decisive: the loss-penalized version produced positive rates off the training manifold and forecasts that stalled.

Training is staged. Stage 1 fits `u` to data. Stage 2 fits `f` to analytic rates from per-battery power-law fade fits `SOH = q0 − a·(cyc/100)^b` (RMSE ≈ 0.004 against measurements) — smooth, noise-free targets that preserve the degradation knee. Stage 3 jointly fine-tunes with a physics-consistency term tying `u`'s cycle-to-cycle increments to `f` (stop-gradient on `f`, best-validation guarded).

## 2. Monitoring: SOH estimation on held-out batteries

| Model | 2C-7 | 2C-8 | 3C-14 | 3C-15 | Aggregate MAPE | RMSE |
|---|---|---|---|---|---|---|
| PINN (staged) | 1.83% | 1.85% | 2.21% | 2.59% | **1.99%** | 0.0225 |
| MLP baseline | 1.35% | 2.38% | 2.03% | 3.43% | 2.11% | 0.0272 |

The PINN's advantage is visible in the prediction plots: the physics-consistency term suppresses the cycle-to-cycle noise that the data-only baseline exhibits, while tracking the knee. Reference: the PINN4SOH paper reports ~0.5–1.2% MAPE on XJTU with per-batch training; this PoC trains across two mixed batches with a smaller network and no tuning sweep, so ~2% is a reasonable reproduction-quality result.

## 3. Diagnostics: residual-based fault detection

A synthetic accelerated-fade fault (extra 0.05% SOH loss per cycle, mimicking e.g. thermal-management degradation) was injected into held-out battery 2C-7 at cycle 219 (60% of life). The detector is a one-sided CUSUM on the innovation residual, self-baselined on each battery's first 60 cycles (k = 5σ, h = 100, σ floor 0.008).

Result: alarm at cycle 346, i.e. **127 cycles after onset**, when the cumulative extra fade reached ≈ 6% SOH — with **zero false alarms** across all four healthy held-out trajectories (≈ 1,080 monitored cycles). The detection margin is wide: healthy CUSUM maxima stayed below 58 while the faulted trajectory exceeded 460.

Honest caveats: thresholds were set with margin against the healthy held-out batteries themselves; a production system would calibrate on a larger healthy fleet. This fault magnitude is near the detectability floor for the short-lived 3C cells (a fault ending at 2.6% extra fade did not separate from noise there).

## 4. Prognostics: RUL by forward-integrating the learned law

From the current state estimate, `dSOH/dt = f(c, t, SOH)` is Euler-integrated to the 80% EOL threshold. No future feature values are assumed — the law depends only on C-rate, time and state.

| Battery | @30% life | @50% life | @70% life | True EOL |
|---|---|---|---|---|
| 2C-7 (pred/true RUL) | 262/283 | 196/210 | 112/137 | 392 |
| 2C-8 | 250/286 | 176/210 | 94/133 | 402 |
| 3C-14 | 133/89 | 158/63 | 104/38 | 131 |
| 3C-15 | 214/99 | 146/70 | 92/42 | 154 |

On the homogeneous 2C group (train lives 373–393), RUL errors are **14–39 cycles, consistently on the conservative (early-warning) side**. On the 3C group the model over-predicts by 44–115 cycles: the training 3C fleet lives span 121–297 cycles, and a fleet-average law cannot resolve cell-to-cell heterogeneity from the SOH state alone — the test cells happen to be among the shortest-lived. This is the expected failure mode of fleet-level prognostics and the standard remedy (per-cell adaptation: recursive Bayesian updating of the law's parameters as each cell's data accumulates, or fine-tuning per PINN4SOH's transfer protocol) is the natural next step.

## 5. Lessons that transfer to the larger physics-AI plan

The loss-penalty vs structural-physics comparison in your survey played out concretely here: the monotonicity constraint only became reliable when moved from a loss penalty into the architecture (−softplus), and the naive PINN formulation (autograd ∂u/∂t as the physics anchor) failed because partial-in-t derivatives miss feature-driven degradation — the discrete state-space (pairwise) formulation with smoothed rate targets is what works. Loss balancing was the dominant failure mode throughout, exactly as the plan's risk register anticipates: physics terms in rate units are 500× amplified relative to SOH units and destroyed training until staged/stop-gradient decoupling separated the objectives.

## 6. Limitations

Laboratory constant-protocol cycling, not production telemetry; one chemistry; synthetic fault applied to the capacity label rather than raw signals; detector thresholds calibrated with knowledge of the healthy held-out set; single seed, no uncertainty quantification (a production RUL system needs prediction intervals, e.g. deep ensembles or MC dropout).

## Artifacts

`runs/poc/metrics.json` (estimation metrics), `vhm_results.json` (diagnostics + RUL), `prognostics.csv`, `figures/` (four plots), `params_pinn.pkl` / `params_baseline.pkl` (weights), `predictions/` (per-battery CSVs).
