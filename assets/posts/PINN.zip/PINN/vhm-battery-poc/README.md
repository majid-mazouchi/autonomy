# VHM Battery PoC — Physics-Informed NN for SOH Monitoring, Diagnostics, Prognostics

Proof of concept for vehicle health management built on a physics-informed neural network trained on the real XJTU battery aging dataset (23 cells, 2C and 3C charging groups, from the PINN4SOH repository accompanying Wang et al., *Nature Communications* 2024).

## What it does

**Monitoring** — a solution network `u(x, t)` estimates state of health from 16 statistical features of a partial charge window. **Diagnostics** — a self-baselined CUSUM detector on the innovation residual (measured − estimated SOH) flags departures from healthy-fleet physics. **Prognostics** — a degradation-law network `f(C-rate, t, SOH)`, constrained non-positive by construction, is forward-integrated from the current state to the 80% EOL threshold to predict remaining useful life.

## Layout

```
src/            data.py, model.py, train.py, vhm_demo.py, plots.py
data/xjtu/      23 battery CSVs (2C + 3C batches)
runs/poc/       metrics.json, vhm_results.json, prognostics.csv,
                params_*.pkl, predictions/, figures/
REPORT.md       results and discussion
```

## Reproduce

```bash
pip install -r requirements.txt
cd src
python train.py --data_dir ../data/xjtu --out ../runs/poc            # both models
python vhm_demo.py --data_dir ../data/xjtu --run ../runs/poc         # diagnostics + RUL
python plots.py --run ../runs/poc --out ../runs/poc/figures
```

CPU-only, JAX; full pipeline runs in about two minutes.

## Headline results (4 held-out batteries)

SOH estimation 1.99% MAPE (data-only MLP baseline: 2.11%). Injected accelerated-fade fault detected 127 cycles after onset with zero false alarms across all healthy held-out trajectories. RUL predicted within 14–39 cycles on the homogeneous 2C group; 3C over-predicted by 44–115 cycles (fleet heterogeneity — see REPORT.md).

Data source: github.com/wang-fujin/PINN4SOH (check upstream citation requirements before derivative use).
