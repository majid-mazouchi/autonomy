Module weld-resistance manufacturing RCA — code & data
======================================================
weld_resistance_rca.py : process-model generator of the 600-module fleet
                         (weld_modules.csv) + full diagnostic pipeline:
                         defect Pareto, correlation screen, partial-correlation
                         confounder test, staged regression, SPC sawtooth,
                         weld-strength vs wear, process capability (Cpk), and
                         the prognosis (dressing-interval optimization + field
                         thermal-flag forecast). Run:  python weld_resistance_rca.py
weld_modules.csv       : the generated mockup dataset (one row per module).
Deps: numpy, scipy.
