---
applyTo: '**/*.py'
---

# Vibration and spectral analysis conventions

When writing code that computes condition indicators from a signal, follow these.

Use the project engine. Call `acf`, `pacf`, `ar_order_aic`, `psd_welch`,
`cross_spectrum`, `real_cepstrum`, `envelope_spectrum`, `bearing_frequencies`,
`time_stats`, `band_kurtosis`, `bispectrum`, `spectrogram_stft`, and `cwt_morlet`
from `scripts/spectral.py` rather than reimplementing.

Detrend and window before any spectral estimate. Compute the kinematic frequencies
from geometry and speed, and read peaks there rather than scanning blindly.

A bearing rate is a modulation: use envelope analysis, choosing the band by
spectral kurtosis. Match the transform to stationarity. Label assumptions in the
code: the sample rate, the window length, and the chosen band next to the call.
