---
mode: agent
description: 'Diagnose a machine fault from a vibration signal by choosing and computing the right condition indicator with the verified engine.'
tools: ['codebase', 'search', 'runCommands']
---

# /diagnose

Turn a vibration (or current) signal into a diagnosis using the project engine.

Inputs the user may give: the signal and sample rate; the machine kinematics
(shaft speed, gear teeth, bearing geometry); and what is suspected. If any is
missing, ask once, then proceed with a stated assumption.

Steps:
1. Compute the kinematic frequencies with `bearing_frequencies` and the mesh/shaft
   rates.
2. Screen with `time_stats` for impulsiveness; report kurtosis and crest factor.
3. Take a `psd_welch`; identify the dominant lines and any resonance.
4. For a bearing, pick the band with `band_kurtosis` and run `envelope_spectrum`;
   match peaks to BPFO/BPFI/BSF/FTF. For a gear, use `real_cepstrum`.
5. If non-stationary, use `spectrogram_stft` or `cwt_morlet`.
6. Report the indicator values, the matched fault frequency, the likely fault and
   location, and the one assumption that would change the conclusion. Cross-check
   `references/pitfalls.md`.

The task to solve: ${input:question:Describe the signal, sample rate, kinematics, and suspected fault}
