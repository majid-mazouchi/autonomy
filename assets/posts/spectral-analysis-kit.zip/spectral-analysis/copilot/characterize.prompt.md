---
mode: agent
description: 'After an indicator alarms, characterize the fault: which mechanism, which frequency, and where in time.'
tools: ['codebase', 'search', 'runCommands']
---

# /characterize

An indicator (a rising kurtosis, a new spectral line) has flagged a problem. Turn
it into a description of the fault.

Steps:
1. Classify the signature. Impulsive (kurtosis, crest) points to a bearing or gear
   impact; a sideband family (cepstrum) to gear modulation; phase coupling
   (bispectrum) to a nonlinear mechanism like looseness.
2. Localize in frequency. Run `envelope_spectrum` over the kurtosis-selected band
   and match peaks to the bearing defect frequencies; or read the gear-mesh
   sidebands.
3. Localize in time if non-stationary. Use `spectrogram_stft` or `cwt_morlet` to
   place the transient against shaft angle.
4. Check assumptions. Confirm detrending, windowing, and the chosen band; verify
   the matched frequency against the kinematics. Cross-check `references/pitfalls.md`.

Output: the fault mechanism, the matched frequency and component, the time of any
transient, and the governing assumption.

The task to solve: ${input:question:Describe the alarmed indicator and what you need characterized}
