"""
Time-series and spectral condition indicators for vibration-based diagnostics.

The methods here turn a raw vibration or current signal into condition indicators:
correlation structure (ACF, PACF) for model order, frequency content (PSD, cross-
spectrum, cepstrum, envelope) for the periodic signatures of bearing and gear
faults, higher-order statistics (kurtosis, skewness, crest factor, bispectrum) for
impulsiveness and nonlinearity, and time-frequency transforms (STFT, wavelet) for
non-stationary transients.

numpy and scipy only. Code is illustrative: window and detrend before spectral
estimation, choose bands from the machine kinematics, and validate indicators
against healthy baselines.
"""
import numpy as np
from scipy import signal, stats


# ===========================================================================
# correlation structure: ACF, PACF, order selection
# ===========================================================================
def acf(x, nlags=40):
    """
    Purpose
    The sample autocorrelation function with its white-noise confidence band. It
    exposes periodicity and memory in a signal, and for a residual it is the basic
    whiteness check; a slowly decaying ACF means strong serial dependence.

    Inputs
    x the series, nlags the number of lags.

    Outputs
    Dict with the autocorrelation at lags 0..nlags and the 95 percent band.
    """
    x = np.asarray(x, float) - np.mean(x); n = len(x)
    c0 = np.dot(x, x) / n
    r = np.array([np.dot(x[:n - k], x[k:]) / n / c0 for k in range(nlags + 1)])
    return dict(lags=np.arange(nlags + 1), acf=r, band=1.96 / np.sqrt(n))


def pacf(x, nlags=40):
    """
    Purpose
    The partial autocorrelation function by the Durbin-Levinson recursion. It is
    the autocorrelation at a lag after removing the effect of all shorter lags, so
    a sharp cutoff after lag p is the signature of an order-p autoregressive
    structure. The standard tool for choosing AR order.

    Inputs
    x the series, nlags the number of lags.

    Outputs
    Dict with the partial autocorrelation at lags 1..nlags and the 95 percent band.
    """
    x = np.asarray(x, float) - np.mean(x); n = len(x)
    c0 = np.dot(x, x) / n
    r = np.array([np.dot(x[:n - k], x[k:]) / n / c0 for k in range(nlags + 1)])
    phi = np.zeros((nlags + 1, nlags + 1)); pac = np.zeros(nlags + 1)
    phi[1, 1] = r[1]; pac[1] = r[1]
    for k in range(2, nlags + 1):
        num = r[k] - sum(phi[k - 1, j] * r[k - j] for j in range(1, k))
        den = 1 - sum(phi[k - 1, j] * r[j] for j in range(1, k))
        phi[k, k] = num / den if den != 0 else 0.0
        for j in range(1, k):
            phi[k, j] = phi[k - 1, j] - phi[k, k] * phi[k - 1, k - j]
        pac[k] = phi[k, k]
    return dict(lags=np.arange(1, nlags + 1), pacf=pac[1:], band=1.96 / np.sqrt(n))


def ar_order_aic(x, maxlag=20):
    """
    Purpose
    Select an autoregressive order by information criterion. It fits an AR model at
    each order by least squares and scores the trade-off between fit and complexity.
    AIC (penalty 2p) is efficient but tends to over-select; BIC (penalty p log n) is
    consistent and parsimonious, so the order is chosen by BIC.

    Inputs
    x the series, maxlag the largest order to try.

    Outputs
    Dict with the AIC and BIC per order and the BIC-selected order.
    """
    x = np.asarray(x, float) - np.mean(x); n = len(x)
    aic, bic = [], []
    for p in range(1, maxlag + 1):
        X = np.column_stack([x[p - j - 1:n - j - 1] for j in range(p)])
        y = x[p:]
        beta, *_ = np.linalg.lstsq(X, y, rcond=None)
        resid = y - X @ beta
        sigma2 = np.dot(resid, resid) / len(y)
        ll = len(y) * np.log(sigma2)
        aic.append(ll + 2 * p); bic.append(ll + p * np.log(len(y)))
    aic = np.array(aic); bic = np.array(bic)
    return dict(orders=np.arange(1, maxlag + 1), aic=aic, bic=bic,
                best=int(np.argmin(bic) + 1))


# ===========================================================================
# frequency domain: PSD, cross-spectrum, cepstrum, envelope
# ===========================================================================
def psd_welch(x, fs, nperseg=256):
    """
    Purpose
    The power spectral density by Welch's method: average the periodograms of
    overlapping windowed segments to trade frequency resolution for a smooth, low-
    variance estimate. The basic frequency-domain condition indicator, where a new
    line or a rising band marks a developing fault.

    Inputs
    x the signal, fs the sample rate, nperseg the segment length.

    Outputs
    Dict with the frequency axis and the power spectral density.
    """
    f, Pxx = signal.welch(np.asarray(x, float), fs=fs, nperseg=min(nperseg, len(x)))
    return dict(f=f, psd=Pxx)


def cross_spectrum(x, y, fs, nperseg=256):
    """
    Purpose
    The cross-spectrum and magnitude-squared coherence between two signals. The
    coherence measures, frequency by frequency, how linearly related two channels
    are, so a coherent peak shows a shared source and helps trace a fault from
    where it is felt to where it originates.

    Inputs
    x and y the two signals, fs the sample rate, nperseg the segment length.

    Outputs
    Dict with the frequency axis, the cross-power magnitude, and the coherence.
    """
    np_ = min(nperseg, len(x))
    f, Pxy = signal.csd(x, y, fs=fs, nperseg=np_)
    fc, Cxy = signal.coherence(x, y, fs=fs, nperseg=np_)
    return dict(f=f, csd_mag=np.abs(Pxy), coherence=Cxy)


def real_cepstrum(x):
    """
    Purpose
    The real cepstrum, the inverse transform of the log magnitude spectrum. By
    turning a family of evenly spaced harmonics or sidebands into a single peak at
    their spacing, it pulls out periodicities in the spectrum itself: gear-mesh
    sideband families, echoes, and repeated harmonic structure.

    Inputs
    x the signal.

    Outputs
    Dict with the quefrency index and the real cepstrum.
    """
    x = np.asarray(x, float)
    spec = np.fft.rfft(x * np.hanning(len(x)))
    logmag = np.log(np.abs(spec) + 1e-12)
    ceps = np.fft.irfft(logmag)
    q = np.arange(len(ceps))
    return dict(quefrency=q, cepstrum=ceps)


def bandpass(x, fs, lo, hi, order=4):
    """
    Purpose
    A zero-phase Butterworth band-pass filter, the front end of envelope analysis:
    isolate the high-frequency resonance band a bearing fault excites before
    demodulating it.

    Inputs
    x the signal, fs the sample rate, lo and hi the band edges in Hz, order the
    filter order.

    Outputs
    The filtered signal.
    """
    b, a = signal.butter(order, [lo / (fs / 2), hi / (fs / 2)], btype="band")
    return signal.filtfilt(b, a, np.asarray(x, float))


def envelope_spectrum(x, fs, band=None):
    """
    Purpose
    Envelope (Hilbert) analysis, the workhorse of bearing diagnostics. A localized
    defect rings the structure at a high resonance once per impact, so the fault
    rate appears not as a spectral line but as the modulation of that resonance.
    Band-passing the resonance, taking the Hilbert envelope, and transforming the
    envelope moves the bearing defect frequencies into plain view.

    Inputs
    x the signal, fs the sample rate, band an optional (lo, hi) resonance band to
    demodulate.

    Outputs
    Dict with the envelope-spectrum frequency axis and magnitude, and the envelope.
    """
    x = np.asarray(x, float)
    xb = bandpass(x, fs, band[0], band[1]) if band else x
    env = np.abs(signal.hilbert(xb))
    env = env - env.mean()
    spec = np.abs(np.fft.rfft(env * np.hanning(len(env))))
    f = np.fft.rfftfreq(len(env), 1 / fs)
    return dict(f=f, env_spec=spec, envelope=np.abs(signal.hilbert(xb)))


def bearing_frequencies(fr, n_balls, d_ball, d_pitch, contact_angle=0.0):
    """
    Purpose
    The characteristic defect frequencies of a rolling-element bearing from its
    geometry and shaft speed: outer race (BPFO), inner race (BPFI), ball (BSF), and
    cage (FTF). These are the lines to look for in the envelope spectrum.

    Inputs
    fr the shaft rate in Hz, n_balls the number of rolling elements, d_ball and
    d_pitch the ball and pitch diameters, contact_angle in radians.

    Outputs
    Dict of the four defect frequencies in Hz.
    """
    ratio = (d_ball / d_pitch) * np.cos(contact_angle)
    return dict(
        FTF=0.5 * fr * (1 - ratio),
        BPFO=0.5 * n_balls * fr * (1 - ratio),
        BPFI=0.5 * n_balls * fr * (1 + ratio),
        BSF=(d_pitch / (2 * d_ball)) * fr * (1 - ratio ** 2),
    )


# ===========================================================================
# higher-order statistics: kurtosis, skewness, crest factor, bispectrum
# ===========================================================================
def time_stats(x):
    """
    Purpose
    The scalar condition indicators computed straight from the waveform: RMS for
    energy, peak and crest factor for impulsiveness, and kurtosis and skewness for
    the shape of the amplitude distribution. Kurtosis in particular climbs sharply
    when a bearing or gear defect makes the signal impulsive, well before RMS moves.

    Inputs
    x the signal.

    Outputs
    Dict with rms, peak, crest factor, kurtosis (normal = 3), and skewness.
    """
    x = np.asarray(x, float)
    rms = np.sqrt(np.mean(x ** 2)); peak = np.max(np.abs(x))
    return dict(rms=float(rms), peak=float(peak), crest=float(peak / rms),
                kurtosis=float(stats.kurtosis(x, fisher=False)),
                skewness=float(stats.skew(x)))


def band_kurtosis(x, fs, bands):
    """
    Purpose
    The spectral-kurtosis idea in miniature: band-pass the signal into candidate
    bands and measure the kurtosis of each, because the band where impulsiveness is
    highest is the best one to demodulate for envelope analysis. A lightweight
    kurtogram for choosing the envelope band.

    Inputs
    x the signal, fs the sample rate, bands a list of (lo, hi) pairs in Hz.

    Outputs
    Dict with the band centers and the kurtosis in each band.
    """
    centers, kurts = [], []
    for lo, hi in bands:
        xb = bandpass(x, fs, lo, hi)
        env = np.abs(signal.hilbert(xb))
        kurts.append(float(stats.kurtosis(env, fisher=False)))
        centers.append(0.5 * (lo + hi))
    return dict(centers=np.array(centers), kurtosis=np.array(kurts))


def bispectrum(x, nfft=128, noverlap=None):
    """
    Purpose
    A direct estimate of the bispectrum, the third-order spectrum, which is nonzero
    only when components are quadratically phase-coupled. Where the power spectrum
    sees two frequencies and a sum frequency as independent, the bispectrum reveals
    whether they share a phase relationship, a fingerprint of the nonlinear coupling
    that mechanical and electrical faults introduce.

    Inputs
    x the signal, nfft the segment length, noverlap the overlap.

    Outputs
    Dict with the frequency axis and the bispectrum magnitude over the (f1, f2) grid.
    """
    x = np.asarray(x, float)
    if noverlap is None:
        noverlap = nfft // 2
    step = nfft - noverlap
    win = np.hanning(nfft)
    half = nfft // 2
    B = np.zeros((half, half), complex); count = 0
    for s in range(0, len(x) - nfft + 1, step):
        X = np.fft.fft((x[s:s + nfft] - x[s:s + nfft].mean()) * win)
        for i in range(half):
            for j in range(half - i):
                B[i, j] += X[i] * X[j] * np.conj(X[i + j])
        count += 1
    B /= max(count, 1)
    f = np.fft.fftfreq(nfft)[:half]
    return dict(f=f, bispec=np.abs(B))


# ===========================================================================
# time-frequency: STFT spectrogram, continuous wavelet transform
# ===========================================================================
def spectrogram_stft(x, fs, nperseg=128, noverlap=None):
    """
    Purpose
    The short-time Fourier transform: slide a window along the signal and transform
    each piece, producing a map of how the spectrum evolves in time. The first tool
    for a non-stationary signal, where a fault transient lives at a particular time
    and frequency rather than across the whole record.

    Inputs
    x the signal, fs the sample rate, nperseg the window, noverlap the overlap.

    Outputs
    Dict with the frequency axis, the time axis, and the spectrogram magnitude.
    """
    if noverlap is None:
        noverlap = nperseg * 3 // 4
    f, t, S = signal.spectrogram(np.asarray(x, float), fs=fs, nperseg=nperseg,
                                 noverlap=noverlap)
    return dict(f=f, t=t, S=S)


def cwt_morlet(x, fs, freqs, w0=6.0):
    """
    Purpose
    The continuous wavelet transform with an analytic Morlet wavelet. Unlike the
    fixed window of the STFT, the wavelet narrows at high frequency and widens at
    low, so it localizes a short, broadband fault transient in time while still
    resolving slow components. The right lens for impulsive, non-stationary faults.

    Inputs
    x the signal, fs the sample rate, freqs the analysis frequencies in Hz, w0 the
    Morlet central frequency.

    Outputs
    Dict with the frequencies and the scalogram magnitude (frequencies by time).
    """
    x = np.asarray(x, float); n = len(x)
    X = np.fft.fft(x)
    omega = 2 * np.pi * np.fft.fftfreq(n, 1 / fs)
    scalo = np.zeros((len(freqs), n))
    for k, fc in enumerate(freqs):
        s = w0 / (2 * np.pi * fc)                       # scale for center freq fc
        psi = (np.pi ** -0.25) * np.sqrt(2) * (omega > 0) * \
              np.exp(-0.5 * (s * omega - w0) ** 2)
        scalo[k] = np.abs(np.fft.ifft(X * psi))
    return dict(freqs=np.asarray(freqs), scalogram=scalo)


# ===========================================================================
# spectral kurtosis and the kurtogram: find the band to demodulate
# ===========================================================================
def spectral_kurtosis(x, fs, nperseg=256, noverlap=None):
    """
    Purpose
    The spectral kurtosis: for each frequency, the kurtosis of the short-time
    spectral magnitude across time. It is large where the signal is impulsive and
    near zero where it is stationary Gaussian, so it points to the frequency band a
    bearing fault excites, the band worth demodulating.

    Inputs
    x the signal, fs the sample rate, nperseg and noverlap the STFT window.

    Outputs
    Dict with the frequency axis and the spectral kurtosis.
    """
    if noverlap is None:
        noverlap = nperseg * 3 // 4
    f, t, Z = signal.stft(np.asarray(x, float), fs=fs, nperseg=nperseg, noverlap=noverlap)
    mag2 = np.abs(Z) ** 2
    m2 = mag2.mean(axis=1)
    m4 = (mag2 ** 2).mean(axis=1)
    sk = m4 / (m2 ** 2 + 1e-20) - 2.0
    return dict(f=f, sk=sk)


def fast_kurtogram(x, fs, nlevel=5, nfreq=128):
    """
    Purpose
    A kurtogram: scan center frequency and bandwidth on a dyadic grid of overlapping
    bands, band-pass the signal into each, and measure the kurtosis of its envelope.
    The band with the highest kurtosis is the optimal one to demodulate for envelope
    analysis, chosen automatically rather than by eye.

    Inputs
    x the signal, fs the sample rate, nlevel the number of dyadic levels, nfreq the
    columns of the output grid.

    Outputs
    Dict with the kurtogram grid (level by frequency), the column frequencies, and
    the best center frequency, bandwidth, band edges, level, and kurtosis.
    """
    x = np.asarray(x, float); nyq = fs / 2
    grid = np.full((nlevel, nfreq), np.nan)
    fcol = np.linspace(0, nyq, nfreq)
    best = dict(kurt=-np.inf, fc=nyq / 2, bw=nyq, band=(fs * 0.01, nyq * 0.9), level=1)
    for lvl in range(1, nlevel + 1):
        nb = 2 ** lvl; bw = nyq / nb; step = bw / 2
        lo = 0.0
        while lo <= nyq - bw + 1:
            hi = lo + bw
            loc = max(lo, fs * 0.004); hic = min(hi, nyq * 0.998)
            if hic - loc >= fs * 0.004:
                try:
                    env = np.abs(signal.hilbert(bandpass(x, fs, loc, hic, order=3)))
                    k = float(stats.kurtosis(env, fisher=False))
                    cols = (fcol >= lo) & (fcol < hi)
                    cur = grid[lvl - 1, cols]
                    grid[lvl - 1, cols] = np.where(np.isnan(cur), k, np.maximum(cur, k))
                    if k > best["kurt"]:
                        best = dict(kurt=k, fc=0.5 * (loc + hic), bw=hic - loc,
                                    band=(loc, hic), level=lvl)
                except Exception:
                    pass
            lo += step
    return dict(grid=grid, fcol=fcol, nlevel=nlevel, nyq=nyq, **best)


# ===========================================================================
# order tracking: resample from time to shaft angle for variable speed
# ===========================================================================
def order_track(x, fs, f_inst, spr=64):
    """
    Purpose
    Computed order tracking. Resample a signal from equal time steps to equal
    increments of shaft angle, using the instantaneous shaft speed, so a component
    locked to the shaft becomes a fixed order regardless of how the speed varies.
    On a run-up the smeared sweeping lines straighten into sharp order peaks.

    Inputs
    x the signal, fs the sample rate, f_inst the instantaneous shaft frequency in Hz
    per sample, spr the resampled samples per revolution.

    Outputs
    Dict with the order axis, the order spectrum, and the angle-resampled signal.
    """
    x = np.asarray(x, float); f_inst = np.asarray(f_inst, float)
    theta = np.cumsum(f_inst) / fs                      # revolutions vs time
    t = np.arange(len(x)) / fs
    total = int(np.floor(theta[-1]))
    ang = np.arange(0, total, 1.0 / spr)
    t_of_ang = np.interp(ang, theta, t)
    xr = np.interp(t_of_ang, t, x)
    X = np.abs(np.fft.rfft((xr - xr.mean()) * np.hanning(len(xr))))
    orders = np.fft.rfftfreq(len(xr), 1.0 / spr)
    return dict(orders=orders, order_spec=X, resampled=xr, spr=spr)


# ===========================================================================
# time-synchronous averaging and gear condition indicators
# ===========================================================================
def time_synchronous_average(x, fs, fr, spr=256, n_rev=None):
    """
    Purpose
    Time-synchronous averaging. Resample to shaft angle and average over revolutions,
    so everything locked to the shaft (the gear-mesh signal and any once-per-rev
    fault) reinforces while noise and non-synchronous content average away. The
    foundational preprocessing of gear diagnostics.

    Inputs
    x the signal, fs the sample rate, fr the shaft rate in Hz, spr samples per
    revolution, n_rev an optional cap on revolutions.

    Outputs
    Dict with the averaged revolution, the revolution count, and samples per rev.
    """
    x = np.asarray(x, float)
    total = int((len(x) / fs) * fr)
    if n_rev:
        total = min(total, n_rev)
    ang = np.arange(total * spr) / spr
    xr = np.interp(ang / fr, np.arange(len(x)) / fs, x)
    rev = xr.reshape(total, spr)
    return dict(tsa=rev.mean(axis=0), n_rev=total, spr=spr)


def gear_indicators(tsa, n_teeth, n_harm=3):
    """
    Purpose
    The classical gear condition indicators from a time-synchronous average. FM0
    compares the peak-to-peak level to the regular mesh energy; FM4, M6A, and M8A
    are normalized higher moments of the residual signal left after the regular mesh
    components are removed, so a localized tooth defect, which disturbs only a few
    teeth, drives them up.

    Inputs
    tsa one averaged revolution, n_teeth the gear tooth count, n_harm the number of
    mesh harmonics treated as regular.

    Outputs
    Dict with FM0, FM4, M6A, and M8A.
    """
    tsa = np.asarray(tsa, float); n = len(tsa)
    X = np.fft.rfft(tsa)
    regular = np.zeros_like(X)
    mesh_amp = 0.0
    for h in range(1, n_harm + 1):
        k = n_teeth * h
        if k < len(X):
            regular[k] = X[k]; mesh_amp += np.abs(X[k])
    reg_sig = np.fft.irfft(regular, n)
    resid = tsa - reg_sig
    d = resid - resid.mean(); var = np.mean(d ** 2) + 1e-20
    fm0 = (tsa.max() - tsa.min()) / (mesh_amp / n * 2 + 1e-20)
    return dict(FM0=float(fm0),
                FM4=float(np.mean(d ** 4) / var ** 2),
                M6A=float(np.mean(d ** 6) / var ** 3),
                M8A=float(np.mean(d ** 8) / var ** 4))


# ===========================================================================
# cyclostationary analysis: the cyclic modulation spectrum
# ===========================================================================
def cyclic_modulation_spectrum(x, fs, nperseg=256, noverlap=None):
    """
    Purpose
    The cyclic modulation spectrum, a fast estimator of the spectral correlation.
    A bearing fault is cyclostationary: the energy in its resonance band is
    modulated at the defect rate. This transform maps that out as a function of two
    frequencies, the carrier frequency f and the cyclic (modulation) frequency
    alpha, so a bearing fault appears as a ridge at alpha equal to the defect rate
    across the resonance, separating random impulsive content from deterministic
    gear and shaft lines.

    Inputs
    x the signal, fs the sample rate, nperseg and noverlap the STFT window.

    Outputs
    Dict with the cyclic-frequency axis alpha, the spectral-frequency axis f, and
    the cyclic modulation spectrum magnitude over the (alpha, f) grid.
    """
    if noverlap is None:
        noverlap = nperseg - max(8, nperseg // 16)     # small hop -> wide cyclic range
    f, t, Z = signal.stft(np.asarray(x, float), fs=fs, nperseg=nperseg, noverlap=noverlap)
    S = np.abs(Z) ** 2
    S = S - S.mean(axis=1, keepdims=True)
    win = np.hanning(S.shape[1])
    C = np.abs(np.fft.rfft(S * win, axis=1))
    dt = t[1] - t[0] if len(t) > 1 else nperseg / fs
    alpha = np.fft.rfftfreq(S.shape[1], dt)
    return dict(alpha=alpha, f=f, cms=C)


# ===========================================================================
# adaptive decomposition, blind deconvolution, liftering, severity
# ===========================================================================
def emd(x, max_imf=6, max_sift=12, sd_tol=0.2):
    """
    Purpose
    Empirical mode decomposition. Without assuming any basis, it peels a signal into
    a small set of intrinsic mode functions, each a narrow-band oscillation, from
    fastest to slowest, plus a residual trend. It adapts to non-stationary and
    nonlinear signals, separating a fast fault transient from slow background motion.

    Inputs
    x the signal, max_imf the maximum number of modes, max_sift the sifting
    iterations, sd_tol the stopping tolerance.

    Outputs
    List of intrinsic mode functions followed by the residual.
    """
    from scipy.interpolate import CubicSpline
    x = np.asarray(x, float); r = x.copy(); imfs = []
    n = len(x); idx = np.arange(n)

    def extrema(s):
        d = np.diff(np.sign(np.diff(s)))
        mx = np.where(d < 0)[0] + 1
        mn = np.where(d > 0)[0] + 1
        return mx, mn

    for _ in range(max_imf):
        h = r.copy()
        for _s in range(max_sift):
            mx, mn = extrema(h)
            if len(mx) < 2 or len(mn) < 2:
                break
            mx = np.r_[0, mx, n - 1]; mn = np.r_[0, mn, n - 1]
            up = CubicSpline(mx, h[mx])(idx)
            lo = CubicSpline(mn, h[mn])(idx)
            mean = 0.5 * (up + lo)
            h_new = h - mean
            if np.sum(mean ** 2) / (np.sum(h ** 2) + 1e-20) < sd_tol:
                h = h_new; break
            h = h_new
        imfs.append(h); r = r - h
        if len(extrema(r)[0]) < 2:
            break
    imfs.append(r)
    return imfs


def med_deconvolve(x, L=40, iters=15):
    """
    Purpose
    Minimum entropy deconvolution. A fault impulse train is blurred by the path it
    travels to the sensor. MED estimates the inverse FIR filter that makes the output
    as impulsive as possible, by iteratively maximizing the output kurtosis, so the
    buried periodic impacts are recovered and sharpened before envelope analysis.

    Inputs
    x the signal, L the filter length, iters the number of iterations.

    Outputs
    Dict with the deconvolved signal and the estimated filter.
    """
    x = np.asarray(x, float); n = len(x)
    X = np.zeros((n, L))
    for i in range(L):
        X[i:, i] = x[:n - i]
    R = X.T @ X + 1e-9 * np.eye(L)
    Rinv = np.linalg.inv(R)
    f = np.zeros(L); f[0] = 1.0
    for _ in range(iters):
        y = X @ f
        b = X.T @ (y ** 3)
        f = Rinv @ b
        f /= np.linalg.norm(f) + 1e-20
    y = X @ f
    return dict(deconvolved=y, filt=f)


def cepstrum_edit(x, q_remove):
    """
    Purpose
    Cepstrum editing (liftering). A regular family of harmonics or sidebands is a
    single peak in the cepstrum, so notching that rahmonic and its multiples removes
    the whole family from the spectrum, cleaning a dominant gear-mesh comb to expose
    weaker structure underneath.

    Inputs
    x the signal, q_remove a list of quefrency indices (and multiples) to notch.

    Outputs
    Dict with the original and edited log-magnitude spectra and the frequency axis.
    """
    x = np.asarray(x, float)
    spec = np.fft.rfft(x * np.hanning(len(x)))
    logmag = np.log(np.abs(spec) + 1e-12)
    ceps = np.fft.irfft(logmag, len(x))
    edited = ceps.copy()
    for q in q_remove:
        for m in range(1, len(ceps) // (q + 1)):
            lo = max(1, m * q - 1)
            edited[lo:m * q + 2] = 0.0
            edited[len(ceps) - m * q - 2:len(ceps) - lo + 1] = 0.0
    logmag_edited = np.fft.rfft(edited, len(x))
    f = np.fft.rfftfreq(len(x))
    return dict(f=f, log_orig=logmag, log_edited=np.real(logmag_edited))


def iso10816_zone(v_rms_mm_s, machine_class="medium"):
    """
    Purpose
    Map a broadband vibration velocity RMS, in millimetres per second, to an ISO
    20816 (formerly 10816) severity zone: A newly commissioned, B unrestricted
    long-term operation, C short-term operation only, D damaging. It turns a measured
    level into an actionable alarm against standard boundaries.

    Inputs
    v_rms_mm_s the velocity RMS in mm/s, machine_class one of small, medium, large
    rigid, or large soft.

    Outputs
    Dict with the zone letter and the A/B, B/C, C/D boundaries.
    """
    table = {
        "small": (0.71, 1.8, 4.5),
        "medium": (1.4, 2.8, 7.1),
        "large_rigid": (2.3, 4.5, 11.0),
        "large_soft": (3.5, 7.1, 18.0),
    }
    ab, bc, cd = table.get(machine_class, table["medium"])
    zone = "A" if v_rms_mm_s < ab else "B" if v_rms_mm_s < bc else "C" if v_rms_mm_s < cd else "D"
    return dict(zone=zone, boundaries=dict(AB=ab, BC=bc, CD=cd))


def _demo():
    rng = np.random.default_rng(0)
    fs = 12000.0
    t = np.arange(8192) / fs

    # AR(2) series for ACF/PACF
    ar = np.zeros(2000)
    for i in range(2, 2000):
        ar[i] = 0.6 * ar[i - 1] - 0.3 * ar[i - 2] + rng.normal(0, 1)
    print("PACF lag1,2,3:", np.round(pacf(ar, 10)["pacf"][:3], 2))
    print("AR order (BIC):", ar_order_aic(ar, 12)["best"])

    # bearing signal: resonance at 3 kHz, impacts at BPFO
    bf = bearing_frequencies(fr=30.0, n_balls=8, d_ball=7.5, d_pitch=39.0)
    bpfo = bf["BPFO"]
    impacts = np.zeros_like(t)
    period = int(fs / bpfo)
    impacts[::period] = 1.0
    resonance = np.sin(2 * np.pi * 3000 * t) * np.exp(-((t % (period / fs)) * 800))
    sig = signal.fftconvolve(impacts, resonance[:period * 2], mode="same")
    sig += 0.4 * rng.normal(0, 1, len(t))
    print("BPFO = %.1f Hz" % bpfo)
    es = envelope_spectrum(sig, fs, band=(2500, 3500))
    peak_f = es["f"][1 + np.argmax(es["env_spec"][1:400])]
    print("envelope peak near %.1f Hz (BPFO %.1f)" % (peak_f, bpfo))
    print("kurtosis healthy vs bearing:",
          round(time_stats(rng.normal(0, 1, 4096))["kurtosis"], 2), "vs",
          round(time_stats(sig)["kurtosis"], 2))

    bs = bispectrum(sig[:2048], nfft=128)
    print("bispectrum grid:", bs["bispec"].shape, "max", round(float(bs["bispec"].max()), 1))
    sp = spectrogram_stft(sig, fs, nperseg=256)
    print("spectrogram:", sp["S"].shape)
    cw = cwt_morlet(sig[:2048], fs, np.linspace(500, 5000, 40))
    print("scalogram:", cw["scalogram"].shape)

    # ---- advanced: kurtogram, order tracking, TSA, cyclostationary, more ----
    impr = np.zeros(int(fs * 0.8)); impr[::int(round(fs / bpfo))] = 1.0
    bb, aa = signal.butter(2, [(3000 - 700) / (fs / 2), (3000 + 700) / (fs / 2)], "band")
    sigr = signal.filtfilt(bb, aa, impr); sigr /= sigr.std()
    sigr = sigr + 0.3 * rng.normal(0, 1, len(sigr))     # impacts ringing a 3 kHz resonance
    sk = spectral_kurtosis(sigr, fs)
    psr = psd_welch(sigr, fs, 512)
    pmask = np.interp(sk["f"], psr["f"], psr["psd"]) > 0.05 * psr["psd"].max()
    fpk = sk["f"][pmask][np.argmax(sk["sk"][pmask])]
    print("peak SK at %.0f Hz (in the signal band)" % fpk)
    kg = fast_kurtogram(sigr, fs, nlevel=4)
    print("kurtogram best band %.0f-%.0f Hz (fc %.0f) kurt %.1f" % (kg["band"][0], kg["band"][1], kg["fc"], kg["kurt"]))

    # order tracking on a run-up (shaft 20 -> 60 Hz)
    K2 = 16000; t2 = np.arange(K2) / fs
    f_inst = 20 + 40 * t2 / t2[-1]
    phase = 2 * np.pi * np.cumsum(f_inst) / fs
    run = np.sin(2 * phase) + 0.6 * np.sin(3 * phase) + 0.3 * rng.normal(0, 1, K2)
    ot = order_track(run, fs, f_inst, spr=64)
    top = ot["orders"][1 + np.argmax(ot["order_spec"][1:200])]
    print("order tracking top order %.2f (expect 2 or 3)" % top)

    # TSA + gear indicators (24-tooth gear, shaft 30 Hz)
    teeth = 24; fr = 30.0
    tg = np.arange(20000) / fs
    mesh = np.sin(2 * np.pi * teeth * fr * tg) + 0.4 * np.sin(2 * np.pi * 2 * teeth * fr * tg)
    fault = ((tg * fr) % 1.0 < 0.01) * 3.0
    gear = mesh + fault + 0.8 * rng.normal(0, 1, len(tg))
    ts = time_synchronous_average(gear, fs, fr, spr=256)
    gi = gear_indicators(ts["tsa"], teeth)
    print("TSA revs %d, FM4 %.1f M6A %.1f" % (ts["n_rev"], gi["FM4"], gi["M6A"]))

    cms = cyclic_modulation_spectrum(sigr, fs)
    prof = cms["cms"][:, 1:].mean(0)
    aa2 = cms["alpha"][1:][np.argmax(prof[1:])]
    print("CMS dominant cyclic freq %.0f Hz (BPFO %.0f)" % (aa2, bpfo))

    imfs = emd(run[:2000]); print("EMD imfs:", len(imfs))
    imp = np.zeros(2000); imp[::120] = 1.0
    smear = signal.fftconvolve(imp, np.exp(-np.arange(40) / 6.0), mode="same") + 0.3 * rng.normal(0, 1, 2000)
    md = med_deconvolve(smear, L=40)
    print("MED kurtosis %.1f -> %.1f" % (stats.kurtosis(smear, fisher=False),
                                         stats.kurtosis(md["deconvolved"], fisher=False)))
    print("ISO zone for 5.0 mm/s:", iso10816_zone(5.0)["zone"])


if __name__ == "__main__":
    _demo()
