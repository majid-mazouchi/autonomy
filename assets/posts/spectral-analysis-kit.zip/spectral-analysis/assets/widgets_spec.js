/* Interactive explorers for the time-series & spectral monograph. Vanilla JS. */
(function () {
  "use strict";
  var INK = "#221d17", MUTE = "#7a6f5e", RUST = "#b0492f",
      TEAL = "#1f6f6a", OCHRE = "#c4922b", LINE = "#d9cfb8";

  function fit(c){var d=window.devicePixelRatio||1,w=c.clientWidth||600,h=c.clientHeight||240;
    c.width=w*d;c.height=h*d;var x=c.getContext("2d");x.setTransform(d,0,0,d,0,0);return {ctx:x,w:w,h:h};}
  function rng(seed){var s=seed>>>0;return function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
  function gauss(n,seed){var r=rng(seed),o=new Float64Array(n),i;
    for(i=0;i<n;i++){var u=Math.max(1e-9,r()),v=r();o[i]=Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}return o;}

  // compact iterative radix-2 FFT, in-place on (re, im)
  function fft(re, im, inv){
    var n=re.length, i, j=0, k, m;
    for(i=0;i<n-1;i++){
      if(i<j){var tr=re[i];re[i]=re[j];re[j]=tr;var ti=im[i];im[i]=im[j];im[j]=ti;}
      k=n>>1; while(k<=j){j-=k;k>>=1;} j+=k;
    }
    for(m=1;m<n;m<<=1){
      var step=m<<1, ang=(inv?Math.PI:-Math.PI)/m;
      for(var g=0;g<m;g++){
        var wr=Math.cos(ang*g), wi=Math.sin(ang*g);
        for(i=g;i<n;i+=step){
          var jj=i+m, xr=re[jj]*wr-im[jj]*wi, xi=re[jj]*wi+im[jj]*wr;
          re[jj]=re[i]-xr; im[jj]=im[i]-xi; re[i]+=xr; im[i]+=xi;
        }
      }
    }
    if(inv){for(i=0;i<n;i++){re[i]/=n;im[i]/=n;}}
  }
  function moments(a){var n=a.length,m=0,i;for(i=0;i<n;i++)m+=a[i];m/=n;
    var s2=0,s4=0,pk=0;for(i=0;i<n;i++){var d=a[i]-m;s2+=d*d;s4+=d*d*d*d;if(Math.abs(a[i])>pk)pk=Math.abs(a[i]);}
    s2/=n;s4/=n;var rms=Math.sqrt(s2);
    return {kurt:s4/(s2*s2), crest:pk/rms, rms:rms};}

  // ======================================================================
  // A. ACF / PACF explorer
  // ======================================================================
  (function corr(){
    var cv=document.getElementById("ex-c-canvas"); if(!cv) return;
    var s1=document.getElementById("ex-c-p1"), s2=document.getElementById("ex-c-p2"),
        read=document.getElementById("ex-c-read"), cap=document.getElementById("ex-c-cap");
    var N=1200, e=gauss(N,5);
    function draw(){
      var phi1=parseFloat(s1.value)/100*1.6-0.8, phi2=parseFloat(s2.value)/100*1.4-0.85, i, k;
      var x=new Float64Array(N); x[0]=e[0]; x[1]=e[1]+phi1*x[0];
      for(i=2;i<N;i++) x[i]=phi1*x[i-1]+phi2*x[i-2]+e[i];
      var m=0;for(i=0;i<N;i++)m+=x[i];m/=N;for(i=0;i<N;i++)x[i]-=m;
      var L=16, c0=0;for(i=0;i<N;i++)c0+=x[i]*x[i];c0/=N;
      var r=[1];for(k=1;k<=L;k++){var c=0;for(i=0;i<N-k;i++)c+=x[i]*x[i+k];r.push(c/N/c0);}
      // PACF via Durbin-Levinson
      var phi=[]; for(i=0;i<=L;i++)phi.push(new Float64Array(L+1));
      var pac=new Float64Array(L+1); phi[1][1]=r[1]; pac[1]=r[1];
      for(k=2;k<=L;k++){var num=r[k],den=1;for(var j=1;j<k;j++){num-=phi[k-1][j]*r[k-j];den-=phi[k-1][j]*r[j];}
        phi[k][k]=den!==0?num/den:0;for(j=1;j<k;j++)phi[k][j]=phi[k-1][j]-phi[k][k]*phi[k-1][k-j];pac[k]=phi[k][k];}
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=26,band=1.96/Math.sqrt(N);
      ctx.clearRect(0,0,w,h);
      function panel(y0,ph,vals,lab,col){
        var mid=y0+h*0.20, sc=(h*0.16)/1.05, bw=(w-2*pad)/L;
        ctx.strokeStyle=LINE;ctx.setLineDash([3,3]);
        [band,-band].forEach(function(bb){ctx.beginPath();ctx.moveTo(pad,mid-bb*sc);ctx.lineTo(w-pad,mid-bb*sc);ctx.stroke();});
        ctx.setLineDash([]);ctx.strokeStyle=MUTE;ctx.beginPath();ctx.moveTo(pad,mid);ctx.lineTo(w-pad,mid);ctx.stroke();
        for(var kk=1;kk<=L;kk++){ctx.fillStyle=col;ctx.fillRect(pad+(kk-1)*bw+bw*0.25,mid,bw*0.5,-vals[kk]*sc);}
        ctx.fillStyle=MUTE;ctx.font="10px monospace";ctx.fillText(lab,pad,y0+10);
      }
      panel(8, r, r, "ACF (lags 1-16)", TEAL);
      panel(h*0.50, pac, pac, "PACF (lags 1-16)", OCHRE);
      read.innerHTML="AR(2) with phi1=<b>"+phi1.toFixed(2)+"</b>, phi2=<b>"+phi2.toFixed(2)+
        "</b> &rarr; PACF cuts off after lag <b style='color:"+OCHRE+"'>2</b>";
      cap.textContent="The ACF of an AR process decays slowly; the PACF cuts off sharply at the model order. Read the order off the last PACF bar that clears the band.";
    }
    [s1,s2].forEach(function(e){e.addEventListener("input",draw);}); window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // B. Envelope analysis explorer (the bearing workhorse)
  // ======================================================================
  (function envelope(){
    var cv=document.getElementById("ex-e-canvas"); if(!cv) return;
    var sBpfo=document.getElementById("ex-e-bpfo"), sNoise=document.getElementById("ex-e-noise"),
        read=document.getElementById("ex-e-read"), cap=document.getElementById("ex-e-cap");
    var Nfft=2048, fs=12000, g=gauss(Nfft,13);
    function draw(){
      var bpfo=parseFloat(sBpfo.value)/100*120+60, noise=parseFloat(sNoise.value)/100*1.2+0.05, i;
      // build impulsive signal: impacts ring a 3 kHz resonance
      var re=new Float64Array(Nfft), im=new Float64Array(Nfft);
      var period=Math.round(fs/bpfo);
      for(i=0;i<Nfft;i++){
        var ph=i%period;
        re[i]=Math.sin(2*Math.PI*3000*ph/fs)*Math.exp(-450*ph/fs) + noise*g[i];
      }
      // analytic signal via Hilbert: fft, zero negative freqs, ifft
      var fr=re.slice(), fi=im.slice(); fft(fr,fi,false);
      var H=new Float64Array(Nfft); H[0]=1; H[Nfft/2]=1;
      for(i=1;i<Nfft/2;i++)H[i]=2; // positive freqs doubled, negatives zero
      for(i=0;i<Nfft;i++){fr[i]*=H[i];fi[i]*=H[i];}
      fft(fr,fi,true);
      var env=new Float64Array(Nfft),em=0;
      for(i=0;i<Nfft;i++){env[i]=Math.sqrt(fr[i]*fr[i]+fi[i]*fi[i]);em+=env[i];}
      em/=Nfft;for(i=0;i<Nfft;i++)env[i]-=em;
      // envelope spectrum
      var er=env.slice(), ei=new Float64Array(Nfft); fft(er,ei,false);
      var half=Nfft/2, spec=new Float64Array(half), mx=0, mxk=0;
      for(i=0;i<half;i++){spec[i]=Math.sqrt(er[i]*er[i]+ei[i]*ei[i]);}
      var df=fs/Nfft, fmaxbin=Math.floor(600/df);
      for(i=2;i<fmaxbin;i++){if(spec[i]>mx){mx=spec[i];mxk=i;}}
      var peakf=mxk*df;
      // the envelope spectrum is a comb at multiples of BPFO; a peak at k*BPFO implies BPFO
      var implied=peakf, kk2=Math.round(peakf/bpfo);
      if(kk2>=1 && Math.abs(peakf-kk2*bpfo)<bpfo*0.08) implied=peakf/kk2;
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=30;ctx.clearRect(0,0,w,h);
      ctx.fillStyle=MUTE;ctx.font="10px monospace";ctx.fillText("envelope spectrum (0-600 Hz)",pad,14);
      var x0=pad, x1=w-pad, y1=h-pad;
      function X(fr_){return x0+(fr_/600)*(x1-x0);}
      function Y(v){return y1-(v/(mx*1.1))*(h-2*pad-10);}
      // BPFO harmonics
      for(var kk=1;kk<=4;kk++){var fx=X(kk*bpfo);if(fx<x1){ctx.strokeStyle=LINE;ctx.setLineDash([3,3]);
        ctx.beginPath();ctx.moveTo(fx,pad+10);ctx.lineTo(fx,y1);ctx.stroke();ctx.setLineDash([]);}}
      ctx.strokeStyle=TEAL;ctx.lineWidth=1.1;ctx.beginPath();
      for(i=0;i<fmaxbin;i++){var px=X(i*df);if(i===0)ctx.moveTo(px,Y(spec[i]));else ctx.lineTo(px,Y(spec[i]));}ctx.stroke();
      ctx.fillStyle=RUST;ctx.fillText("BPFO "+bpfo.toFixed(0)+" Hz",X(bpfo)+3,pad+22);
      var hit=Math.abs(implied-bpfo)<bpfo*0.08;
      read.innerHTML="defect frequency set to <b>"+bpfo.toFixed(0)+" Hz</b>, envelope comb implies <b style='color:"+
        (hit?TEAL:RUST)+"'>"+implied.toFixed(0)+" Hz</b> &rarr; "+
        (hit?"<b style='color:"+TEAL+"'>BPFO recovered</b>":"buried in noise, raise the signal or pick a better band");
      cap.textContent="A bearing defect rings a resonance once per impact. The raw spectrum shows the resonance, not the defect rate; the envelope spectrum exposes the defect frequency and its harmonics.";
    }
    [sBpfo,sNoise].forEach(function(e){e.addEventListener("input",draw);}); window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // C. Kurtosis / impulsiveness explorer
  // ======================================================================
  (function kurt(){
    var cv=document.getElementById("ex-k-canvas"); if(!cv) return;
    var sImp=document.getElementById("ex-k-imp"), read=document.getElementById("ex-k-read"),
        cap=document.getElementById("ex-k-cap");
    var N=2000, g=gauss(N,17), u=rng(31);
    var spikes=[];for(var q=0;q<N;q++)spikes.push(u());
    function draw(){
      var imp=parseFloat(sImp.value)/100, i;        // 0 = pure noise, 1 = very impulsive
      var x=new Float64Array(N);
      for(i=0;i<N;i++){x[i]=g[i];
        if(spikes[i]<0.02*imp) x[i]+=(spikes[i]<0.01*imp?1:-1)*(6+10*imp);}
      var st=moments(x);
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=24;ctx.clearRect(0,0,w,h);
      var mid=h*0.5, sc=(h*0.4)/Math.max(6,st.crest*st.rms*1.1);
      ctx.strokeStyle=INK;ctx.lineWidth=0.6;ctx.beginPath();
      for(i=0;i<N;i++){var px=pad+i/(N-1)*(w-2*pad);if(i===0)ctx.moveTo(px,mid-x[i]*sc);else ctx.lineTo(px,mid-x[i]*sc);}ctx.stroke();
      ctx.fillStyle=MUTE;ctx.font="10px monospace";ctx.fillText("waveform",pad,14);
      var faulty=st.kurt>4.5;
      read.innerHTML="kurtosis = <b style='color:"+(faulty?RUST:TEAL)+"'>"+st.kurt.toFixed(1)+
        "</b> (normal 3), crest factor = <b>"+st.crest.toFixed(1)+"</b> &rarr; <b style='color:"+
        (faulty?RUST:TEAL)+"'>"+(faulty?"impulsive (incipient bearing/gear defect)":"near-Gaussian (healthy)")+"</b>";
      cap.textContent="Kurtosis and crest factor measure impulsiveness. A few sharp impacts barely move the RMS but drive kurtosis well above 3, which is why they flag bearing and gear defects early.";
    }
    sImp.addEventListener("input",draw); window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // D. Time-synchronous averaging
  // ======================================================================
  (function tsa(){
    var cv=document.getElementById("ex-tsa-canvas"); if(!cv) return;
    var sN=document.getElementById("ex-tsa-n"), read=document.getElementById("ex-tsa-read"),
        cap=document.getElementById("ex-tsa-cap");
    var spr=360, teeth=18, NR=48;
    var noise=[], nsync=[]; for(var r=0;r<NR;r++){noise.push(gauss(spr,100+r)); nsync.push(Math.random()*2*Math.PI);}
    function draw(){
      var N=parseInt(sN.value,10), i, r;
      var avg=new Float64Array(spr);
      for(r=0;r<N;r++){ for(i=0;i<spr;i++){
        var th=i/spr;
        var mesh=Math.sin(2*Math.PI*teeth*th)+0.4*Math.sin(2*Math.PI*2*teeth*th);
        var fault=(th<0.02)?2.2:0;
        var ns=0.7*Math.sin(2*Math.PI*5.3*th + nsync[r]);   // non-synchronous: random phase per rev
        avg[i]+=mesh+fault+ns+1.0*noise[r][i];
      }}
      for(i=0;i<spr;i++)avg[i]/=N;
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=22;ctx.clearRect(0,0,w,h);
      ctx.fillStyle=MUTE;ctx.font="10px monospace";ctx.fillText("averaged revolution (1 shaft turn)",pad,14);
      var mid=h*0.5, sc=h*0.13;
      ctx.strokeStyle=MUTE;ctx.lineWidth=0.5;ctx.beginPath();ctx.moveTo(pad,mid);ctx.lineTo(w-pad,mid);ctx.stroke();
      ctx.strokeStyle=TEAL;ctx.lineWidth=1.1;ctx.beginPath();
      for(i=0;i<spr;i++){var px=pad+i/(spr-1)*(w-2*pad);if(i===0)ctx.moveTo(px,mid-avg[i]*sc);else ctx.lineTo(px,mid-avg[i]*sc);}ctx.stroke();
      read.innerHTML="averaging <b>"+N+"</b> revolution"+(N>1?"s":"")+" &rarr; noise and non-synchronous content down ~<b style='color:"+TEAL+"'>"+Math.sqrt(N).toFixed(1)+"x</b>; the gear mesh and the once-per-rev fault emerge";
      cap.textContent="Synchronous averaging keeps whatever repeats every shaft revolution and averages away everything else. With one revolution the pattern is buried; with many, the mesh teeth and the fault impulse stand clear.";
    }
    sN.addEventListener("input",draw); window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // E. Order tracking
  // ======================================================================
  (function order(){
    var cv=document.getElementById("ex-ot-canvas"); if(!cv) return;
    var sV=document.getElementById("ex-ot-var"), read=document.getElementById("ex-ot-read"),
        cap=document.getElementById("ex-ot-cap");
    var N=2048, fs=2000, g=gauss(N,77);
    function draw(){
      var sv=parseFloat(sV.value)/100, i;
      var f0=80, ordK=3;                                   // component at order 3
      var phase=new Float64Array(N), ph=0;
      var finst=new Float64Array(N);
      for(i=0;i<N;i++){ finst[i]=f0*(1+sv*(i/N)); ph+=2*Math.PI*finst[i]/fs; phase[i]=ph; }
      var re=new Float64Array(N), im=new Float64Array(N);
      for(i=0;i<N;i++){ re[i]=Math.sin(ordK*phase[i])+0.25*g[i]; }
      // raw spectrum
      var rr=re.slice(), ri=new Float64Array(N); fft(rr,ri,false);
      var half=N/2, raw=new Float64Array(half), mx=0;
      for(i=0;i<half;i++){raw[i]=Math.sqrt(rr[i]*rr[i]+ri[i]*ri[i]);if(raw[i]>mx)mx=raw[i];}
      // order tracking: resample to equal angle
      var theta=new Float64Array(N); for(i=0;i<N;i++)theta[i]=phase[i]/(2*Math.PI);
      var spr=32, totalRev=Math.floor(theta[N-1]);
      var M=totalRev*spr, xr=new Float64Array(M);
      for(i=0;i<M;i++){ var ang=i/spr;
        // find time index for this angle (theta is monotonic) via linear search/interp
        var lo=0,hi=N-1; while(hi-lo>1){var m=(lo+hi)>>1; if(theta[m]<ang)lo=m;else hi=m;}
        var frac=(ang-theta[lo])/((theta[hi]-theta[lo])||1); xr[i]=re[lo]+frac*(re[hi]-re[lo]); }
      // pad to power of 2
      var P=1; while(P<M)P<<=1;
      var orr=new Float64Array(P), ori=new Float64Array(P);
      for(i=0;i<M;i++)orr[i]=xr[i]; fft(orr,ori,false);
      var ohalf=P/2, ords=new Float64Array(ohalf), omx=0;
      for(i=0;i<ohalf;i++){ords[i]=Math.sqrt(orr[i]*orr[i]+ori[i]*ori[i]);if(ords[i]>omx)omx=ords[i];}
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=26;ctx.clearRect(0,0,w,h);
      ctx.fillStyle=MUTE;ctx.font="10px monospace";
      ctx.fillText("raw spectrum (smears with speed)",pad,13);
      ctx.fillStyle=RUST;ctx.fillText("order spectrum (stays sharp)",w/2+10,13);
      // left: raw spectrum 0-400 Hz
      var fmax=400, fb=Math.floor(fmax/(fs/N)), x0=pad, x1=w/2-6, y1=h-pad, ytop=22;
      ctx.strokeStyle=MUTE;ctx.lineWidth=1;ctx.beginPath();
      for(i=0;i<fb;i++){var px=x0+(i/(fb-1))*(x1-x0), py=y1-(raw[i]/(mx*1.05))*(y1-ytop);if(i===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);}ctx.stroke();
      // right: order spectrum 0-8 orders
      var omax=8, ob=Math.floor(omax*spr* (P/M) /1); ob=Math.min(ob, ohalf-1);
      var ordPerBin=spr/(P/ (M))/M; // orders per bin = spr/P * (P/M)... compute directly
      // order axis: bin k -> order = k * spr / P  (since resampled at spr/rev, length P)
      var x2=w/2+6, x3=w-pad;
      ctx.strokeStyle=RUST;ctx.lineWidth=1;ctx.beginPath();
      var firstO=true;
      for(i=0;i<ohalf;i++){ var order=i*spr/P; if(order>omax)break;
        var px=x2+(order/omax)*(x3-x2), py=y1-(ords[i]/(omx*1.05))*(y1-ytop);
        if(firstO){ctx.moveTo(px,py);firstO=false;}else ctx.lineTo(px,py);}ctx.stroke();
      ctx.fillStyle=TEAL;ctx.font="9px monospace";
      ctx.fillText("order 3",x2+(3/omax)*(x3-x2)-14,y1-2);
      read.innerHTML="speed variation <b>"+(sv*100).toFixed(0)+"%</b> &rarr; the raw peak <b style='color:"+MUTE+"'>smears</b> across frequency while the order peak <b style='color:"+RUST+"'>stays sharp</b> at order 3";
      cap.textContent="When shaft speed varies, a component locked to the shaft sweeps in frequency and its raw spectral peak smears. Resampling to equal shaft angle puts it back at a fixed order, sharp regardless of the speed profile.";
    }
    sV.addEventListener("input",draw); window.addEventListener("resize",draw); draw();
  })();
})();
