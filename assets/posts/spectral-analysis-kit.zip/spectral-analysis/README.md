# Time-series & spectral analysis kit

A VS Code Copilot skill for vibration-based condition monitoring, in the
progressive-disclosure layout. Read `SKILL.md` first; it routes to the rest.

## Layout
- `SKILL.md` routing and overview.
- `references/01-correlation-structure.md` covers correlation structure, what memory does the signal carry?.
- `references/02-frequency-domain.md` covers frequency domain, which lines and bands carry the fault?.
- `references/03-higher-order-statistics.md` covers higher-order statistics, how impulsive and how nonlinear?.
- `references/04-time-frequency.md` covers time-frequency, where in time does the fault live?.
- `references/05-kurtogram-and-order-tracking.md` covers kurtogram and order tracking.
- `references/06-synchronous-averaging.md` covers synchronous averaging and gear indicators.
- `references/07-cyclostationary.md` covers cyclostationary analysis.
- `references/08-decomposition-deconvolution-severity.md` covers decomposition, deconvolution, liftering, and severity.
- `references/decision-map.md`, `references/rules-of-thumb.md`, `references/pitfalls.md`, `references/case-study.md`, `references/at-a-glance.md`, `references/references.md`.
- `scripts/spectral.py` the tested engine (numpy, scipy only). Run it for a self-test:

      python scripts/spectral.py

- `copilot/` a vibration-analyst chat mode, a `/diagnose` and a `/characterize` prompt, and path-scoped instructions.
- `assets/spectral-analysis.html` the full illustrated monograph.
