# Rules of thumb

1. Detrend and window before any spectral estimate. Low-frequency drift and edge discontinuities leak across the spectrum and masquerade as faults.
2. Read peaks at the machine's kinematic frequencies, not blindly. Compute the shaft, mesh, and bearing defect frequencies from the geometry and speed first, then look there.
3. A bearing rate is a modulation, not a line. Use envelope analysis, not the raw spectrum, to find outer-race, inner-race, ball, and cage defect frequencies.
4. Choose the envelope band where impulsiveness is highest. A spectral-kurtosis or kurtogram scan picks the resonance to demodulate better than a guess.
5. Kurtosis and crest factor catch impulsive faults early but saturate. Trend them alongside RMS, since kurtosis can fall back toward three as a fault matures.
6. Match the transform to stationarity. PSD for a steady regime, STFT for a run-up, the wavelet for short broadband transients; a Fourier spectrum of a changing signal is misleading.
7. Resolution is a trade-off you must choose. Longer windows resolve close frequencies, shorter ones localize transients; there is no setting that does both.
8. Express frequency in orders when speed varies. Order-tracking against shaft speed keeps a kinematic line sharp instead of smearing it across a run-up.

## Pick by scenario

| Scenario | Pick | Why |
| --- | --- | --- |
| Find the dominant periodicity and model order | ACF / PACF | correlation structure and AR order |
| Spot a new line or rising harmonic | Welch PSD | smooth, low-variance spectrum |
| Decide if two sensors share a source | coherence | linear association per frequency |
| Track a gear sideband family | cepstrum | collapses the family to one peak |
| Find a rolling-bearing defect frequency | envelope analysis | demodulates the resonance |
| Catch an early impulsive bearing fault | kurtosis / crest factor | impulsiveness before RMS moves |
| Expose nonlinear frequency coupling | bispectrum | phase coupling the PSD misses |
| Analyze a variable-speed run-up | STFT spectrogram | spectrum evolving in time |
| Localize a brief broadband transient | wavelet (CWT) | adaptive time-frequency resolution |
