# Cyclostationary analysis

## Cyclic modulation spectrum

**Essence.** A fast estimator of the spectral correlation. It maps energy against two frequencies, the carrier f and the cyclic modulation frequency alpha, so a bearing fault appears as a ridge at alpha equal to the defect rate across its resonance, separating random impulsive content from deterministic lines.

**In plain words.** A bearing fault is not stationary and not periodic but cyclostationary: the random ringing is repeated, with statistics that cycle at the defect rate. The cyclic modulation spectrum captures that by asking, for each carrier frequency, how strongly its energy is modulated and at what rate. The result is a map over the carrier frequency f and the cyclic frequency alpha, on which a bearing fault is a vertical ridge at alpha equal to its defect frequency, spread across the resonance band in f. Deterministic gear and shaft lines sit at their own cyclic frequencies and so separate out, which is why the cyclic approach succeeds on mixed signals where a plain envelope spectrum blends everything together.

**Diagnostic example.** A signal carries both a strong gear mesh and a weak bearing fault. The envelope spectrum is dominated by the gear and its sidebands; the cyclic modulation spectrum places the gear content at the shaft cyclic frequency and reveals the bearing as a separate ridge at its defect rate across the resonance.

**Engine call.** `cyclic_modulation_spectrum(x, fs, nperseg=256)`

```python
import numpy as np
from scipy import signal

def cyclic_modulation_spectrum(x, fs, nperseg=256):
    noverlap = nperseg - max(8, nperseg//16)      # small hop -> wide alpha
    f, t, Z = signal.stft(x, fs, nperseg=nperseg, noverlap=noverlap)
    S = np.abs(Z)**2; S = S - S.mean(axis=1, keepdims=True)
    C = np.abs(np.fft.rfft(S*np.hanning(S.shape[1]), axis=1))
    alpha = np.fft.rfftfreq(S.shape[1], t[1]-t[0])
    return alpha, f, C        # ridge at alpha = defect rate
```

**Practical note.** The cyclic frequency range is set by the analysis frame rate, so use enough overlap to reach the defect frequencies and their harmonics. Deterministic components can still mask faint faults, so the normalized form, the cyclic spectral coherence, is preferred for weak signatures. It costs more than envelope analysis but separates sources the envelope blends.

**Reference.** Antoni (2009), Mech. Syst. Signal Process. 23; Borghesani & Antoni (2018), MSSP 105.
