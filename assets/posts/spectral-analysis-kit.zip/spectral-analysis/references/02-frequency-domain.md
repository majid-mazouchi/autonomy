# Frequency domain, which lines and bands carry the fault?

_A fault advertises itself at a frequency tied to the machine kinematics: a shaft rate, a gear-mesh frequency, a bearing defect rate. The frequency-domain tools move those signatures into view, including the ones, like a bearing rate, that hide as modulation rather than a line._

## Power spectral density (Welch)

**Essence.** The distribution of power over frequency, estimated by averaging the periodograms of overlapping windowed segments for a smooth, low-variance result. The basic frequency-domain condition indicator.

**In plain words.** A single Fourier transform of a noisy signal gives a spectrum so erratic that real peaks are hard to separate from scatter. Welch's method tames that by splitting the record into overlapping segments, windowing each to control leakage, transforming them, and averaging the resulting power spectra. The price is coarser frequency resolution; the reward is a stable estimate in which a genuine line stands clear of the floor. In condition monitoring the lines sit at known kinematic frequencies, so a new line, a rising harmonic, or a growing band is read directly as a developing fault.

**Diagnostic example.** An induction motor develops a broken rotor bar, which plants sidebands around the supply frequency at twice the slip frequency. Averaged over many segments, the Welch spectrum resolves those small sidebands from the noise floor, where a raw periodogram would bury them in variance.

**Engine call.** `psd_welch(x, fs, nperseg=256)`

```python
from scipy import signal

def psd_welch(x, fs, nperseg=1024):
    f, Pxx = signal.welch(x, fs=fs, nperseg=nperseg)
    return f, Pxx

f, Pxx = psd_welch(vibration, fs=12000, nperseg=1024)
# inspect Pxx at kinematic frequencies (shaft, mesh, sidebands)
```

**Practical note.** The segment length trades resolution against variance: longer segments resolve close lines but average fewer, so the estimate is noisier. Always window to control leakage, and read peaks at the machine's kinematic frequencies rather than hunting blindly. Express axes in orders of shaft speed when the speed varies, so a line does not smear.

**Reference.** Welch (1967), IEEE Trans. Audio Electroacoust. 15; Oppenheim & Schafer (2010), Discrete-Time Signal Processing.

## Cross-spectrum and coherence

**Essence.** The frequency-by-frequency linear relationship between two signals. Coherence near one at a frequency means a shared source, which helps trace a fault from where it is sensed back to where it originates.

**In plain words.** A single sensor cannot say whether two peaks at the same frequency on two channels come from one source or two coincidences. The cross-spectrum and its normalized form, the magnitude-squared coherence, answer that: coherence runs between zero and one and measures how consistently the phase between the channels holds at each frequency. A value near one means the two are linearly linked there, sharing a common source or a transmission path; a value near zero means they are independent. It is the tool for path analysis, deciding which of several measurement points actually drives a resonance and which merely feel it.

**Diagnostic example.** Two accelerometers on a pump both show a peak near a structural resonance. High coherence between them at that frequency confirms a single shared excitation traveling through the structure, rather than two local sources, focusing the search for the root cause on the common path.

**Engine call.** `cross_spectrum(x, y, fs, nperseg=256)`

```python
from scipy import signal
import numpy as np

def coherence_xy(x, y, fs, nperseg=1024):
    f, Pxy = signal.csd(x, y, fs=fs, nperseg=nperseg)
    fc, Cxy = signal.coherence(x, y, fs=fs, nperseg=nperseg)
    return f, np.abs(Pxy), Cxy

f, csd_mag, coh = coherence_xy(ch1, ch2, fs=12000)
```

**Practical note.** Coherence needs averaging over several segments to be meaningful; a single segment gives a coherence of one everywhere and tells you nothing. A low coherence can mean independence or simply too little signal-to-noise, so check the cross-power magnitude alongside it, and remember coherence finds linear association, not causation or direction.

**Reference.** Bendat & Piersol (2010), Random Data; Carter (1987), Proc. IEEE 75.

## Cepstrum

**Essence.** The inverse transform of the log spectrum. By turning an evenly spaced family of harmonics or sidebands into a single peak at their spacing, it isolates periodic structure within the spectrum itself, the signature of gear sidebands and echoes.

**In plain words.** Some faults do not add a single line but a whole comb: a gear with a local defect modulates the mesh frequency, planting a family of evenly spaced sidebands around it. Reading the spacing off a crowded spectrum is hard. The cepstrum takes the logarithm of the spectrum and transforms it again, so a regularly spaced family of peaks in frequency becomes one peak in the new axis, called quefrency, located at the reciprocal of the spacing. It collapses a sideband family or a repeated echo into a single, easy-to-track number, which is why it is a staple of gearbox diagnostics.

**Diagnostic example.** A cracked gear tooth modulates the mesh frequency, scattering sidebands at the shaft rate across the spectrum. The cepstrum gathers that whole family into one rahmonic at the shaft period, turning a smear of small sidebands into a single peak that can be trended over time.

**Engine call.** `real_cepstrum(x)`

```python
import numpy as np

def real_cepstrum(x):
    spec = np.fft.rfft(x * np.hanning(len(x)))
    logmag = np.log(np.abs(spec) + 1e-12)
    ceps = np.fft.irfft(logmag)
    return ceps                      # peak at quefrency = 1 / spacing

ceps = real_cepstrum(vibration)
# a peak at quefrency q means a spectral spacing of fs/len * (1/q)
```

**Practical note.** Window before transforming and work with the log magnitude, since the log is what turns a multiplicative harmonic family into an additive peak. Strong single tones and the overall spectral shape produce low-quefrency content that can mask the rahmonics you want, so lifter (filter in quefrency) to suppress them. A cepstral peak gives the spacing, not which sideband family it belongs to.

**Reference.** Bogert, Healy & Tukey (1963), Proc. Symp. Time Series; Randall (2017), Mech. Syst. Signal Process. 97.

## Envelope analysis (Hilbert)

**Essence.** The workhorse of bearing diagnostics. A localized defect rings the structure once per impact, so the fault rate appears as the modulation of a high resonance, not as a line. Band-passing the resonance and transforming its Hilbert envelope brings the defect frequency into plain view.

**In plain words.** A spalled bearing does not hum at its defect frequency; it strikes, and each strike rings a high structural resonance that decays before the next. The defect rate is therefore the rate at which the resonance is amplitude-modulated, invisible as a line in the ordinary spectrum, which only shows the resonance. Envelope analysis recovers it: band-pass the signal around the resonance to isolate the rung region, take the magnitude of its analytic signal with the Hilbert transform to get the envelope that traces the impacts, and transform that envelope. The bearing defect frequencies, computed from the geometry as the outer-race, inner-race, ball, and cage rates, then appear as clear lines and harmonics.

**Diagnostic example.** An outer-race spall on a fan bearing produces impacts at the outer-race defect frequency, each ringing a resonance near three kilohertz. The raw spectrum shows only the resonance hump; band-passing it and taking the envelope spectrum reveals a sharp line at the outer-race frequency and its harmonics, identifying the fault and its location.

**Engine call.** `envelope_spectrum(x, fs, band); bearing_frequencies(fr, n_balls, d_ball, d_pitch)`

```python
import numpy as np
from scipy import signal

def envelope_spectrum(x, fs, band):
    b, a = signal.butter(4, [band[0]/(fs/2), band[1]/(fs/2)], "band")
    xb = signal.filtfilt(b, a, x)
    env = np.abs(signal.hilbert(xb)); env -= env.mean()
    f = np.fft.rfftfreq(len(env), 1/fs)
    return f, np.abs(np.fft.rfft(env * np.hanning(len(env))))

def bearing_frequencies(fr, n, d, D, phi=0.0):
    r = (d/D)*np.cos(phi)
    return dict(BPFO=0.5*n*fr*(1-r), BPFI=0.5*n*fr*(1+r),
                BSF=(D/(2*d))*fr*(1-r**2), FTF=0.5*fr*(1-r))
```

**Practical note.** Everything depends on choosing the right resonance band to demodulate; pick it where the impulsiveness is highest, which a spectral-kurtosis or kurtogram scan finds automatically. Compute the defect frequencies from the actual geometry and shaft speed, and expect the measured lines to sit a percent or two off because of slip. Inner-race and ball faults are modulated by shaft and cage rotation, adding sidebands, so look for families, not single lines.

**Reference.** Randall & Antoni (2011), Mech. Syst. Signal Process. 25; McFadden & Smith (1984), J. Sound Vib. 96.
