# Synchronous averaging and gear indicators

## Synchronous averaging and gear indicators

**Essence.** Averaging the signal synchronized to shaft rotation keeps the part that repeats every revolution and averages away noise and non-synchronous content. The residual left after removing the regular mesh yields FM4, M6A, and M8A.

**In plain words.** Everything locked to a shaft repeats every revolution; everything else does not. Time-synchronous averaging exploits that by resampling to shaft angle and averaging over many revolutions, so the gear-mesh signal and any once-per-revolution fault reinforce while noise and components from other shafts average toward zero. The averaged revolution is a clean picture of that gear. Subtracting its regular mesh harmonics leaves a residual that is flat for a healthy gear but spikes where a local defect, a cracked or spalled tooth, disturbs a few teeth; the normalized fourth, sixth, and eighth moments of that residual, FM4, M6A, and M8A, turn the disturbance into trendable numbers.

**Diagnostic example.** One gear in a multi-stage box has a cracked tooth. Synchronous averaging at that shaft's rate pulls its mesh pattern out of the mixture, and the once-per-revolution disturbance from the crack drives FM4 well above its healthy value of three while the overall spectrum looks unchanged.

**Engine call.** `time_synchronous_average(x, fs, fr, spr=256); gear_indicators(tsa, n_teeth, n_harm=3)`

```python
import numpy as np

def time_synchronous_average(x, fs, fr, spr=256):
    total = int((len(x)/fs)*fr)
    ang = np.arange(total*spr)/spr
    xr = np.interp(ang/fr, np.arange(len(x))/fs, x)
    return xr.reshape(total, spr).mean(axis=0)   # one clean revolution

def gear_indicators(tsa, n_teeth, n_harm=3):
    X = np.fft.rfft(tsa); reg = np.zeros_like(X)
    for h in range(1, n_harm+1):
        if n_teeth*h < len(X): reg[n_teeth*h] = X[n_teeth*h]
    d = tsa - np.fft.irfft(reg, len(tsa)); v = np.mean(d**2)
    return dict(FM4=np.mean(d**4)/v**2, M6A=np.mean(d**6)/v**3)
```

**Practical note.** TSA needs an accurate once-per-rev trigger and many revolutions, since noise falls only as the square root of the count. The indicators need a healthy baseline: FM4 and NA4 are meant to be trended against a learned normal, since their absolute value depends on the gear. In a multi-stage box, average at each shaft's own rate to separate the gears.

**Reference.** McFadden (1987), Mech. Syst. Signal Process. 1; Zakrajsek et al. (1993), NASA TM 105950.
