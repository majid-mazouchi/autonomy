# Worked case study: an outer-race bearing fault

A fan bearing develops an outer-race spall. From the geometry the defect
frequencies are BPFO 96.9 Hz, BPFI 143.1 Hz, BSF 75.1 Hz,
and cage 12.1 Hz. All numbers are produced by the engine on a
1-second record at 12000 Hz.

## Step 1 - flag impulsiveness
Kurtosis rises from 2.8 to 3.8 and crest factor
from 3.7 to 5.3, while RMS barely moves
(0.45 to 0.48). The signal has become impulsive.

## Step 2 - find the resonance, choose the band
The Welch PSD is dominated by the shaft line and a broadband resonance near
3393 Hz, with no line at any bearing rate. Scanning bands by the
kurtosis of their envelope picks the resonance band (band kurtosis 6.0).

## Step 3 - demodulate and read the defect frequency
Band-passing the resonance, taking the Hilbert envelope, and transforming it gives
an envelope-spectrum peak at 97.0 Hz, within a percent of the computed
BPFO of 96.9 Hz, with harmonics. The match to the outer-race frequency
identifies the fault and its location.

## Verdict
Screen with kurtosis, locate the resonance, demodulate with the envelope, and read
the answer at the kinematic frequencies. The time domain says how impulsive; the
right transform says which fault.
