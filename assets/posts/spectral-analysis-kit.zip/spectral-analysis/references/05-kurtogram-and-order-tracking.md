# Kurtogram and order tracking

## Spectral kurtosis and the kurtogram

**Essence.** Spectral kurtosis measures impulsiveness frequency by frequency; the kurtogram scans center frequency and bandwidth to find the single most impulsive band, the optimal one to band-pass before envelope analysis.

**In plain words.** Envelope analysis depends on demodulating the resonance a bearing's impacts excite, and choosing that band by eye is unreliable. Spectral kurtosis turns the choice into a measurement: for each frequency it takes the kurtosis of the short-time spectral magnitude over time, large where the signal is intermittently impulsive, near zero where it is stationary. The kurtogram extends this over a grid of center frequencies and bandwidths, so the brightest cell names both where to filter and how wide. Feeding that band to the envelope spectrum is the modern, automated bearing pipeline.

**Diagnostic example.** A gearbox bearing fault rings a resonance whose frequency is not known in advance. The kurtogram lights up a band near three kilohertz as the most impulsive; band-passing there and enveloping recovers the defect frequency a guessed band would have missed.

**Engine call.** `spectral_kurtosis(x, fs); fast_kurtogram(x, fs, nlevel=4)`

```python
import numpy as np
from scipy import signal, stats

def fast_kurtogram(x, fs, nlevel=4):
    nyq = fs/2; best = dict(kurt=-np.inf)
    for lvl in range(1, nlevel+1):
        bw = nyq/2**lvl; lo = 0.0
        while lo <= nyq - bw + 1:
            loc, hic = max(lo, fs*0.004), min(lo+bw, nyq*0.998)
            if hic-loc >= fs*0.004:
                b, a = signal.butter(3, [loc/nyq, hic/nyq], "band")
                env = np.abs(signal.hilbert(signal.filtfilt(b, a, x)))
                k = stats.kurtosis(env, fisher=False)
                if k > best["kurt"]:
                    best = dict(kurt=k, band=(loc, hic))
            lo += bw/2
    return best          # band -> feed to envelope_spectrum
```

**Practical note.** The kurtosis can be maximized by a band so narrow it cannot resolve the defect-frequency sidebands, so cap the level or require the bandwidth to exceed several times the expected defect rate. Strong deterministic components like gear-mesh lines distort the kurtogram, so remove them first by synchronous averaging or cepstrum editing.

**Reference.** Antoni (2006), Mech. Syst. Signal Process. 20; Antoni & Randall (2006), MSSP 20.

## Computed order tracking

**Essence.** Resample a signal from equal time steps to equal increments of shaft angle, using the instantaneous speed, so a shaft-locked component becomes a fixed order regardless of how the speed varies. It un-smears a run-up.

**In plain words.** When shaft speed changes, every component locked to the shaft changes frequency with it, so a Fourier spectrum of a run-up smears each order into a broad hump and resolves nothing. Order tracking removes the speed: using a tachometer or an estimate of instantaneous phase, it resamples the signal at equal increments of shaft angle rather than equal time. In that angle domain a shaft-order component sits at a fixed number of cycles per revolution no matter how the speed varies, so the smeared sweeps collapse back into sharp order lines. Structural resonances, fixed in frequency, do the opposite and smear, which itself helps tell a forced order from a resonance.

**Diagnostic example.** A turbocharger is run up from idle while vibration is recorded. In the raw spectrum the blade-pass order is an unreadable smear; after order tracking it is a sharp line at the blade count per revolution, and a fixed resonance band that now smears is exposed as structural rather than forced.

**Engine call.** `order_track(x, fs, f_inst, spr=64)`

```python
import numpy as np

def order_track(x, fs, f_inst, spr=64):
    theta = np.cumsum(f_inst)/fs           # revolutions vs time
    t = np.arange(len(x))/fs
    ang = np.arange(0, int(theta[-1]), 1.0/spr)
    xr = np.interp(np.interp(ang, theta, t), t, x)   # resample to angle
    X = np.abs(np.fft.rfft((xr-xr.mean())*np.hanning(len(xr))))
    orders = np.fft.rfftfreq(len(xr), 1.0/spr)
    return orders, X, xr
```

**Practical note.** Order tracking needs an accurate angle reference; phase errors blur the orders just as speed variation blurred the spectrum. Resample with enough samples per revolution to cover the highest order of interest without aliasing. Remember resonances stay at fixed frequencies and therefore smear in the order domain, the mirror image of the time-domain picture.

**Reference.** Fyfe & Munck (1997), Mech. Syst. Signal Process. 11; Bossley et al. (1999), MSSP 13.
