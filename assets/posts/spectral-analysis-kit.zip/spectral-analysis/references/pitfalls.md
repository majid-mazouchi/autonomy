# Pitfalls and assumptions

Read before presenting any indicator or peak as a verdict.

## Autocorrelation function (ACF)

Remove the mean and any trend before computing, or low-frequency drift dominates the early lags. Read the band as a guide, not a verdict, since at many lags a few bars clear it by chance. For a fault indicator, trend the autocorrelation at the kinematic lag rather than scanning all lags each time.

## Partial autocorrelation and order

The partial autocorrelation is for autoregressive order, the autocorrelation for moving-average order; use them together to read a mixed model. Confirm the visual cutoff with an information criterion, preferring BIC for a parsimonious order, and remember both assume a stationary series, so analyze within one operating regime.

## Power spectral density (Welch)

The segment length trades resolution against variance: longer segments resolve close lines but average fewer, so the estimate is noisier. Always window to control leakage, and read peaks at the machine's kinematic frequencies rather than hunting blindly. Express axes in orders of shaft speed when the speed varies, so a line does not smear.

## Cross-spectrum and coherence

Coherence needs averaging over several segments to be meaningful; a single segment gives a coherence of one everywhere and tells you nothing. A low coherence can mean independence or simply too little signal-to-noise, so check the cross-power magnitude alongside it, and remember coherence finds linear association, not causation or direction.

## Cepstrum

Window before transforming and work with the log magnitude, since the log is what turns a multiplicative harmonic family into an additive peak. Strong single tones and the overall spectral shape produce low-quefrency content that can mask the rahmonics you want, so lifter (filter in quefrency) to suppress them. A cepstral peak gives the spacing, not which sideband family it belongs to.

## Envelope analysis (Hilbert)

Everything depends on choosing the right resonance band to demodulate; pick it where the impulsiveness is highest, which a spectral-kurtosis or kurtogram scan finds automatically. Compute the defect frequencies from the actual geometry and shaft speed, and expect the measured lines to sit a percent or two off because of slip. Inner-race and ball faults are modulated by shaft and cage rotation, adding sidebands, so look for families, not single lines.

## Kurtosis, skewness, crest factor

Kurtosis is sensitive but not specific and is easily corrupted by a single outlier or electrical spike, so clean the signal and confirm with the envelope spectrum before calling a fault. It also saturates: once a fault is well developed and impacts are frequent, kurtosis can fall back toward three even as damage grows, so trend it alongside RMS rather than alone.

## Bispectrum

The bispectrum needs many segments to average down its variance and is expensive to compute, so restrict the frequency grid to the region of interest. It detects quadratic phase coupling specifically, not every nonlinearity, and a peak shows association, not mechanism, so pair it with a physical hypothesis about what could couple those frequencies.

## STFT spectrogram

The window length is the whole trade-off: short for sharp timing of transients, long for resolving close frequencies, and you cannot have both at once. Overlap the windows to smooth the time axis, window each segment to limit leakage, and for rotating machinery order-track against speed so a run-up sweep does not blur a fixed resonance.

## Wavelet transform (CWT)

Choose the analysis frequencies and the wavelet's bandwidth from the transient you expect; a higher Morlet center frequency sharpens frequency at the cost of time. The continuous transform is redundant and can be heavy, so limit the frequency range. Mind edge effects at the start and end of the record, where the wavelet runs off the data and the scalogram is unreliable.
