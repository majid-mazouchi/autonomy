# Decomposition, deconvolution, liftering, and severity

## Empirical mode decomposition

**Essence.** Without assuming any basis, EMD peels a signal into a few intrinsic mode functions, fastest to slowest, plus a trend. It adapts to non-stationary, nonlinear signals, separating a fast fault transient from slow background.

**In plain words.** Where the wavelet uses a fixed prototype, empirical mode decomposition builds its basis from the data itself. It repeatedly identifies the local extrema, fits smooth envelopes through the maxima and minima, and subtracts their mean, peeling off the fastest oscillation as the first intrinsic mode function, then the next, down to a slow residual trend. The result is a data-driven filter bank that follows a non-stationary or nonlinear signal, so a brief fault transient lands in an early mode separated from the slow operating background. Combined with the Hilbert transform it gives instantaneous frequencies, the Hilbert-Huang view.

**Diagnostic example.** A vibration record mixes a slow load oscillation, a steady tone, and a short impact. EMD separates them: the impact appears alone in the first intrinsic mode, where it can be enveloped or timed, while the slow load lands in the trend.

**Engine call.** `emd(x, max_imf=6, max_sift=12)`

```python
# see scripts/spectral.py: emd(x, max_imf=6)
# sift: extrema -> cubic-spline envelopes -> subtract the mean
# repeat per mode; returns [IMF1, IMF2, ..., residual]
imfs = emd(vibration, max_imf=4)
transient = imfs[0]          # fastest mode isolates the impact
```

**Practical note.** EMD is adaptive but fragile: mode mixing can split one component across modes or merge two, and it is sensitive to noise and to endpoint handling. Ensemble EMD and variational mode decomposition are more robust. Treat the modes as a filter bank to inspect, not as physically labeled components.

**Reference.** Huang et al. (1998), Proc. R. Soc. A 454; Lei et al. (2013), Mech. Syst. Signal Process. 35.

## Minimum entropy deconvolution

**Essence.** A fault impulse train is blurred by the path it travels to the sensor. MED estimates the inverse filter that makes the output as impulsive as possible, by maximizing output kurtosis, recovering the buried impacts before envelope analysis.

**In plain words.** By the time a bearing impact reaches the accelerometer it has been smeared by the transmission path, its sharp edge spread into a ring. Minimum entropy deconvolution tries to undo that: it searches for the finite impulse-response filter that, applied to the signal, makes the output as impulsive, as low-entropy, as possible, which it measures by kurtosis and maximizes by a short iteration. The deconvolved signal restores the periodic spikes the path had blurred, sharpening a faint impulse train so the subsequent envelope spectrum reads cleanly.

**Diagnostic example.** A bearing fault is so smeared by a long structural path that its impacts are invisible and its kurtosis barely raised. MED estimates the inverse path, the deconvolved signal shows a clean train of spikes at the defect period, and the kurtosis jumps, confirming the fault.

**Engine call.** `med_deconvolve(x, L=40, iters=15)`

```python
# see scripts/spectral.py: med_deconvolve(x, L=40, iters=15)
# iterate: y = X f ; f = R^-1 (X^T y^3) ; normalize  (R = X^T X)
out = med_deconvolve(vibration, L=50, iters=20)
sharpened = out["deconvolved"]   # then envelope_spectrum(sharpened, ...)
```

**Practical note.** MED maximizes kurtosis, so it favors one large impulse and can lock onto a single outlier rather than the periodic train; maximum correlated kurtosis deconvolution, which targets a specified period, is more robust for bearings. Choose the filter length long enough to invert the path but short enough to stay stable, and follow with envelope analysis rather than reading the deconvolved signal directly.

**Reference.** Wiggins (1978), Geophys. Prospect. 26; McDonald et al. (2012), Mech. Syst. Signal Process. 33.

## Cepstrum editing (liftering)

**Essence.** A regular harmonic or sideband family is a single peak in the cepstrum, so notching that rahmonic removes the whole family from the spectrum, cleaning a dominant gear-mesh comb to expose weaker structure underneath.

**In plain words.** The cepstrum gathers an evenly spaced family of spectral lines into one peak at their spacing, which makes it a precise editing tool: zero that peak and its multiples, transform back, and the entire family vanishes from the spectrum while everything else is untouched. This liftering is the standard way to strip a dominant gear-mesh comb that would otherwise swamp a weak bearing signature, a prewhitening step that lets the spectral kurtosis and the envelope work on what remains.

**Diagnostic example.** A strong gear mesh and its sidebands bury a small bearing fault. Liftering the mesh family out in the cepstral domain removes the comb and leaves the bearing's resonance, which the kurtogram and envelope then pick up cleanly.

**Engine call.** `cepstrum_edit(x, q_remove)`

```python
# see scripts/spectral.py: cepstrum_edit(x, q_remove)
# real cepstrum -> zero the rahmonic at q = fs / spacing -> back to spectrum
ce = cepstrum_edit(vibration, [int(fs/sideband_spacing)])
cleaned_spectrum = ce["log_edited"]   # mesh family removed
```

**Practical note.** Editing the real cepstrum removes magnitude structure but discards phase, so to reconstruct a time signal use the complex cepstrum, which preserves phase but needs careful unwrapping. Liftering a dominant mesh family is a common prewhitening step before bearing analysis, removing the deterministic comb that would otherwise dominate the kurtosis and the envelope.

**Reference.** Randall (2017), Mech. Syst. Signal Process. 97; Borghesani et al. (2013), MSSP 36.

## ISO 20816 severity zones

**Essence.** Map a broadband vibration velocity RMS to a standard severity zone, A newly commissioned, B unrestricted operation, C short-term only, D damaging. It turns a measured level into an actionable alarm.

**In plain words.** Diagnosis says what is wrong; severity assessment says how urgent it is. The ISO 20816 family (formerly 10816) defines velocity RMS boundaries that sort a machine into four zones from newly commissioned through damaging, set by the machine's size, power, and mounting. A single broadband number placed against those boundaries gives operations a clear, standardized action: keep running, plan maintenance, or stop. It is the coarse overall gauge that sits above the diagnostic indicators, telling you when the detailed analysis becomes urgent.

**Diagnostic example.** A pump's overall velocity RMS climbs from one millimetre per second into zone C over several months. The level alone does not say why, but it triggers the diagnostic chain, where the envelope spectrum then identifies a bearing outer-race fault as the cause.

**Engine call.** `iso10816_zone(v_rms_mm_s, machine_class='medium')`

```python
def iso10816_zone(v_rms_mm_s, machine_class="medium"):
    table = {"small": (0.71, 1.8, 4.5), "medium": (1.4, 2.8, 7.1),
             "large_rigid": (2.3, 4.5, 11.0), "large_soft": (3.5, 7.1, 18.0)}
    ab, bc, cd = table[machine_class]
    z = "A" if v_rms_mm_s<ab else "B" if v_rms_mm_s<bc else \
        "C" if v_rms_mm_s<cd else "D"
    return z, dict(AB=ab, BC=bc, CD=cd)
```

**Practical note.** The boundaries depend on machine size, power, and mounting, rigid or flexible, so use the class that matches; the zones here are illustrative. Broadband velocity RMS is a coarse gauge, not a diagnosis: it can sit in zone A while a localized bearing fault, which kurtosis and the envelope catch, develops. Trend the overall level and the diagnostic indicators together.

**Reference.** ISO 20816-1 (2016); ISO 10816-3 (2009).
