# At a glance

| Method | Domain | Reveals | Output | Key assumption |
| --- | --- | --- | --- | --- |
| ACF | lag | periodicity, memory | correlation vs lag | stationary |
| PACF | lag | AR order | partial corr + order | stationary |
| Welch PSD | frequency | spectral lines and bands | power vs frequency | stationary in window |
| Coherence | frequency | shared source between channels | 0 to 1 vs frequency | needs averaging |
| Cepstrum | quefrency | harmonic / sideband spacing | peak at spacing | periodic structure |
| Envelope | frequency | bearing defect rate | defect lines + harmonics | resonance band chosen |
| Kurtosis / crest | amplitude | impulsiveness | scalar indicator | outlier-sensitive |
| Bispectrum | bifrequency | quadratic phase coupling | magnitude on (f1,f2) | needs many segments |
| STFT | time-frequency | spectrum over time | spectrogram | fixed resolution |
| Wavelet | time-frequency | localized transients | scalogram | adaptive resolution |

## Which tool for which fault

| Fault | First indicator | Confirm with |
| --- | --- | --- |
| Rolling-bearing spall | kurtosis / crest factor | envelope spectrum at BPFO/BPFI/BSF |
| Gear tooth defect | cepstrum (sideband spacing) | envelope, STFT per revolution |
| Looseness / rub (nonlinear) | bispectrum | PSD harmonics, orbit |
| Resonance crossing on run-up | STFT spectrogram | order tracking |
| Brief broadband transient | wavelet scalogram | kurtosis |
