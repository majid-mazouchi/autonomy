# Time-frequency, where in time does the fault live?

_A Fourier transform assumes the spectrum holds for the whole record. A fault transient does not: it happens at a moment. Time-frequency transforms map how the spectrum evolves, localizing a transient in both time and frequency._

## STFT spectrogram

**Essence.** The short-time Fourier transform: slide a window along the signal and transform each piece, mapping how the spectrum evolves in time. The first tool for a non-stationary signal where a fault lives at a particular time and frequency.

**In plain words.** The ordinary spectrum collapses the whole record into one frequency picture, which is wrong the moment the signal changes in time, during a run-up, a load change, or a transient fault. The short-time Fourier transform restores time by sliding a window along the signal and transforming each windowed piece, producing a spectrogram, a map of frequency against time. Its one compromise is fixed resolution: a short window localizes events in time but blurs frequency, a long window does the reverse, and you must choose. Within that limit it is the standard way to see a frequency sweep during start-up or a fault that appears only under certain conditions.

**Diagnostic example.** A variable-speed drive is run up from rest while vibration is recorded. The spectrogram shows the order lines sweeping upward with shaft speed and a resonance band staying fixed, so the speed at which an order crosses the resonance, the critical speed, is read directly off the time-frequency map.

**Engine call.** `spectrogram_stft(x, fs, nperseg=128)`

```python
from scipy import signal

def spectrogram_stft(x, fs, nperseg=256, noverlap=None):
    noverlap = noverlap or nperseg*3//4
    f, t, S = signal.spectrogram(x, fs=fs, nperseg=nperseg,
                                 noverlap=noverlap)
    return f, t, S          # short window: time-sharp; long: freq-sharp

f, t, S = spectrogram_stft(runup, fs=12000, nperseg=256)
```

**Practical note.** The window length is the whole trade-off: short for sharp timing of transients, long for resolving close frequencies, and you cannot have both at once. Overlap the windows to smooth the time axis, window each segment to limit leakage, and for rotating machinery order-track against speed so a run-up sweep does not blur a fixed resonance.

**Reference.** Allen & Rabiner (1977), Proc. IEEE 65; Cohen (1995), Time-Frequency Analysis.

## Wavelet transform (CWT)

**Essence.** The continuous wavelet transform with a Morlet wavelet. Unlike the fixed window of the STFT, the wavelet narrows at high frequency and widens at low, so it localizes a short broadband transient in time while still resolving slow components. The right lens for impulsive, non-stationary faults.

**In plain words.** The short-time Fourier transform must use one window length for the whole signal, which is a poor fit when a record holds both slow oscillations and sharp impacts. The wavelet transform adapts: it correlates the signal with scaled copies of a single prototype wave, the Morlet wavelet being a common choice, so high-frequency analysis uses short wavelets that pinpoint impacts in time and low-frequency analysis uses long ones that resolve slow components in frequency. The result, a scalogram, gives sharp time resolution exactly where impulsive faults need it. It is the natural tool for bearing impacts, gear transients, and any fault whose signature is a brief, broadband burst.

**Diagnostic example.** A chipped gear tooth produces a brief impact once per revolution, smeared across frequency. On a fixed-window spectrogram each impact is blurred; the wavelet scalogram resolves each one as a sharp vertical ridge at its instant, so the impacts can be counted and timed against the shaft angle to locate the damaged tooth.

**Engine call.** `cwt_morlet(x, fs, freqs, w0=6)`

```python
import numpy as np

def cwt_morlet(x, fs, freqs, w0=6.0):
    x = np.asarray(x, float); n = len(x); X = np.fft.fft(x)
    omega = 2*np.pi*np.fft.fftfreq(n, 1/fs)
    scalo = np.zeros((len(freqs), n))
    for k, fc in enumerate(freqs):
        s = w0/(2*np.pi*fc)
        psi = np.pi**-0.25 * np.sqrt(2) * (omega>0) * \
              np.exp(-0.5*(s*omega - w0)**2)
        scalo[k] = np.abs(np.fft.ifft(X * psi))
    return scalo
```

**Practical note.** Choose the analysis frequencies and the wavelet's bandwidth from the transient you expect; a higher Morlet center frequency sharpens frequency at the cost of time. The continuous transform is redundant and can be heavy, so limit the frequency range. Mind edge effects at the start and end of the record, where the wavelet runs off the data and the scalogram is unreliable.

**Reference.** Mallat (2008), A Wavelet Tour of Signal Processing; Peng & Chu (2004), Mech. Syst. Signal Process. 18.
