# References

- Box, Jenkins & Reinsel (2008), Time Series Analysis; Brockwell & Davis (1991), Time Series.
- Box, Jenkins & Reinsel (2008), Time Series Analysis; Akaike (1974), IEEE TAC 19; Schwarz (1978), Ann. Statist. 6.
- Welch (1967), IEEE Trans. Audio Electroacoust. 15; Oppenheim & Schafer (2010), Discrete-Time Signal Processing.
- Bendat & Piersol (2010), Random Data; Carter (1987), Proc. IEEE 75.
- Bogert, Healy & Tukey (1963), Proc. Symp. Time Series; Randall (2017), Mech. Syst. Signal Process. 97.
- Randall & Antoni (2011), Mech. Syst. Signal Process. 25; McFadden & Smith (1984), J. Sound Vib. 96.
- Dyer & Stewart (1978), J. Mech. Design 100; Antoni (2006), Mech. Syst. Signal Process. 20 (spectral kurtosis).
- Nikias & Mendel (1993), IEEE Signal Process. Mag. 10; Collis, White & Hammond (1998), Mech. Syst. Signal Process. 12.
- Allen & Rabiner (1977), Proc. IEEE 65; Cohen (1995), Time-Frequency Analysis.
- Mallat (2008), A Wavelet Tour of Signal Processing; Peng & Chu (2004), Mech. Syst. Signal Process. 18.