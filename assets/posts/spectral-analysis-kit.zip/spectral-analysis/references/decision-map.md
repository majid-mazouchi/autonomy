# Decision map

Start from the question you have, not the method you know.

| If you are asking | Reach for |
| --- | --- |
| What is the correlation structure or AR order? | ACF / PACF |
| Which frequencies carry the energy? | Welch PSD |
| Do two channels share a source or path? | cross-spectrum / coherence |
| Is there a harmonic or sideband family? | cepstrum |
| What is a rolling-element bearing's defect rate? | envelope analysis |
| Is the signal impulsive (early bearing/gear)? | kurtosis / crest factor |
| Are frequencies nonlinearly phase-coupled? | bispectrum |
| How does the spectrum evolve during a run-up? | STFT spectrogram |
| Where is a short broadband transient? | wavelet (CWT) |

## Order of work for vibration diagnostics

1. Detrend and window; compute the kinematic frequencies from geometry and shaft speed.
2. Screen the waveform with `time_stats` (kurtosis, crest) for impulsiveness.
3. Take a `psd_welch` to see the lines and locate any resonance.
4. For a bearing, pick the band with `fast_kurtogram`, then `envelope_spectrum` to read the defect rate.
5. For a gear, `time_synchronous_average` then `real_cepstrum` and the residual `gear_indicators`.
6. If non-stationary, `order_track` a run-up or use `cwt_morlet` for short transients.
7. For mixed signals or faint faults, `cyclic_modulation_spectrum` separates random bearing content from deterministic lines.

## Going further (references 05-08)
Automatic band selection (`fast_kurtogram`), angular resampling (`order_track`), synchronous averaging and gear indicators (`time_synchronous_average`, `gear_indicators`), the cyclic spectrum (`cyclic_modulation_spectrum`), and supporting tools: `emd`, `med_deconvolve`, `cepstrum_edit`, and `iso10816_zone`.
