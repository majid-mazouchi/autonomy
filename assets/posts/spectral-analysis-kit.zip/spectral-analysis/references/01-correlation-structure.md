# Correlation structure, what memory does the signal carry?

_Before the frequency domain, the autocorrelation says how a signal relates to its own past. That structure reveals periodicity, sets the order of a model, and is the basis of the whiteness checks that model-based detectors rely on._

## Autocorrelation function (ACF)

**Essence.** The correlation of a signal with lagged copies of itself, lag by lag, with a white-noise band. It exposes periodicity and memory; for a moving-average process it cuts off at the order, and a slowly decaying ACF means strong serial dependence.

**In plain words.** The autocorrelation function asks, for each lag, how much a sample looks like the sample that many steps earlier. A pure random signal correlates with nothing but itself at lag zero, so every other bar sits inside a narrow band around zero. Real signals carry memory: a rotating machine repeats, so its ACF shows peaks at the rotation period and its multiples, and a damped resonance shows a decaying oscillation. The shape is diagnostic, a sharp cutoff after a few lags points to a moving-average structure, a slow decay to a long memory, and any bar that clears the band is correlation worth modeling.

**Diagnostic example.** A gearbox vibration signal repeats once per shaft revolution. Its autocorrelation shows a clear peak at the shaft period and smaller peaks at the harmonics, confirming the dominant periodicity before any spectrum is computed and giving the lag at which to look for sidebands.

**Engine call.** `acf(x, nlags=40)`

```python
import numpy as np

def acf(x, nlags=40):
    x = np.asarray(x, float) - np.mean(x); n = len(x)
    c0 = x @ x / n
    r = [ (x[:n-k] @ x[k:]) / n / c0 for k in range(nlags+1) ]
    band = 1.96 / np.sqrt(n)          # white-noise 95% band
    return np.array(r), band

r, band = acf(vibration, 40)
```

**Practical note.** Remove the mean and any trend before computing, or low-frequency drift dominates the early lags. Read the band as a guide, not a verdict, since at many lags a few bars clear it by chance. For a fault indicator, trend the autocorrelation at the kinematic lag rather than scanning all lags each time.

**Reference.** Box, Jenkins & Reinsel (2008), Time Series Analysis; Brockwell & Davis (1991), Time Series.

## Partial autocorrelation and order

**Essence.** The autocorrelation at a lag after removing the effect of all shorter lags. A sharp cutoff after lag p is the fingerprint of an order-p autoregressive structure, and an information criterion confirms the order.

**In plain words.** A plain autocorrelation at lag three is inflated by the chain of correlations running through lags one and two. The partial autocorrelation strips those out, reporting only the direct relationship at each lag, computed efficiently by the Durbin-Levinson recursion. That makes it the natural order-selection tool: an autoregressive process of order p has a partial autocorrelation that is large up to lag p and then drops inside the band. To confirm the choice rather than read it by eye, fit autoregressive models of increasing order and score them with an information criterion, where AIC is efficient but tends to over-fit and BIC is parsimonious, taking the order at the minimum.

**Diagnostic example.** A bearing housing behaves like a lightly damped resonator driven by noise, well described by a low-order autoregressive model. The partial autocorrelation clears the band only at the first two lags, and BIC bottoms out at order two, so a compact AR(2) captures the dynamics and its residual becomes the input to a whiteness-based detector.

**Engine call.** `pacf(x, nlags=40); ar_order_aic(x, maxlag=20)`

```python
import numpy as np

def pacf(x, nlags=40):
    x = np.asarray(x, float) - np.mean(x); n = len(x)
    c0 = x @ x / n
    r = np.array([(x[:n-k] @ x[k:])/n/c0 for k in range(nlags+1)])
    phi = np.zeros((nlags+1, nlags+1)); pac = np.zeros(nlags+1)
    phi[1,1] = r[1]; pac[1] = r[1]
    for k in range(2, nlags+1):
        num = r[k] - sum(phi[k-1,j]*r[k-j] for j in range(1,k))
        den = 1 - sum(phi[k-1,j]*r[j] for j in range(1,k))
        phi[k,k] = num/den
        for j in range(1,k):
            phi[k,j] = phi[k-1,j] - phi[k,k]*phi[k-1,k-j]
        pac[k] = phi[k,k]
    return pac[1:], 1.96/np.sqrt(n)
```

**Practical note.** The partial autocorrelation is for autoregressive order, the autocorrelation for moving-average order; use them together to read a mixed model. Confirm the visual cutoff with an information criterion, preferring BIC for a parsimonious order, and remember both assume a stationary series, so analyze within one operating regime.

**Reference.** Box, Jenkins & Reinsel (2008), Time Series Analysis; Akaike (1974), IEEE TAC 19; Schwarz (1978), Ann. Statist. 6.
