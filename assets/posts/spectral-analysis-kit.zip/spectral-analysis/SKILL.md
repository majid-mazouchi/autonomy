---
name: spectral-analysis
description: >-
  Choose and apply the right time-series or spectral condition indicator for
  vibration-based diagnostics: correlation structure (ACF, PACF and AR order),
  frequency-domain indicators (Welch PSD, cross-spectrum and coherence, cepstrum,
  and Hilbert envelope analysis for bearing defect frequencies), higher-order
  statistics (kurtosis, skewness, crest factor, bispectrum), and time-frequency
  transforms (STFT spectrogram, Morlet wavelet), and a going-further set: the
  spectral kurtosis and fast kurtogram for automatic band selection, computed order
  tracking for variable speed, time-synchronous averaging with gear indicators, the
  cyclic modulation spectrum, empirical mode decomposition, minimum entropy
  deconvolution, cepstrum editing, and ISO 20816 severity zones. Use when the task
  is to find a fault's signature in a signal and tie it to the machine kinematics,
  and to generate correct Python.
---

# Time-series and spectral analysis for condition monitoring

A progressive-disclosure skill for turning a vibration signal into a diagnosis.
Read this file first, then open only the reference you need.

Overview
The indicators organize by domain: correlation structure says what memory and
periodicity a signal carries; the frequency domain finds the lines and bands a
fault excites, including bearing rates that hide as modulation; higher-order
statistics measure impulsiveness and nonlinear coupling; and time-frequency
transforms localize a transient. A tested engine implements every indicator with
numpy and scipy only.

When to use this skill
Use it whenever a diagnostics task is about a measured signal: finding a defect
frequency, screening for an impulsive bearing fault, reading a gear sideband
family, or analyzing a non-stationary run-up.

How to route a request
1. Correlation structure or model order? references/01-correlation-structure.md (acf, pacf, ar_order_aic)
2. Frequency content, coherence, cepstrum, or a bearing defect rate? references/02-frequency-domain.md (psd_welch, cross_spectrum, real_cepstrum, envelope_spectrum, bearing_frequencies)
3. Impulsiveness or nonlinear coupling? references/03-higher-order-statistics.md (time_stats, band_kurtosis, bispectrum)
4. Non-stationary transient or run-up? references/04-time-frequency.md (spectrogram_stft, cwt_morlet)
5. Going further: automatic band selection or variable speed? references/05-kurtogram-and-order-tracking.md (fast_kurtogram, spectral_kurtosis, order_track)
6. Gears? references/06-synchronous-averaging.md (time_synchronous_average, gear_indicators)
7. Mixed signals or faint faults? references/07-cyclostationary.md (cyclic_modulation_spectrum)
8. Decomposition, deconvolution, liftering, or severity? references/08-decomposition-deconvolution-severity.md (emd, med_deconvolve, cepstrum_edit, iso10816_zone)
Always consult references/decision-map.md to confirm the choice and
references/pitfalls.md before trusting a number.

Reference docs
- `references/01-correlation-structure.md` covers correlation structure, what memory does the signal carry?.
- `references/02-frequency-domain.md` covers frequency domain, which lines and bands carry the fault?.
- `references/03-higher-order-statistics.md` covers higher-order statistics, how impulsive and how nonlinear?.
- `references/04-time-frequency.md` covers time-frequency, where in time does the fault live?.
- `references/05-kurtogram-and-order-tracking.md` covers kurtogram and order tracking.
- `references/06-synchronous-averaging.md` covers synchronous averaging and gear indicators.
- `references/07-cyclostationary.md` covers cyclostationary analysis.
- `references/08-decomposition-deconvolution-severity.md` covers decomposition, deconvolution, liftering, and severity.
- `references/decision-map.md` maps every question to its indicator and the order of work.
- `references/rules-of-thumb.md` gives general heuristics and a scenario table.
- `references/at-a-glance.md` is the comparison table and the fault-to-tool matrix.
- `references/case-study.md` runs the whole chain on a bearing fault, a worked example.
- `references/pitfalls.md` lists the assumptions and failure modes.
- `references/references.md` is the bibliography.

Engine
scripts/spectral.py is the single source of truth. Import the named function from
each reference. Run it directly for a self-test:

    python scripts/spectral.py

Core functionalities
Read correlation structure with acf, pacf, and ar_order_aic. Estimate spectra with
psd_welch and cross_spectrum, find harmonic spacing with real_cepstrum, and read
bearing defect rates with envelope_spectrum and bearing_frequencies. Measure
impulsiveness with time_stats and band_kurtosis and nonlinear coupling with
bispectrum. Localize transients with spectrogram_stft and cwt_morlet. Going
further: choose the demodulation band automatically with spectral_kurtosis and
fast_kurtogram, handle variable speed with order_track, average gears with
time_synchronous_average and score them with gear_indicators, separate mixed
sources with cyclic_modulation_spectrum, and support the workflow with emd,
med_deconvolve, cepstrum_edit, and iso10816_zone.

Conventions for generated answers
Detrend and window before spectral estimation. Compute the kinematic frequencies
from geometry and speed, and read peaks there. A bearing rate is a modulation, so
use the envelope. Match the transform to stationarity, and state the assumption
that would change the conclusion next to any reported value.

Assets
assets/spectral-analysis.html is the full illustrated monograph, with figures, a
worked example per method, three interactive explorers, and an end-to-end case study.
