---
name: change-detection
description: >-
  Choose and apply the right change or fault detection test over time: the
  sequential detectors CUSUM, EWMA, Page-Hinkley and SPRT, the model-based
  generalized likelihood ratio test, and the classical hypothesis tests
  (t-test and ANOVA for means, KS and Anderson-Darling for distributions,
  chi-square for independence, Levene and Bartlett for variance). Use when the
  task is to decide whether a signal has changed, when it changed, or what kind
  of change it is, online on a stream or by comparing two windows, and to
  generate correct Python.
---

# Change and fault detection over time

A progressive-disclosure skill for deciding whether and how a signal has changed,
and producing verified Python. Read this file first, then open only the reference
you need.

Overview
This skill organizes change detectors by when they decide and what they look for.
Online detectors (CUSUM, EWMA, Page-Hinkley, SPRT) run on a stream. The GLRT is
the model-based test for an unknown change. The classical hypothesis tests compare
two windows for a mean, variance, distribution, or categorical change. A tested
engine implements every method with numpy and scipy only.

When to use this skill
Use it whenever a diagnostics task is about change in time: monitoring a live
signal for a step or drift, deciding healthy versus faulty from few samples,
dating an unknown change, or comparing a recent window to a healthy baseline.

How to route a request
First decide online or two-window, then open the matching reference.
1. Online detection (step, drift, jump, or minimal-sample decision): references/01-sequential-detectors.md
2. Unknown change size and time, model-based: references/02-model-based.md
3. Compare two windows (mean, variance, distribution, categorical): references/03-window-tests.md
4. Going further, when the base methods are not enough:
   - Several correlated sensors: references/04-multivariate.md (mcusum, mewma)
   - A run-length posterior or many change points at once: references/05-bayesian-and-segmentation.md (bocpd, pelt)
   - A degrading data-driven model: references/06-concept-drift.md (ddm, adwin, kswin)
   - Tuning to a target run length, or comparing detectors: references/07-arl-and-evaluation.md (simulate_arl, delay_far_curve)
   - A change in variance, an autocorrelated stream, or spectral content: references/08-other-change-shapes.md (cusum_variance, ar1_residuals, band_power_stream)
Always consult references/decision-map.md to confirm the choice and
references/pitfalls.md before trusting a number.

Reference docs
- `references/01-sequential-detectors.md` covers sequential detectors, decide as data arrives.
- `references/02-model-based.md` covers model-based detection.
- `references/03-window-tests.md` covers comparing two windows: classical hypothesis tests.
- `references/04-multivariate.md` covers multivariate change detection.
- `references/05-bayesian-and-segmentation.md` covers bayesian and multiple-change detection.
- `references/06-concept-drift.md` covers concept-drift detectors.
- `references/07-arl-and-evaluation.md` covers run-length design and evaluation.
- `references/08-other-change-shapes.md` covers beyond a mean step.
- `references/decision-map.md` maps every question to its test and the escalation order.
- `references/rules-of-thumb.md` gives general heuristics and a scenario table.
- `references/at-a-glance.md` is the comparison table and the change-to-test matrix.
- `references/case-study.md` runs the whole ladder on one fault, a worked example.
- `references/pitfalls.md` lists the assumptions and failure modes.
- `references/references.md` is the bibliography.

Engine
scripts/change_detection.py is the single source of truth. Import the named
function from each reference. Run it directly for a self-test:

    python scripts/change_detection.py

Core functionalities
Detect online with cusum, ewma, page_hinkley, and sprt. Detect and date an
unknown change with glr_mean_shift. Compare two windows with compare_windows
(Welch t, Levene, Bartlett, F, KS, Anderson-Darling), anova for several groups,
and chi2_independence for a contingency table.

Conventions for generated answers
Estimate the healthy baseline from a verified reference, never from the stream.
Match the detector to the fault shape. After an online alarm, characterize the
change with a mean, a variance, and a distribution test together. State the
assumption that would change the conclusion next to any reported value.

Assets
assets/change-detection.html is the full illustrated monograph, with a figure,
worked example, two interactive explorers, and an end-to-end case study.
