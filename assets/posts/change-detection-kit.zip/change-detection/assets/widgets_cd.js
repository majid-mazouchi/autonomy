/* Interactive explorers for the change-detection monograph. Vanilla JS. */
(function () {
  "use strict";
  var INK = "#221d17", MUTE = "#7a6f5e", RUST = "#b0492f",
      TEAL = "#1f6f6a", OCHRE = "#c4922b", LINE = "#d9cfb8";

  function fit(c){var d=window.devicePixelRatio||1,w=c.clientWidth||600,h=c.clientHeight||240;
    c.width=w*d;c.height=h*d;var x=c.getContext("2d");x.setTransform(d,0,0,d,0,0);return {ctx:x,w:w,h:h};}
  function rng(seed){var s=seed>>>0;return function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
  function gauss(n,seed){var r=rng(seed),o=new Float64Array(n),i;
    for(i=0;i<n;i++){var u=Math.max(1e-9,r()),v=r();o[i]=Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}return o;}
  function mean(a){var s=0,i;for(i=0;i<a.length;i++)s+=a[i];return s/a.length;}
  function variance(a){var m=mean(a),s=0,i;for(i=0;i<a.length;i++)s+=(a[i]-m)*(a[i]-m);return s/(a.length-1);}
  function median(a){var b=a.slice().sort(function(p,q){return p-q;});var n=b.length;
    return n%2?b[(n-1)/2]:(b[n/2-1]+b[n/2])/2;}

  // ======================================================================
  // A. Online change detection: CUSUM vs EWMA vs Page-Hinkley
  // ======================================================================
  (function online(){
    var cv=document.getElementById("ex-cd-canvas"); if(!cv) return;
    var sShift=document.getElementById("ex-cd-shift"), sType=document.getElementById("ex-cd-type"),
        sDet=document.getElementById("ex-cd-det"), read=document.getElementById("ex-cd-read"),
        cap=document.getElementById("ex-cd-cap");
    var N=300, cp=150, g=gauss(N,91);
    function draw(){
      var shift=parseFloat(sShift.value)/100*1.6, type=sType.value, det=sDet.value, i;
      var x=new Float64Array(N);
      for(i=0;i<N;i++){var add=0;
        if(i>=cp){ add = type==="step" ? shift : shift*(i-cp)/(N-cp); }
        x[i]=g[i]+add;}
      // detector statistic (reference: healthy mean 0, sd 1)
      var stat=new Float64Array(N), lim, alarm=-1, label;
      if(det==="cusum"){ var ch=0,cl=0,k=0.5; lim=6;
        for(i=0;i<N;i++){ch=Math.max(0,ch+x[i]-k);cl=Math.max(0,cl-x[i]-k);stat[i]=Math.max(ch,cl);
          if(alarm<0&&stat[i]>lim)alarm=i;} label="CUSUM"; }
      else if(det==="ewma"){ var lam=0.15,p=0; lim=3*Math.sqrt(lam/(2-lam));
        for(i=0;i<N;i++){p=lam*x[i]+(1-lam)*p;stat[i]=Math.abs(p);
          if(alarm<0&&stat[i]>lim)alarm=i;} label="EWMA |z|"; }
      else { var run=0,cum=0,ext=0,d=0.3; lim=10;
        for(i=0;i<N;i++){run+=(x[i]-run)/(i+1);cum+=x[i]-run-d;ext=Math.min(ext,cum);stat[i]=cum-ext;
          if(alarm<0&&stat[i]>lim)alarm=i;} label="Page-Hinkley"; }
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=30, midy=h*0.30, boty=h*0.72;
      ctx.clearRect(0,0,w,h);
      function X(i){return pad+i/(N-1)*(w-2*pad);}
      ctx.fillStyle="rgba(176,73,47,0.06)";ctx.fillRect(X(cp),pad,w-pad-X(cp),h-2*pad);
      // top: signal
      var slo=-3.5,shi=Math.max(4,shift+3.5);
      function Ys(v){return midy-(v-(slo+shi)/2)/(shi-slo)*(h*0.30);}
      ctx.fillStyle="rgba(122,111,94,0.45)";for(i=0;i<N;i++){ctx.beginPath();ctx.arc(X(i),Ys(x[i]),1.4,0,6.28);ctx.fill();}
      ctx.fillStyle=MUTE;ctx.font="11px monospace";ctx.fillText("signal",pad,pad+4);
      // bottom: detector statistic
      var smax=Math.max(lim*1.4, Math.max.apply(null,Array.prototype.slice.call(stat)));
      function Yd(v){return boty+ (h*0.24) - v/smax*(h*0.24);}
      ctx.strokeStyle=LINE;ctx.beginPath();ctx.moveTo(pad,Yd(0));ctx.lineTo(w-pad,Yd(0));ctx.stroke();
      ctx.strokeStyle=INK;ctx.setLineDash([4,3]);ctx.beginPath();ctx.moveTo(pad,Yd(lim));ctx.lineTo(w-pad,Yd(lim));ctx.stroke();ctx.setLineDash([]);
      ctx.strokeStyle=TEAL;ctx.lineWidth=1.6;ctx.beginPath();
      for(i=0;i<N;i++){if(i===0)ctx.moveTo(X(i),Yd(stat[i]));else ctx.lineTo(X(i),Yd(stat[i]));}ctx.stroke();
      ctx.fillStyle=TEAL;ctx.fillText(label,pad,boty-2);
      ctx.fillStyle=INK;ctx.fillText("limit",w-pad-26,Yd(lim)-3);
      ctx.fillStyle=MUTE;ctx.fillText("change \u2192",X(cp)+4,h-pad-4);
      if(alarm>=0){ctx.strokeStyle=RUST;ctx.lineWidth=1.3;ctx.setLineDash([4,3]);
        ctx.beginPath();ctx.moveTo(X(alarm),pad);ctx.lineTo(X(alarm),h-pad);ctx.stroke();ctx.setLineDash([]);}
      var pre=alarm>=0&&alarm<cp;
      var delay=alarm>=0?(alarm-cp):null;
      read.innerHTML = alarm<0 ? "no alarm" :
        (pre ? "<b style='color:"+RUST+"'>false alarm</b> before the change (sample "+alarm+")"
             : "detected at sample "+alarm+", <b>delay "+delay+"</b>");
      cap.textContent = type==="step"
        ? "Step change: CUSUM is quickest. EWMA lags, Page-Hinkley sits between."
        : "Drift: EWMA and Page-Hinkley track the ramp well; a raw step-tuned CUSUM can lag.";
    }
    [sShift,sType,sDet].forEach(function(e){e.addEventListener("input",draw);});
    window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // B. Two windows, which test fires?
  // ======================================================================
  (function twowin(){
    var cv=document.getElementById("ex-tw-canvas"); if(!cv) return;
    var sMean=document.getElementById("ex-tw-mean"), sVar=document.getElementById("ex-tw-var"),
        read=document.getElementById("ex-tw-read"), cap=document.getElementById("ex-tw-cap");
    var n=180, ga=gauss(n,31), gb=gauss(n,37);
    function draw(){
      var dm=parseFloat(sMean.value)/100*2.5, vr=parseFloat(sVar.value)/100*2.4+0.4, i;
      var a=new Float64Array(n), b=new Float64Array(n);
      for(i=0;i<n;i++){a[i]=ga[i];b[i]=dm+vr*gb[i];}
      // Welch t
      var ma=mean(a),mb=mean(b),va=variance(a),vb=variance(b);
      var tt=(ma-mb)/Math.sqrt(va/n+vb/n);
      var tReject=Math.abs(tt)>1.97;
      // Levene (abs dev from median -> ANOVA F, 2 groups)
      var meda=median(a),medb=median(b);
      var za=new Float64Array(n),zb=new Float64Array(n);
      for(i=0;i<n;i++){za[i]=Math.abs(a[i]-meda);zb[i]=Math.abs(b[i]-medb);}
      var mza=mean(za),mzb=mean(zb),mz=(mza+mzb)/2;
      var sb2=n*((mza-mz)*(mza-mz)+(mzb-mz)*(mzb-mz));
      var sw2=0;for(i=0;i<n;i++){sw2+=(za[i]-mza)*(za[i]-mza)+(zb[i]-mzb)*(zb[i]-mzb);}
      var Flev=(sb2/1)/(sw2/(2*n-2));
      var levReject=Flev>3.89;
      // KS
      var sa=a.slice().sort(function(p,q){return p-q;}), sbb=b.slice().sort(function(p,q){return p-q;});
      var D=0;
      for(i=0;i<n;i++){var v=sa[i];
        var Fa=(i+1)/n; var Fb=0,j;for(j=0;j<n;j++)if(sbb[j]<=v)Fb++;Fb/=n;
        D=Math.max(D,Math.abs(Fa-Fb));}
      var Dc=1.36*Math.sqrt((2*n)/(n*n));
      var ksReject=D>Dc;
      // draw histograms
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=24;ctx.clearRect(0,0,w,h);
      var lo=-5,hi=8,nb=34,bw=(hi-lo)/nb;
      var ha=new Array(nb).fill(0),hb=new Array(nb).fill(0);
      for(i=0;i<n;i++){var ia=Math.floor((a[i]-lo)/bw),ib=Math.floor((b[i]-lo)/bw);
        if(ia>=0&&ia<nb)ha[ia]++; if(ib>=0&&ib<nb)hb[ib]++;}
      var hmax=Math.max(Math.max.apply(null,ha),Math.max.apply(null,hb));
      function X(v){return pad+(v-lo)/(hi-lo)*(w-2*pad);}
      function barH(c){return c/hmax*(h-2*pad-10);}
      for(i=0;i<nb;i++){var x0=X(lo+i*bw),x1=X(lo+(i+1)*bw);
        ctx.fillStyle="rgba(31,111,106,0.45)";ctx.fillRect(x0,h-pad-barH(ha[i]),x1-x0-1,barH(ha[i]));
        ctx.fillStyle="rgba(176,73,47,0.45)";ctx.fillRect(x0,h-pad-barH(hb[i]),x1-x0-1,barH(hb[i]));}
      ctx.strokeStyle=LINE;ctx.beginPath();ctx.moveTo(pad,h-pad);ctx.lineTo(w-pad,h-pad);ctx.stroke();
      ctx.font="11px monospace";ctx.fillStyle=TEAL;ctx.fillText("before",pad+2,pad);
      ctx.fillStyle=RUST;ctx.fillText("after",pad+54,pad);
      function row(name,stat,rej){return '<div class="gauge"><span class="g-lab">'+name+'</span>'+
        '<span class="g-val" style="width:auto;color:'+(rej?RUST:MUTE)+'">'+stat+(rej?"  reject":"  ok")+'</span></div>';}
      read.innerHTML = row("t (mean)","t="+tt.toFixed(2),tReject)+
                       row("Levene (var)","F="+Flev.toFixed(2),levReject)+
                       row("KS (shape)","D="+D.toFixed(2),ksReject);
      cap.textContent = (!tReject && (levReject||ksReject))
        ? "A pure variance or shape change: the t-test sees nothing, but Levene and KS fire. One test is not enough."
        : (tReject && !levReject ? "A clean mean shift: the t-test fires. Add a variance change and watch Levene wake up."
           : "Move the mean and the spread independently and watch which tests respond.");
    }
    [sMean,sVar].forEach(function(e){e.addEventListener("input",draw);});
    window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // C. ARL design calculator: tune a CUSUM and read its run lengths
  // ======================================================================
  (function arl(){
    var cv=document.getElementById("ex-arl-canvas"); if(!cv) return;
    var sK=document.getElementById("ex-arl-k"), sH=document.getElementById("ex-arl-h"),
        sShift=document.getElementById("ex-arl-shift"), read=document.getElementById("ex-arl-read"),
        cap=document.getElementById("ex-arl-cap");
    function runlen(k,h,shift,reps,cap_n,seed){
      var r=rng(seed), tot=0, i, j;
      for(i=0;i<reps;i++){
        var c=0, t=0;
        for(j=0;j<cap_n;j++){
          var u=Math.max(1e-9,r()),v=r();
          var x=Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)+shift;
          c=Math.max(0,c+x-k); t++;
          if(c>h)break;
        }
        tot+=t;
      }
      return tot/reps;
    }
    function draw(){
      var k=parseFloat(sK.value)/100*1.2+0.1, h=parseFloat(sH.value)/100*8+2,
          shift=parseFloat(sShift.value)/100*2.2;
      var arl0=runlen(k,h,0,140,4000,7);
      var arl1=runlen(k,h,shift,200,4000,9);
      var f=fit(cv),ctx=f.ctx,w=f.w,hh=f.h,pad=30;ctx.clearRect(0,0,w,hh);
      var vals=[{l:"ARL0 (false alarm)",v:arl0,c:RUST},{l:"detection delay",v:arl1,c:TEAL}];
      var mx=Math.max(arl0,arl1,10), bx=w*0.34, bw=w*0.26;
      vals.forEach(function(o,i){
        var x0=bx+i*(bw+w*0.06), bh=(hh-2*pad)*Math.pow(Math.min(1,o.v/mx),0.42)*0.92+2;
        ctx.fillStyle=o.c;ctx.fillRect(x0,hh-pad-bh,bw,bh);
        ctx.fillStyle=INK;ctx.font="13px monospace";ctx.textAlign="center";
        ctx.fillText(Math.round(o.v),x0+bw/2,hh-pad-bh-6);
        ctx.fillStyle=MUTE;ctx.font="10.5px monospace";ctx.fillText(o.l,x0+bw/2,hh-pad+15);
      });
      ctx.textAlign="left";
      read.innerHTML="allowance k=<b>"+k.toFixed(2)+"</b>, limit h=<b>"+h.toFixed(1)+
        "</b> &rarr; in-control run length <b style='color:"+RUST+"'>"+Math.round(arl0)+
        "</b>, delay at "+shift.toFixed(1)+"&sigma; <b style='color:"+TEAL+"'>"+Math.round(arl1)+"</b>";
      cap.textContent="Raise h for fewer false alarms (longer ARL0) at the cost of slower detection; raise k to target larger shifts. There is no free lunch.";
    }
    var deb; [sK,sH,sShift].forEach(function(e){e.addEventListener("input",function(){
      clearTimeout(deb); deb=setTimeout(draw,40);});});
    window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // D. Multivariate MEWMA vs two univariate charts
  // ======================================================================
  (function mv(){
    var cv=document.getElementById("ex-mv-canvas"); if(!cv) return;
    var sMag=document.getElementById("ex-mv-mag"), sAng=document.getElementById("ex-mv-ang"),
        read=document.getElementById("ex-mv-read"), cap=document.getElementById("ex-mv-cap");
    var N=260, cp=150, g1=gauss(N,61), g2=gauss(N,67), lam=0.2, rho=0.8;
    // cov = [[1,rho],[rho,1]]; cov_z = lam/(2-lam)*cov; invert 2x2
    var s=lam/(2-lam), a=s*1, b=s*rho, det=a*a-b*b, i00=a/det, i01=-b/det, i11=a/det;
    var hlim=13.8; // chi2(2) 0.999
    function draw(){
      var mag=parseFloat(sMag.value)/100*1.8, ang=parseFloat(sAng.value)/100*Math.PI, i;
      var dx=mag*Math.cos(ang), dy=mag*Math.sin(ang);
      var z1=new Float64Array(N), z2=new Float64Array(N), t2=new Float64Array(N);
      var Z1=0,Z2=0, uniAlarm=-1, mAlarm=-1;
      for(i=0;i<N;i++){
        var x1=g1[i], x2=rho*g1[i]+Math.sqrt(1-rho*rho)*g2[i];
        if(i>=cp){x1+=dx;x2+=dy;}
        z1[i]=x1; z2[i]=x2;
        Z1=lam*x1+(1-lam)*Z1; Z2=lam*x2+(1-lam)*Z2;
        t2[i]=Z1*(i00*Z1+i01*Z2)+Z2*(i01*Z1+i11*Z2);
        if(uniAlarm<0 && i>=cp && (Math.abs(x1)>3||Math.abs(x2)>3)) uniAlarm=i;
        if(mAlarm<0 && t2[i]>hlim) mAlarm=i;
      }
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=26, midy=h*0.46;
      ctx.clearRect(0,0,w,h);
      function X(i){return pad+i/(N-1)*(w-2*pad);}
      ctx.fillStyle="rgba(176,73,47,0.06)";ctx.fillRect(X(cp),pad,w-pad-X(cp),h-2*pad);
      // top: two z signals with +-3 lines
      function Yz(v){return pad+(h*0.40)/2 - v/4.5*(h*0.40)/2;}
      [3,-3].forEach(function(L){ctx.strokeStyle=LINE;ctx.setLineDash([3,3]);
        ctx.beginPath();ctx.moveTo(pad,Yz(L));ctx.lineTo(w-pad,Yz(L));ctx.stroke();ctx.setLineDash([]);});
      function plot(z,col){ctx.strokeStyle=col;ctx.lineWidth=0.8;ctx.beginPath();
        for(i=0;i<N;i++){if(i===0)ctx.moveTo(X(i),Yz(z[i]));else ctx.lineTo(X(i),Yz(z[i]));}ctx.stroke();}
      plot(z1,TEAL); plot(z2,OCHRE);
      ctx.fillStyle=MUTE;ctx.font="10.5px monospace";ctx.fillText("each sensor (z), \u00b13\u03c3",pad,pad+2);
      // bottom: MEWMA T2
      var t2max=Math.max(hlim*1.5, Math.max.apply(null,Array.prototype.slice.call(t2)));
      function Yt(v){return h-pad - v/t2max*(h*0.40);}
      ctx.strokeStyle=INK;ctx.setLineDash([4,3]);ctx.beginPath();ctx.moveTo(pad,Yt(hlim));ctx.lineTo(w-pad,Yt(hlim));ctx.stroke();ctx.setLineDash([]);
      ctx.strokeStyle=RUST;ctx.lineWidth=1.6;ctx.beginPath();
      for(i=0;i<N;i++){if(i===0)ctx.moveTo(X(i),Yt(t2[i]));else ctx.lineTo(X(i),Yt(t2[i]));}ctx.stroke();
      ctx.fillStyle=RUST;ctx.fillText("MEWMA T\u00b2",pad,midy+10);
      ctx.fillStyle=MUTE;ctx.fillText("change \u2192",X(cp)+4,h-pad-3);
      read.innerHTML="univariate charts: <b style='color:"+(uniAlarm<0?TEAL:RUST)+"'>"+
        (uniAlarm<0?"no alarm":"alarm @ "+uniAlarm)+"</b> &nbsp;|&nbsp; MEWMA: <b style='color:"+
        (mAlarm<0?MUTE:RUST)+"'>"+(mAlarm<0?"no alarm":"alarm @ "+mAlarm)+"</b>";
      cap.textContent = (uniAlarm<0 && mAlarm>=0)
        ? "A small shift spread across correlated sensors: each channel stays within its own limit, yet the joint MEWMA catches it."
        : "Push the shift further and the single-sensor charts eventually trip too; the joint chart simply gets there first.";
    }
    [sMag,sAng].forEach(function(e){e.addEventListener("input",draw);});
    window.addEventListener("resize",draw); draw();
  })();
})();
