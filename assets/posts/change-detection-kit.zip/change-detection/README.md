# Change-detection kit

A VS Code Copilot skill for change and fault detection over time, in the
progressive-disclosure layout. Read `SKILL.md` first; it routes to the rest.

## Layout
- `SKILL.md` routing and overview.
- `references/01-sequential-detectors.md` covers sequential detectors, decide as data arrives.
- `references/02-model-based.md` covers model-based detection.
- `references/03-window-tests.md` covers comparing two windows: classical hypothesis tests.
- `references/04-multivariate.md` covers multivariate change detection.
- `references/05-bayesian-and-segmentation.md` covers bayesian and multiple-change detection.
- `references/06-concept-drift.md` covers concept-drift detectors.
- `references/07-arl-and-evaluation.md` covers run-length design and evaluation.
- `references/08-other-change-shapes.md` covers beyond a mean step.
- `references/decision-map.md`, `references/rules-of-thumb.md`, `references/pitfalls.md`, `references/case-study.md`, `references/at-a-glance.md`, `references/references.md`.
- `scripts/change_detection.py` the tested engine (numpy, scipy only). Run it for a self-test:

      python scripts/change_detection.py

- `scripts/benchmark.py` prints run-length tables and delay-versus-false-alarm operating curves to compare and tune detectors.
- `copilot/` a change-detection analyst chat mode, a `/detect` and a `/characterize` prompt, and path-scoped instructions.
- `assets/change-detection.html` the full illustrated monograph.
