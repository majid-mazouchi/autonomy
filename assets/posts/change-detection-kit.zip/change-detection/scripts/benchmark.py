"""
Benchmark a detector by its operating curve and run lengths.

Run length is the honest figure of merit for a sequential detector: long between
false alarms, short to detect a real change. This script estimates the in-control
average run length and the detection delay for a range of limits, then prints the
delay-versus-false-alarm operating curve so two detectors can be compared fairly.

Usage:
    python benchmark.py
"""
import numpy as np
from change_detection import simulate_arl, delay_far_curve


def arl_table(detector="cusum", shift=1.0, hs=(4, 5, 6, 7, 8), **kw):
    print(f"\n{detector} run lengths (shift={shift} sigma)")
    print(f"{'h':>5} {'ARL0':>10} {'delay':>10}")
    for h in hs:
        arl0 = simulate_arl(detector, 0.0, reps=200, n=4000, h=h, **kw)
        d = simulate_arl(detector, shift, reps=300, n=4000, h=h, **kw)
        print(f"{h:>5} {arl0:>10.0f} {d:>10.1f}")


def operating_curve(detector="cusum", shift=0.8):
    c = delay_far_curve(detector, shift=shift, reps=200)
    print(f"\n{detector} operating curve (shift={shift} sigma)")
    print(f"{'thr':>6} {'FAR':>8} {'delay':>8}")
    for t, f, d in zip(c["thresholds"], c["far"], c["delay"]):
        print(f"{t:>6.2f} {f:>8.3f} {d:>8.1f}")


if __name__ == "__main__":
    arl_table("cusum", shift=1.0)
    operating_curve("cusum", shift=0.8)
    operating_curve("ph", shift=0.8)
    print("\nLower-and-left operating curve wins; pick the limit at an acceptable FAR.")
