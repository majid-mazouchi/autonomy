"""
Change and fault detection over time, for system health management.

Purpose
One tested module behind the monograph and the Copilot kit. Implements the
sequential change detectors (CUSUM, EWMA, Page-Hinkley, SPRT), the model-based
generalized likelihood ratio test, and the classical two-sample and
distributional hypothesis tests for comparing a before window to an after window.

Dependencies
numpy and scipy only.
"""
import numpy as np
from scipy import stats


# ===========================================================================
# sequential detectors: decide as each sample arrives
# ===========================================================================
def cusum(x, target=None, sd=None, k=0.5, h=5.0):
    """
    Purpose
    Two-sided tabular CUSUM. Accumulates standardized deviations from a healthy
    target so a small persistent mean shift compounds into an alarm. Most
    sensitive to step changes.

    Inputs
    x is the stream. target and sd are the in-control mean and standard
    deviation (estimate them from a healthy reference, not from x). k is the
    allowance in sigma (half the shift you want to catch fast), h the limit.

    Outputs
    Dict with the upper and lower CUSUM paths, the limit, and the first alarm
    index (or -1).
    """
    x = np.asarray(x, float)
    mu = x.mean() if target is None else target
    s = (x.std() if sd is None else sd) + 1e-12
    z = (x - mu) / s
    sh = np.zeros(len(x)); sl = np.zeros(len(x))
    ch = cl = 0.0; alarm = -1
    for i, v in enumerate(z):
        ch = max(0.0, ch + v - k)
        cl = max(0.0, cl - v - k)
        sh[i], sl[i] = ch, cl
        if alarm < 0 and (ch > h or cl > h):
            alarm = i
    return dict(sh=sh, sl=sl, limit=h, alarm=alarm)


def ewma(x, lam=0.2, L=3.0, target=None, sd=None):
    """
    Purpose
    Exponentially weighted moving average control chart. Smooths the stream so a
    slow drift compounds into an alarm. Most sensitive to gradual drifts.

    Inputs
    x is the stream, lam the memory (small means long memory), L the limit width
    in sigma, target and sd the in-control reference.

    Outputs
    Dict with the EWMA series, its upper and lower limits, and the first alarm.
    """
    x = np.asarray(x, float)
    mu = x.mean() if target is None else target
    s = (x.std() if sd is None else sd) + 1e-12
    z = np.empty(len(x)); prev = mu
    for i, v in enumerate(x):
        prev = lam * v + (1 - lam) * prev
        z[i] = prev
    width = L * s * np.sqrt(lam / (2 - lam))
    ucl, lcl = mu + width, mu - width
    alarm = next((i for i, v in enumerate(z) if v > ucl or v < lcl), -1)
    return dict(ewma=z, ucl=ucl, lcl=lcl, center=mu, alarm=alarm)


def page_hinkley(x, delta=0.5, threshold=8.0, target=None, direction="up"):
    """
    Purpose
    The Page-Hinkley test, a popular abrupt-change detector in condition
    monitoring. Tracks the cumulative difference between each sample and the
    running mean, minus a small slack, and alarms when it departs from its own
    running minimum.

    Inputs
    x is the stream, delta the slack (tolerated drift per sample), threshold the
    alarm bound, direction up or down for the shift sign.

    Outputs
    Dict with the Page-Hinkley statistic, the threshold, and the first alarm.
    """
    x = np.asarray(x, float)
    sgn = 1.0 if direction == "up" else -1.0
    run = x[0] if target is None else target
    cum = 0.0; ext = 0.0
    ph = np.zeros(len(x)); alarm = -1
    for i, v in enumerate(x):
        if target is None:
            run += (v - run) / (i + 1)
        cum += sgn * (v - run) - delta
        ext = min(ext, cum)
        ph[i] = cum - ext
        if alarm < 0 and ph[i] > threshold:
            alarm = i
    return dict(ph=ph, threshold=threshold, alarm=alarm)


def sprt(x, mu0, mu1, sd, alpha=0.05, beta=0.05):
    """
    Purpose
    Wald's sequential probability ratio test. Decides between a healthy
    hypothesis (mean mu0) and a faulty one (mean mu1) using the fewest samples,
    by walking a log-likelihood ratio between two decision bounds.

    Inputs
    x the stream, mu0 and mu1 the two hypothesized means, sd the known standard
    deviation, alpha and beta the target error rates.

    Outputs
    Dict with the log-likelihood-ratio path, the two bounds, the decision, and
    the sample index at which it was reached.
    """
    x = np.asarray(x, float)
    A = np.log((1 - beta) / alpha)
    B = np.log(beta / (1 - alpha))
    llr = np.cumsum(((mu1 - mu0) / sd ** 2) * (x - (mu0 + mu1) / 2))
    decision, idx = "continue", -1
    for i, v in enumerate(llr):
        if v >= A:
            decision, idx = "accept H1 (faulty)", i; break
        if v <= B:
            decision, idx = "accept H0 (healthy)", i; break
    return dict(llr=llr, upper=A, lower=B, decision=decision, index=idx)


# ===========================================================================
# model-based: generalized likelihood ratio for an unknown mean change
# ===========================================================================
def glr_mean_shift(x, sd=None):
    """
    Purpose
    Generalized likelihood ratio test for a single change in mean at an unknown
    time and of unknown size, the standard model-based test when the fault
    parameters are not known in advance. It maximizes the likelihood ratio over
    every candidate change point.

    Inputs
    x the segment to test, sd the known in-control standard deviation (estimated
    from a healthy reference if omitted).

    Outputs
    Dict with the GLR statistic profile over candidate change points, the
    estimated change point, and the peak statistic (compare to a chi-square or
    simulated threshold).
    """
    x = np.asarray(x, float)
    n = len(x)
    s = (x.std() if sd is None else sd) + 1e-12
    cs = np.cumsum(x)
    G = np.zeros(n)
    for k in range(1, n):
        n1, n2 = k, n - k
        m1 = cs[k - 1] / n1
        m2 = (cs[-1] - cs[k - 1]) / n2
        G[k] = (n1 * n2 / n) * (m1 - m2) ** 2 / s ** 2
    kbest = int(np.argmax(G))
    return dict(glr=G, change_point=kbest, stat=float(G[kbest]))


# ===========================================================================
# classical hypothesis tests: compare a before window to an after window
# ===========================================================================
def variance_ratio_test(a, b):
    """F-test for equal variances. Returns (F, p)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    va, vb = a.var(ddof=1), b.var(ddof=1)
    F = va / vb
    df1, df2 = len(a) - 1, len(b) - 1
    p = 2 * min(stats.f.cdf(F, df1, df2), 1 - stats.f.cdf(F, df1, df2))
    return F, p


def compare_windows(a, b):
    """
    Purpose
    Run the standard battery comparing two windows, so a mean test, a variance
    test, and a distribution test are read together. A mean shift, a variance
    change, and a shape change are different faults and need different tests.

    Inputs
    a is the before window, b the after window.

    Outputs
    Dict of (statistic, p-value) pairs for Welch t (mean), Levene and Bartlett
    and the F-test (variance), and the two-sample Kolmogorov-Smirnov and
    Anderson-Darling tests (whole distribution).
    """
    a, b = np.asarray(a, float), np.asarray(b, float)
    t = stats.ttest_ind(a, b, equal_var=False)
    lev = stats.levene(a, b)
    bart = stats.bartlett(a, b)
    F, pF = variance_ratio_test(a, b)
    ks = stats.ks_2samp(a, b)
    ad = stats.anderson_ksamp([a, b])
    return dict(
        t_mean=(float(t.statistic), float(t.pvalue)),
        levene_var=(float(lev.statistic), float(lev.pvalue)),
        bartlett_var=(float(bart.statistic), float(bart.pvalue)),
        f_var=(float(F), float(pF)),
        ks_dist=(float(ks.statistic), float(ks.pvalue)),
        ad_dist=(float(ad.statistic), float(ad.pvalue)),
    )


def anova(*groups):
    """One-way ANOVA across several groups (means). Returns (F, p)."""
    r = stats.f_oneway(*groups)
    return float(r.statistic), float(r.pvalue)


def chi2_independence(table):
    """Chi-square test of independence on a contingency table. Returns (chi2, p, dof)."""
    chi2, p, dof, _ = stats.chi2_contingency(np.asarray(table))
    return float(chi2), float(p), int(dof)


# ===========================================================================
# multivariate change detection: watch a vector stream as one
# ===========================================================================
def mcusum(X, mean0, cov0, k=0.5, h=5.5):
    """
    Purpose
    Crosier's multivariate CUSUM. Accumulates a vector of deviations from the
    healthy mean and measures its Mahalanobis length, so a small shift spread
    across several correlated sensors is caught even when no single channel
    moves enough to alarm on its own.

    Inputs
    X is samples by sensors, mean0 and cov0 the healthy mean vector and
    covariance, k the allowance, h the limit.

    Outputs
    Dict with the scalar MCUSUM statistic per sample, the limit, and the alarm.
    """
    X = np.atleast_2d(np.asarray(X, float))
    Si = np.zeros(X.shape[1])
    inv = np.linalg.inv(cov0)
    stat = np.zeros(len(X)); alarm = -1
    for i, x in enumerate(X):
        d = Si + x - mean0
        Ci = np.sqrt(d @ inv @ d)
        Si = np.zeros_like(d) if Ci <= k else d * (1 - k / Ci)
        stat[i] = np.sqrt(Si @ inv @ Si)
        if alarm < 0 and stat[i] > h:
            alarm = i
    return dict(stat=stat, limit=h, alarm=alarm)


def mewma(X, mean0, cov0, lam=0.2, h=None):
    """
    Purpose
    The multivariate EWMA control chart. Smooths the vector stream and monitors
    the Hotelling distance of the smoothed vector, so a slow multivariate drift
    compounds into an alarm.

    Inputs
    X is samples by sensors, mean0 and cov0 the healthy reference, lam the
    memory, h the limit (a chi-square quantile is used if omitted).

    Outputs
    Dict with the MEWMA statistic per sample, the limit, and the alarm.
    """
    X = np.atleast_2d(np.asarray(X, float))
    p = X.shape[1]
    if h is None:
        h = stats.chi2.ppf(0.999, p)
    cov_z = (lam / (2 - lam)) * cov0
    inv = np.linalg.inv(cov_z)
    Z = np.zeros(p); t2 = np.zeros(len(X)); alarm = -1
    for i, x in enumerate(X):
        Z = lam * (x - mean0) + (1 - lam) * Z
        t2[i] = Z @ inv @ Z
        if alarm < 0 and t2[i] > h:
            alarm = i
    return dict(t2=t2, limit=h, alarm=alarm)


# ===========================================================================
# Bayesian online change-point detection (Adams and MacKay, 2007)
# ===========================================================================
def bocpd(x, hazard=200.0, mu0=0.0, kappa0=1.0, alpha0=1.0, beta0=1.0):
    """
    Purpose
    Bayesian online change-point detection with a Gaussian model of unknown
    mean and variance. Rather than a hard alarm it maintains, at every step, a
    posterior over the run length since the last change, which collapses to zero
    when a change is detected and grows as evidence of stability accumulates.

    Inputs
    x the stream, hazard the expected run length between changes (constant hazard
    1/hazard), and the Normal-Gamma prior parameters.

    Outputs
    Dict with the run-length posterior matrix R and the maximum-a-posteriori run
    length over time (a drop to zero marks a detected change).
    """
    x = np.asarray(x, float); n = len(x)
    R = np.zeros((n + 1, n + 1)); R[0, 0] = 1.0
    muT = np.array([mu0]); kapT = np.array([kappa0])
    alT = np.array([alpha0]); beT = np.array([beta0])
    rl = np.zeros(n + 1); H = 1.0 / hazard
    for t in range(1, n + 1):
        xt = x[t - 1]
        df = 2 * alT
        scale = np.sqrt(beT * (kapT + 1) / (alT * kapT))
        pred = stats.t.pdf(xt, df=df, loc=muT, scale=scale)
        growth = R[0:t, t - 1] * pred * (1 - H)
        cp = np.sum(R[0:t, t - 1] * pred * H)
        R[1:t + 1, t] = growth; R[0, t] = cp
        R[:, t] /= R[:, t].sum() + 1e-300
        new_mu = (kapT * muT + xt) / (kapT + 1)
        new_beta = beT + (kapT * (xt - muT) ** 2) / (2 * (kapT + 1))
        muT = np.concatenate([[mu0], new_mu])
        beT = np.concatenate([[beta0], new_beta])
        kapT = np.concatenate([[kappa0], kapT + 1])
        alT = np.concatenate([[alpha0], alT + 0.5])
        rl[t] = np.argmax(R[:, t])
    return dict(R=R, run_length=rl)


# ===========================================================================
# multiple change points: PELT (Killick, Fearnhead and Eckley, 2012)
# ===========================================================================
def pelt(x, penalty=None, min_size=6):
    """
    Purpose
    Exact multiple-change-point detection by pruned dynamic programming, with a
    Gaussian cost that responds to a change in mean or variance. Where the GLRT
    finds one change, PELT partitions the whole record into homogeneous segments.

    Inputs
    x the record, penalty the cost of adding a change point (a BIC-like default),
    min_size the smallest segment length.

    Outputs
    Sorted list of change-point indices.
    """
    x = np.asarray(x, float); n = len(x)
    if penalty is None:
        penalty = 3.0 * np.log(n)
    cs = np.concatenate([[0], np.cumsum(x)])
    cs2 = np.concatenate([[0], np.cumsum(x ** 2)])

    def cost(s, t):
        m = t - s
        var = (cs2[t] - cs2[s]) / m - ((cs[t] - cs[s]) / m) ** 2
        return m * np.log(max(var, 1e-8))

    F = np.full(n + 1, np.inf); F[0] = -penalty
    last = [0] * (n + 1); R = [0]
    for t in range(min_size, n + 1):
        best_v, best_s = np.inf, 0
        for s in R:
            if t - s < min_size:
                continue
            v = F[s] + cost(s, t) + penalty
            if v < best_v:
                best_v, best_s = v, s
        F[t] = best_v; last[t] = best_s
        R = [s for s in R if F[s] + cost(s, t) <= F[t]] + [t]
    cps, t = [], n
    while t > 0:
        s = last[t]
        if s > 0:
            cps.append(s)
        t = s
    return sorted(cps)


# ===========================================================================
# concept-drift detectors: the streaming-ML relatives of Page-Hinkley
# ===========================================================================
def ddm(errors, warm=30):
    """
    Purpose
    The Drift Detection Method (Gama et al., 2004). Monitors the error rate of a
    running model on a binary correct/incorrect stream and signals a warning then
    a drift when the rate climbs significantly above its best-ever level.

    Inputs
    errors a 0/1 stream (1 = the model was wrong); warm the warm-up count before
    testing begins.

    Outputs
    Dict with the warning and drift sample indices (or -1).
    """
    e = np.asarray(errors, float); n = len(e)
    pmin = smin = np.inf; ne = 0; warn = drift = -1
    for i in range(1, n + 1):
        ne += e[i - 1]
        if i < warm:
            continue
        p = ne / i; s = np.sqrt(p * (1 - p) / i)
        if p + s <= pmin + smin:
            pmin, smin = p, s
        if p + s > pmin + 3 * smin:
            drift = i - 1; break
        if warn < 0 and p + s > pmin + 2 * smin:
            warn = i - 1
    return dict(warning=warn, drift=drift)


def adwin(x, delta=0.002):
    """
    Purpose
    A simplified ADWIN (Bifet and Gavalda, 2007). Keeps an adaptive window and
    drops its older part whenever two sub-windows differ in mean by more than a
    Hoeffding bound, flagging a drift at that point.

    Inputs
    x the stream, delta the confidence parameter.

    Outputs
    Dict with the list of drift indices.
    """
    x = np.asarray(x, float); W = []; drifts = []
    for i, v in enumerate(x):
        W.append(v)
        for j in range(1, len(W)):
            n0, n1 = j, len(W) - j
            m = 1.0 / (1.0 / n0 + 1.0 / n1)
            eps = np.sqrt((1.0 / (2 * m)) * np.log(4 * len(W) / delta))
            if abs(np.mean(W[:j]) - np.mean(W[j:])) > eps:
                W = W[j:]; drifts.append(i); break
    return dict(drifts=drifts)


def kswin(x, window=120, stat_size=30, alpha=0.005):
    """
    Purpose
    KSWIN (Raab et al., 2020). Slides a window and compares its most recent
    samples to the rest with a Kolmogorov-Smirnov test, flagging a drift when
    the distributions differ, so it catches shape changes a mean-based detector
    misses.

    Inputs
    x the stream, window the total window, stat_size the recent block, alpha the
    test level.

    Outputs
    Dict with the list of drift indices.
    """
    x = np.asarray(x, float); drifts = []
    for i in range(window, len(x)):
        w = x[i - window:i]
        d, p = stats.ks_2samp(w[:-stat_size], w[-stat_size:])
        if p < alpha:
            drifts.append(i)
    return dict(drifts=drifts)


# ===========================================================================
# other change shapes: variance, autocorrelation, spectral content
# ===========================================================================
def cusum_variance(x, target, sd, k=1.0, h=8.0):
    """
    Purpose
    A CUSUM for a change in spread rather than mean. It accumulates the
    standardized squared deviation minus its in-control expectation, so a
    variance increase with no mean change is caught.

    Inputs
    x the stream, target and sd the healthy mean and standard deviation.

    Outputs
    Dict with the variance CUSUM path, the limit, and the alarm.
    """
    z = ((np.asarray(x, float) - target) / sd) ** 2 - 1.0
    z = z / np.sqrt(2.0)                             # unit variance in control
    cp = np.zeros(len(z)); c = 0.0; alarm = -1
    for i, v in enumerate(z):
        c = max(0.0, c + v - k); cp[i] = c
        if alarm < 0 and c > h:
            alarm = i
    return dict(cusum=cp, limit=h, alarm=alarm)


def ar1_residuals(x):
    """
    Purpose
    Whiten an autocorrelated stream by removing a fitted first-order
    autoregression, so the residual is close to independent and the i.i.d. limits
    behind CUSUM and EWMA become valid again.

    Inputs
    x the autocorrelated stream.

    Outputs
    The residual series and the estimated AR(1) coefficient.
    """
    x = np.asarray(x, float)
    phi = np.corrcoef(x[:-1], x[1:])[0, 1]
    return x[1:] - phi * x[:-1], float(phi)


def band_power_stream(x, fs, band, win=128, step=16):
    """
    Purpose
    Turn a raw vibration or acoustic signal into a feature stream of power in a
    frequency band, computed on a sliding window. A fault that changes the
    spectral content (a new tone) shows up here even when the amplitude and
    variance barely move, so the change detectors can be run on the feature.

    Inputs
    x the signal, fs the sample rate, band a (low, high) frequency pair, win and
    step the window and hop in samples.

    Outputs
    The band-power feature stream.
    """
    x = np.asarray(x, float)
    f = np.fft.rfftfreq(win, 1.0 / fs)
    sel = (f >= band[0]) & (f <= band[1])
    w = np.hanning(win)
    out = []
    for s in range(0, len(x) - win, step):
        P = np.abs(np.fft.rfft(x[s:s + win] * w)) ** 2
        out.append(P[sel].sum())
    return np.asarray(out)


# ===========================================================================
# design and evaluation: average run length, delay-vs-false-alarm
# ===========================================================================
def simulate_arl(detector="cusum", shift=0.0, reps=300, n=2000, seed=0, **kw):
    """
    Purpose
    Estimate the average run length of a detector by Monte Carlo: with shift 0 it
    is the in-control ARL (mean samples to a false alarm); with a shift it is the
    detection delay. Use it to tune k, h, lambda, or L to a target.

    Inputs
    detector one of cusum, ewma, ph; shift the post-change mean; reps and n the
    simulation size; remaining keyword arguments pass to the detector.

    Outputs
    The mean run length.
    """
    rs = np.random.default_rng(seed); d = []
    for _ in range(reps):
        x = rs.normal(shift, 1.0, n)
        if detector == "cusum":
            a = cusum(x, target=0, sd=1, **kw)["alarm"]
        elif detector == "ewma":
            a = ewma(x, target=0, sd=1, **kw)["alarm"]
        else:
            a = page_hinkley(x, target=0, **kw)["alarm"]
        d.append(a if a >= 0 else n)
    return float(np.mean(d))


def delay_far_curve(detector="cusum", shift=1.0, thresholds=None, reps=200, n=600, cp=300, seed=1):
    """
    Purpose
    Trace a detector's operating curve: for a range of thresholds, the mean
    detection delay against the false-alarm rate (the fraction of runs that
    alarm before the true change). This is the honest way to compare detectors.

    Inputs
    detector, shift, the thresholds to sweep, simulation size, and the change
    point cp.

    Outputs
    Dict with arrays of false-alarm rate and mean detection delay.
    """
    if thresholds is None:
        thresholds = np.linspace(2, 9, 12)
    rs = np.random.default_rng(seed)
    far, delay = [], []
    for h in thresholds:
        fa = 0; dl = []
        for _ in range(reps):
            x = rs.normal(0, 1, n); x[cp:] += shift
            if detector == "cusum":
                a = cusum(x, target=0, sd=1, h=h)["alarm"]
            else:
                a = page_hinkley(x, target=0, threshold=h)["alarm"]
            if 0 <= a < cp:
                fa += 1
            elif a >= cp:
                dl.append(a - cp)
        far.append(fa / reps)
        delay.append(np.mean(dl) if dl else n - cp)
    return dict(far=np.asarray(far), delay=np.asarray(delay), thresholds=np.asarray(thresholds))


def _demo():
    rng = np.random.default_rng(0)
    n = 300; cp = 180
    x = rng.normal(0, 1, n)
    x[cp:] += 0.9                                   # small step at cp
    print("CUSUM alarm  ", cusum(x, target=0, sd=1, h=6)["alarm"])
    print("EWMA alarm   ", ewma(x, target=0, sd=1, L=3.5)["alarm"])
    print("Page-Hinkley ", page_hinkley(x, delta=0.3, threshold=10, target=0)["alarm"])
    sp = sprt(x[cp:], mu0=0, mu1=0.9, sd=1); print("SPRT         ", sp["decision"], "at", sp["index"])
    g = glr_mean_shift(x, sd=1); print("GLR change pt", g["change_point"], "stat %.1f" % g["stat"])
    cw = compare_windows(x[:cp], x[cp:])
    print("t p %.1e | Levene p %.2f | KS p %.1e" %
          (cw["t_mean"][1], cw["levene_var"][1], cw["ks_dist"][1]))
    print("ANOVA", "%.2f" % anova(x[:100], x[100:200], x[200:])[1])
    print("chi2", chi2_independence([[30, 10], [12, 28]])[:2])
    # advanced detectors
    p = 3
    mean0 = np.zeros(p); cov0 = np.eye(p)
    Xm = rng.normal(0, 1, (n, p)); Xm[cp:] += 0.6        # small joint shift
    print("MCUSUM alarm ", mcusum(Xm, mean0, cov0)["alarm"])
    print("MEWMA alarm  ", mewma(Xm, mean0, cov0)["alarm"])
    bo = bocpd(x, hazard=200); print("BOCPD MAP run-length at end", int(bo["run_length"][-1]))
    xm = rng.normal(0, 1, 400)
    xm[120:] += 2.0; xm[260:] -= 3.0
    print("PELT change points", pelt(xm))
    err_rng = np.random.default_rng(1)
    err = np.r_[err_rng.binomial(1, 0.15, 250), err_rng.binomial(1, 0.55, 150)]
    print("DDM", ddm(err, warm=60)); print("KSWIN drifts (count)", len(kswin(x)["drifts"]))
    xv = rng.normal(0, 1, n); xv[cp:] *= 2.2
    print("variance CUSUM alarm", cusum_variance(xv, target=0, sd=1)["alarm"])
    xa = np.zeros(n)
    for i in range(1, n):
        xa[i] = 0.7 * xa[i - 1] + rng.normal(0, 1)
    res, phi = ar1_residuals(xa); print("AR(1) phi %.2f" % phi)
    print("ARL0 cusum h=5 ~", "%.0f" % simulate_arl("cusum", 0.0, reps=80, h=5))
    print("ARL1 cusum shift=1 ~", "%.1f" % simulate_arl("cusum", 1.0, reps=80, h=5))


if __name__ == "__main__":
    _demo()
