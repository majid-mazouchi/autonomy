# Multivariate change detection

_Watch a vector of correlated sensors as one signal, so a small shift spread across several channels is caught even when no single channel leaves its limit._

## Multivariate CUSUM (MCUSUM)
The vector form of CUSUM. It accumulates a running vector of deviations from the healthy mean and measures its Mahalanobis length against the healthy covariance, alarming when that length exceeds a limit. Tuned, like scalar CUSUM, for a step shift.

**Engine call.** `mcusum(X, mean0, cov0, k=0.5, h=5.5)` where `X` is samples by sensors.

## Multivariate EWMA (MEWMA)
The vector form of EWMA. It smooths the vector stream and monitors the Hotelling distance of the smoothed vector, so a slow multivariate drift compounds into an alarm. Tuned for drift.

**Engine call.** `mewma(X, mean0, cov0, lam=0.2, h=None)` (a chi-square quantile sets `h` if omitted).

**Practical note.** Estimate `mean0` and `cov0` from a healthy reference and mind the sample-to-variable ratio: an ill-conditioned covariance destabilizes the Mahalanobis distance, so regularize or reduce dimension. Set the limit by simulation; the chi-square approximation is asymptotic. On an alarm, decompose the statistic to per-sensor contributions to localize the fault. These are the time-domain counterpart to T-squared and Q monitoring.

**Reference.** Crosier (1988), Technometrics 30; Lowry, Woodall, Champ & Rigdon (1992), Technometrics 34.