# Pitfalls and assumptions

Read before presenting any alarm or p-value as a verdict.

## CUSUM

Estimate the target and standard deviation from a verified healthy reference, never from the stream you are watching, or a developing fault inflates the baseline and hides itself. Choose k as half the shift you most want to catch quickly, and set h from the in-control average run length you can tolerate. Reset and re-estimate after a confirmed repair. CUSUM assumes roughly independent, stationary samples; autocorrelation makes it alarm early.

## EWMA

Pick lambda for the speed of fault you fear: small (0.05 to 0.2) for slow drifts, larger for abrupt ones; lambda near one reduces to a Shewhart chart. Set limits from a healthy reference, and prefer the time-varying limits for the first few samples. Like CUSUM it assumes independent samples, so whiten or widen the limits for autocorrelated streams.

## Page-Hinkley test

The slack delta sets how much drift is tolerated for free, so tune it to the noise level: too small floods false alarms, too large misses slow faults. Run separate tests for upward and downward changes. Page-Hinkley detects a change but does not size it, so follow an alarm with a window comparison to characterize what changed.

## SPRT (Wald's sequential test)

The bounds depend on the error rates you choose and on both hypothesized means, so the test is only as good as mu1, the faulty mean you specify; a fault smaller than mu1 takes longer to catch. It assumes independent samples from a known distribution. With a poor variance estimate the decision can be badly miscalibrated, so validate on labeled healthy and faulty runs.

## Generalized likelihood ratio test (GLRT)

Scanning every change point is the cost, and a maximized statistic needs a higher threshold than a fixed chi-square would suggest, so calibrate by simulation or a corrected critical value rather than the naive chi-square quantile. It assumes a known noise model and variance; estimate the variance from healthy data. Near the ends of the window the estimates are noisy, so trim the search range.

## Mean shifts: t-test and ANOVA

Use Welch, not the equal-variance t-test, unless you have checked the variances match. Both the t-test and ANOVA assume approximate normality and independent samples, and they test only the mean, so a significant result tells you the mean moved and nothing about spread or shape. With many comparisons, correct for multiple testing.

## Distribution change: KS and Anderson-Darling

KS and Anderson-Darling are powerful and assumption-light, but a significant result only says the distributions differ, not how, so follow up with mean and variance tests to characterize the change. They need a decent sample in each window, and like the others assume independent samples; serial correlation inflates significance.

## Independence: chi-square

Each expected cell count should be at least about five, or the chi-square approximation breaks down and you should use Fisher's exact test instead. The test detects association, not its direction or strength, so inspect the residuals to see which cells drive it, and remember a significant association is not causation.

## Variance homogeneity: Levene and Bartlett

Prefer Levene over Bartlett unless you are confident the data are normal, since Bartlett is sensitive to non-normality and will flag it as unequal variance. A variance change and a mean change are different faults, so run a variance test alongside a mean test rather than instead of it.
