# At a glance

| Method | Mode | Best for | Output | Key assumption |
| --- | --- | --- | --- | --- |
| CUSUM | online | small persistent step | alarm + direction | i.i.d., known healthy mean/sd |
| EWMA | online | slow drift | alarm | i.i.d., known healthy mean/sd |
| Page-Hinkley | online | abrupt jump | alarm | roughly stationary baseline |
| SPRT | online | fewest-sample decision | healthy / faulty | known mu0, mu1, sd |
| GLRT | batch / online | unknown size & time | statistic + change point | known noise model |
| t-test / ANOVA | batch | mean shift | statistic + p | approx normal |
| KS / Anderson-Darling | batch | distribution change | statistic + p | distribution-free |
| Levene / Bartlett | batch | variance change | statistic + p | Levene robust, Bartlett normal |
| chi-square | batch | categorical association | statistic + p | expected counts >= 5 |

## Which test for which change
| What changed | Mean test | Variance test | Distribution test |
| --- | --- | --- | --- |
| Mean only | fires | silent | fires |
| Variance only | silent | fires | fires |
| Shape / tails only | silent | maybe | fires |
| Mean and variance | fires | fires | fires |
