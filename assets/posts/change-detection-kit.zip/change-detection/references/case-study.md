# Worked case study: an incipient bearing fault

A bearing wears and its vibration RMS shifts up by less than one standard
deviation at sample 250 of a 420-sample record. All numbers are
produced by the engine.

## Step 1 - catch it online
With limits fixed from a healthy reference, the sequential detectors fire within
a few samples: CUSUM delay 7, EWMA delay 5,
Page-Hinkley delay 7. No single reading is out of range; they
accumulate the small consistent bias.

## Step 2 - date the change
The GLRT scans every candidate change point and peaks at sample 239,
close to the true onset at 250, without knowing the shift size in advance.

## Step 3 - say what kind of change
Comparing before and after windows: Welch t-test p = 4e-21 (mean moved),
Kolmogorov-Smirnov p = 2e-14 (distribution moved), Levene
p = 0.95 (variance unchanged). The signature is a clean mean shift.

## Step 4 - decide with minimum data
Framed as healthy vs faulty, the SPRT reaches "accept H1 (faulty)" after only
6 samples.

## Verdict
Detect online, date with the GLRT, characterize with the window battery, decide
with the SPRT. Online finds when; batch says what.
