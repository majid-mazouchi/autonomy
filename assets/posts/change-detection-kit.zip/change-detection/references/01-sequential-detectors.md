# Sequential detectors, decide as data arrives

_These run online, one sample at a time, and raise an alarm the moment evidence crosses a bound. They are what watches a live signal between scheduled checks._

## CUSUM

**Essence.** Accumulates standardized deviations from a healthy target, so a small persistent step compounds into an alarm. The most sensitive of the classic charts to step changes.

**In plain words.** A Shewhart limit looks at each sample alone and ignores a shift too small to break it on any single reading. The cumulative sum chart instead adds up how far each sample sits from the healthy mean, after subtracting a small allowance k that absorbs ordinary noise. As long as the process is healthy the sum hovers near zero, reset whenever it would go negative; once a real shift begins, every sample pushes the same way and the running sum climbs steadily until it crosses the decision interval h. Two sums run in parallel, one for upward shifts and one for downward, so either direction trips the alarm.

**Diagnostic example.** A converter cooling fan partially seizes and the inlet temperature rises by a fraction of its normal scatter. No single reading looks alarming, but the upward CUSUM accumulates the consistent bias and crosses its limit within a handful of samples, long before a fixed threshold would.

**Engine call.** `cusum(x, target, sd, k=0.5, h=6.0)`

```python
import numpy as np

def cusum(x, target, sd, k=0.5, h=6.0):
    z = (np.asarray(x) - target) / sd
    sh = sl = 0.0
    for i, v in enumerate(z):
        sh = max(0.0, sh + v - k)     # upward
        sl = max(0.0, sl - v - k)     # downward
        if sh > h or sl > h:
            return i                  # alarm index
    return -1

# target and sd come from a healthy reference, never from the live stream
alarm = cusum(stream, target=mu0, sd=sd0, k=0.5, h=6.0)
```

**Practical note.** Estimate the target and standard deviation from a verified healthy reference, never from the stream you are watching, or a developing fault inflates the baseline and hides itself. Choose k as half the shift you most want to catch quickly, and set h from the in-control average run length you can tolerate. Reset and re-estimate after a confirmed repair. CUSUM assumes roughly independent, stationary samples; autocorrelation makes it alarm early.

**Reference.** Page (1954), Biometrika 41; Hawkins & Olwell (1998), Cumulative Sum Charts and Charting for Quality Improvement.

## EWMA

**Essence.** An exponentially weighted moving average weights recent samples most, so a gradual drift compounds across the limit. The most sensitive of the charts to slow drifts.

**In plain words.** The EWMA replaces the raw signal with a running average that forgets the past geometrically: each new value gets weight lambda, the previous estimate keeps the rest. Small lambda means a long memory that smooths hard and reacts to slow drift; large lambda tracks recent values and behaves more like a raw chart. Because the smoothed value has a known steady-state variance, the control limits sit a few of those standard deviations from the target. A slow drift that never trips a per-sample limit gradually pulls the EWMA across its band.

**Diagnostic example.** A battery cell's internal resistance creeps up over weeks, nudging its temperature a little higher each cycle. The EWMA of cell temperature bends slowly upward and crosses its limit while a step-tuned CUSUM, waiting for a sharp move, is slower to react.

**Engine call.** `ewma(x, target, sd, lam=0.15, L=3.0)`

```python
import numpy as np

def ewma(x, target, sd, lam=0.15, L=3.0):
    width = L * sd * np.sqrt(lam / (2 - lam))
    ucl, lcl = target + width, target - width
    z = target
    for i, v in enumerate(np.asarray(x)):
        z = lam * v + (1 - lam) * z
        if z > ucl or z < lcl:
            return i
    return -1

alarm = ewma(stream, target=mu0, sd=sd0, lam=0.15, L=3.0)
```

**Practical note.** Pick lambda for the speed of fault you fear: small (0.05 to 0.2) for slow drifts, larger for abrupt ones; lambda near one reduces to a Shewhart chart. Set limits from a healthy reference, and prefer the time-varying limits for the first few samples. Like CUSUM it assumes independent samples, so whiten or widen the limits for autocorrelated streams.

**Reference.** Roberts (1959), Technometrics 1; Lucas & Saccucci (1990), Technometrics 32.

## Page-Hinkley test

**Essence.** Tracks the cumulative gap between each sample and the running mean, minus a slack, and alarms when it departs from its own running minimum. A popular abrupt-change detector in condition monitoring.

**In plain words.** The Page-Hinkley test keeps a cumulative sum of how far each sample exceeds the running mean, after subtracting a small tolerance delta that sets how much drift is allowed for free. It also remembers the lowest that cumulative sum has ever been. The alarm is the gap between the current sum and that running minimum: while the process is healthy the sum wanders and the gap stays small, but a genuine upward change makes the sum pull steadily away from its minimum until the gap exceeds a threshold. It is a close relative of CUSUM, framed for streaming data and widely used in condition monitoring.

**Diagnostic example.** A bearing begins to spall and the vibration RMS jumps to a new level. The Page-Hinkley statistic, flat through the healthy run, climbs sharply once the jump arrives and crosses its threshold, flagging the abrupt change with a short delay.

**Engine call.** `page_hinkley(x, delta=0.3, threshold=10.0)`

```python
import numpy as np

def page_hinkley(x, delta=0.3, threshold=10.0):
    run = cum = ext = 0.0
    for i, v in enumerate(np.asarray(x)):
        run += (v - run) / (i + 1)         # running mean
        cum += (v - run) - delta
        ext = min(ext, cum)
        if cum - ext > threshold:
            return i
    return -1

alarm = page_hinkley(stream, delta=0.3, threshold=10.0)
```

**Practical note.** The slack delta sets how much drift is tolerated for free, so tune it to the noise level: too small floods false alarms, too large misses slow faults. Run separate tests for upward and downward changes. Page-Hinkley detects a change but does not size it, so follow an alarm with a window comparison to characterize what changed.

**Reference.** Hinkley (1971), Biometrika 58; Page (1954), Biometrika 41; Gama et al. (2014), ACM Computing Surveys 46 (concept drift).

## SPRT (Wald's sequential test)

**Essence.** Decides between a healthy and a faulty hypothesis with the fewest samples possible, by walking a log-likelihood ratio between two bounds set by the target error rates.

**In plain words.** Where a fixed-sample test collects a set number of points and then decides, the sequential probability ratio test decides after every sample whether it has enough evidence yet. It accumulates the log of the likelihood ratio between two hypotheses, healthy with mean mu0 and faulty with mean mu1, and compares the running total to two bounds derived from the false-alarm and missed-detection rates you will accept. Cross the upper bound and you declare faulty, cross the lower and you declare healthy, otherwise take another sample. On average it reaches a confident decision with far fewer samples than a fixed test.

**Diagnostic example.** An end-of-line rig must pass or fail a unit on a torque measurement without wasting cycles. The SPRT accumulates evidence and, for a clearly faulty unit, crosses the faulty bound in a handful of samples; a borderline unit simply draws a few more before deciding.

**Engine call.** `sprt(x, mu0, mu1, sd, alpha=0.05, beta=0.05)`

```python
import numpy as np

def sprt(x, mu0, mu1, sd, alpha=0.05, beta=0.05):
    A = np.log((1 - beta) / alpha)        # upper bound -> H1
    B = np.log(beta / (1 - alpha))        # lower bound -> H0
    llr = 0.0
    for i, v in enumerate(np.asarray(x)):
        llr += ((mu1 - mu0) / sd**2) * (v - (mu0 + mu1) / 2)
        if llr >= A:
            return "faulty", i
        if llr <= B:
            return "healthy", i
    return "continue", -1
```

**Practical note.** The bounds depend on the error rates you choose and on both hypothesized means, so the test is only as good as mu1, the faulty mean you specify; a fault smaller than mu1 takes longer to catch. It assumes independent samples from a known distribution. With a poor variance estimate the decision can be badly miscalibrated, so validate on labeled healthy and faulty runs.

**Reference.** Wald (1945), Ann. Math. Statist. 16; Wald & Wolfowitz (1948), Ann. Math. Statist. 19.
