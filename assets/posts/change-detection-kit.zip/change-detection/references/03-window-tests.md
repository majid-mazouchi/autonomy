# Comparing two windows: classical hypothesis tests

_Offline, the question is whether a window of recent data differs from a healthy baseline, and in what way. A mean shift, a variance change, a shape change, and a categorical association are different faults that need different tests._

## Mean shifts: t-test and ANOVA

**Essence.** The t-test asks whether two windows have different means; one-way ANOVA and its F-statistic generalize that to several groups or operating modes at once.

**In plain words.** The two-sample t-test compares the means of a before and an after window relative to their scatter, answering whether the difference is larger than noise would explain. Use the Welch version, which does not assume the two windows share a variance. When you have more than two groups, say several operating modes or several units, one-way ANOVA tests in a single shot whether any group mean differs, using an F-statistic that compares variation between groups to variation within them. Both assume roughly normal data and are tests of the mean only, blind to a change that leaves the mean fixed.

**Diagnostic example.** A pump's discharge pressure is logged before and after a maintenance action. A Welch t-test confirms the mean shifted; across a fleet of pumps in three duty cycles, ANOVA flags that at least one duty cycle now runs at a different mean pressure.

**Engine call.** `compare_windows(before, after)['t_mean']; anova(*groups)`

```python
from scipy import stats

# two windows: did the mean move?
t, p = stats.ttest_ind(before, after, equal_var=False)   # Welch

# several groups (operating modes): does any mean differ?
F, p_anova = stats.f_oneway(mode_a, mode_b, mode_c)
```

**Practical note.** Use Welch, not the equal-variance t-test, unless you have checked the variances match. Both the t-test and ANOVA assume approximate normality and independent samples, and they test only the mean, so a significant result tells you the mean moved and nothing about spread or shape. With many comparisons, correct for multiple testing.

**Reference.** Welch (1947), Biometrika 34; Fisher (1925), Statistical Methods for Research Workers.

## Distribution change: KS and Anderson-Darling

**Essence.** These compare whole distributions, not just the mean, so they catch a change in shape or spread that a mean test misses entirely.

**In plain words.** The two-sample Kolmogorov-Smirnov test measures the largest vertical gap between the empirical cumulative distributions of two windows; a large gap means the distributions differ somewhere, in location, spread, or shape. The Anderson-Darling test answers the same question but weights the tails more heavily, so it is more sensitive to changes in the extremes, which often carry the earliest fault signature. Both are distribution-free and need no assumption of normality, which makes them the right reach when you do not know how a fault will reshape the signal.

**Diagnostic example.** A signal's mean and variance look unchanged, but a developing fault has made its distribution heavy-tailed, with occasional large excursions. A t-test sees nothing; the KS and especially the tail-weighted Anderson-Darling test flag that the distribution has changed.

**Engine call.** `compare_windows(before, after)['ks_dist'] and ['ad_dist']`

```python
from scipy import stats

ks = stats.ks_2samp(before, after)            # largest CDF gap
ad = stats.anderson_ksamp([before, after])    # tail-weighted

print(ks.statistic, ks.pvalue)
print(ad.statistic, ad.pvalue)
```

**Practical note.** KS and Anderson-Darling are powerful and assumption-light, but a significant result only says the distributions differ, not how, so follow up with mean and variance tests to characterize the change. They need a decent sample in each window, and like the others assume independent samples; serial correlation inflates significance.

**Reference.** Massey (1951), JASA 46; Scholz & Stephens (1987), JASA 82 (k-sample Anderson-Darling).

## Independence: chi-square

**Essence.** Tests whether two categorical variables are associated, for example whether a fault state depends on the operating mode, by comparing observed counts to what independence would predict.

**In plain words.** When both variables are categorical, a fault code and an operating mode, a part supplier and a failure outcome, the chi-square test of independence builds a contingency table of counts and compares it to the table you would expect if the two were unrelated. A large chi-square statistic, relative to its degrees of freedom, means the pattern of counts is unlikely under independence, so the variables are associated. It is the categorical counterpart to correlation, and the standard first check for whether a fault clusters in a particular regime or batch.

**Diagnostic example.** A fleet logs fault severity against the operating mode each unit spent most time in. The chi-square test shows severity is far from independent of mode, with major faults concentrated in one duty cycle, pointing maintenance at that regime.

**Engine call.** `chi2_independence(table)`

```python
from scipy import stats
import numpy as np

# rows = operating mode, cols = fault severity
table = np.array([[42, 9, 4],
                  [15, 31, 8],
                  [6, 12, 35]])
chi2, p, dof, expected = stats.chi2_contingency(table)
```

**Practical note.** Each expected cell count should be at least about five, or the chi-square approximation breaks down and you should use Fisher's exact test instead. The test detects association, not its direction or strength, so inspect the residuals to see which cells drive it, and remember a significant association is not causation.

**Reference.** Pearson (1900), Phil. Mag. 50; Agresti (2013), Categorical Data Analysis.

## Variance homogeneity: Levene and Bartlett

**Essence.** These test whether windows share the same variance. A change in spread with no change in mean is a real fault that mean tests are blind to.

**In plain words.** A loosening mount or a failing controller often shows up first as increased variability, not a shifted average. Levene's test checks for unequal variance by running an analysis of variance on the absolute deviations from each group's center, which makes it robust to non-normal data. Bartlett's test answers the same question and is more powerful when the data really are normal, but is sensitive to departures from it. The plain F-test of the variance ratio is the two-group special case. Run one of these alongside a mean test, because a pure variance change leaves the mean untouched.

**Diagnostic example.** An actuator's position error keeps the same average but starts swinging more widely as a bushing wears. The mean is unchanged so a t-test stays silent, while Levene's test on the before and after windows registers the increased variance.

**Engine call.** `compare_windows(before, after)['levene_var'] / ['bartlett_var'] / ['f_var']`

```python
from scipy import stats

lev = stats.levene(before, after)       # robust to non-normality
bart = stats.bartlett(before, after)    # more powerful if normal

# the two-group F-test of the variance ratio
import numpy as np
F = np.var(before, ddof=1) / np.var(after, ddof=1)
```

**Practical note.** Prefer Levene over Bartlett unless you are confident the data are normal, since Bartlett is sensitive to non-normality and will flag it as unequal variance. A variance change and a mean change are different faults, so run a variance test alongside a mean test rather than instead of it.

**Reference.** Levene (1960), in Contributions to Probability and Statistics; Bartlett (1937), Proc. R. Soc. A 160.
