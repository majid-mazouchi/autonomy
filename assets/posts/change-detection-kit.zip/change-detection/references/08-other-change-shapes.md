# Beyond a mean step

_Real faults also change the variance, arrive in autocorrelated streams that break the independence assumption, or hide in the frequency content._

## A CUSUM for variance
A loosening mount or failing controller raises variability while the mean holds. A CUSUM on the standardized squared deviation (known in-control expectation) accumulates a genuine increase in spread. Run it alongside the mean CUSUM.

**Engine call.** `cusum_variance(x, target, sd, k=1.0, h=8.0)`.

**Practical note.** The squared deviation is right-skewed, so this needs a higher limit than the mean CUSUM for the same in-control run length; calibrate on healthy data. The same idea extends to an event rate with a Poisson CUSUM.

## Autocorrelation breaks the limit
CUSUM, EWMA, and the hypothesis tests assume independent samples. Autocorrelated streams make a naive chart cross its limit with no change present. Fit a simple autoregression and monitor the residual, which is close to independent, restoring valid limits.

**Engine call.** `ar1_residuals(x)` returns the residual series and the AR(1) coefficient; feed the residual to `cusum`.

**Practical note.** Check the residual's autocorrelation after fitting; add autoregressive order if structure remains. When a stream is fast enough to be autocorrelated, whiten it or judge alarms by run length, not single crossings.

## Spectral change
A bearing defect or resonance appears as a new tone, a change in frequency content, while amplitude and variance barely move. Compute a feature, the power in a diagnostic band on a sliding window, and run a detector on that feature stream.

**Engine call.** `band_power_stream(x, fs, band, win=128, step=16)`; feed the output to any sequential detector.

**Practical note.** Choose the band from the physics (for example a bearing's characteristic defect frequency) and the window long enough to resolve it but short enough to react. Order-track against shaft speed for rotating machinery.

**Reference.** Hawkins & Olwell (1998), Cumulative Sum Charts; Montgomery & Mastrangelo (1991), J. Quality Technology 23; Randall & Antoni (2011), Mech. Syst. Signal Process. 25.