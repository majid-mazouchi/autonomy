# Model-based detection

_When you can write down the likelihood of the data under healthy and faulty models, the likelihood ratio is the most powerful test. The challenge is that the fault parameters are usually unknown._

## Generalized likelihood ratio test (GLRT)

**Essence.** The standard model-based test when the fault size and time are unknown. It maximizes the likelihood ratio over every candidate fault parameter, including the change point.

**In plain words.** A plain likelihood ratio test needs both hypotheses fully specified, but in practice you rarely know the size of a fault or when it started. The generalized likelihood ratio test handles this by plugging in the maximum-likelihood estimate of the unknown parameters under each hypothesis. For a single change in mean at an unknown time, that means scanning every possible change point, fitting the best before-and-after means at each, and keeping the location that maximizes the ratio. The peak value is the test statistic, compared against a threshold from a chi-square approximation or a simulation, and the location of the peak estimates when the change occurred.

**Diagnostic example.** A temperature log shows degraded cooling but nobody knows when it began or by how much. The GLRT sweeps every candidate change point, and its statistic peaks sharply at the sample where the regime shifted, both detecting the fault and dating it.

**Engine call.** `glr_mean_shift(x, sd)`

```python
import numpy as np

def glr_mean_shift(x, sd):
    x = np.asarray(x); n = len(x); cs = np.cumsum(x)
    G = np.zeros(n)
    for k in range(1, n):                 # change after index k-1
        n1, n2 = k, n - k
        m1 = cs[k-1] / n1
        m2 = (cs[-1] - cs[k-1]) / n2
        G[k] = (n1 * n2 / n) * (m1 - m2)**2 / sd**2
    return G, int(G.argmax())             # statistic profile, change point

glr, change_point = glr_mean_shift(segment, sd=sd0)
```

**Practical note.** Scanning every change point is the cost, and a maximized statistic needs a higher threshold than a fixed chi-square would suggest, so calibrate by simulation or a corrected critical value rather than the naive chi-square quantile. It assumes a known noise model and variance; estimate the variance from healthy data. Near the ends of the window the estimates are noisy, so trim the search range.

**Reference.** Willsky & Jones (1976), IEEE Trans. Automat. Control 21; Basseville & Nikiforov (1993), Detection of Abrupt Changes.
