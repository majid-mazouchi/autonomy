# References

- Page (1954), Biometrika 41; Hawkins & Olwell (1998), Cumulative Sum Charts and Charting for Quality Improvement.
- Roberts (1959), Technometrics 1; Lucas & Saccucci (1990), Technometrics 32.
- Hinkley (1971), Biometrika 58; Page (1954), Biometrika 41; Gama et al. (2014), ACM Computing Surveys 46 (concept drift).
- Wald (1945), Ann. Math. Statist. 16; Wald & Wolfowitz (1948), Ann. Math. Statist. 19.
- Willsky & Jones (1976), IEEE Trans. Automat. Control 21; Basseville & Nikiforov (1993), Detection of Abrupt Changes.
- Welch (1947), Biometrika 34; Fisher (1925), Statistical Methods for Research Workers.
- Massey (1951), JASA 46; Scholz & Stephens (1987), JASA 82 (k-sample Anderson-Darling).
- Pearson (1900), Phil. Mag. 50; Agresti (2013), Categorical Data Analysis.
- Levene (1960), in Contributions to Probability and Statistics; Bartlett (1937), Proc. R. Soc. A 160.