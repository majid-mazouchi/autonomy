# Run-length design and evaluation

_Tuning is choosing where to sit on the trade-off between false-alarm frequency and detection delay, and comparison must be done as curves, not single numbers._

## Average run length (ARL) and tuning
The right figure of merit is the average run length: mean samples to an alarm. In control it is the time between false alarms (want long); after a change it is the detection delay (want short). The allowance and limit set both at once, and there is no setting that improves both. Design to a target in-control run length, then accept the delay.

**Engine call.** `simulate_arl(detector, shift=0.0, reps=300, n=2000, seed=0, **kw)` (shift 0 gives in-control ARL; a shift gives detection delay).

## The delay-versus-false-alarm operating curve
Sweep a detector's threshold and, on labeled runs, measure the false-alarm rate and the mean detection delay at each setting. Plotting one against the other traces an operating curve, the analogue of an ROC. The detector whose curve is lower and to the left wins; where they cross, the costlier error decides.

**Engine call.** `delay_far_curve(detector, shift=1.0, thresholds=None, reps=200, n=600, cp=300, seed=1)` returns `far`, `delay`, `thresholds`.

**Practical note.** Fix the in-control run length first from how many false alarms the operation can absorb, then read off the delay for the smallest fault you care about. Estimate by simulation on healthy data, not a formula, since autocorrelation always shortens the true in-control run length. Evaluate on held-out runs and report delay at a fixed false-alarm rate, never a best case.

**Reference.** Page (1954), Biometrika 41; Basseville & Nikiforov (1993), Detection of Abrupt Changes; Lavin & Ahmad (2015), IEEE ICMLA (NAB).