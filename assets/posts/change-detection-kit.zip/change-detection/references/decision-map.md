# Decision map

Start from the question you have, not the method you know.

| If you are asking | Reach for |
| --- | --- |
| Is a small persistent step starting in a live signal? | CUSUM |
| Is a slow drift building in a live signal? | EWMA |
| Did an abrupt change just happen in a stream? | Page-Hinkley |
| Decide healthy vs faulty in the fewest samples? | SPRT |
| When did it change, and by how much (unknown)? | GLRT |
| Did the mean of a window move? | t-test / ANOVA |
| Did the whole distribution change? | KS / Anderson-Darling |
| Did the variability change but not the mean? | Levene / Bartlett |
| Is a fault state associated with an operating mode? | chi-square |

## Escalation order

1. Fix the healthy baseline (in-control mean and sd) from a verified healthy reference.
2. Watch online: `cusum` for steps, `ewma` for drifts, `page_hinkley` for abrupt jumps.
3. For a minimal-sample healthy-vs-faulty call, `sprt` against a specified faulty model.
4. When size and time are unknown, `glr_mean_shift` to detect and date the change.
5. Characterize with `compare_windows`: a mean test, a variance test, and a distribution test together.
6. At fleet scale, correct for multiple testing and judge alarms by run length.
