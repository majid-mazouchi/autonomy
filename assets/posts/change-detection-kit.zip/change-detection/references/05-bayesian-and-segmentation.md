# Bayesian and multiple-change detection

_Relax the single-change, hard-answer framing of the GLRT: keep a posterior over the time since the last change, or partition a whole record into many segments at once._

## Bayesian online change-point detection (BOCPD)
Maintains, at every step, a posterior over the run length (samples since the last change), updated in closed form under a conjugate Gaussian model. The mass collapses onto a short run length when a change arrives. The output is a calibrated belief about stability, valuable when a false alarm is costly.

**Engine call.** `bocpd(x, hazard=200, mu0=0.0, kappa0=1.0, alpha0=1.0, beta0=1.0)` returns `R` (run-length posterior) and `run_length` (MAP).

**Practical note.** The hazard encodes how often changes are expected; too low is sluggish, too high is jumpy. The Gaussian model assumes piecewise-constant Gaussian segments; heavy tails or trends need a richer model. It is online and recursive but its cost grows with run-length support unless pruned.

## Multiple change points with PELT
Finds the whole set of change points at once by minimizing a global penalized cost with exact dynamic programming, made linear by pruning. With a Gaussian segment cost it responds to a change in mean or variance and returns the full partition.

**Engine call.** `pelt(x, penalty=None, min_size=6)` returns a list of change-point indices.

**Practical note.** The penalty governs how many change points you get; a BIC-like default is sensible but validate it. PELT is offline, for a complete record, not live monitoring. Set a minimum segment length and match the cost to the expected change.

**Reference.** Adams & MacKay (2007), arXiv:0710.3742; Killick, Fearnhead & Eckley (2012), JASA 107; Truong, Oudre & Vayatis (2020), Signal Processing 167.