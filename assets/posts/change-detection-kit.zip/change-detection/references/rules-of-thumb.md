# Rules of thumb

1. Match the detector to the fault shape. CUSUM for steps, EWMA for drifts, Page-Hinkley for abrupt jumps; tune each to the smallest change worth catching.
2. Set limits from healthy data, never from the stream you are watching. A baseline estimated from data that already contains the fault will hide it.
3. Online finds when, batch says what. A sequential detector flags the change; a two-window test then characterizes it as a mean, variance, or shape change.
4. Pick the test for the change you fear. A mean test is blind to a pure variance or shape change, so run a variance and a distribution test alongside it.
5. Judge alarms by run length, not single samples. Report both the in-control average run length and the detection delay when you set a threshold.
6. Mind independence. CUSUM, EWMA, SPRT and the hypothesis tests all assume independent samples; autocorrelation makes every one of them over-alarm.
7. Specify the faulty hypothesis honestly. SPRT and the likelihood-ratio tests are only as good as the faulty model you give them; too optimistic a mu1 slows real detection.
8. Correct for multiple testing at fleet scale. Screening thousands of windows makes some cross any fixed threshold by chance; control the false-discovery rate.

## Pick by scenario

| Scenario | Pick | Why |
| --- | --- | --- |
| Small persistent step in a live signal | CUSUM | accumulates the consistent bias |
| Slow drift over many cycles | EWMA | long memory compounds the drift |
| Abrupt jump in a monitored stream | Page-Hinkley | departure from the running minimum |
| Pass/fail decision with fewest samples | SPRT | stops as soon as evidence suffices |
| Change of unknown size and time | GLRT | scans every change point |
| Did the mean of a window move | Welch t-test | two-sample mean comparison |
| Several modes, any mean differ | ANOVA | between vs within variation |
| Shape or tail changed, mean did not | KS / Anderson-Darling | compares whole distributions |
| Variability changed, mean did not | Levene / Bartlett | tests equality of variance |
| Fault state tied to operating mode | chi-square | association in a contingency table |
