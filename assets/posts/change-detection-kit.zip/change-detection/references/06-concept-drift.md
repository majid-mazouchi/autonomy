# Concept-drift detectors

_When the monitored object is a data-driven model rather than a sensor, the change of interest is in the model's error stream. These are the streaming-ML relatives of Page-Hinkley._

## DDM (Drift Detection Method)
Watches a model's running error rate and raises a warning, then a drift, when the rate climbs significantly above its best-ever level.

**Engine call.** `ddm(errors, warm=30)` on a 0/1 error stream (1 = wrong); returns `warning` and `drift` indices.

## ADWIN (Adaptive Windowing)
Keeps an adaptive window and drops its older part whenever two sub-windows differ by more than a Hoeffding bound; the window length itself signals drift.

**Engine call.** `adwin(x, delta=0.002)` on the raw value stream; returns `drifts`.

## KSWIN (Kolmogorov-Smirnov Windowing)
Slides a window and compares recent samples to older ones with a KS test, catching distributional drift a mean-based rate would miss.

**Engine call.** `kswin(x, window=120, stat_size=30, alpha=0.005)` returns `drifts`.

**Practical note.** These run on a model's error or residual stream, so they need ground truth or a proxy. DDM assumes the error rate only improves with learning and can false-alarm on noisy stationary streams, so confirm its warning. Tune window and confidence to trade delay against false alarms. The usual response to a drift is to retrain or adapt.

**Reference.** Gama et al. (2004), SBIA; Bifet & Gavalda (2007), SDM; Raab, Heusinger & Schleif (2020), Neurocomputing 416.