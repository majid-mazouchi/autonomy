---
mode: agent
description: 'After an alarm, characterize the change: what kind, when, how big, and across which sensors, using the verified engine.'
tools: ['codebase', 'search', 'runCommands']
---

# /characterize

A detector has alarmed. Turn the alarm into a description of the change rather
than a yes or no.

Inputs the user may give: the signal (one channel or several), the alarm index or
suspected change region, and a healthy reference. If any is missing, ask once,
then proceed with a stated assumption.

Steps:
1. Date the change. Run `glr_mean_shift` for a single change, or `pelt` for
   several, to locate the change point(s) precisely.
2. Classify the shape. Run the two-window battery from
   `references/03-window-tests.md` across the change point: a mean test, a variance
   test, and a distribution test together, so a pure variance or shape change is
   not missed. If a mean step is absent but variance moved, use
   `cusum_variance`; if the content moved without amplitude, build a feature with
   `band_power_stream` and re-test.
3. Size it. Report the estimated shift in engineering units and in sigma.
4. Localize it. For several sensors, use `mewma` or `mcusum` and decompose the
   statistic to the per-sensor contributions naming the channels involved.
5. Check the assumption. Confirm independence (see `references/08-other-change-shapes.md`
   on autocorrelation) and cross-check `references/pitfalls.md` before reporting.

Output: change point(s), the kind of change, its size, the sensors involved, and
the one assumption that would change the conclusion.

The task to solve: ${input:question:Describe the alarmed signal and what you need characterized}
