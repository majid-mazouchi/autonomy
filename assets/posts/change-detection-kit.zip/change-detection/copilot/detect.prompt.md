---
mode: agent
description: 'Set up change or fault detection for a signal-over-time question, using the verified engine.'
tools: ['codebase', 'search', 'runCommands']
---

# /detect

Pick and apply the right change-detection test, then return runnable code from
the project engine.

Inputs the user may give: the signal or two windows, a healthy reference, whether
detection must be online or can be batch, and what is suspected (step, drift,
jump, variance change, distribution change). If any is missing, ask once, then
proceed with a stated assumption.

Steps:
1. Restate the question and the framing (online vs two-window) in one line.
2. Open `references/decision-map.md` and name the recommended test(s).
3. Open the relevant group reference for interpretation and caveats.
4. Produce the exact call into `scripts/change_detection.py`, wired to the user's
   variables, with the healthy baseline estimated from a clean reference.
5. State the result against its limit or p-value and the single assumption that
   would flip the conclusion. Cross-check `references/pitfalls.md`.

The task to solve: ${input:question:Describe the signal or windows and what change you suspect}
