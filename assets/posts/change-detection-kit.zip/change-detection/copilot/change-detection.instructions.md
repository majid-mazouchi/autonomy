---
applyTo: '**/*.py'
---

# Change-detection conventions

When writing code that detects change over time for diagnostics, follow these.

Use the project engine. Call `cusum`, `ewma`, `page_hinkley`, `sprt`,
`glr_mean_shift`, and `compare_windows` in `scripts/change_detection.py` instead
of re-implementing them.

Fix the baseline from healthy data. Estimate the in-control mean and standard
deviation from a verified healthy reference, never from the stream being watched.

Match the detector to the fault. CUSUM for steps, EWMA for drifts, Page-Hinkley
for abrupt jumps, SPRT for a minimal-sample decision, GLRT for unknown size/time.

Characterize after detecting. Follow an online alarm with `compare_windows` and
read the mean, variance, and distribution tests together; a mean test alone is
blind to a variance or shape change.

Label assumptions in the code. Note independence, the baseline window, and any
normality assumption next to the call, and judge alarms by run length.
