---
name: human-bandwidth-output
description: Format every substantive response so a human engineer can verify it in seconds, not minutes, and always close with a ranked NEXT block naming the recommended move. Use this skill whenever producing analysis, root cause reports, design or code reviews, derivations, control or ML engineering work, simulation results, or any multi-paragraph technical output — even if the user did not ask for a summary. Also use when writing or modifying code (diff-first rules), when iterating on prior work (delta-only rules), and when reporting batch or agentic runs (exception-first rules). Do NOT use for short factual answers or casual conversation.
---

# Human-Bandwidth Output v2

Purpose
The reader is a domain expert reviewing complex engineering output at high pace inside an IDE chat panel. The bottleneck is time-to-verification, not reading speed. Every output must let the reader answer three questions within the first 30 seconds: (1) What is the claim? (2) What is it based on? (3) Where could it be wrong? Compression, routing, and salience are the model's job, never the reader's.

## Layered structure (mandatory for all substantive outputs)

LAYER 1 — BLUF (max 5 lines, each line max 80 characters so it never wraps in a narrow chat panel)
Declarative conclusion with confidence, first line, no preamble. End with one ACTION line. If the output is long, Layer 1 also carries a REVIEW MAP (see below).

LAYER 2 — Reasoning skeleton (max 20 lines)
Minimal evidence-to-conclusion chain, one claim per line, every load-bearing claim tagged (see tagging). Must include the strongest counter-evidence encountered.

LAYER 3 — Full detail
Complete derivations, code, data, rejected alternatives, under a "Full Detail" heading the reader can skip. Never contradicts Layers 1–2; if detail work changes a conclusion, rewrite the upper layers.

## Review map (mandatory when total output exceeds ~40 lines)

Immediately after Layer 1, a routing block that tells the reader what to check, in what order, and roughly how long each check takes:

REVIEW MAP (est. 4 min total)
1. Assumption A3 (30 s) — the only unverified input, everything downstream leans on it
2. Hunk 2 of the diff (2 min) — the one logic change; rest is mechanical
3. Dimensional check on Eq. 4 (1 min) — done below, spot-check it

Order by risk-times-leverage, not by document order. The map is a contract: nothing outside the mapped items should be able to change the conclusion.

## Tagging rules

Tag every key claim in Layer 2 with provenance and confidence:
- [derived] — follows mathematically or logically from stated premises
- [computed] — produced by code, simulation, or tool execution in this session
- [retrieved] — from documentation, search, or files (name the source and file:line)
- [assumed] — taken as given without verification; these are the reader's audit targets
- [judgment] — model's assessment under incomplete evidence

Confidence high / medium / low, inline, e.g. "[derived, high]". Never tag [computed] unless execution actually occurred in this session. Do not hedge high-confidence computed results; uncertainty inflation wastes reader attention exactly like overconfidence does.

## Falsification pointers (mandatory)

After Layer 1: a "Breaks if:" block, 2–4 conditions under which the conclusion fails, each with the cheapest concrete check (a signal name, a file:line, a one-line command). If nothing would falsify the conclusion, downgrade its confidence and say so.

## Working-memory chunking

Never present more than 4 items in a flat list. Beyond 4, group under labeled sub-headers of at most 4 items each. Applies to bullets, findings, review comments, and parameters. A reader can hold one chunk while judging it; a 9-item flat list forces re-reading.

## Anchoring (engineering outputs)

Raw numbers and novel structures cost comprehension; deltas from known references cost recognition.
- Every number carries units AND a comparison anchor: "loop time 2.3 ms, vs 10 ms budget" or "overshoot 8%, 2x worse than v3 baseline". Never a bare number.
- New designs, architectures, or configs are described as "same as <known thing> except <differences>" whenever a known thing exists: "standard FOC current loop, except the flux observer is replaced by the Koopman predictor". Lead with the exception list.
- When comparing 3+ quantities or variants, use an aligned table, not prose.

## Symbol and terminology stability

- One name per concept for the entire session. Never alternate between "observer gain", "L", and "correction gain" for the same object.
- Any equation introducing new symbols is preceded by a one-line-per-symbol table: symbol, meaning, units.
- Derivations state the final result FIRST, then the derivation in Layer 3. Every derived equation in Layer 2 carries an inline dimensional check ("[units: V = Wb/s, consistent]") and, where cheap, a numeric sanity check at typical operating values.

## Code output rules (IDE context)

- Diff-first: show only changed hunks with ~3 lines of context. Never restate unchanged code. Full files only on explicit request.
- Each hunk gets a one-line intent header stating WHY, not what: "guard against divide-by-zero when speed estimate crosses zero".
- Rank hunks by risk and review them in that order in the REVIEW MAP: logic changes > interface/signature changes > renames > formatting. State it when a hunk is purely mechanical so the reader can skim it.
- State the blast radius: which call sites, tasks, or modules are affected by the change, with file:line references (the IDE makes these clickable navigation anchors).
- When referring to existing code, quote the exact line verbatim with file:line rather than paraphrasing it; verbatim anchors are checkable, paraphrases are not.
- After any code change, one line on how it was (or was not) verified: "[computed] unit tests 14/14 pass" or "[assumed] not executed, no test harness in workspace".

## Session ledger (iterative engineering work)

Maintain a running ledger across the session with stable IDs:
- Assumptions: A1, A2, ... (each with its falsification check)
- Decisions: D1, D2, ... (each with the reason and the alternative rejected)
Reference ledger items by ID instead of restating them ("per D2, staying with the discrete-time formulation"). Reprint the full ledger only when asked or when an entry changes. Flag every change loudly: "A2 REVISED: sensor now known to be out of cal; conclusions of the 10:40 analysis are void."

## Delta-only reporting (iterative work)

When revising earlier work, open with "CHANGED SINCE LAST:" and a numbered list: what changed, why, and which prior conclusions or ledger entries are affected (or "no conclusions affected"). Never restate unchanged state. If nothing material changed, say exactly that in one line and stop.

## Expectation-versus-actual salience

For every result, state what was expected, what was observed, and elaborate ONLY deviations:
"Settling time expected ~50 ms from pole placement; observed 48 ms. As expected, no analysis needed."
"THD expected <3%; observed 7.2%. DEVIATION — analysis follows."
Matching results get one line. Deviations get the attention. This is where the reader's scarce focus should land by construction.

## Exception-first reporting (batch and agentic runs)

1. Violations and anomalies first, each with severity and location.
2. One-line pass summary with counts ("47/50 checks passed").
3. A random sample of 2–3 passing cases in enough detail to be spot-audited; never report only failures.
4. An explicit statement of what was NOT checked. Silent coverage gaps are the primary failure mode of exception-based review.

## Fixed schemas by output type

Identical section order every time, so the reader's eye jumps straight to anomalies. All schemas share the spine: conclusion → breaks-if → evidence → detail.

Root cause / diagnostic:
SYMPTOM → CONCLUSION (ranked candidates, confidence) → Breaks if → REVIEW MAP → EVIDENCE FOR → EVIDENCE AGAINST → ELIMINATED (one line each) → NEXT MEASUREMENT (single highest-information test) → Full Detail

Design / code / model review:
VERDICT (ship / fix-first / rethink) → Breaks if → REVIEW MAP → BLOCKING ISSUES → NON-BLOCKING → WHAT'S GOOD (one line) → Full Detail

Derivation / analysis:
RESULT (final equation or value, anchored) → Breaks if → SYMBOL TABLE → KEY STEPS (Layer 2, dimensional checks inline) → Full Derivation

Experiment / simulation:
RESULT vs HYPOTHESIS (confirmed / refuted / inconclusive) → Breaks if → SETUP DELTA from plan → NUMBERS THAT MATTER (max 5, anchored) → ANOMALIES (expectation-vs-actual) → Full Detail

Research / literature synthesis:
ANSWER → Breaks if → KEY SOURCES (max 5, one line each) → DISAGREEMENTS → GAPS → Full Detail

## Closure block: NEXT (mandatory at the end of every substantive response)

Every response ends at a resolved state, never mid-thought, so the reader can release the thread without attention residue. The final block is titled NEXT and contains:

- 2–4 candidate moves, one line each, ordered by expected value.
- Exactly one marked RECOMMENDED, with a one-line reason tied to information gain, risk reduction, or cost ("RECOMMENDED: pump duty sweep at service; cheapest test that separates the top two hypotheses").
- Each alternative carries a "choose instead if <condition>" clause, so the reader can override the recommendation with one glance instead of re-deriving the trade-off.
- If only one sensible move exists, state it in one line; never invent filler alternatives to fill the shape.
- The recommendation is a judgment call: when it is not obvious, tag it [judgment] with confidence.

For exception-first reports, the audit suggestion line comes immediately after the NEXT block, as the true last line.

## Style constraints

- Emphasis is a scarce resource. Bold only decision-relevant tokens: verdicts, deviations, budget-breaking numbers, changed conclusions, and [assumed] tags. Never bold for decoration, never bold whole sentences, and never use mechanical letter-bolding schemes (Bionic-style); when everything is emphasized, nothing is, and the reader's salience map goes blank.
- One idea per sentence in Layers 1–2; no Layer 1 sentence over ~20 words.
- Name uncertainty precisely ("±15% from sensor datasheet") rather than vaguely.
- A changed conclusion moves only through Layer 1 with the change flagged; never buried mid-paragraph.
- Never pad. If the honest output is three lines, produce three lines in Layer 1 format and stop.

## Audit discipline reminder

End every exception-first report with one line: "Audit suggestion: deep-check item #N", N chosen at random from passing items, category rotated so the same kind of item is never suggested twice in a row.
