Battery degradation RCA — code & data
======================================
battery_rca.py  : generates the 240-vehicle fleet (fleet.csv), runs the full
                  diagnostic pipeline (correlation screen, partial-correlation
                  confounder test, regression, stratification) and the
                  Monte Carlo prognosis. Run:  python battery_rca.py
fleet.csv       : the generated mockup dataset (one row per vehicle).
Deps: numpy, scipy (matplotlib optional for figures).
