---
name: mcp-builder
description: Guidance for designing and building high quality MCP (Model Context Protocol) servers that expose an external service or API to an agent as well designed tools. Use when the task is to create a new MCP server, wrap an API as MCP tools, or review and improve an existing server, in either Python (FastMCP) or TypeScript (MCP SDK).
---

Purpose
Build MCP servers that let an agent accomplish real tasks against an external service. The measure of a good server is not endpoint count. It is whether an agent can pick the right tool, call it correctly, and act on what comes back. This skill is a router. It carries the workflow and the design principles, and points to reference files for language detail and evaluation.

When to use
Use this when the task is to create a new MCP server, to wrap an API or service as MCP tools, or to review and harden an existing server. Use it for both local stdio servers and remote HTTP servers. Do not use it for ordinary application code that happens to call an API. An MCP server exists to be driven by an agent.

The four phases
Research and plan first. Read the target API. Identify the authentication model, the core resources, the common operations, the pagination scheme, and the rate limits. Decide which operations matter most. Skim the MCP specification and the SDK readme for the language you will use, since both move. Prefer comprehensive coverage of the common operations over a few clever shortcuts, then add workflow tools where one call should stand in for several.

Implement second. Create one shared API client with authentication, one shared error formatter, and shared helpers for pagination and output shaping. Never duplicate that logic across tools. Each tool gets a validated input model, a clear docstring that states inputs and the output shape, correct annotations, and async network calls.

Review and test third. Read for duplication, consistent error handling, and full type coverage. Verify the server starts and that every tool has a name, a description, and annotations. Exercise a few real calls and a few error cases. For Python, compile the file. For either language, drive it with the MCP Inspector.

Evaluate last. Write about ten realistic questions that need several tool calls to answer, solve them yourself to fix the expected answers, and check that an agent using only your tools can reach them. See reference/evaluation.md.

Tool design principles
Name tools with a service prefix in snake case, so the agent never confuses them with another server. For example use stripe_create_invoice, not create_invoice.
Write the description for an agent, not a human reader. State what the tool does, what each parameter means, and the exact shape of the return value.
Return focused data. Offer a response format choice when results can be large: a compact human readable form and a full machine readable form. Convert timestamps to readable text. Show display names with IDs.
Support pagination and filtering on anything that lists. Return whether more results exist and how to get them.
Make errors actionable. Tell the agent what went wrong and what to do next, not just a status code. A 401 should say which credential to check. A 429 should say to wait or add a key.
Set annotations honestly. Mark read only tools as read only. Mark anything that writes or deletes as not read only and as destructive where true. Mark external calls as open world.
Keep inputs validated by the schema, not by hand. Let the model layer reject bad input with clear messages.

Reference files
Load these as needed rather than all at once.
reference/python-fastmcp.md for the Python and FastMCP patterns: server setup, Pydantic input models, tool registration, error handling, transports, and a quality checklist.
reference/typescript-sdk.md for the TypeScript SDK patterns: project setup, Zod schemas, registerTool, structured output, and transports.
reference/evaluation.md for writing and running an evaluation that proves the server is usable.

Quality checklist
The server name follows the service convention and carries no version or date.
Every tool has a service prefixed name, a description that an agent can act on, validated inputs, and correct annotations.
A single shared client handles authentication and a single helper formats errors.
All network calls are async and all large listings paginate and filter.
The server starts cleanly and a handful of real and error calls behave as expected.
An evaluation of about ten questions confirms an agent can drive the tools to correct answers.

Guardrails
Do not invent API fields. Confirm them against the live documentation or a real response before relying on them.
Do not leak secrets. Read credentials from the environment and never log them.
Do not return raw upstream payloads when they are large. Shape them for agent context.
Prefer least privilege. Request the narrowest scope the tools need.

By Majid Mazouchi . Drafted with Claude.
