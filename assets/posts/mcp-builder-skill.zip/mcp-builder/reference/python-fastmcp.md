# Python and FastMCP reference

Plain prose with code examples. Load this when building an MCP server in Python.

Server naming
Name the server service_mcp in lower case with underscores. Keep it general and free of versions or dates. Examples: github_mcp, jira_mcp, stripe_mcp.

Setup
Use the official MCP Python SDK, which provides FastMCP. Validate inputs with Pydantic v2. Use httpx for async network calls. Read credentials from the environment.

```python
import os
import json
from typing import Optional, List
from enum import Enum

import httpx
from pydantic import BaseModel, Field, ConfigDict
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("service_mcp")
BASE = "https://api.service.com/v1"
TIMEOUT = 30.0
```

Shared infrastructure
Build the client, the error formatter, and the output helpers once. Never copy this logic into each tool.

```python
def _auth_headers() -> dict:
    token = os.environ.get("SERVICE_API_KEY")
    if not token:
        raise RuntimeError("Set SERVICE_API_KEY in the environment.")
    return {"Authorization": f"Bearer {token}", "Accept": "application/json"}

def _handle_error(e: Exception) -> str:
    if isinstance(e, httpx.HTTPStatusError):
        code = e.response.status_code
        hints = {
            401: "authentication failed. Check SERVICE_API_KEY.",
            403: "permission denied. Check the token scope.",
            404: "not found. Verify the identifier.",
            429: "rate limit exceeded. Wait and retry, or raise your quota.",
        }
        return json.dumps({"error": f"{code}: {hints.get(code, 'request failed.')}"})
    if isinstance(e, httpx.TimeoutException):
        return json.dumps({"error": "request timed out. Retry."})
    return json.dumps({"error": f"unexpected {type(e).__name__}: {e}"})
```

Input models
Define a Pydantic model per tool. Forbid extra fields, strip whitespace, and put constraints and examples in the field descriptions. Let the schema do validation.

```python
class SearchInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    query: str = Field(..., description="Search text, for example 'open invoices'.", min_length=1, max_length=200)
    limit: int = Field(default=20, description="Max results.", ge=1, le=100)
    offset: int = Field(default=0, description="Results to skip for pagination.", ge=0)
```

Response format option
Offer a compact and a full form when results can be large.

```python
class Fmt(str, Enum):
    MARKDOWN = "markdown"
    JSON = "json"
```

Tool registration
Register with the decorator. Give every tool a service prefixed name, honest annotations, and a docstring that states inputs and the exact return shape. Use async for all network calls.

```python
@mcp.tool(
    name="service_search_items",
    annotations={
        "title": "Search items",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def service_search_items(params: SearchInput) -> str:
    """Search items by text and return a ranked page.

    Returns:
        str: JSON with total, count, offset, has_more, next_offset, and items.
        Each item has: id, name, status, updated_at.
    """
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            r = await client.get(
                f"{BASE}/items",
                params={"q": params.query, "limit": params.limit, "offset": params.offset},
                headers=_auth_headers(),
            )
            r.raise_for_status()
            data = r.json()
    except Exception as e:  # normalize to an actionable payload
        return _handle_error(e)

    items = data.get("items", [])
    total = data.get("total", len(items))
    has_more = total > params.offset + len(items)
    return json.dumps({
        "total": total,
        "count": len(items),
        "offset": params.offset,
        "has_more": has_more,
        "next_offset": params.offset + len(items) if has_more else None,
        "items": items,
    }, indent=2)
```

Transports
Use stdio for a local server that VS Code launches as a subprocess. Use streamable HTTP for a remote server.

```python
if __name__ == "__main__":
    mcp.run()                       # stdio, the default
    # mcp.run(transport="streamable_http", port=8000)
```

Registering with VS Code
A local stdio server is wired in .vscode/mcp.json.

```json
{
  "servers": {
    "service": {
      "type": "stdio",
      "command": "python",
      "args": ["${workspaceFolder}/server/service_mcp.py"],
      "env": { "SERVICE_API_KEY": "${env:SERVICE_API_KEY}" }
    }
  }
}
```

Testing
Compile the file to catch syntax errors: python -m py_compile server/service_mcp.py.
Drive it interactively with the MCP Inspector: npx @modelcontextprotocol/inspector.
Exercise one real call and one error case per tool.

Quality checklist
Server name is service_mcp with no version.
Every tool is async, service prefixed, annotated, and validated by a Pydantic model.
One shared client and one shared error formatter, no duplication.
Listings paginate and filter and report has_more.
Errors are actionable and name the credential or next step.
Docstrings state the exact return shape.

By Majid Mazouchi . Drafted with Claude.
