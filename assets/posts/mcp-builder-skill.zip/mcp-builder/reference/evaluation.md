# Evaluation reference

Plain prose. Load this after a server works, to prove an agent can actually drive it.

Why evaluate
A server can pass a syntax check and still be unusable, because the tool names are unclear, the descriptions are thin, or the returns are too noisy to act on. An evaluation tests the only thing that matters: can an agent, using just these tools, answer realistic questions correctly.

How to build one
Inspect the tools first. List them and read each description as if you were the agent.
Explore with read only calls to learn what real data looks like.
Write about ten questions. Then solve each one yourself using the tools, and record the verified answer.

What makes a good question
Independent. It does not depend on the answer to another question.
Read only. Answering it never writes or deletes.
Complex. It needs several tool calls and some reasoning, not a single lookup.
Realistic. A real user of this service would ask it.
Verifiable. It has one clear answer that a string comparison can check.
Stable. The answer will not drift over time.

Output format
Store the set as XML so it can be replayed.

```xml
<evaluation>
  <qa_pair>
    <question>Among the three most cited papers returned for "Koopman operator control", which appeared first, and in what year?</question>
    <answer>2015</answer>
  </qa_pair>
  <!-- about ten pairs total -->
</evaluation>
```

How to run it
Give an agent only the server under test. For each question, let it choose and call tools, then compare its final answer to the recorded answer by string match. Track the pass rate. A low score usually points at unclear tool names, weak descriptions, or returns that bury the needed field. Fix the server, not the questions, then rerun.

What a failing pattern tells you
The agent picks the wrong tool: the names or descriptions are not distinct enough.
The agent calls the right tool but with bad arguments: the input descriptions or constraints are unclear.
The agent gets data but answers wrong: the return is too noisy or omits the key field. Shape the output.

By Majid Mazouchi . Drafted with Claude.
