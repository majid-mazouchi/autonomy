# TypeScript SDK reference

Plain prose with code examples. Load this when building an MCP server in TypeScript. The TypeScript SDK has strong typing and good tooling, which suits servers that other teams will maintain.

Setup
Use the official MCP TypeScript SDK and Zod for input schemas. Use the native fetch for network calls. Read credentials from the environment.

```bash
npm init -y
npm install @modelcontextprotocol/sdk zod
npm install -D typescript @types/node
```

Server and a tool
Create the server, then register tools with registerTool. Give each tool a service prefixed name, a Zod input schema, an output schema when the shape is known, and honest annotations. Return both text and structuredContent on modern SDK versions.

```typescript
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const BASE = "https://api.service.com/v1";

function authHeaders(): Record<string, string> {
  const token = process.env.SERVICE_API_KEY;
  if (!token) throw new Error("Set SERVICE_API_KEY in the environment.");
  return { Authorization: `Bearer ${token}`, Accept: "application/json" };
}

function handleError(e: unknown): string {
  const msg = e instanceof Error ? e.message : String(e);
  return JSON.stringify({ error: msg });
}

const server = new McpServer({ name: "service_mcp", version: "1.0.0" });

server.registerTool(
  "service_search_items",
  {
    title: "Search items",
    description: "Search items by text and return a ranked page. Returns total, count, offset, has_more, next_offset, and items with id, name, status, updated_at.",
    inputSchema: {
      query: z.string().min(1).max(200).describe("Search text, for example 'open invoices'."),
      limit: z.number().int().min(1).max(100).default(20).describe("Max results."),
      offset: z.number().int().min(0).default(0).describe("Results to skip for pagination."),
    },
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true },
  },
  async ({ query, limit, offset }) => {
    try {
      const url = new URL(`${BASE}/items`);
      url.searchParams.set("q", query);
      url.searchParams.set("limit", String(limit));
      url.searchParams.set("offset", String(offset));
      const res = await fetch(url, { headers: authHeaders() });
      if (!res.ok) {
        const hint = res.status === 401 ? "check SERVICE_API_KEY" : res.status === 429 ? "rate limited, wait and retry" : "request failed";
        return { content: [{ type: "text", text: JSON.stringify({ error: `${res.status}: ${hint}` }) }] };
      }
      const data: any = await res.json();
      const items = data.items ?? [];
      const total = data.total ?? items.length;
      const hasMore = total > offset + items.length;
      const payload = { total, count: items.length, offset, has_more: hasMore, next_offset: hasMore ? offset + items.length : null, items };
      return { content: [{ type: "text", text: JSON.stringify(payload, null, 2) }], structuredContent: payload };
    } catch (e) {
      return { content: [{ type: "text", text: handleError(e) }] };
    }
  }
);
```

Transports
Use stdio for a local server. Use streamable HTTP for a remote one.

```typescript
const transport = new StdioServerTransport();
await server.connect(transport);
```

Registering with VS Code
A local server built to dist runs through node.

```json
{
  "servers": {
    "service": {
      "type": "stdio",
      "command": "node",
      "args": ["${workspaceFolder}/dist/service_mcp.js"],
      "env": { "SERVICE_API_KEY": "${env:SERVICE_API_KEY}" }
    }
  }
}
```

Testing
Build with npm run build to catch type errors.
Drive it with the MCP Inspector: npx @modelcontextprotocol/inspector.

Quality checklist
Server name is service_mcp.
Every tool has a service prefixed name, a Zod input schema with descriptions, annotations, and a description an agent can act on.
Output schema and structuredContent are used where the shape is known.
One shared auth helper and one shared error helper.
Listings paginate and report has_more.

By Majid Mazouchi . Drafted with Claude.
