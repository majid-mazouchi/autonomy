@echo off
REM ============================================================
REM  Phase 0: differentiable battery pack thermal solver (Warp)
REM  One-shot setup + pipeline + verification (Windows)
REM
REM  Requires: Python 3.9+ on PATH. GPU optional (Warp uses CPU
REM  if no CUDA driver is found; pass --device cuda:0 manually
REM  in step 2 to use the GPU).
REM ============================================================
setlocal
cd /d "%~dp0"

echo [1/5] Creating virtual environment and installing dependencies...
if not exist .venv (
    python -m venv .venv
    if errorlevel 1 goto :fail
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip -q
pip install warp-lang numpy matplotlib -q
if errorlevel 1 goto :fail

echo [2/5] Generating ground-truth dataset (nominal + fault scenarios)...
python scripts\generate_dataset.py --preset demo --t-total 300 --n-nominal 2 --n-fault 1
if errorlevel 1 goto :fail

echo [3/5] Running differentiable inverse demo (recover faulty cell R_int)...
python scripts\demo_inverse.py
if errorlevel 1 goto :fail

echo [4/5] Rendering figures...
python scripts\make_figures.py
if errorlevel 1 goto :fail

echo [5/5] Verifying results...
python scripts\verify.py
if errorlevel 1 goto :fail

echo.
echo ============================================================
echo  SUCCESS. Dataset, figures, and checks are in the data\ folder.
echo ============================================================
pause
exit /b 0

:fail
echo.
echo ############################################################
echo  PIPELINE FAILED at the step above. See messages for details.
echo ############################################################
pause
exit /b 1
