#!/usr/bin/env bash
# Phase 0 one-shot pipeline (Linux / WSL / macOS). Mirrors run_all.bat.
set -euo pipefail
cd "$(dirname "$0")"

echo "[1/5] venv + dependencies..."
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip -q
pip install warp-lang numpy matplotlib -q

echo "[2/5] dataset generation..."
python scripts/generate_dataset.py --preset demo --t-total 300 --n-nominal 2 --n-fault 1

echo "[3/5] differentiable inverse demo..."
python scripts/demo_inverse.py

echo "[4/5] figures..."
python scripts/make_figures.py

echo "[5/5] verification..."
python scripts/verify.py

echo "SUCCESS. Outputs in data/"
