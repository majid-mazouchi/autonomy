"""Fault scenarios for ground-truth dataset generation.

Three physical fault families relevant to VHM thermal monitoring:
  hot_cell        : elevated internal resistance on one cell (aging, ISC precursor)
  blocked_channel : reduced coolant flow in a band of channels
  tim_degraded    : delaminated / degraded interface material between two cells
"""

import numpy as np


def apply_fault(sim, geo, fault: str, severity: float = 1.0, rng=None):
    rng = rng or np.random.default_rng(0)
    meta = {"fault": fault, "severity": float(severity)}

    if fault == "none":
        pass

    elif fault == "hot_cell":
        cid = int(rng.integers(0, geo.n_cells))
        r = sim.r_int.numpy()
        r[cid] *= (1.0 + 2.0 * severity)   # up to 3x nominal
        import warp as wp
        sim.r_int = wp.array(r, dtype=float, device=sim.device,
                             requires_grad=sim.diff)
        meta["cell"] = cid

    elif fault == "blocked_channel":
        ff = np.ones(geo.n_channels, dtype=np.float32)
        c0 = int(rng.integers(2, geo.n_channels - 6))
        width = 4
        ff[c0:c0 + width] = max(0.05, 1.0 - severity)
        sim.set_flow(ff)
        meta["channels"] = [c0, c0 + width]

    elif fault == "tim_degraded":
        # geometry-level: caller must rebuild sim AFTER calling geo.degrade_tim
        raise RuntimeError("apply tim_degraded via geo.degrade_tim() before Simulator()")

    else:
        raise ValueError(fault)
    return meta
