"""Differentiable 3D transient conduction solver for a liquid-cooled battery pack.

Physics per step:
  1. heat_source   : Bernardi heat generation q = (I^2 R_c + I T dU/dT) / V_cell,
                     distributed over each cell's voxels
  2. coolant_march : 1D energy balance along each channel (serial march per thread)
  3. diffuse       : explicit FTCS anisotropic conduction + convective floor sink

All state lives in Warp arrays, so wp.Tape() gives adjoints end-to-end:
d(loss)/d(r_int), d(loss)/d(initial state), etc. flow through every kernel.
"""

import numpy as np
import warp as wp

from .config import PackConfig
from .geometry import PackGeometry

wp.init()


@wp.kernel
def heat_source(cell_id: wp.array(dtype=wp.int32),
                r_int: wp.array(dtype=float),
                temp: wp.array(dtype=float),
                q: wp.array(dtype=float),
                current: float,
                dudt: float,
                inv_cell_volume: float):
    i = wp.tid()
    cid = cell_id[i]
    if cid >= 0:
        t_k = temp[i] + 273.15
        p = current * current * r_int[cid] + current * t_k * dudt
        q[i] = p * inv_cell_volume
    else:
        q[i] = 0.0


@wp.kernel
def coolant_march(temp: wp.array(dtype=float),
                  t_cool: wp.array(dtype=float),
                  wall_vox: wp.array(dtype=wp.int32),
                  coef: wp.array(dtype=float),   # per channel, precomputed, clamped [0,1]
                  n_seg: int,
                  t_inlet: float):
    c = wp.tid()
    tc = t_inlet
    cc = coef[c]
    for s in range(n_seg):
        idx = c * n_seg + s
        t_cool[idx] = tc
        tw = temp[wall_vox[idx]]
        tc = tc + cc * (tw - tc)


@wp.kernel
def diffuse(t_in: wp.array(dtype=float),
            t_out: wp.array(dtype=float),
            q: wp.array(dtype=float),
            kx: wp.array(dtype=float),
            ky: wp.array(dtype=float),
            kz: wp.array(dtype=float),
            rhocp: wp.array(dtype=float),
            chan: wp.array(dtype=wp.int32),
            cool_index: wp.array(dtype=wp.int32),
            t_cool: wp.array(dtype=float),
            h_eff: wp.array(dtype=float),        # per channel [W/m^2 K]
            nx: int, ny: int, nz: int,
            inv_dx2: float, inv_dz: float, dt: float):
    i = wp.tid()
    iz = i % nz
    iy = (i // nz) % ny
    ix = i // (nz * ny)

    t0 = t_in[i]
    acc = q[i]

    # x neighbors (stride ny*nz)
    if ix > 0:
        j = i - ny * nz
        kf = 2.0 * kx[i] * kx[j] / (kx[i] + kx[j] + 1.0e-9)
        acc = acc + kf * (t_in[j] - t0) * inv_dx2
    if ix < nx - 1:
        j = i + ny * nz
        kf = 2.0 * kx[i] * kx[j] / (kx[i] + kx[j] + 1.0e-9)
        acc = acc + kf * (t_in[j] - t0) * inv_dx2

    # y neighbors (stride nz)
    if iy > 0:
        j = i - nz
        kf = 2.0 * ky[i] * ky[j] / (ky[i] + ky[j] + 1.0e-9)
        acc = acc + kf * (t_in[j] - t0) * inv_dx2
    if iy < ny - 1:
        j = i + nz
        kf = 2.0 * ky[i] * ky[j] / (ky[i] + ky[j] + 1.0e-9)
        acc = acc + kf * (t_in[j] - t0) * inv_dx2

    # z neighbors (stride 1)
    if iz > 0:
        j = i - 1
        kf = 2.0 * kz[i] * kz[j] / (kz[i] + kz[j] + 1.0e-9)
        acc = acc + kf * (t_in[j] - t0) * inv_dx2
    if iz < nz - 1:
        j = i + 1
        kf = 2.0 * kz[i] * kz[j] / (kz[i] + kz[j] + 1.0e-9)
        acc = acc + kf * (t_in[j] - t0) * inv_dx2

    # convective floor sink coupled to local coolant segment
    ci = cool_index[i]
    if ci >= 0:
        c = chan[i]
        acc = acc + h_eff[c] * (t_cool[ci] - t0) * inv_dz

    t_out[i] = t0 + dt * acc / rhocp[i]


@wp.kernel
def add_sq_err(temp: wp.array(dtype=float),
               meas: wp.array(dtype=float),
               sensors: wp.array(dtype=wp.int32),
               loss: wp.array(dtype=float)):
    s = wp.tid()
    d = temp[sensors[s]] - meas[s]
    wp.atomic_add(loss, 0, d * d)


class Simulator:
    """Owns Warp buffers for one pack. Set differentiable=True to keep per-step
    buffers alive so wp.Tape() can backpropagate through the whole rollout."""

    def __init__(self, cfg: PackConfig, geo: PackGeometry,
                 device: str = "cpu", differentiable: bool = False):
        self.cfg, self.geo, self.device = cfg, geo, device
        self.diff = differentiable
        g = geo
        rg = differentiable

        def farr(a, grad=False):
            return wp.array(a.astype(np.float32), dtype=float, device=device,
                            requires_grad=grad and rg)

        self.kx = farr(g.flat(g.kx))
        self.ky = farr(g.flat(g.ky))
        self.kz = farr(g.flat(g.kz))
        self.rhocp = farr(g.flat(g.rhocp))
        self.cell_id = wp.array(g.flat(g.cell_id), dtype=wp.int32, device=device)
        self.chan = wp.array(g.flat(g.chan), dtype=wp.int32, device=device)
        self.cool_index = wp.array(g.flat(g.cool_index), dtype=wp.int32, device=device)
        self.wall_vox = wp.array(g.wall_vox, dtype=wp.int32, device=device)

        # nominal per-cell resistance (overridable / optimizable)
        self.r_int = wp.array(np.full(g.n_cells, cfg.r_int, dtype=np.float32),
                              dtype=float, device=device, requires_grad=rg)

        self.set_flow(np.ones(g.n_channels, dtype=np.float32))

        self.inv_cell_volume = 1.0 / g.cell_volume
        self.inv_dx2 = 1.0 / (cfg.dx * cfg.dx)
        self.inv_dz = 1.0 / cfg.dx

    def set_flow(self, flow_factor: np.ndarray):
        """Per-channel flow factors (1 = nominal, ~0 = blocked). Updates h and
        the coolant marching coefficient (Dittus-Boelter-ish h ~ ff^0.8)."""
        cfg, g = self.cfg, self.geo
        ff = np.clip(flow_factor.astype(np.float32), 1e-3, None)
        h = cfg.h_base * ff ** 0.8
        mdot_ch = cfg.mdot_total / g.n_channels
        a_seg = cfg.dx * cfg.dx
        coef = np.clip(h * a_seg / (mdot_ch * ff * cfg.cp_cool), 0.0, 1.0)
        self.h_eff = wp.array(h, dtype=float, device=self.device)
        self.coef = wp.array(coef.astype(np.float32), dtype=float, device=self.device)

    def _buf(self, n, grad):
        return wp.zeros(n, dtype=float, device=self.device,
                        requires_grad=grad and self.diff)

    def rollout(self, current: np.ndarray, snap_every: int = 0):
        """Run the drive cycle. Returns (snapshots, per-cell mean temps, coolant).
        In differentiable mode, per-step buffers are retained (tape-safe)."""
        cfg, g = self.cfg, self.geo
        n = g.n_vox
        n_steps = len(current)
        t = self._buf(n, True)
        t.fill_(cfg.t_init)
        self.states = [t]  # kept for tape correctness in diff mode
        snaps, cell_means, cool_hist = [], [], []

        for k in range(n_steps):
            q = self._buf(n, True)
            t_cool = self._buf(g.n_channels * g.n_seg, True)
            t_next = self._buf(n, True)
            wp.launch(heat_source, dim=n,
                      inputs=[self.cell_id, self.r_int, t, q,
                              float(current[k]), cfg.dudt, self.inv_cell_volume],
                      device=self.device)
            wp.launch(coolant_march, dim=g.n_channels,
                      inputs=[t, t_cool, self.wall_vox, self.coef,
                              g.n_seg, cfg.t_inlet],
                      device=self.device)
            wp.launch(diffuse, dim=n,
                      inputs=[t, t_next, q, self.kx, self.ky, self.kz, self.rhocp,
                              self.chan, self.cool_index, t_cool, self.h_eff,
                              g.nx, g.ny, g.nz, self.inv_dx2, self.inv_dz, cfg.dt],
                      device=self.device)
            t = t_next
            if self.diff:
                self.states.append(t)
            else:
                self.states = [t]
            if snap_every and (k + 1) % snap_every == 0:
                tn = t.numpy()
                snaps.append(tn.astype(np.float16))
                cid = self.geo.flat(self.geo.cell_id)
                means = np.array([tn[cid == c].mean() for c in range(g.n_cells)],
                                 dtype=np.float32)
                cell_means.append(means)
                cool_hist.append(t_cool.numpy().astype(np.float16))
        self.t_final = t
        return snaps, np.array(cell_means), cool_hist
