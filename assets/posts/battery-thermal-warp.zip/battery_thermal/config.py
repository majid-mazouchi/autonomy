"""Configuration for the differentiable battery pack thermal solver.

Geometry convention (voxel grid, row-major flat index i = (ix*ny + iy)*nz + iz):
  x : coolant flow direction (channels run along x under the pack floor)
  y : cell stacking direction within a module (prismatic through-stack axis)
  z : cell height (z = 0 is the cooled floor)

Units: SI throughout. Temperatures in degrees C.
"""

from dataclasses import dataclass, field


@dataclass
class PackConfig:
    # Voxel resolution
    dx: float = 0.005                 # voxel edge length [m]

    # Prismatic cell footprint in voxels (x, y, z). y is through-stack.
    cell_vox: tuple = (24, 5, 16)

    # Module / pack layout
    cells_per_module: int = 8         # stacked along y
    modules_x: int = 1
    modules_y: int = 2
    tim_vox: int = 1                  # interface gap voxels between cells (along y)
    module_gap_vox: int = 2           # gap between modules
    margin_vox: int = 2               # foam margin around the pack
    top_margin_vox: int = 2           # foam above cells

    # Cell materials (prismatic jellyroll, anisotropic; y = through-stack)
    k_cell: tuple = (25.0, 2.0, 25.0)  # W/mK
    rhocp_cell: float = 2.4e6          # J/m^3K
    k_tim: float = 1.5
    rhocp_tim: float = 2.0e6
    k_fill: float = 0.2                # structural foam / potting
    rhocp_fill: float = 5.0e5

    # Electro-thermal (per cell, Bernardi heat generation)
    r_int: float = 0.6e-3              # internal resistance [Ohm]
    dudt: float = -0.1e-3              # entropic coefficient dU/dT [V/K]

    # Cooling (channels along x, one per y-row of floor voxels)
    h_base: float = 600.0              # convective coefficient [W/m^2 K]
    mdot_total: float = 0.15           # total coolant mass flow [kg/s]
    cp_cool: float = 3500.0            # glycol-water [J/kg K]
    t_inlet: float = 25.0              # [C]

    # Time stepping (explicit FTCS; keep dt below stability limit)
    dt: float = 0.2                    # [s]
    t_init: float = 25.0               # [C]

    def stability_dt(self) -> float:
        """Conservative explicit stability limit."""
        alphas = [
            max(self.k_cell) / self.rhocp_cell,
            self.k_tim / self.rhocp_tim,
            self.k_fill / self.rhocp_fill,
        ]
        return self.dx * self.dx / (6.0 * max(alphas))


def demo_config() -> PackConfig:
    """Mid-size config: 2 modules x 8 cells, 5 mm voxels. Runs fast on CPU."""
    return PackConfig()


def coarse_config() -> PackConfig:
    """Small config for the differentiable inverse demo: 1 module x 6 cells, 10 mm voxels."""
    return PackConfig(
        dx=0.01,
        cell_vox=(12, 3, 8),
        cells_per_module=6,
        modules_x=1,
        modules_y=1,
        tim_vox=1,
        module_gap_vox=1,
        margin_vox=1,
        top_margin_vox=1,
        mdot_total=0.05,
        dt=0.5,
    )


def full_config() -> PackConfig:
    """Full pack: 2x4 modules x 12 cells. For real dataset generation (GPU recommended)."""
    return PackConfig(
        cell_vox=(35, 9, 25),
        cells_per_module=12,
        modules_x=2,
        modules_y=4,
        mdot_total=0.35,
    )
