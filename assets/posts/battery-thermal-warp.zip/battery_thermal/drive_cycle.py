"""Synthetic drive-cycle current profiles (WLTP-flavored segments + regen).

Positive current = discharge. All cells in series carry the pack current.
Replace with real WLTP/US06 -> current traces from PyBaMM or vehicle logs later.
"""

import numpy as np


def synthetic_cycle(t_total: float, dt: float, seed: int = 0,
                    i_urban: float = 90.0, i_highway: float = 150.0,
                    i_peak: float = 260.0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n = int(round(t_total / dt))
    t = 0.0
    current = np.zeros(n, dtype=np.float32)
    i = 0
    phases = ["urban", "urban", "highway", "aggressive", "urban"]
    p = 0
    while i < n:
        seg = rng.uniform(4.0, 15.0)
        m = min(n - i, max(1, int(seg / dt)))
        phase = phases[p % len(phases)]
        if rng.uniform() < 0.22:                      # regen braking
            amp = -rng.uniform(0.2, 0.6) * i_urban
        elif phase == "urban":
            amp = rng.uniform(0.1, 1.0) * i_urban
        elif phase == "highway":
            amp = rng.uniform(0.6, 1.0) * i_highway
        else:
            amp = rng.uniform(0.5, 1.0) * i_peak
        current[i:i + m] = amp
        i += m
        t += seg
        if rng.uniform() < 0.25:
            p += 1
    # first-order smoothing (driver/powertrain dynamics)
    tau = 2.0
    a = dt / (tau + dt)
    for k in range(1, n):
        current[k] = current[k - 1] + a * (current[k] - current[k - 1])
    return current
