"""Builds the voxelized pack: material fields, cell id map, cooling channel maps.

Everything here is plain numpy; the Warp solver consumes the resulting arrays.
"""

import numpy as np

from .config import PackConfig


class PackGeometry:
    def __init__(self, cfg: PackConfig):
        self.cfg = cfg
        cx, cy, cz = cfg.cell_vox
        pitch = cy + cfg.tim_vox  # y pitch per cell

        module_y = cfg.cells_per_module * pitch - cfg.tim_vox
        self.nx = cfg.modules_x * cx + (cfg.modules_x - 1) * cfg.module_gap_vox + 2 * cfg.margin_vox
        self.ny = cfg.modules_y * module_y + (cfg.modules_y - 1) * cfg.module_gap_vox + 2 * cfg.margin_vox
        self.nz = cz + cfg.top_margin_vox
        self.n_vox = self.nx * self.ny * self.nz

        shape = (self.nx, self.ny, self.nz)
        self.kx = np.full(shape, cfg.k_fill, dtype=np.float32)
        self.ky = np.full(shape, cfg.k_fill, dtype=np.float32)
        self.kz = np.full(shape, cfg.k_fill, dtype=np.float32)
        self.rhocp = np.full(shape, cfg.rhocp_fill, dtype=np.float32)
        self.cell_id = np.full(shape, -1, dtype=np.int32)

        # Place cells module by module; record TIM interface slabs for fault injection.
        self.n_cells = 0
        self.tim_slabs = []  # (module_index, interface_index, y0, y1, x0, x1)
        for mx in range(cfg.modules_x):
            x0 = cfg.margin_vox + mx * (cx + cfg.module_gap_vox)
            for my in range(cfg.modules_y):
                ybase = cfg.margin_vox + my * (module_y + cfg.module_gap_vox)
                m_idx = mx * cfg.modules_y + my
                for c in range(cfg.cells_per_module):
                    y0 = ybase + c * pitch
                    sl = (slice(x0, x0 + cx), slice(y0, y0 + cy), slice(0, cz))
                    self.kx[sl] = cfg.k_cell[0]
                    self.ky[sl] = cfg.k_cell[1]
                    self.kz[sl] = cfg.k_cell[2]
                    self.rhocp[sl] = cfg.rhocp_cell
                    self.cell_id[sl] = self.n_cells
                    self.n_cells += 1
                    if c < cfg.cells_per_module - 1:  # TIM slab after this cell
                        ty0 = y0 + cy
                        tl = (slice(x0, x0 + cx), slice(ty0, ty0 + cfg.tim_vox), slice(0, cz))
                        self.kx[tl] = cfg.k_tim
                        self.ky[tl] = cfg.k_tim
                        self.kz[tl] = cfg.k_tim
                        self.rhocp[tl] = cfg.rhocp_tim
                        self.tim_slabs.append((m_idx, c, tl))

        self.cell_volume = float(np.sum(self.cell_id == 0)) * cfg.dx ** 3

        # Cooling: one straight channel per y-row of floor voxels, flowing along +x.
        self.n_channels = self.ny
        self.n_seg = self.nx
        self.chan = np.full(shape, -1, dtype=np.int32)       # channel id per voxel
        self.cool_index = np.full(shape, -1, dtype=np.int32) # segment index per voxel
        self.wall_vox = np.zeros(self.n_channels * self.n_seg, dtype=np.int32)
        for iy in range(self.ny):
            for ix in range(self.nx):
                flat = (ix * self.ny + iy) * self.nz + 0
                self.chan[ix, iy, 0] = iy
                self.cool_index[ix, iy, 0] = iy * self.n_seg + ix
                self.wall_vox[iy * self.n_seg + ix] = flat

        # Per-cell sensor voxels: top-center of each cell (for the inverse demo).
        self.sensor_vox = np.zeros(self.n_cells, dtype=np.int32)
        for cid in range(self.n_cells):
            mask = np.argwhere(self.cell_id == cid)
            top = mask[mask[:, 2] == mask[:, 2].max()]
            cx_, cy_, cz_ = top[len(top) // 2]
            self.sensor_vox[cid] = (cx_ * self.ny + cy_) * self.nz + cz_

    # ---- fault injection (geometry-level) ----
    def degrade_tim(self, slab_index: int, factor: float = 0.1):
        _, _, tl = self.tim_slabs[slab_index]
        self.kx[tl] *= factor
        self.ky[tl] *= factor
        self.kz[tl] *= factor

    def flat(self, arr):
        return np.ascontiguousarray(arr).reshape(-1)
