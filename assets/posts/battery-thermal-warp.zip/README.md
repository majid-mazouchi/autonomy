# Phase 0: Differentiable Battery Pack Thermal Solver (NVIDIA Warp)

Ground-truth data generation for a battery pack thermal digital twin, feeding
PINN (Phase 1), KNO/FNO operator surrogates (Phase 2), MeshGraphNet pack-topology
models (Phase 3), and residual-based VHM fault detection (Phase 4).

The entire forward model is written in Warp kernels, so `wp.Tape()` provides
exact adjoints through the full transient rollout: gradients of any sensor-based
loss with respect to per-cell internal resistance, initial state, or (with minor
extension) material and cooling parameters.

## Physics

- Prismatic cells on a voxel grid, anisotropic conduction (in-plane k = 25 W/mK,
  through-stack k = 2 W/mK), TIM slabs between cells, foam structural fill.
- Bernardi heat generation per cell: q = (I^2 R_int + I T dU/dT) / V_cell, with
  pack current from a synthetic WLTP-flavored drive cycle (all cells in series).
- Liquid cooling as straight channels along x under the pack floor: a serial
  1D coolant energy balance per channel (captures inlet-to-outlet warming),
  coupled to the solid as a convective sink on floor voxels. Blocked-flow faults
  scale h via a Dittus-Boelter-like h ~ ff^0.8.
- Explicit FTCS time stepping with harmonic-mean face conductivities.
  `PackConfig.stability_dt()` reports the stability limit; the dataset script
  asserts dt is below it.

## Fault families (VHM-relevant)

- hot_cell: elevated R_int on one cell (aging / ISC precursor)
- blocked_channel: reduced flow in a band of channels (cooling degradation)
- tim_degraded: delaminated interface material between two cells

## Layout

- battery_thermal/config.py    presets: coarse (inverse demo), demo, full pack
- battery_thermal/geometry.py  voxel pack builder, channel maps, sensor voxels
- battery_thermal/drive_cycle.py  synthetic current profiles
- battery_thermal/solver.py    Warp kernels + Simulator (tape-safe rollout)
- battery_thermal/faults.py    scenario-level fault injection
- scripts/generate_dataset.py  scenario sweep -> compressed .npz files
- scripts/demo_inverse.py      recover faulty-cell R_int via solver adjoint

## Quick start (one command)

    run_all.bat      (Windows)
    ./run_all.sh     (Linux / WSL / macOS)

Creates a venv, installs dependencies, generates the dataset, runs the
differentiable inverse demo, renders figures, and runs scripts/verify.py,
which PASS/FAIL-checks dataset plausibility, fault detectability, and
inverse-recovery accuracy (exits nonzero on failure, so it gates CI too).

## Manual usage

    pip install warp-lang numpy matplotlib

    # dataset (CPU demo scale: 2 modules x 8 cells, ~4 s per 300 s scenario)
    python scripts/generate_dataset.py --preset demo --t-total 300 \
        --n-nominal 2 --n-fault 1

    # differentiability demo (coarse pack, ~9 s for 40 Adam iterations)
    python scripts/demo_inverse.py

Measured on CPU: the inverse demo recovers a 3x R_int fault to 0.4% relative
error from 12 noisy snapshots of 6 surface thermocouples, healthy cells staying
at nominal. Use `--preset full` on a GPU (`--device cuda:0`) for the
2x4-module, 96-cell pack.

## Dataset format (per scenario .npz)

- snaps      (S, n_vox) float16, flat row-major (x, y, z) temperature fields
- cell_means (S, n_cells) per-cell mean temperature
- coolant    (S, n_channels * n_seg) coolant temperature field
- current    (N,) drive-cycle current
- meta       JSON: fault info, grid shape, inlet temp, flow scale, dt

## Hooks into later phases

- Phase 1 (PINN, physicsnemo.sym): the inverse demo IS the target inverse
  problem; the PINN version replaces the numerical adjoint with residual losses.
  Compare estimation accuracy and wall time head to head.
- Phase 2 (KNO/FNO): snaps reshape directly to the (nx, ny, nz) grid FNO/KNO
  expect. Because the solver is differentiable, physics-informed fine-tuning of
  operator surrogates (solver-in-the-loop) needs no extra machinery.
- Phase 3 (MeshGraphNet): cell_means + the cell adjacency implied by
  geometry.tim_slabs give node features and edges; snapshots supervise node
  temperatures across pack configurations.
- Phase 4 (VHM): nominal vs fault scenarios are the labeled corpus for
  residual/innovation detectors and Koopman eigenvalue tracking.

## Known simplifications (upgrade path)

- Explicit time stepping (swap in ADI/implicit for stiffer configs or finer voxels)
- Coolant model is 1D marching, energy coupling is one-way approximate
- Constant R_int vs temperature/SOC (hook PyBaMM ECM output into heat_source)
- No busbar Joule heating or tab conduction paths yet
