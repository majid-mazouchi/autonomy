"""End-of-pipeline verification: checks the generated dataset and the inverse
demo results. Exits nonzero on failure so batch scripts can gate on it.

Checks:
  1. Dataset npz files exist, temperatures are finite and physically plausible.
  2. Fault scenarios actually differ from nominal (detectability sanity check).
  3. Inverse demo recovered the faulty cell R_int within tolerance and kept
     healthy cells near nominal.
"""

import glob
import json
import sys
from pathlib import Path

import numpy as np

DATA = Path(__file__).resolve().parents[1] / "data"
FAULT_R_TOL = 0.05      # 5% relative error allowed on faulty cell R_int
HEALTHY_R_TOL = 0.20    # healthy cells within 20% of nominal
T_MIN, T_MAX = 5.0, 90.0

failures = []


def check(name, ok, detail=""):
    status = "PASS" if ok else "FAIL"
    print(f"  [{status}] {name}" + (f"  ({detail})" if detail else ""))
    if not ok:
        failures.append(name)


print("== 1. Dataset sanity ==")
files = sorted(glob.glob(str(DATA / "*.npz")))
files = [f for f in files if "inverse_demo" not in f]
check("dataset files present", len(files) >= 2, f"{len(files)} scenario files")

nominal_peaks, fault_peaks = [], []
for f in files:
    d = np.load(f)
    snaps = d["snaps"].astype(np.float32)
    meta = json.loads(str(d["meta"]))
    ok_finite = np.isfinite(snaps).all()
    ok_range = (snaps.min() > T_MIN) and (snaps.max() < T_MAX)
    check(f"{Path(f).name}: finite + plausible T",
          ok_finite and ok_range,
          f"range [{snaps.min():.1f}, {snaps.max():.1f}] C")
    rise = float(d["cell_means"].max() - meta["t_inlet"])
    (nominal_peaks if "nominal" in Path(f).name else fault_peaks).append(rise)

if nominal_peaks:
    check("cells heat up under drive cycle", max(nominal_peaks) > 0.5,
          f"max rise over inlet {max(nominal_peaks):.2f} C")

print("== 2. Inverse demo (differentiable parameter recovery) ==")
inv_path = DATA / "inverse_demo.npz"
check("inverse_demo.npz present", inv_path.exists())
if inv_path.exists():
    inv = np.load(inv_path)
    r_est = inv["r_hist"][-1]
    r_true = inv["r_true"]
    fc = int(inv["fault_cell"])
    err_fault = abs(r_est[fc] - r_true[fc]) / r_true[fc]
    healthy = np.delete(np.arange(len(r_est)), fc)
    err_healthy = np.abs(r_est[healthy] - r_true[healthy]) / r_true[healthy]
    check("loss decreased", inv["loss"][-1] < 0.5 * inv["loss"][0],
          f"{inv['loss'][0]:.3f} -> {inv['loss'][-1]:.3f}")
    check("faulty cell R_int recovered", err_fault < FAULT_R_TOL,
          f"rel. error {100*err_fault:.1f}% (tol {100*FAULT_R_TOL:.0f}%)")
    check("healthy cells near nominal", err_healthy.max() < HEALTHY_R_TOL,
          f"worst rel. error {100*err_healthy.max():.1f}%")

print()
if failures:
    print(f"VERIFICATION FAILED: {len(failures)} check(s) failed: {failures}")
    sys.exit(1)
print("ALL CHECKS PASSED")
