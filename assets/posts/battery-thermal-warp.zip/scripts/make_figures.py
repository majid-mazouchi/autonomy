"""Generates the three verification figures from the dataset and inverse demo:
  fig1_drive_cycle_temps.png   drive cycle + per-cell mean temperatures
  fig2_temperature_field.png   final temperature field slices
  fig3_inverse_convergence.png loss + per-cell R_int recovery
"""

import glob
import json
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DATA = Path(__file__).resolve().parents[1] / "data"
RUST, TEAL = "#B7410E", "#2A7F7F"

# pick the hottest scenario for field plots (fault scenarios preferred)
cands = [f for f in sorted(glob.glob(str(DATA / "*.npz"))) if "inverse" not in f]
if not cands:
    sys.exit("no dataset files in data/ - run generate_dataset.py first")
pick = max(cands, key=lambda f: float(np.load(f)["cell_means"].max()))
d = np.load(pick)
meta = json.loads(str(d["meta"]))
name = Path(pick).stem

cur, cm = d["current"], d["cell_means"]
t_cur = np.arange(len(cur)) * meta["dt"]
t_snap = (np.arange(len(cm)) + 1) * meta["snap_dt"]
fig, ax = plt.subplots(2, 1, figsize=(9, 6), sharex=True)
ax[0].plot(t_cur, cur, lw=0.8, color=RUST)
ax[0].set_ylabel("Pack current [A]")
ax[0].set_title(f"Scenario: {name} | drive cycle -> Bernardi heat -> 3D conduction")
for c in range(cm.shape[1]):
    ax[1].plot(t_snap, cm[:, c], lw=1, alpha=0.7)
ax[1].plot(t_snap, cm.max(axis=1), "k--", lw=1.5, label="hottest cell")
ax[1].set_ylabel("Cell mean T [C]"); ax[1].set_xlabel("time [s]"); ax[1].legend()
plt.tight_layout(); plt.savefig(DATA / "fig1_drive_cycle_temps.png", dpi=130); plt.close()

nx, ny, nz = meta["grid"]
T = d["snaps"][-1].astype(np.float32).reshape(nx, ny, nz)
fig, ax = plt.subplots(1, 2, figsize=(11, 4))
im0 = ax[0].imshow(T[:, :, nz // 2].T, origin="lower", cmap="inferno", aspect="auto")
ax[0].set_title("mid-height x-y slice"); plt.colorbar(im0, ax=ax[0], label="T [C]")
im1 = ax[1].imshow(T[nx // 2, :, :].T, origin="lower", cmap="inferno", aspect="auto")
ax[1].set_title("y-z slice (cooled floor at z=0)"); plt.colorbar(im1, ax=ax[1], label="T [C]")
plt.tight_layout(); plt.savefig(DATA / "fig2_temperature_field.png", dpi=130); plt.close()

inv_path = DATA / "inverse_demo.npz"
if inv_path.exists():
    inv = np.load(inv_path)
    loss, rh = inv["loss"], inv["r_hist"] * 1e3
    rt, fc = inv["r_true"] * 1e3, int(inv["fault_cell"])
    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    ax[0].semilogy(loss, color=RUST)
    ax[0].set_xlabel("Adam iteration"); ax[0].set_ylabel("sensor MSE loss")
    ax[0].set_title("Loss (backprop through full rollout)")
    for c in range(rh.shape[1]):
        style = dict(color=RUST, lw=2) if c == fc else dict(color=TEAL, lw=1, alpha=0.6)
        ax[1].plot(rh[:, c], **style)
    ax[1].axhline(rt[fc], color=RUST, ls="--", lw=1, label="true faulty R")
    ax[1].axhline(rt[0], color=TEAL, ls="--", lw=1, label="true healthy R")
    ax[1].set_xlabel("Adam iteration"); ax[1].set_ylabel("estimated R_int [mOhm]")
    ax[1].set_title("Per-cell R_int recovered via solver adjoint"); ax[1].legend()
    plt.tight_layout(); plt.savefig(DATA / "fig3_inverse_convergence.png", dpi=130); plt.close()

print(f"figures written to {DATA}")
