"""Phase 0 dataset generation: sweep drive cycles, operating points, and faults.

Each scenario exports an .npz with:
  snaps      (S, n_vox)  float16 temperature fields (flat, row-major x,y,z)
  cell_means (S, n_cells)
  coolant    (S, n_channels*n_seg)
  current    (N,) drive-cycle current
  meta       json string (fault info, flow, inlet, grid shape)

Usage:
  python scripts/generate_dataset.py --preset demo --t-total 300 --n-nominal 2 --n-fault 2
"""

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from battery_thermal.config import demo_config, coarse_config, full_config
from battery_thermal.geometry import PackGeometry
from battery_thermal.solver import Simulator
from battery_thermal.drive_cycle import synthetic_cycle
from battery_thermal.faults import apply_fault

PRESETS = {"demo": demo_config, "coarse": coarse_config, "full": full_config}


def run_scenario(cfg, geo, fault, seed, t_total, snap_dt, out_dir, tag, device):
    rng = np.random.default_rng(seed)
    # operating-point variation
    cfg.t_inlet = float(rng.uniform(20.0, 35.0))
    cfg.t_init = cfg.t_inlet
    flow_scale = float(rng.uniform(0.8, 1.2))

    sim = Simulator(cfg, geo, device=device, differentiable=False)
    sim.set_flow(flow_scale * np.ones(geo.n_channels, dtype=np.float32))
    meta = apply_fault(sim, geo, fault, severity=float(rng.uniform(0.5, 1.0)), rng=rng)
    meta.update(dict(t_inlet=cfg.t_inlet, flow_scale=flow_scale, seed=seed,
                     grid=[geo.nx, geo.ny, geo.nz], n_cells=geo.n_cells,
                     dt=cfg.dt, snap_dt=snap_dt))

    current = synthetic_cycle(t_total, cfg.dt, seed=seed)
    snap_every = max(1, int(round(snap_dt / cfg.dt)))
    t0 = time.time()
    snaps, cell_means, cool = sim.rollout(current, snap_every=snap_every)
    wall = time.time() - t0

    path = out_dir / f"{tag}.npz"
    np.savez_compressed(path,
                        snaps=np.stack(snaps),
                        cell_means=cell_means,
                        coolant=np.stack(cool),
                        current=current,
                        meta=json.dumps(meta))
    print(f"  {tag:28s} fault={fault:16s} peak={cell_means.max():6.2f}C "
          f"steps={len(current)} wall={wall:5.1f}s -> {path.name}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", default="demo", choices=PRESETS)
    ap.add_argument("--t-total", type=float, default=300.0)
    ap.add_argument("--snap-dt", type=float, default=10.0)
    ap.add_argument("--n-nominal", type=int, default=2)
    ap.add_argument("--n-fault", type=int, default=1)
    ap.add_argument("--out", default="data")
    ap.add_argument("--device", default="cpu")
    args = ap.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    cfg = PRESETS[args.preset]()
    assert cfg.dt <= cfg.stability_dt(), \
        f"dt={cfg.dt} exceeds explicit stability limit {cfg.stability_dt():.3f}s"

    seed = 0
    for i in range(args.n_nominal):
        geo = PackGeometry(cfg)
        run_scenario(cfg, geo, "none", seed, args.t_total, args.snap_dt,
                     out_dir, f"nominal_{i:03d}", args.device)
        seed += 1
    for fault in ("hot_cell", "blocked_channel", "tim_degraded"):
        for i in range(args.n_fault):
            geo = PackGeometry(cfg)
            if fault == "tim_degraded":
                geo.degrade_tim(int(np.random.default_rng(seed).integers(0, len(geo.tim_slabs))),
                                factor=0.08)
                geo_fault = "none"  # geometry already carries the fault
            else:
                geo_fault = fault
            run_scenario(cfg, geo, geo_fault, seed, args.t_total, args.snap_dt,
                         out_dir, f"{fault}_{i:03d}", args.device)
            seed += 1
    print("done.")


if __name__ == "__main__":
    main()
