"""Differentiability payoff demo: recover per-cell internal resistance from
sparse surface thermocouples by backpropagating THROUGH the thermal solver.

  1. Ground truth: coarse pack, one cell with 3x nominal R_int, drive cycle.
     "Measure" the top-center sensor of each cell every meas_dt (+ noise).
  2. Estimation: start all cells at nominal R, run the same cycle inside
     wp.Tape(), accumulate sensor MSE, backward(), Adam-update r_int.

This is exactly the Phase 1 PINN inverse problem, solved instead with the
adjoint of the numerical solver -- and it doubles as the hook for
physics-informed fine-tuning of the Phase 2/3 surrogates.
"""

import sys
import time
from pathlib import Path

import numpy as np
import warp as wp

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from battery_thermal.config import coarse_config
from battery_thermal.geometry import PackGeometry
from battery_thermal.solver import Simulator, heat_source, coolant_march, diffuse, add_sq_err
from battery_thermal.drive_cycle import synthetic_cycle

DEVICE = "cpu"
T_TOTAL = 120.0
MEAS_EVERY = 20          # steps between "thermocouple" samples
NOISE = 0.05             # C
FAULT_CELL = 3
FAULT_FACTOR = 3.0
ITERS = 40
LR = 4e-5                # Adam step on r [Ohm]


def taped_rollout(sim, current, sensors_wp, meas_steps, meas_wp, loss):
    cfg, g = sim.cfg, sim.geo
    n = g.n_vox
    t = wp.zeros(n, dtype=float, device=DEVICE, requires_grad=True)
    t.fill_(cfg.t_init)
    keep = [t]
    mi = 0
    for k in range(len(current)):
        q = wp.zeros(n, dtype=float, device=DEVICE, requires_grad=True)
        t_cool = wp.zeros(g.n_channels * g.n_seg, dtype=float, device=DEVICE, requires_grad=True)
        t_next = wp.zeros(n, dtype=float, device=DEVICE, requires_grad=True)
        wp.launch(heat_source, dim=n,
                  inputs=[sim.cell_id, sim.r_int, t, q, float(current[k]),
                          cfg.dudt, sim.inv_cell_volume], device=DEVICE)
        wp.launch(coolant_march, dim=g.n_channels,
                  inputs=[t, t_cool, sim.wall_vox, sim.coef, g.n_seg, cfg.t_inlet],
                  device=DEVICE)
        wp.launch(diffuse, dim=n,
                  inputs=[t, t_next, q, sim.kx, sim.ky, sim.kz, sim.rhocp,
                          sim.chan, sim.cool_index, t_cool, sim.h_eff,
                          g.nx, g.ny, g.nz, sim.inv_dx2, sim.inv_dz, cfg.dt],
                  device=DEVICE)
        t = t_next
        keep.append(t)
        keep.append(q)
        keep.append(t_cool)
        if mi < len(meas_steps) and k == meas_steps[mi]:
            wp.launch(add_sq_err, dim=g.n_cells,
                      inputs=[t, meas_wp[mi], sensors_wp, loss], device=DEVICE)
            mi += 1
    return keep


def main():
    cfg = coarse_config()
    geo = PackGeometry(cfg)
    current = synthetic_cycle(T_TOTAL, cfg.dt, seed=7)
    n_steps = len(current)
    meas_steps = list(range(MEAS_EVERY - 1, n_steps, MEAS_EVERY))
    print(f"grid {geo.nx}x{geo.ny}x{geo.nz} = {geo.n_vox} voxels, "
          f"{geo.n_cells} cells, {n_steps} steps, {len(meas_steps)} measurement times")

    # ---- ground truth ----
    truth = Simulator(cfg, geo, device=DEVICE, differentiable=False)
    r_true = truth.r_int.numpy().copy()
    r_true[FAULT_CELL] *= FAULT_FACTOR
    truth.r_int = wp.array(r_true, dtype=float, device=DEVICE)
    rng = np.random.default_rng(1)

    sensors = geo.sensor_vox
    meas = []
    t = wp.zeros(geo.n_vox, dtype=float, device=DEVICE)
    t.fill_(cfg.t_init)
    # simple non-taped forward capturing sensor values
    snaps, _, _ = truth.rollout(current, snap_every=MEAS_EVERY)
    for s in snaps:
        meas.append(s.astype(np.float32)[sensors] + rng.normal(0, NOISE, size=len(sensors)))
    meas_wp = [wp.array(m.astype(np.float32), dtype=float, device=DEVICE) for m in meas]
    sensors_wp = wp.array(sensors, dtype=wp.int32, device=DEVICE)

    # ---- inverse: optimize r_int through the solver adjoint ----
    est = Simulator(cfg, geo, device=DEVICE, differentiable=True)
    r = np.full(geo.n_cells, cfg.r_int, dtype=np.float32)
    m1 = np.zeros_like(r)
    m2 = np.zeros_like(r)
    hist = []
    t0 = time.time()
    for it in range(1, ITERS + 1):
        est.r_int = wp.array(r, dtype=float, device=DEVICE, requires_grad=True)
        loss = wp.zeros(1, dtype=float, device=DEVICE, requires_grad=True)
        tape = wp.Tape()
        with tape:
            keep = taped_rollout(est, current, sensors_wp, meas_steps, meas_wp, loss)
        tape.backward(loss=loss)
        g = est.r_int.grad.numpy().astype(np.float64)
        lval = float(loss.numpy()[0])
        tape.zero()
        del keep

        # Adam
        m1 = 0.9 * m1 + 0.1 * g
        m2 = 0.999 * m2 + 0.001 * g * g
        mh = m1 / (1 - 0.9 ** it)
        vh = m2 / (1 - 0.999 ** it)
        r = np.clip(r - LR * mh / (np.sqrt(vh) + 1e-12), 1e-4, 5e-3).astype(np.float32)
        hist.append((lval, r.copy()))
        if it % 5 == 0 or it == 1:
            print(f"iter {it:3d}  loss {lval:9.4f}  "
                  f"r[fault]={r[FAULT_CELL]*1e3:.3f} mOhm (true {r_true[FAULT_CELL]*1e3:.3f})  "
                  f"r[healthy avg]={np.delete(r, FAULT_CELL).mean()*1e3:.3f} mOhm")
    print(f"optimization wall time: {time.time()-t0:.1f}s")

    np.savez("data/inverse_demo.npz",
             loss=np.array([h[0] for h in hist]),
             r_hist=np.stack([h[1] for h in hist]),
             r_true=r_true, fault_cell=FAULT_CELL)
    err = abs(r[FAULT_CELL] - r_true[FAULT_CELL]) / r_true[FAULT_CELL]
    print(f"final relative error on faulty cell R_int: {100*err:.1f}%")


if __name__ == "__main__":
    main()
