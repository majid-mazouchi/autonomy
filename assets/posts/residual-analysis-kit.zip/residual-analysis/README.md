# Residual & innovation analysis kit

A VS Code Copilot skill for model-based fault detection and isolation, in the
progressive-disclosure layout. Read `SKILL.md` first; it routes to the rest.

## Layout
- `SKILL.md` routing and overview.
- `references/01-whiteness-tests.md` covers whiteness tests, is the residual white?.
- `references/02-innovation-consistency.md` covers innovation consistency, is the filter telling the truth?.
- `references/03-parity-space.md` covers parity space, which fault?.
- `references/04-residual-generation.md` covers residual generation.
- `references/05-robust-evaluation.md` covers robust evaluation and thresholds.
- `references/06-fault-estimation.md` covers beyond detect and isolate.
- `references/07-sharper-tests.md` covers sharper whiteness and consistency tests.
- `references/08-data-driven-generation.md` covers data-driven residual generation.
- `references/decision-map.md`, `references/rules-of-thumb.md`, `references/pitfalls.md`, `references/case-study.md`, `references/at-a-glance.md`, `references/references.md`.
- `scripts/residuals.py` the tested engine (numpy, scipy only). Run it for a self-test:

      python scripts/residuals.py

- `copilot/` a residual-analysis chat mode, a `/diagnose` and a `/characterize` prompt, and path-scoped instructions.
- `assets/residual-analysis.html` the full illustrated monograph.
