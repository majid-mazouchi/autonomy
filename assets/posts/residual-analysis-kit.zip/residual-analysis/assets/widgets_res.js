/* Interactive explorers for the residual & innovation monograph. Vanilla JS. */
(function () {
  "use strict";
  var INK = "#221d17", MUTE = "#7a6f5e", RUST = "#b0492f",
      TEAL = "#1f6f6a", OCHRE = "#c4922b", LINE = "#d9cfb8";

  function fit(c){var d=window.devicePixelRatio||1,w=c.clientWidth||600,h=c.clientHeight||240;
    c.width=w*d;c.height=h*d;var x=c.getContext("2d");x.setTransform(d,0,0,d,0,0);return {ctx:x,w:w,h:h};}
  function rng(seed){var s=seed>>>0;return function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
  function gauss(n,seed){var r=rng(seed),o=new Float64Array(n),i;
    for(i=0;i<n;i++){var u=Math.max(1e-9,r()),v=r();o[i]=Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}return o;}
  function chi2cdf(x,k){ // regularized lower incomplete gamma P(k/2, x/2)
    if(x<=0)return 0; var a=k/2, t=x/2;
    // series expansion
    var sum=1/a, term=1/a, n;
    for(n=1;n<200;n++){term*=t/(a+n);sum+=term;if(term<sum*1e-10)break;}
    var lng=lgamma(a);
    return Math.exp(-t+a*Math.log(t)-lng)*sum;
  }
  function lgamma(z){var g=[76.18009172947146,-86.50532032941677,24.01409824083091,
    -1.231739572450155,0.1208650973866179e-2,-0.5395239384953e-5];
    var x=z,y=z,tmp=x+5.5;tmp-=(x+0.5)*Math.log(tmp);var ser=1.000000000190015,j;
    for(j=0;j<6;j++){y+=1;ser+=g[j]/y;}return -tmp+Math.log(2.5066282746310005*ser/x);}

  // ======================================================================
  // A. Whiteness explorer: slide residual autocorrelation, read the tests
  // ======================================================================
  (function whiteness(){
    var cv=document.getElementById("ex-w-canvas"); if(!cv) return;
    var sPhi=document.getElementById("ex-w-phi"), read=document.getElementById("ex-w-read"),
        cap=document.getElementById("ex-w-cap");
    var N=320, e=gauss(N,21);
    function draw(){
      var phi=parseFloat(sPhi.value)/100*0.85, i, k;
      var r=new Float64Array(N); r[0]=e[0];
      for(i=1;i<N;i++) r[i]=phi*r[i-1]+e[i];
      // mean-center
      var m=0;for(i=0;i<N;i++)m+=r[i];m/=N;for(i=0;i<N;i++)r[i]-=m;
      var c0=0;for(i=0;i<N;i++)c0+=r[i]*r[i];c0/=N;
      var L=18, acf=[], Q=0;
      for(k=1;k<=L;k++){var c=0;for(i=0;i<N-k;i++)c+=r[i]*r[i+k];c=c/N/c0;acf.push(c);
        if(k<=10)Q+=c*c/(N-k);}
      Q*=N*(N+2);
      var p=1-chi2cdf(Q,10);
      // Durbin-Watson
      var num=0,den=0;for(i=1;i<N;i++)num+=(r[i]-r[i-1])*(r[i]-r[i-1]);for(i=0;i<N;i++)den+=r[i]*r[i];
      var dw=num/den;
      // draw ACF bars
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=24,band=1.96/Math.sqrt(N);
      ctx.clearRect(0,0,w,h);
      var mid=h*0.52, sc=(h*0.42)/Math.max(0.5,band*1.2+0.4);
      ctx.strokeStyle=LINE;ctx.setLineDash([3,3]);
      [band,-band].forEach(function(b){ctx.beginPath();ctx.moveTo(pad,mid-b*sc);ctx.lineTo(w-pad,mid-b*sc);ctx.stroke();});
      ctx.setLineDash([]);ctx.strokeStyle=MUTE;ctx.beginPath();ctx.moveTo(pad,mid);ctx.lineTo(w-pad,mid);ctx.stroke();
      var bw=(w-2*pad)/L;
      for(k=0;k<L;k++){var x=pad+k*bw+bw*0.5, bh=acf[k]*sc;
        ctx.fillStyle=Math.abs(acf[k])>band?RUST:TEAL;
        ctx.fillRect(x-bw*0.3,mid,bw*0.6,-bh);}
      ctx.fillStyle=MUTE;ctx.font="10px monospace";ctx.fillText("residual autocorrelation (lags 1-18), dashed = white-noise band",pad,14);
      var white=p>0.05;
      read.innerHTML="lag-1 correlation \u2248 <b>"+phi.toFixed(2)+"</b> &nbsp; Ljung-Box p=<b style='color:"+
        (white?TEAL:RUST)+"'>"+(p<1e-3?p.toExponential(1):p.toFixed(3))+"</b> &nbsp; Durbin-Watson=<b>"+dw.toFixed(2)+
        "</b> &rarr; <b style='color:"+(white?TEAL:RUST)+"'>"+(white?"white (model OK)":"not white (fault / unmodeled dynamics)")+"</b>";
      cap.textContent=white
        ? "A white residual stays inside the band and Durbin-Watson sits near 2: the model explains the data."
        : "Correlation leaks past the band, Ljung-Box rejects whiteness, and Durbin-Watson falls below 2: something is unmodeled.";
    }
    sPhi.addEventListener("input",draw); window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // B. NIS consistency explorer: filter covariance vs reality
  // ======================================================================
  (function nis(){
    var cv=document.getElementById("ex-n-canvas"); if(!cv) return;
    var sMis=document.getElementById("ex-n-mis"), read=document.getElementById("ex-n-read"),
        cap=document.getElementById("ex-n-cap");
    var N=260, g=gauss(N,33);
    function draw(){
      // mismatch: ratio of true innovation std to filter-predicted std
      var ratio=parseFloat(sMis.value)/100*2.4+0.4;   // 0.4 .. 2.8
      var i,k,Spred=1.0, nisv=new Float64Array(N);
      for(i=0;i<N;i++){var nu=g[i]*ratio*Math.sqrt(Spred); nisv[i]=nu*nu/Spred;}
      // windowed average
      var w=15, avg=[], lo, hi;
      // chi2 band for w*dof, dof=1
      lo=chi2inv(0.025,w)/w; hi=chi2inv(0.975,w)/w;
      for(k=w-1;k<N;k++){var s=0;for(i=k-w+1;i<=k;i++)s+=nisv[i];avg.push(s/w);}
      var f=fit(cv),ctx=f.ctx,wd=f.w,h=f.h,pad=26;ctx.clearRect(0,0,wd,h);
      var ymax=Math.max(hi*1.6, 3.5);
      function Y(v){return h-pad - Math.min(v,ymax)/ymax*(h-2*pad);}
      function X(j){return pad + j/(avg.length-1)*(wd-2*pad);}
      ctx.fillStyle="rgba(31,111,106,0.13)";ctx.fillRect(pad,Y(hi),wd-2*pad,Y(lo)-Y(hi));
      ctx.strokeStyle=INK;ctx.lineWidth=1.5;ctx.beginPath();
      for(k=0;k<avg.length;k++){if(k===0)ctx.moveTo(X(k),Y(avg[k]));else ctx.lineTo(X(k),Y(avg[k]));}ctx.stroke();
      ctx.fillStyle=MUTE;ctx.font="10px monospace";ctx.fillText("windowed NIS (shaded = 95% consistency band, target 1)",pad,16);
      var meanA=0;for(k=0;k<avg.length;k++)meanA+=avg[k];meanA/=avg.length;
      var verdict, col;
      if(meanA>hi){verdict="inconsistent: filter is OVERCONFIDENT (covariance too small)";col=RUST;}
      else if(meanA<lo){verdict="inconsistent: filter is CONSERVATIVE (covariance too large)";col=OCHRE;}
      else {verdict="consistent (innovations match the filter's covariance)";col=TEAL;}
      read.innerHTML="true / predicted innovation std = <b>"+ratio.toFixed(2)+
        "</b> &rarr; average NIS <b>"+meanA.toFixed(2)+"</b> &rarr; <b style='color:"+col+"'>"+verdict+"</b>";
      cap.textContent="NIS needs no ground truth: it only asks whether the innovations are as big as the filter expected. A persistent departure is a model or sensor fault.";
    }
    function chi2inv(p,k){ // bisection on chi2cdf
      var lo=0, hi=k*5+40, mid;
      for(var it=0;it<60;it++){mid=(lo+hi)/2; if(chi2cdf(mid,k)<p)lo=mid;else hi=mid;}
      return mid;
    }
    sMis.addEventListener("input",draw); window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // C. Parity isolation explorer: pick the fault, watch the signature
  // ======================================================================
  (function parity(){
    var cv=document.getElementById("ex-p-canvas"); if(!cv) return;
    var read=document.getElementById("ex-p-read"), cap=document.getElementById("ex-p-cap"),
        btns=document.querySelectorAll("[data-fault]");
    var faults=["sensor 1","sensor 2","actuator","none"];
    // signature: residuals (r1,r2,r3) x faults (s1,s2,act); 'none' fires nothing
    var sig=[[1,0,1],[0,1,1],[1,1,0]];
    var active=0;
    function fired(fi){
      if(fi===3)return [0,0,0];
      return [sig[0][fi],sig[1][fi],sig[2][fi]];
    }
    function isolate(obs){
      if(obs[0]+obs[1]+obs[2]===0)return {idx:-1,unique:true};
      var best=-1,bestScore=-1,ties=0,j,i;
      for(j=0;j<3;j++){var sc=0;for(i=0;i<3;i++)sc+=(sig[i][j]===obs[i])?1:0;
        if(sc>bestScore){bestScore=sc;best=j;ties=1;}else if(sc===bestScore)ties++;}
      return {idx:best,unique:ties===1};
    }
    function draw(){
      var obs=fired(active), iso=isolate(obs);
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h;ctx.clearRect(0,0,w,h);
      var x0=w*0.30, y0=24, cw=(w*0.62)/3, ch=(h-50)/3;
      // header: fault columns
      ctx.font="11px monospace";ctx.textAlign="center";
      ["s1","s2","act"].forEach(function(t,j){ctx.fillStyle=MUTE;ctx.fillText(t,x0+cw*(j+0.5),y0-8);});
      ctx.textAlign="right";
      for(var i=0;i<3;i++){ctx.fillStyle=MUTE;ctx.fillText("r"+(i+1),x0-8,y0+ch*(i+0.5)+4);
        for(var j=0;j<3;j++){var on=sig[i][j];
          ctx.fillStyle=on?"rgba(34,29,23,0.82)":"rgba(217,207,184,0.4)";
          ctx.fillRect(x0+cw*j+2,y0+ch*i+2,cw-4,ch-4);
          ctx.fillStyle=on?"#fbf7ee":INK;ctx.textAlign="center";
          ctx.fillText(on?"1":"0",x0+cw*(j+0.5),y0+ch*(i+0.5)+4);ctx.textAlign="right";}}
      // highlight matched column
      if(iso.idx>=0 && iso.unique){ctx.strokeStyle=RUST;ctx.lineWidth=2.4;
        ctx.strokeRect(x0+cw*iso.idx+1,y0,cw-2,ch*3);}
      // observed pattern column on the left
      ctx.textAlign="center";ctx.fillStyle=MUTE;ctx.font="10px monospace";
      ctx.fillText("observed",x0*0.5,y0-8);
      for(i=0;i<3;i++){ctx.fillStyle=obs[i]?RUST:"rgba(217,207,184,0.5)";
        ctx.fillRect(x0*0.5-cw*0.3,y0+ch*i+2,cw*0.6,ch-4);
        ctx.fillStyle=obs[i]?"#fbf7ee":INK;ctx.fillText(obs[i]?"1":"0",x0*0.5,y0+ch*(i+0.5)+4);}
      ctx.textAlign="left";
      var msg;
      if(active===3) msg="<b style='color:"+TEAL+"'>no fault</b>: every residual stays at zero.";
      else if(iso.unique) msg="firing pattern uniquely matches <b style='color:"+RUST+"'>"+faults[iso.idx]+"</b>.";
      else msg="pattern is <b style='color:"+OCHRE+"'>ambiguous</b>: more than one fault fits.";
      read.innerHTML="injected fault: <b>"+faults[active]+"</b> &rarr; "+msg;
      cap.textContent="Each residual is built blind to some faults, so every fault leaves a distinct firing pattern. Isolation is reading off which column the pattern matches.";
    }
    btns.forEach(function(btn){btn.addEventListener("click",function(){
      active=parseInt(btn.getAttribute("data-fault"),10);
      btns.forEach(function(b){b.classList.remove("sel");});btn.classList.add("sel");draw();});});
    window.addEventListener("resize",draw); draw();
  })();

  // ---- D. GLR detection: fault size vs detection delay ----
  (function () {
    var cv = document.getElementById("ex-g-canvas"); if (!cv) return;
    var sMag = document.getElementById("ex-g-mag"), read = document.getElementById("ex-g-read"),
        cap = document.getElementById("ex-g-cap");
    var N = 300, onset = 150, base = gauss(N, 71), Mw = 40, thr = 10.83;
    function draw() {
      var mag = parseFloat(sMag.value) / 100 * 1.6 + 0.1;   // 0.1 .. 1.7
      var r = new Float64Array(N), i;
      for (i = 0; i < N; i++) r[i] = base[i] + (i >= onset ? mag : 0);
      var cs = new Float64Array(N + 1);
      for (i = 0; i < N; i++) cs[i + 1] = cs[i] + r[i];
      var g = new Float64Array(N), delay = -1;
      for (i = 0; i < N; i++) {
        var bestv = 0, lo = Math.max(0, i - Mw + 1), th;
        for (th = lo; th <= i; th++) {
          var len = i - th + 1, s = cs[i + 1] - cs[th], v = s * s / len;
          if (v > bestv) bestv = v;
        }
        g[i] = bestv;
        if (delay < 0 && i >= onset && g[i] > thr) delay = i - onset;
      }
      var f = fit(cv), ctx = f.ctx, w = f.w, h = f.h, pad = 26; ctx.clearRect(0, 0, w, h);
      var midy = h * 0.46, x0 = pad, x1 = w - pad;
      function X(k) { return x0 + k / N * (x1 - x0); }
      // residual (top)
      var rmax = 4;
      ctx.strokeStyle = INK; ctx.lineWidth = 0.6; ctx.beginPath();
      for (i = 0; i < N; i++) { var y = midy - 6 - (r[i] / rmax) * (midy - 16); if (i === 0) ctx.moveTo(X(i), y); else ctx.lineTo(X(i), y); }
      ctx.stroke();
      ctx.strokeStyle = RUST; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(X(onset), 10); ctx.lineTo(X(onset), h - 16); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = MUTE; ctx.font = "10px monospace"; ctx.fillText("residual", x0, 12); ctx.fillText("GLR", x0, midy + 12);
      // GLR (bottom)
      var gmax = Math.max(thr * 1.5, Math.max.apply(null, Array.prototype.slice.call(g)));
      ctx.strokeStyle = TEAL; ctx.lineWidth = 1.2; ctx.beginPath();
      for (i = 0; i < N; i++) { var yy = (h - 16) - (g[i] / gmax) * (h - 16 - midy - 6); if (i === 0) ctx.moveTo(X(i), yy); else ctx.lineTo(X(i), yy); }
      ctx.stroke();
      var ythr = (h - 16) - (thr / gmax) * (h - 16 - midy - 6);
      ctx.strokeStyle = RUST; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.moveTo(x0, ythr); ctx.lineTo(x1, ythr); ctx.stroke(); ctx.setLineDash([]);
      var msg = delay < 0 ? "<b style='color:" + RUST + "'>not detected</b>" : "detected after <b style='color:" + TEAL + "'>" + delay + "</b> samples";
      read.innerHTML = "fault size <b>" + mag.toFixed(2) + " sigma</b> &rarr; " + msg;
      cap.textContent = "The generalized likelihood ratio maximizes over the unknown fault onset, so it acts as a matched detector. A larger fault clears the threshold sooner; a small one can take many samples, or hide in the noise.";
    }
    sMag.addEventListener("input", draw); window.addEventListener("resize", draw); draw();
  })();

  // ---- E. Adaptive threshold under varying load ----
  (function () {
    var cv = document.getElementById("ex-a-canvas"); if (!cv) return;
    var sKu = document.getElementById("ex-a-ku"), read = document.getElementById("ex-a-read"),
        cap = document.getElementById("ex-a-cap");
    var N = 300, onset = 220, g = gauss(N, 83), i;
    var load = new Float64Array(N), r = new Float64Array(N);
    for (i = 0; i < N; i++) { load[i] = 0.5 + 0.5 * Math.abs(Math.sin(2 * Math.PI * i / 80)); r[i] = Math.abs(g[i] * (0.25 + 0.5 * load[i]) + (i >= onset ? 1.4 : 0)); }
    function draw() {
      var ku = parseFloat(sKu.value) / 100 * 2.2;          // 0 .. 2.2
      var base = 0.4, meanLoad = 0; for (i = 0; i < N; i++) meanLoad += load[i]; meanLoad /= N;
      var fixed = base + ku * meanLoad, faFixed = 0, faAdapt = 0;
      for (i = 0; i < onset; i++) { if (r[i] > fixed) faFixed++; if (r[i] > base + ku * load[i]) faAdapt++; }
      var f = fit(cv), ctx = f.ctx, w = f.w, h = f.h, pad = 28; ctx.clearRect(0, 0, w, h);
      var x0 = pad, x1 = w - pad, y1 = h - pad, yt = 14, ymax = 3.2;
      function X(k) { return x0 + k / N * (x1 - x0); } function Y(v) { return y1 - v / ymax * (y1 - yt); }
      ctx.strokeStyle = INK; ctx.lineWidth = 0.6; ctx.beginPath();
      for (i = 0; i < N; i++) { if (i === 0) ctx.moveTo(X(i), Y(r[i])); else ctx.lineTo(X(i), Y(r[i])); } ctx.stroke();
      ctx.strokeStyle = TEAL; ctx.lineWidth = 1.3; ctx.beginPath();
      for (i = 0; i < N; i++) { var t = base + ku * load[i]; if (i === 0) ctx.moveTo(X(i), Y(t)); else ctx.lineTo(X(i), Y(t)); } ctx.stroke();
      ctx.strokeStyle = MUTE; ctx.setLineDash([5, 3]); ctx.beginPath(); ctx.moveTo(x0, Y(fixed)); ctx.lineTo(x1, Y(fixed)); ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = RUST; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(X(onset), yt); ctx.lineTo(X(onset), y1); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = MUTE; ctx.font = "10px monospace"; ctx.fillText("|residual|", x0, 11); ctx.fillStyle = TEAL; ctx.fillText("adaptive", x1 - 92, 11); ctx.fillStyle = MUTE; ctx.fillText("fixed", x1 - 36, 11);
      read.innerHTML = "false alarms before the fault: fixed <b style='color:" + RUST + "'>" + faFixed + "</b> vs adaptive <b style='color:" + TEAL + "'>" + faAdapt + "</b>";
      cap.textContent = "Model uncertainty makes the healthy residual grow with load. A fixed threshold either false-alarms at high load or misses at low load; a threshold that scales with the operating point holds the false-alarm rate roughly constant.";
    }
    sKu.addEventListener("input", draw); window.addEventListener("resize", draw); draw();
  })();
})();
