# Decision map

Start from the question you have, not the method you know.

| If you are asking | Reach for |
| --- | --- |
| Does the model explain the data (residual white)? | Ljung-Box |
| A fast one-number whiteness screen? | Durbin-Watson |
| Does the residual linger on one side (bias)? | runs test |
| Are a Kalman filter's innovations the right size? | NIS |
| Is the filter's covariance honest (a design check)? | NEES |
| Are the innovations correlated in time? | innovation whiteness |
| Build a residual that ignores the unknown state? | parity-space residual |
| Which sensor or actuator failed? | structured residuals |

## Order of work for model-based FDI

1. Build a residual generator: an observer, a Kalman filter, or a parity relation from the model.
2. Calibrate on healthy data: estimate Q and R and confirm the residual is white and zero-mean.
3. Test whiteness online with `ljung_box` and `durbin_watson`; non-white means unmodeled dynamics or a fault.
4. Test magnitude with the windowed `nis`; innovations larger than predicted mean a sensor or covariance fault.
5. Certify the filter at design time with `nees` over Monte Carlo runs.
6. Isolate with structured residuals: `isolate_by_signature` matches the firing pattern to a fault.

## Going further (references 04-08)
Generate the residual with `luenberger_observer`/`observer_residual`, decouple a disturbance with `unknown_input_observer`, or isolate sensors with `generalized_observer_scheme`. Make the decision robust with `glr_detector` (abrupt faults), `adaptive_threshold` (load-varying), or `interval_observer` (guaranteed). Estimate the fault size with `augmented_fault_kalman`, `pi_observer`, or `imm_filter`. Sharpen the tests with `cumulative_periodogram`, `arch_test`, and `cusum_residual`. When no model is available, learn the residual with `dd_parity` or `reconstruction_residual`.
