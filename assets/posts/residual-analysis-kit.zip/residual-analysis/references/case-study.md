# Worked case study: a degrading sensor in an observer

A two-state process is watched by three sensors through a Kalman filter. At
sample 200 of a 360-sample record, sensor 2 degrades (its noise
inflates). All numbers are produced by the engine.

## Step 1 - generate the residual
The filter produces innovations that are zero-mean and inside their predicted
covariance while healthy, the white, self-scaled baseline the theory promises.

## Step 2 - detect with NIS
NIS averages 2.58 before the fault (chi-square expectation
3, upper band 4.16) and jumps to 13.14
after, flagging the fault at sample 200 with no ground truth.

## Step 3 - read the whiteness tests
Ljung-Box on the faulty channel moves only from p=0.125 to
p=0.054, and Durbin-Watson stays near 2 at 1.85. The
residual is still white: a noise-variance fault inflates magnitude, not
time-correlation. That is why whiteness and NIS are run together.

## Step 4 - isolate
Per-channel normalized innovations read 0.86, 2.62,
0.88 in standardized units, so only sensor 2's residual fires. The
firing pattern matches a single signature column, isolating the fault uniquely.

## Verdict
Generate a residual, test whiteness and magnitude together, then isolate by
signature. Detection says something changed; the pattern of which tests fire
says what.
