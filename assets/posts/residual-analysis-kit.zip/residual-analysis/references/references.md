# References

- Box & Pierce (1970), JASA 65; Brockwell & Davis (1991), Time Series: Theory and Methods.
- Ljung & Box (1978), Biometrika 65; Box, Jenkins & Reinsel (2008), Time Series Analysis.
- Durbin & Watson (1950, 1951), Biometrika 37 and 38.
- Kalman (1960), J. Basic Eng. 82; Mehra & Peschon (1971), Automatica 7 (innovations approach).
- Bar-Shalom, Li & Kirubarajan (2001), Estimation with Applications to Tracking and Navigation.
- Bar-Shalom, Li & Kirubarajan (2001); Mehra & Peschon (1971), Automatica 7.
- Chow & Willsky (1984), IEEE Trans. Automat. Control 29; Gertler (1998), Fault Detection and Diagnosis in Engineering Systems.
- Gertler (1998), Fault Detection and Diagnosis; Isermann (2006), Fault-Diagnosis Systems; Ding (2013), Model-Based Fault Diagnosis Techniques.