# Data-driven residual generation

_When no first-principles model is at hand, the residual can be learned from healthy data. These two close the loop: parity relations identified from data, and a reconstruction residual from a learned subspace._

## Data-driven parity space

**Essence.** Parity relations identified directly from healthy input-output data rather than from a state-space model. The left null space of a stacked data matrix gives generators that annihilate normal data, so applied to new data they yield a residual that grows under a fault, the model-free counterpart to the parity space.

**In plain words.** The classical parity space needs a state-space model to compute the relations that should hold among inputs and outputs. When such a model is unavailable or untrustworthy, the same relations can be learned from data. Stacking windows of inputs and outputs from healthy operation into a matrix, its dominant directions describe how normal data move, and its smallest directions, the left null space, are combinations that are essentially constant, zero up to noise, for any healthy window. Those combinations are the data-driven parity relations: apply them to a fresh window and the result stays near zero in health and departs under a fault. It is identification and residual design in one, closely related to subspace system identification, and it inherits the parity space's clean fault sensitivity without ever writing down a model.

**Diagnostic example.** A subsystem with no reliable physical model is logged through healthy operation. The learned parity relations produce a residual that hovers near zero on validation data and jumps cleanly when a sensor later biases, giving model-based-quality detection from data alone.

**Engine call.** `dd_parity(U, Y, s, W=None, mean=None)`

```python
# see scripts/residuals.py
train = dd_parity(U_healthy, Y_healthy, s=2)
test = dd_parity(U_new, Y_new, s=2, W=train["W"], mean=train["mean"])
test["residual"]      # near zero in health, jumps at a fault
```

**Practical note.** The relations are only valid in the operating regime the training data covered, so a benign change of operating point can look like a fault; train across the full envelope or schedule by regime. It needs genuinely healthy, sufficiently exciting training data. The window order sets how much dynamics the relations capture, like the parity-window length.

**Reference.** Ding (2014), Data-Driven Design of Fault Diagnosis Systems; Qin (2012), Annu. Rev. Control 36.

## Reconstruction residuals (PCA / autoencoder)

**Essence.** A residual from a learned model of normal data: project onto the healthy subspace and reconstruct, and the reconstruction error is the residual. Small for normal operation, large when a fault pushes data off the learned manifold, it is the squared-prediction-error of the multivariate monitoring world.

**In plain words.** If the healthy data live near a low-dimensional surface, a model of that surface gives a residual for free. Principal component analysis finds the leading linear subspace of the healthy data; projecting a new sample onto it and reconstructing leaves an error, the part of the sample that does not lie on the healthy manifold. That reconstruction error, the squared-prediction-error or Q statistic, is small for normal operation and large when a fault moves the data off the manifold, so it is a residual built entirely from data. An autoencoder generalizes the idea to a nonlinear manifold, learning an encoder and decoder whose reconstruction error plays the same role, but the linear version already connects this directly to the Q statistic in your multivariate-monitoring toolkit.

**Diagnostic example.** Several correlated sensors normally move together on a two-dimensional subspace. When one drifts and breaks the correlation, the sample no longer reconstructs from the learned subspace, its reconstruction error jumps past the healthy control limit, and the off-manifold fault is flagged even though each sensor alone looks plausible.

**Engine call.** `reconstruction_residual(X_train, X_test, k)`

```python
# see scripts/residuals.py
rc = reconstruction_residual(X_train_healthy, X_test, k=2)
fault = rc["spe"] > rc["limit"]      # off-manifold data exceeds the Q limit
```

**Practical note.** The number of retained components sets the split between signal and residual; too many and faults hide in the kept subspace, too few and normal variation inflates the residual. It assumes the fault leaves the learned manifold, so a fault that moves data along it is invisible to the reconstruction error and needs a complementary score. Standardize features and validate the control limit out of sample.

**Reference.** Jackson & Mudholkar (1979), Technometrics 21; Qin (2003), J. Chemometrics 17.
