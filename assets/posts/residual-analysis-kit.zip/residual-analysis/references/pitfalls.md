# Pitfalls and assumptions

Read before presenting any alarm, statistic, or isolation as a verdict.

## Residual autocorrelation and runs

Estimate the band from the healthy residual length, and read the autocorrelation and the runs test together, since one catches correlated dynamics and the other a standing bias. A residual built from a model fitted to the same data will look whiter than it is, so validate on held-out healthy data. A few bars just past the band at random lags is expected; a coherent lobe at low lags is the real signal.

## Ljung-Box test

Choose the number of lags to cover the dynamics you fear without diluting the statistic, a common choice is around ten to twenty for short memory. Subtract the number of fitted parameters from the degrees of freedom when the residual comes from an identified model, or the test runs optimistic. It assumes a stationary residual; a changing operating point will show as false correlation, so test within a regime.

## Durbin-Watson

Treat Durbin-Watson as a screen, not a verdict: it sees only lag one, so confirm a value far from 2 with Ljung-Box across more lags. The classical critical values assume a regression residual with fixed regressors; for a filter innovation use it descriptively and lean on the chi-square tests for the formal decision.

## Kalman innovations

The innovation is only white and correctly scaled if the model and the noise covariances Q and R are right, so estimate Q and R from healthy data first; a wrong R will make the innovations look inconsistent with no fault present. Check zero-mean, whiteness, and magnitude separately, since a bias, an unmodeled dynamic, and a covariance error leave different fingerprints.

## NIS: normalized innovation squared

NIS needs no ground truth, which makes it the online monitor, but it does need a trustworthy innovation covariance, so it is only as good as the filter's Q and R. Average over a window rather than reacting to a single sample, and set the band from the chi-square for that window. A persistent NIS above the band is a fault or a model error; a persistent NIS below it means the filter is conservative.

## NEES: normalized estimation error squared

NEES requires the true state, so it lives in simulation: run many Monte Carlo trajectories and average. Above the band means an overconfident covariance, the dangerous case that will mask faults, so tune Q and R until NEES sits inside before deployment. It certifies the filter, not the field data, so pair it with NIS once the filter is running.

## Parity-space residuals

The parity window order trades detectability against noise: a longer window gives more parity relations but accumulates noise, so choose it from the fault directions you need to see. The construction assumes a known, linear, time-invariant model; for nonlinear or scheduled systems, linearize per operating point. Parity and observer residuals are mathematically equivalent, so pick the better-conditioned one.

## Structured residuals and isolation

Isolation is only as good as the design: check in advance that every fault you care about has a distinct column in the signature matrix, since two faults that share a column can be detected but never told apart. Set residual thresholds from healthy data, and prefer robust or directional residual designs when disturbances would otherwise corrupt the firing pattern.
