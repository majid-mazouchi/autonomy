# Residual generation: the other half

_The opening sections evaluate a residual; these build it. A residual is only as good as its design, sensitive to faults and blind to disturbances, and the observer is the workhorse generator alongside the parity space._

## Observer-based residual generation

**Essence.** A Luenberger observer estimates the state from the model and the measurements; the leftover output error is the residual. By placing the error-dynamics poles, the designer fixes how fast it settles, and the fault detection filter shapes which faults appear in which directions.

**In plain words.** The parity space builds a residual from a window of data; an observer builds one recursively. It runs a model of the plant in parallel with the real system, correcting its state estimate by a gain times the output error, and that output error, the innovation, is the residual. Pole placement sets the eigenvalues of the estimation-error dynamics, trading settling speed against noise sensitivity. With the model correct the residual is near zero plus noise; a fault the observer does not model drives it away from zero. The Beard-Jones fault detection filter is the same idea with the gain chosen so that each fault forces the residual into a fixed, known direction, which turns detection into isolation.

**Diagnostic example.** A thermal model of a motor is run as an observer. In health the output residual sits in a tight band; when a cooling fault develops, the unmodeled heat drives the residual out of the band, and because the filter was designed with structured gains, the residual moves along the direction assigned to cooling faults.

**Engine call.** `luenberger_observer(A, C, poles); observer_residual(A, B, C, L, u, y)`

```python
# see scripts/residuals.py
L = luenberger_observer(A, C, poles=[0.2, 0.25])
res = observer_residual(A, B, C, L, u, y)["residual"]
# residual ~ noise under the model, steps away at a fault
```

**Practical note.** Pole placement is a tradeoff: fast poles reject disturbances quickly but amplify noise, slow poles smooth noise but lag a fault. The model must be good, since modelling error looks like a permanent fault. For multi-output systems the fault detection filter's directional design needs the fault directions to be distinguishable, which is a structural property to check before relying on isolation.

**Reference.** Luenberger (1971), IEEE TAC 16; Beard (1971) and Jones (1973); Chen & Patton (1999), Robust Model-Based FDI.

## Unknown input observer

**Essence.** An observer designed so its residual is decoupled from a disturbance that enters through a known direction. The residual then responds to faults but not to the disturbance, the classic route to a robust residual that does not false-alarm on a modelled nuisance input.

**In plain words.** A plain observer reacts to everything the model omits, including disturbances that are not faults, so it false-alarms whenever a known disturbance acts. The unknown input observer removes that sensitivity by construction. Given the direction through which the disturbance enters the state, it transforms the estimation so the disturbance is annihilated, leaving error dynamics that the designer can still stabilize by pole placement. The residual is then provably insensitive to that disturbance while remaining sensitive to faults in other directions. The price is an existence condition, the disturbance must be observable in a particular sense, rank of the output times the disturbance direction equal to the disturbance dimension, and detectability of the decoupled pair.

**Diagnostic example.** A vehicle thermal observer is disturbed by ambient temperature swings that are not faults. Designing an unknown input observer that decouples the ambient direction leaves a residual flat through the swings, so when a sensor bias appears the residual rises against a quiet background instead of being lost in disturbance-driven noise.

**Engine call.** `unknown_input_observer(A, B, C, E, poles); uio_residual(uio, u, y)`

```python
# see scripts/residuals.py (needs rank(C E) = rank(E))
uio = unknown_input_observer(A, B, C, E, poles=[0.2, 0.25])
res = uio_residual(uio, u, y)["residual"]
# flat under the disturbance E, responsive to faults
```

**Practical note.** The decoupling only holds for the disturbance directions you build in, so the disturbance model must be right; an unmodelled disturbance still leaks through. The existence conditions can fail, in which case no full-order unknown input observer exists and you fall back to an approximate or optimal robust design. Decoupling can also reduce fault sensitivity, so check the fault is still detectable after decoupling.

**Reference.** Chen & Patton (1999), Robust Model-Based FDI; Darouach et al. (1994), IEEE TAC 39.

## Dedicated and generalized observer schemes

**Essence.** A bank of observers, each driven by a different subset of the sensors, so a fault in one sensor disturbs every observer except the one that ignores it. The pattern of which residuals fire isolates the faulty sensor, turning a bank of detectors into an isolator.

**In plain words.** One residual detects; isolation needs several with a known fault-to-residual pattern. The generalized observer scheme builds that pattern structurally. It runs one observer per sensor, each using all the outputs except its own, so observer i is by construction insensitive to a fault in sensor i but sensitive to faults in any other sensor. When sensor i fails, every observer except the i-th sees the corrupted signal and its residual fires, while observer i stays clean, so the one quiet residual names the fault. The dedicated observer scheme is the dual arrangement, each observer driven by a single sensor. Both convert a set of observers into a structured-residual isolator without a hand-built signature table.

**Diagnostic example.** A three-sensor drive has a bank of three observers, each excluding one sensor. A bias on sensor two lifts the residuals of the observers that use sensor two while the observer that excludes it stays in band, so the clean observer points directly at sensor two as the fault.

**Engine call.** `generalized_observer_scheme(A, B, C, poles, u, y)`

```python
# see scripts/residuals.py
gos = generalized_observer_scheme(A, B, C, poles=[0.2, 0.25], u=u, y=y)
gos["norms"]      # residual norm per observer
gos["cleanest"]   # the observer that excludes the faulty sensor
```

**Practical note.** Isolation needs the faults to be structurally distinguishable; sensors that always appear together cannot be told apart by exclusion. Each observer must be detectable from its reduced sensor set, which can fail when too many sensors are dropped. The scheme isolates sensor faults cleanly but actuator and process faults need the dual or a mixed design.

**Reference.** Clark (1978), IEEE TAES; Frank (1990), Automatica 26; Chen & Patton (1999).
