# Sharper whiteness and consistency tests

_The opening whiteness tests catch linear autocorrelation; these catch what they miss, periodic structure in the frequency domain, a change in variance, and a slow drift in the mean._

## Cumulative periodogram

**Essence.** Bartlett's whiteness test in the frequency domain. The normalized cumulative sum of the residual's periodogram follows the diagonal for white noise; periodic or colored structure makes it bow away beyond a Kolmogorov band, catching narrowband content the autocorrelation can smear.

**In plain words.** The autocorrelation tests look at the residual in the time domain and can blur a concentrated periodic component across several lags. The cumulative periodogram looks in the frequency domain instead. White noise has a flat spectrum, so the running cumulative sum of its periodogram rises in a straight diagonal line from zero to one across frequency. A periodic or colored residual has its power concentrated at some frequencies, so the cumulative curve climbs steeply there and bows away from the diagonal, and a Kolmogorov-type band says how far it may stray under whiteness before the departure is significant. It is especially good at exposing a single tonal component, a once-per-revolution leakage, that a time-domain test would dilute.

**Diagnostic example.** A residual that passes the Ljung-Box test still hides a faint tone at the shaft rate. Its cumulative periodogram shows a sharp step at that frequency, climbing well outside the band, revealing a periodic disturbance the lag-based test averaged away.

**Engine call.** `cumulative_periodogram(r)`

```python
# see scripts/residuals.py
cp = cumulative_periodogram(residual)
cp["white"]      # False if the curve bows outside the band
```

**Practical note.** It assumes the rest of the residual is otherwise white, so a broadband-colored residual will fail for reasons other than a tone. The band is asymptotic, so it needs a reasonable record length. It is a complement to, not a replacement for, the time-domain whiteness tests; use them together.

**Reference.** Bartlett (1955), Stochastic Processes; Priestley (1981), Spectral Analysis and Time Series.

## ARCH / heteroscedasticity test

**Essence.** Engle's test for a time-varying residual variance. A residual can pass every mean-whiteness test yet have its variance cluster or grow, the signature of an intermittent or developing fault; regressing the squared residual on its own lags exposes it.

**In plain words.** The whiteness tests check that the residual has no correlation in its mean, but they say nothing about its variance, which can change over time even when the mean stays white. Such conditional heteroscedasticity, volatility that clusters, is itself a fault signature: an intermittent fault, a loosening part, or a developing wear process inflates the residual's spread in bursts. Engle's test detects it by regressing the squared residual on its own recent past; if the squared residual is predictable from its history, its variance is time-varying, and the test's statistic, the sample size times the regression's goodness of fit, is large with a small p-value. It catches a class of faults the mean-based tests are blind to.

**Diagnostic example.** A bearing residual stays zero-mean and uncorrelated, so the whiteness tests pass, but its variance swells in bursts as a spall intermittently loads. The ARCH test, seeing the squared residual cluster, returns a tiny p-value and flags the changing variance the other tests missed.

**Engine call.** `arch_test(r, lags=5)`

```python
# see scripts/residuals.py
at = arch_test(residual, lags=5)
at["heteroscedastic"], at["pvalue"]   # variance change in the residual
```

**Practical note.** It assumes the mean is already white, so remove any mean structure first or the test conflates the two. The number of lags sets which timescale of volatility you probe. A significant result says the variance is time-varying, not why, so follow it with a look at when the bursts occur.

**Reference.** Engle (1982), Econometrica 50; Bollerslev (1986), J. Econometrics 31.

## CUSUM of residuals (structural stability)

**Essence.** The Brown-Durbin-Evans cumulative-sum test for a slow drift in the residual mean. The running sum of standardized residuals stays within a widening boundary if the model holds throughout; crossing it signals that the mean drifted, a slow fault or a model that has stopped fitting.

**In plain words.** A fault need not be abrupt; a residual mean can creep away from zero so gradually that no single sample looks wrong and a whiteness test on a short window sees nothing. Accumulating the residual exposes the creep. The Brown-Durbin-Evans test forms the cumulative sum of standardized residuals and compares its path to a pair of boundary lines that widen with time to keep a constant false-alarm rate under stability. While the residual is genuinely zero-mean the cumulative sum wanders like a bounded random walk and stays inside; once a persistent bias sets in, the sum drifts steadily and eventually breaches a boundary, dating the loss of fit. It is the model-validation counterpart of the CUSUM change detectors, watching for structural drift rather than an abrupt jump.

**Diagnostic example.** A model fitted on fresh hardware slowly degrades as a component ages. Each window's residual looks acceptable, but the cumulative sum drifts monotonically and breaches its boundary after weeks, flagging that the model no longer represents the aged system and should be re-identified.

**Engine call.** `cusum_residual(r)`

```python
# see scripts/residuals.py
cu = cusum_residual(residual)
cu["stable"]     # False if the path breaches the boundary (drift)
```

**Practical note.** The standardization assumes the no-fault residual is zero-mean with an estimated variance; a biased baseline trips it immediately. It is tuned for slow drift, so an abrupt jump is better served by a CUSUM or generalized likelihood ratio detector. Reading where the path breaches dates the drift but only approximately.

**Reference.** Brown, Durbin & Evans (1975), J. R. Stat. Soc. B 37; Ploberger & Kramer (1992), Econometrica 60.
