# Innovation consistency, is the filter telling the truth?

_An observer or Kalman filter turns a model into a residual generator: the innovation, measurement minus prediction. Under the correct model it is zero-mean, white, and exactly as large as the filter's own covariance says. These checks test that promise, and are the core of observer-based detection._

## Kalman innovations

**Essence.** The innovation is the one-step prediction error of a Kalman filter, and under the correct model it is a zero-mean white sequence with a known covariance. It is the residual that observer-based FDI watches.

**In plain words.** A Kalman filter predicts the next measurement, then corrects its state when the real measurement arrives. The gap between the two, the innovation, is what the filter could not anticipate. If the model and noise statistics are right, that gap should be unpredictable: zero on average, uncorrelated in time, and scattered with exactly the covariance the filter computes from its own uncertainty and the measurement noise. That makes the innovation a self-calibrating residual, it carries its own yardstick, so a fault that the model does not include shows up as innovations that are biased, correlated, or simply too large for their predicted band, without any need for the true state.

**Diagnostic example.** A state estimator tracks battery state of charge from current and voltage. While healthy, the voltage innovation sits inside its predicted band; when the sensor begins to degrade, the innovations spread well beyond that band, the first observable sign of the fault.

**Engine call.** `kalman_filter(y, F, H, Q, R, x0, P0)`

```python
import numpy as np

def kalman_step(x, P, y, F, H, Q, R):
    x = F @ x;  P = F @ P @ F.T + Q          # predict
    nu = y - H @ x                            # innovation
    S = H @ P @ H.T + R                       # innovation covariance
    K = P @ H.T @ np.linalg.inv(S)
    x = x + K @ nu;  P = (np.eye(len(x)) - K @ H) @ P
    return x, P, nu, S                        # nu, S drive detection
```

**Practical note.** The innovation is only white and correctly scaled if the model and the noise covariances Q and R are right, so estimate Q and R from healthy data first; a wrong R will make the innovations look inconsistent with no fault present. Check zero-mean, whiteness, and magnitude separately, since a bias, an unmodeled dynamic, and a covariance error leave different fingerprints.

**Reference.** Kalman (1960), J. Basic Eng. 82; Mehra & Peschon (1971), Automatica 7 (innovations approach).

## NIS: normalized innovation squared

**Essence.** The Mahalanobis length of each innovation in its own predicted covariance. It follows a chi-square with as many degrees of freedom as outputs, so it tests innovation consistency without ever needing the true state.

**In plain words.** The innovation sequence carries its own covariance, so the natural consistency check is to normalize each innovation by that covariance: the normalized innovation squared is the innovation times the inverse of its predicted covariance times the innovation. Under the correct model this is a chi-square random variable with degrees of freedom equal to the number of measurements, so its average over a window should sit inside a tight chi-square band around that value. When the filter is right, the NIS stays in the band; when a fault makes the innovations larger than predicted, or a wrong noise model makes them inconsistent, the windowed NIS steps out. Because it uses only measured quantities, NIS is the workhorse online consistency monitor.

**Diagnostic example.** A windowed NIS runs on a navigation filter. A creeping scale-factor error on one sensor inflates the innovations beyond what the filter expects, and the averaged NIS climbs out of its upper chi-square bound while every individual reading still looks plausible.

**Engine call.** `nis(innov, S)`

```python
import numpy as np
from scipy import stats

def nis(innov, S):                 # innov: (n, m), S: (n, m, m)
    n, m = innov.shape
    vals = np.array([innov[k] @ np.linalg.inv(S[k]) @ innov[k]
                     for k in range(n)])
    lo = stats.chi2.ppf(0.025, n*m) / n
    hi = stats.chi2.ppf(0.975, n*m) / n
    return vals, (lo, hi)          # consistent if mean within band
```

**Practical note.** NIS needs no ground truth, which makes it the online monitor, but it does need a trustworthy innovation covariance, so it is only as good as the filter's Q and R. Average over a window rather than reacting to a single sample, and set the band from the chi-square for that window. A persistent NIS above the band is a fault or a model error; a persistent NIS below it means the filter is conservative.

**Reference.** Bar-Shalom, Li & Kirubarajan (2001), Estimation with Applications to Tracking and Navigation.

## NEES: normalized estimation error squared

**Essence.** The Mahalanobis length of the true estimation error in the filter's reported covariance. It needs ground truth, so it is the Monte Carlo design check that the covariance is honest, not over- or under-confident.

**In plain words.** NIS asks whether the innovations match the filter's expectation; NEES asks the deeper question of whether the filter's state covariance is itself believable. It is the true estimation error, the difference between the real state and the estimate, normalized by the filter's reported covariance. Because it needs the true state, it is computed in simulation over many Monte Carlo runs during design and tuning. Averaged across runs it should fall inside a chi-square band around the state dimension. Sitting above the band means the filter is overconfident, its covariance too small, the dangerous case where it will ignore a real fault; sitting below means it is conservative and sluggish. NEES is how you certify a filter before it ever sees a fault.

**Diagnostic example.** Before deployment, a tracking filter is run over sixty Monte Carlo trajectories and its averaged NEES plotted against the chi-square band. A version with the process noise set too low rides above the band, exposing an overconfident covariance that is corrected before it can mask a fault in the field.

**Engine call.** `nees(err, P)`

```python
import numpy as np
from scipy import stats

def nees(err, P):                  # err: (n, nx) true - estimate
    n, nx = err.shape
    vals = np.array([err[k] @ np.linalg.inv(P[k]) @ err[k]
                     for k in range(n)])
    lo = stats.chi2.ppf(0.025, n*nx) / n
    hi = stats.chi2.ppf(0.975, n*nx) / n
    return vals, (lo, hi)          # Monte Carlo consistency check
```

**Practical note.** NEES requires the true state, so it lives in simulation: run many Monte Carlo trajectories and average. Above the band means an overconfident covariance, the dangerous case that will mask faults, so tune Q and R until NEES sits inside before deployment. It certifies the filter, not the field data, so pair it with NIS once the filter is running.

**Reference.** Bar-Shalom, Li & Kirubarajan (2001); Mehra & Peschon (1971), Automatica 7.
