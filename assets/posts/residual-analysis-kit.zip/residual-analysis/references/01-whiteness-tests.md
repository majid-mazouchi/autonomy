# Whiteness tests, is the residual white?

_A correctly modeled residual is white noise: zero mean, no correlation from one sample to the next. Any structure that survives means the model missed something, an unmodeled dynamic or a fault. These tests decide whether that structure is there._

## Residual autocorrelation and runs

**Essence.** The sample autocorrelation is the direct picture of whiteness: a white residual stays inside a narrow band at every lag, while leftover dynamics or a fault push bars past it. The runs test adds a complementary check on sign.

**In plain words.** The autocorrelation function measures how much a residual at one time resembles itself a few samples later. For genuine white noise every lag should be near zero, scattered inside a band of roughly plus or minus two over the square root of the sample count; a bar that pokes out means the residual carries memory the model did not capture. The runs test looks at the same question from the side of sign: it counts how many times the residual switches sides of its median, because a residual that lingers on one side, too few runs, betrays a slow bias or drift even when each value looks ordinary. Read together they catch both correlated dynamics and standing offsets.

**Diagnostic example.** An observer for a thermal model leaves a residual that should be white. After a heat-exchanger fouls, the residual develops a slow positive lobe: its lag-one autocorrelation climbs past the band and the runs test sees a long stay above the median, both pointing to an unmodeled, fault-driven dynamic.

**Engine call.** `residual_acf(r, nlags=20); runs_test(r)`

```python
import numpy as np

def residual_acf(r, nlags=20):
    r = np.asarray(r, float) - np.mean(r); n = len(r)
    c0 = r @ r / n
    acf = [ (r[:n-k] @ r[k:]) / n / c0 for k in range(1, nlags+1) ]
    band = 1.96 / np.sqrt(n)          # white-noise 95% band
    return np.array(acf), band

acf, band = residual_acf(resid, 20)
not_white = np.any(np.abs(acf) > band)
```

**Practical note.** Estimate the band from the healthy residual length, and read the autocorrelation and the runs test together, since one catches correlated dynamics and the other a standing bias. A residual built from a model fitted to the same data will look whiter than it is, so validate on held-out healthy data. A few bars just past the band at random lags is expected; a coherent lobe at low lags is the real signal.

**Reference.** Box & Pierce (1970), JASA 65; Brockwell & Davis (1991), Time Series: Theory and Methods.

## Ljung-Box test

**Essence.** Pools the squared autocorrelations up to a chosen lag into one chi-square statistic, turning the whole autocorrelation picture into a single accept-or-reject of whiteness. The standard portmanteau whiteness test.

**In plain words.** Looking at each lag by eye is informal; the Ljung-Box test makes it a hypothesis test. It sums the squared autocorrelations from lag one up to a chosen horizon, each weighted to account for the shrinking sample at longer lags, into a single statistic Q. Under the null that the residual is white, Q follows a chi-square distribution whose degrees of freedom are the number of lags pooled, less any parameters already fitted to the data. A large Q, a small p-value, rejects whiteness: the residual carries correlation somewhere in those lags, which for a model-based detector is the headline alarm that the model no longer fits.

**Diagnostic example.** A Kalman filter's innovation channel is tested every window with Ljung-Box over ten lags. Through healthy operation Q sits well below its chi-square limit; once an actuator starts to lag, the innovations become correlated, Q climbs past the limit, and the detector flags an unmodeled dynamic.

**Engine call.** `ljung_box(r, lags=10, n_params=0)`

```python
import numpy as np
from scipy import stats

def ljung_box(r, lags=10, n_params=0):
    r = np.asarray(r, float) - np.mean(r); n = len(r)
    c0 = r @ r / n; Q = 0.0
    for k in range(1, lags+1):
        rho = (r[:n-k] @ r[k:]) / n / c0
        Q += rho*rho / (n - k)
    Q *= n * (n + 2)
    dof = max(1, lags - n_params)
    return Q, 1 - stats.chi2.cdf(Q, dof)

Q, p = ljung_box(resid, lags=10)   # p < 0.05 rejects whiteness
```

**Practical note.** Choose the number of lags to cover the dynamics you fear without diluting the statistic, a common choice is around ten to twenty for short memory. Subtract the number of fitted parameters from the degrees of freedom when the residual comes from an identified model, or the test runs optimistic. It assumes a stationary residual; a changing operating point will show as false correlation, so test within a regime.

**Reference.** Ljung & Box (1978), Biometrika 65; Box, Jenkins & Reinsel (2008), Time Series Analysis.

## Durbin-Watson

**Essence.** A single number that screens for lag-one autocorrelation: near 2 for a white residual, toward 0 for positive correlation, toward 4 for negative. The cheapest whiteness check.

**In plain words.** The Durbin-Watson statistic compares the sum of squared successive differences of the residual to the sum of squared residuals. When the residual is white, consecutive values are unrelated and the statistic lands near 2. Positive autocorrelation, the common case where the residual changes slowly, makes successive differences small and pulls the statistic toward 0; negative autocorrelation, where it alternates, pushes it toward 4. It only sees lag one, so it is a screen rather than a verdict, but it is instant to compute and a value far from 2 is a reliable early warning that the residual is not white.

**Diagnostic example.** A controller's tracking-error residual is logged with a one-number Durbin-Watson summary on each batch. A drop from about 2 toward 1 over successive batches flags creeping positive autocorrelation, prompting a fuller Ljung-Box test that confirms an unmodeled lag.

**Engine call.** `durbin_watson(r)`

```python
import numpy as np

def durbin_watson(r):
    r = np.asarray(r, float)
    d = np.sum(np.diff(r)**2) / np.sum(r**2)
    return d, 1 - d/2          # statistic, implied lag-1 correlation

dw, rho1 = durbin_watson(resid)   # dw near 2 => white
```

**Practical note.** Treat Durbin-Watson as a screen, not a verdict: it sees only lag one, so confirm a value far from 2 with Ljung-Box across more lags. The classical critical values assume a regression residual with fixed regressors; for a filter innovation use it descriptively and lean on the chi-square tests for the formal decision.

**Reference.** Durbin & Watson (1950, 1951), Biometrika 37 and 38.
