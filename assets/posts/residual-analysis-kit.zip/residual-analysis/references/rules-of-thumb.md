# Rules of thumb

1. A healthy residual is white and zero-mean. Engineer the generator so that holds, and then any departure, in correlation, mean, or magnitude, is a fault signal rather than noise.
2. Whiteness and magnitude are different faults. Ljung-Box and Durbin-Watson catch time-correlation from unmodeled dynamics; NIS catches innovations that are the wrong size from a sensor or covariance fault. Run both, because each is blind to the other's case.
3. Estimate the noise covariances from healthy data. A wrong measurement covariance R or process covariance Q makes the innovation consistency tests misfire with no fault present, so calibrate them before trusting an alarm.
4. NIS is the online monitor, NEES is the design check. NIS uses only measured innovations; NEES needs the true state and so lives in Monte Carlo simulation during tuning.
5. Judge a residual on a window, not a sample. One large innovation is noise; a sustained departure from the band is a fault. Set the band from the chi-square for the window length.
6. Design for isolation, do not hope for it. Make each structured residual blind to a subset of faults so every fault leaves a unique firing signature, and verify the signature columns are distinct before deployment.
7. Parity and observer residuals are duals. They span the same space; choose whichever exposes the fault directions you need and is numerically better conditioned.
8. Validate whiteness on healthy data first. A residual generator fitted to the data it is tested on always looks whiter than it is, so confirm on a held-out healthy record.

## Pick by scenario

| Scenario | Pick | Why |
| --- | --- | --- |
| Model or regression residual, anything unmodeled? | Ljung-Box | pools autocorrelations into one chi-square |
| Fast lag-one whiteness screen | Durbin-Watson | one number near 2 when white |
| Residual drifts to one side of zero | runs test | too few sign runs flags a bias |
| Kalman innovations too large for their band | NIS | chi-square consistency, no truth needed |
| Is the filter overconfident before deployment? | NEES | Monte Carlo check against ground truth |
| Innovations correlated in time | innovation whiteness | Ljung-Box on the innovation sequence |
| Residual that cancels the unknown state | parity-space residual | project onto the parity space |
| Identify which sensor or actuator failed | structured residuals | match the observed firing signature |
