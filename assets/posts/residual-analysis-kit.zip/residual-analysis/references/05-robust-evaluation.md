# Robust evaluation and thresholds

_A residual still has to be turned into a decision. These three sharpen that step: a matched detector for an abrupt fault, a threshold that follows the operating point, and a deterministic bound for guaranteed detection._

## Generalized likelihood ratio detection

**Essence.** A matched detector for an abrupt change of unknown size and onset in the residual mean. It maximizes the log-likelihood ratio over all recent onset times, giving a statistic that is quiet under the no-fault model and spikes once a bias appears, the residual-domain bridge to your change-detection methods.

**In plain words.** A fixed threshold on the raw residual ignores that a fault is often a structured change, a step in the mean, not just a single large sample. The generalized likelihood ratio test exploits that structure. For every possible onset time in a recent window it computes how much more likely the data are under a hypothesized step than under no change, and takes the maximum, so it is matched to a step of any size starting at any time. The statistic stays near zero while the residual is white and rises sharply once a sustained bias accumulates, with a chi-square threshold from the likelihood theory. It is the same sequential-detection logic as the CUSUM in your change-detection work, specialized to a residual with known noise covariance.

**Diagnostic example.** An observer residual on a sensor channel is white until a slow bias begins. The raw residual barely clears its band on any single sample, but the generalized likelihood ratio, accumulating the consistent offset since its onset, climbs past its threshold and declares the fault with an estimate of when it started.

**Engine call.** `glr_detector(r, sigma, m_max=40)`

```python
# see scripts/residuals.py
glr = glr_detector(residual, sigma=sigma_healthy, m_max=40)
fault = glr["glr"] > glr["threshold"]   # spikes after an abrupt bias
```

**Practical note.** It assumes the no-fault residual covariance is known, so estimate it from healthy data and re-check it. The search over onsets costs computation that grows with the window, so cap the window to the longest delay you can tolerate. It is tuned for abrupt changes; a very gradual drift is better matched by a different alternative hypothesis.

**Reference.** Willsky & Jones (1976), IEEE TAC 21; Basseville & Nikiforov (1993), Detection of Abrupt Changes.

## Adaptive thresholds

**Essence.** A threshold that scales with the operating point. Model uncertainty makes the healthy residual grow with load, so a fixed threshold misses faults at low load or false-alarms at high load; an adaptive threshold tracks the load and holds the false-alarm rate roughly constant.

**In plain words.** In practice the no-fault residual is never exactly zero, because the model is never exact, and its spread typically grows with the input or load, the larger the excitation the larger the modelling error. A single fixed threshold cannot serve the whole envelope: set it for high load and small faults at low load slip through, set it for low load and normal high-load operation trips it. An adaptive threshold makes the bound a function of the operating point, widening with load by an amount tuned to the model uncertainty, so the effective false-alarm rate stays roughly constant across conditions. It is the simplest form of the robustness that the unknown input observer pursues structurally.

**Diagnostic example.** A drivetrain observer's residual swells during hard acceleration purely from modelling error. A fixed threshold flags every aggressive maneuver; a threshold that rises with torque demand stays quiet through normal aggressive driving and still catches a genuine fault that exceeds the load-scaled bound.

**Engine call.** `adaptive_threshold(r, u, base, k_u)`

```python
# see scripts/residuals.py
at = adaptive_threshold(residual, u=load, base=0.2, k_u=0.15)
alarm = at["alarm"]      # |residual| > base + k_u*|load|
```

**Practical note.** The threshold is only as honest as the uncertainty model behind it; calibrate the load scaling on healthy data across the full operating envelope, not one condition. Too aggressive a scaling hides real faults at high load, so bound how far it can widen. It addresses false alarms from known operating-point effects, not from unmodelled disturbances, which need a decoupling design.

**Reference.** Emami-Naeini et al. (1988), Automatica 24; Ding (2013), Model-Based Fault Diagnosis Techniques.

## Set-membership (interval) residuals

**Essence.** A deterministic alternative to statistical thresholds. Given bounded process and measurement disturbances, it propagates a guaranteed envelope for the residual; while the measurement stays inside, no fault is possible, so an exceedance is a guaranteed detection rather than a probable one.

**In plain words.** Statistical thresholds accept a false-alarm rate and a missed-detection rate; sometimes you want a guarantee instead. Set-membership detection provides one by replacing probability distributions with hard bounds. If the process and measurement disturbances are known to lie within stated limits, the no-fault residual must lie within an envelope that those limits imply, computed by propagating the bounds through the observer error dynamics to a steady-state interval. As long as the measurement stays inside the envelope, the data are consistent with the healthy model and no fault has occurred; the moment it steps outside, a fault is certain, not merely likely. The cost is conservatism, the bound is wide, so only sufficiently large faults are guaranteed to be caught.

**Diagnostic example.** A battery-pack model with bounded sensor error and bounded current disturbance yields a guaranteed voltage-residual envelope. Through normal operation the residual stays strictly inside; when a cell fault pushes it past the envelope, the detection is certain, which is valuable for a safety case that cannot rest on a probabilistic threshold.

**Engine call.** `interval_observer(A, B, C, L, u, y, w_bound, v_bound)`

```python
# see scripts/residuals.py
iv = interval_observer(A, B, C, L, u, y, w_bound=0.06, v_bound=0.15)
alarm = iv["alarm"]      # leaving iv["envelope"] is a guaranteed detection
```

**Practical note.** The guarantee is only as good as the disturbance bounds; an optimistic bound gives false confidence, a loose one makes the envelope so wide that small faults are missed. The steady-state envelope here is conservative; tighter zonotopic or interval-observer methods reduce the wrapping but need more machinery and nonnegativity conditions. Use it where a guarantee matters more than sensitivity.

**Reference.** Milanese et al. (1996), Bounding Approaches to System Identification; Puig (2010), Int. J. Adapt. Control Signal Process.
