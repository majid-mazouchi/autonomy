# At a glance

| Method | Tests | Needs truth? | Output | Key assumption |
| --- | --- | --- | --- | --- |
| Residual ACF / runs | whiteness, bias | no | bars vs band, runs z | stationary residual |
| Ljung-Box | whiteness (pooled lags) | no | Q + p-value | stationary residual |
| Durbin-Watson | lag-1 autocorrelation | no | statistic near 2 | screen only |
| Kalman innovation | prediction error | no | residual + covariance | known model, Q, R |
| NIS | innovation magnitude | no | chi-square vs band | trustworthy S |
| NEES | covariance honesty | yes (Monte Carlo) | chi-square vs band | design-time truth |
| Parity residual | state-free detection | no | residual vector | known LTI model |
| Structured residuals | isolation | no | fault signature match | distinct signatures |

## Which test catches which fault

| Fault | Whiteness (Ljung-Box, DW) | Magnitude (NIS) | Isolation (structured) |
| --- | --- | --- | --- |
| Unmodeled dynamic / lag | fires | often fires | locates if structured |
| Sensor bias (absorbed states) | maybe (transient) | fires at onset | locates |
| Sensor noise increase | silent | fires (sustained) | locates |
| Actuator fault | fires | fires | locates |

A whiteness test and a magnitude test are complementary: a pure noise-variance
fault inflates NIS but stays white, while an unmodeled dynamic is caught by
whiteness. Run both.
