# Beyond detect and isolate: fault estimation

_Detection says a fault exists, isolation says where; estimation says how large. These three reconstruct the fault signal itself, the step that lets you accommodate a fault rather than only flag it._

## Fault-as-state estimation

**Essence.** Estimate a fault's magnitude by adding it to the state vector as an extra, slowly-varying state and running a Kalman filter on the enlarged model. The estimated fault state tracks an additive bias, turning detection into identification with no new machinery.

**In plain words.** The most direct way to estimate a fault is to make it part of what the filter estimates. Augment the state vector with the fault, model it as nearly constant (a slow random walk), and write down how it enters the dynamics or the measurements. A Kalman filter on this augmented model then estimates the fault alongside the true state, so its dedicated component reads off the fault magnitude in real time. It reuses the entire Kalman machinery, including the innovation as a residual, and degrades gracefully, the fault estimate is smoothed by the filter rather than jumping on every sample. The assumption is that the fault is slow relative to the dynamics, which holds for biases, drifts, and developing faults but not for instantaneous jumps.

**Diagnostic example.** An actuator develops a constant offset. Augmenting the state with that offset and filtering, the augmented Kalman filter's fault state climbs from zero and settles at the true bias within a few time constants, so the controller can be told not just that the actuator is faulty but by how much to compensate.

**Engine call.** `augmented_fault_kalman(A, B, C, Q, R, fault_dir, y, u=None)`

```python
# see scripts/residuals.py
af = augmented_fault_kalman(A, B, C, Q, R, fault_dir=B.ravel(), y=y, u=u)
af["fault"]      # estimated fault magnitude over time
```

**Practical note.** The fault must be observable from the augmented model; if it is not, the estimate drifts. The random-walk variance on the fault state tunes the speed-versus-noise tradeoff, like any process noise. It assumes a slow fault, so for abrupt faults pair it with a jump detector and reset, and watch that a persistent modelling error is not absorbed into the fault estimate.

**Reference.** Friedland (1969), IEEE TAC 14; Gillijns & De Moor (2007), Automatica 43.

## PI and sliding-mode observers for reconstruction

**Essence.** A proportional-integral observer adds an integral of the output error that accumulates into a fault estimate, reconstructing an additive fault online. The sliding-mode observer reconstructs it instead from the equivalent output-error injection, both recovering the fault signal rather than merely flagging it.

**In plain words.** A standard observer uses the output error proportionally to correct the state. A proportional-integral observer adds a second loop that integrates that error into an explicit fault estimate, so a persistent residual is driven into a reconstructed fault signal instead of biasing the state, much as integral action in a controller cancels a steady offset. The result tracks a developing fault, a drift or a ramp, in real time. The sliding-mode observer reaches the same goal by a different mechanism: it forces the estimation error to zero with a switching injection, and the average of that injection, the equivalent output-error injection, reconstructs the fault. Both turn the residual into an estimate of the fault itself, the basis for fault-tolerant control.

**Diagnostic example.** A slowly ramping sensor fault is reconstructed by a proportional-integral observer whose integral channel follows the ramp almost exactly, so downstream logic can subtract the reconstructed bias and keep using the sensor instead of discarding it.

**Engine call.** `pi_observer(A, B, C, L, Kf, fault_dir, u, y)`

```python
# see scripts/residuals.py
pio = pi_observer(A, B, C, L, Kf=[0, 0.18], fault_dir=B.ravel(), u=u, y=y)
pio["fault"]     # reconstructed fault signal
```

**Practical note.** The integral and proportional gains trade reconstruction speed against noise amplification and must be tuned together for stability. The sliding-mode variant needs care with chattering, usually a smoothed switching law. Both assume the fault enters through a known direction and that the system remains observable with the fault present.

**Reference.** Beale & Shafai (1989), Int. J. Control; Edwards, Spurgeon & Patton (2000), Automatica 36.

## Interacting multiple model

**Essence.** A bank of Kalman filters, one per hypothesized mode, healthy and one or more faulty, mixed each step by a Markov transition matrix. The posterior probability of each mode both detects and isolates: a rising probability for a faulty model names the fault, tying this to your Bayesian toolkit.

**In plain words.** When a system can be in one of several regimes, healthy or various faulty ones, a single model cannot serve all of them. The interacting multiple model estimator runs a Kalman filter for each candidate mode and maintains a probability over which mode is active, governed by a Markov chain of mode transitions. At each step it mixes the filters' estimates according to those probabilities, updates each filter, and reweights the mode probabilities by how well each predicted the new measurement. The output is a soft, continuously updated belief over modes, so the probability of a faulty mode rising toward one is simultaneously a detection and an isolation, and the estimate stays good across the switch because the filters are blended rather than chosen abruptly.

**Diagnostic example.** A sensor degrades partway through a run. An interacting multiple model with a healthy mode and a high-noise faulty mode keeps almost all probability on the healthy mode until the degradation begins, then shifts decisively to the faulty mode, both flagging the fault and identifying it as the sensor-noise regime.

**Engine call.** `imm_filter(y, models, Pi, mu0=None, u=None, B=None)`

```python
# see scripts/residuals.py
m0 = dict(F=A, H=C, Q=Q, R=R_healthy, x0=x0, P0=P0)
m1 = dict(F=A, H=C, Q=Q, R=R_faulty,  x0=x0, P0=P0)
imm = imm_filter(y, [m0, m1], Pi=[[0.97, 0.03], [0.03, 0.97]], u=u, B=B)
imm["mode_prob"]    # P(faulty mode) rises at the fault
```

**Practical note.** The mode set must contain the faults you expect; an unmodelled fault is forced into the nearest mode. The transition matrix encodes how often modes switch, and a too-sticky or too-jumpy choice blurs the result. Modes that fit the data equally well cannot be told apart, so design the faulty models to be distinguishable from healthy operation.

**Reference.** Blom & Bar-Shalom (1988), IEEE TAC 33; Mazor et al. (1998), IEEE TAES 34.
