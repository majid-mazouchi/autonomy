# Parity space, which fault?

_Detection says something is wrong; isolation says what. Parity relations build residuals that depend only on noise and faults, not on the unknown state, and structuring them so each is blind to certain faults gives every fault a distinct signature to match._

## Parity-space residuals

**Essence.** Projects a window of inputs and outputs onto the left null space of the observability matrix, producing a residual that cancels the unknown state and so depends only on noise and faults. The algebraic route to a residual.

**In plain words.** Over a short window, the stacked outputs of a linear system equal the observability matrix times the initial state plus a known term in the inputs. The state is unknown, but the part of the output space that the observability matrix cannot reach, its left null space, is not affected by the state at all. Projecting the measured window onto that parity space therefore removes the state entirely and leaves a residual built only from noise and any fault. With no fault the parity residual hovers at zero within the noise; a sensor or actuator fault drives it away from zero along a direction fixed by which signal failed, which is what makes isolation possible.

**Diagnostic example.** A redundant set of three sensors watches a two-state process, one more measurement than the state needs. The extra degree of freedom is a parity relation: while healthy its residual sits at zero, and when one sensor develops a bias the parity residual jumps cleanly, independent of where the process happens to be.

**Engine call.** `parity_matrix(A, C, s); parity_residual(W, Y)`

```python
import numpy as np

def parity_matrix(A, C, s):
    nx = A.shape[0]; O, Ap = [], np.eye(nx)
    for _ in range(s+1):
        O.append(C @ Ap); Ap = Ap @ A
    O = np.vstack(O)                       # extended observability
    U, sv, _ = np.linalg.svd(O)
    rank = int(np.sum(sv > 1e-9*sv[0]))
    return U[:, rank:].T                   # rows annihilate O

W = parity_matrix(A, C, s=3)
residual = W @ Y_window                    # zero when healthy
```

**Practical note.** The parity window order trades detectability against noise: a longer window gives more parity relations but accumulates noise, so choose it from the fault directions you need to see. The construction assumes a known, linear, time-invariant model; for nonlinear or scheduled systems, linearize per operating point. Parity and observer residuals are mathematically equivalent, so pick the better-conditioned one.

**Reference.** Chow & Willsky (1984), IEEE Trans. Automat. Control 29; Gertler (1998), Fault Detection and Diagnosis in Engineering Systems.

## Structured residuals and isolation

**Essence.** Designs a bank of residuals each insensitive to a chosen subset of faults, so every fault lights up a unique pattern. Isolation becomes reading off which fault signature the firing pattern matches.

**In plain words.** A single residual can detect a fault but cannot name it. Structured residuals solve that by design: each residual in a bank is made blind to some faults and sensitive to others, so that the set of residuals that fire, the firing pattern, is different for every fault. Those intended patterns are collected as columns of an incidence or signature matrix, one column per candidate fault. When residuals exceed their thresholds, the observed firing pattern is compared to the columns, and the closest-matching column names the fault. As long as the design gives every fault a distinct column, isolation is unambiguous; if two faults share a column they cannot be told apart, which the signature matrix makes obvious in advance.

**Diagnostic example.** Three structured residuals are designed so a sensor-one fault fires residuals one and three, a sensor-two fault fires two and three, and an actuator fault fires one and two. An observed pattern of residuals two and three firing matches only the sensor-two column, isolating the fault to that sensor.

**Engine call.** `isolate_by_signature(fired, signature)`

```python
import numpy as np

def isolate(fired, signature):     # signature: residuals x faults (0/1)
    sig = np.asarray(signature); fired = np.asarray(fired)
    scores = sig.shape[0] - np.sum(np.abs(sig - fired[:, None]), axis=0)
    best = int(np.argmax(scores))
    unique = np.sum(scores == scores[best]) == 1
    return best, unique            # which fault, and whether it is unambiguous

# columns: sensor1=[1,0,1], sensor2=[0,1,1], actuator=[1,1,0]
fault, ok = isolate([0,1,1], [[1,0,1],[0,1,1],[1,1,0]])
```

**Practical note.** Isolation is only as good as the design: check in advance that every fault you care about has a distinct column in the signature matrix, since two faults that share a column can be detected but never told apart. Set residual thresholds from healthy data, and prefer robust or directional residual designs when disturbances would otherwise corrupt the firing pattern.

**Reference.** Gertler (1998), Fault Detection and Diagnosis; Isermann (2006), Fault-Diagnosis Systems; Ding (2013), Model-Based Fault Diagnosis Techniques.
