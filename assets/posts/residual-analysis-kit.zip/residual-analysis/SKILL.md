---
name: residual-analysis
description: >-
  Choose and apply the right residual and innovation analysis for model-based
  fault detection and isolation: whiteness tests (Ljung-Box, Durbin-Watson,
  residual autocorrelation and runs) on model or observer residuals; innovation
  consistency on Kalman-filter innovations (NIS and NEES); and parity-space
  structured residuals for fault isolation. A going-further set adds residual
  generation (Luenberger and unknown-input observers, observer banks), robust
  evaluation (generalized likelihood ratio, adaptive and set-membership thresholds),
  fault estimation (augmented Kalman, PI observer, interacting multiple model),
  sharper tests (cumulative periodogram, ARCH, CUSUM of residuals), and data-driven
  generation (data-driven parity, reconstruction residuals). Use when the task is to
  decide whether a model still fits, detect a fault from a residual or innovation
  sequence, certify a filter's covariance, or isolate which sensor or actuator
  failed, and to generate correct Python.
---

# Residual and innovation analysis for model-based FDI

A progressive-disclosure skill for deciding whether a model still fits its system
and isolating the fault when it does not. Read this file first, then open only the
reference you need.

Overview
A model-based FDI scheme generates a residual (observer, Kalman filter, or parity
relation), evaluates whether it is consistent with the no-fault model, and isolates
the fault. Whiteness tests catch unmodeled dynamics; innovation consistency (NIS,
NEES) catches covariance and sensor faults; parity-space structured residuals
isolate which signal failed. A tested engine implements every method with numpy
and scipy only.

When to use this skill
Use it whenever a diagnostics task is about a residual or a Kalman filter: testing
whether a residual is white, checking that innovations are zero-mean and correctly
scaled, certifying a filter before deployment, or isolating a fault to a sensor or
actuator.

How to route a request
1. Is the residual white (model fit / unmodeled dynamics)? references/01-whiteness-tests.md (ljung_box, durbin_watson, residual_acf, runs_test)
2. Are a Kalman filter's innovations consistent in size? references/02-innovation-consistency.md (kalman_filter, nis, nees)
3. Which sensor or actuator failed? references/03-parity-space.md (parity_matrix, parity_residual, isolate_by_signature)
4. How do I generate a good residual (observer, disturbance decoupling, sensor isolation)? references/04-residual-generation.md (luenberger_observer, observer_residual, unknown_input_observer, uio_residual, generalized_observer_scheme)
5. How do I make the decision robust (abrupt fault, varying load, guaranteed bound)? references/05-robust-evaluation.md (glr_detector, adaptive_threshold, interval_observer)
6. How large is the fault (estimate or reconstruct it)? references/06-fault-estimation.md (augmented_fault_kalman, pi_observer, imm_filter)
7. Sharper whiteness or consistency tests (tones, variance, slow drift)? references/07-sharper-tests.md (cumulative_periodogram, arch_test, cusum_residual)
8. No model available, learn the residual from data? references/08-data-driven-generation.md (dd_parity, reconstruction_residual)
Always consult references/decision-map.md to confirm the choice and
references/pitfalls.md before trusting a number.

Reference docs
- `references/01-whiteness-tests.md` covers whiteness tests, is the residual white?.
- `references/02-innovation-consistency.md` covers innovation consistency, is the filter telling the truth?.
- `references/03-parity-space.md` covers parity space, which fault?.
- `references/04-residual-generation.md` covers residual generation.
- `references/05-robust-evaluation.md` covers robust evaluation and thresholds.
- `references/06-fault-estimation.md` covers beyond detect and isolate.
- `references/07-sharper-tests.md` covers sharper whiteness and consistency tests.
- `references/08-data-driven-generation.md` covers data-driven residual generation.
- `references/decision-map.md` maps every question to its test and the order of work.
- `references/rules-of-thumb.md` gives general heuristics and a scenario table.
- `references/at-a-glance.md` is the comparison table and the fault-to-test matrix.
- `references/case-study.md` runs the whole chain on one fault, a worked example.
- `references/pitfalls.md` lists the assumptions and failure modes.
- `references/references.md` is the bibliography.

Engine
scripts/residuals.py is the single source of truth. Import the named function from
each reference. Run it directly for a self-test:

    python scripts/residuals.py

Core functionalities
Test whiteness with ljung_box, durbin_watson, residual_acf, and runs_test. Build a
residual generator with kalman_filter and check innovation consistency with nis
(online) and nees (Monte Carlo design check). Generate a state-free residual with
parity_matrix and parity_residual, and isolate a fault with isolate_by_signature.
Going further: generate residuals with luenberger_observer/observer_residual,
unknown_input_observer/uio_residual (disturbance decoupling), and
generalized_observer_scheme (sensor isolation); decide robustly with glr_detector,
adaptive_threshold, and interval_observer; estimate fault size with
augmented_fault_kalman, pi_observer, and imm_filter; sharpen the tests with
cumulative_periodogram, arch_test, and cusum_residual; and learn the residual from
data with dd_parity and reconstruction_residual.

Conventions for generated answers
Estimate the noise covariances from a healthy reference, never from the record
under test. Run whiteness and magnitude tests together, since each is blind to the
other's fault. Judge a residual on a window. State the assumption that would change
the conclusion next to any reported value, and confirm signature columns are
distinct before claiming isolation.

Assets
assets/residual-analysis.html is the full illustrated monograph, with figures, a
worked example per method, three interactive explorers, and an end-to-end case
study.
