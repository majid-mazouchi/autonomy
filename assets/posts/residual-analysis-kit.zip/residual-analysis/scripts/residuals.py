"""
Residual and innovation analysis for model-based fault detection and isolation.

A model-based FDI scheme generates a residual (from an observer, a Kalman filter,
or a parity relation), evaluates whether that residual is consistent with the
no-fault model, and, when it is not, isolates which fault is responsible. This
engine collects the standard residual evaluators.

numpy and scipy only. Each function carries a short docstring in plain-text
sections. Code is illustrative: estimate noise statistics from healthy data,
check the assumptions, and calibrate thresholds out of sample.
"""
import numpy as np
from scipy import stats


# ===========================================================================
# whiteness tests: is the residual a white (uncorrelated) sequence?
# ===========================================================================
def residual_acf(r, nlags=20):
    """
    Purpose
    The sample autocorrelation of a residual sequence with its white-noise
    confidence band. A white residual stays inside the band; correlation that
    leaks past it signals unmodeled dynamics or a fault the model did not expect.

    Inputs
    r the residual sequence, nlags the number of lags.

    Outputs
    Dict with the autocorrelation at lags 1..nlags and the two-sided 95 percent
    band half-width.
    """
    r = np.asarray(r, float); r = r - r.mean(); n = len(r)
    c0 = np.dot(r, r) / n
    acf = np.array([np.dot(r[:n - k], r[k:]) / n / c0 for k in range(1, nlags + 1)])
    band = 1.96 / np.sqrt(n)
    return dict(lags=np.arange(1, nlags + 1), acf=acf, band=band)


def ljung_box(r, lags=10, n_params=0):
    """
    Purpose
    The Ljung-Box portmanteau test. It pools the squared autocorrelations of the
    residual up to a chosen lag into a single statistic and tests, against a
    chi-square, the null that the residual is white. A small p-value rejects
    whiteness, the model-based detector's headline alarm.

    Inputs
    r the residual, lags the number of lags to pool, n_params the number of
    parameters already fitted to the data (subtracted from the degrees of freedom).

    Outputs
    Dict with the Q statistic, degrees of freedom, p-value, and a white flag.
    """
    r = np.asarray(r, float); r = r - r.mean(); n = len(r)
    c0 = np.dot(r, r) / n
    Q = 0.0
    for k in range(1, lags + 1):
        rho = np.dot(r[:n - k], r[k:]) / n / c0
        Q += rho * rho / (n - k)
    Q *= n * (n + 2)
    dof = max(1, lags - n_params)
    p = 1 - stats.chi2.cdf(Q, dof)
    return dict(Q=float(Q), dof=dof, pvalue=float(p), white=bool(p > 0.05))


def durbin_watson(r):
    """
    Purpose
    The Durbin-Watson statistic, a fast check for lag-one autocorrelation in a
    residual. It runs near 2 for a white residual, toward 0 for positive
    correlation, toward 4 for negative. It is the cheapest whiteness screen.

    Inputs
    r the residual sequence.

    Outputs
    Dict with the Durbin-Watson statistic and the implied lag-one correlation.
    """
    r = np.asarray(r, float); dr = np.diff(r)
    d = float(np.dot(dr, dr) / np.dot(r, r))
    return dict(dw=d, rho1=float(1 - d / 2))


def runs_test(r):
    """
    Purpose
    The Wald-Wolfowitz runs test for randomness of sign about the median. Too few
    runs means the residual lingers on one side, a slow bias or drift; too many
    means it alternates. A complement to the correlation-based tests.

    Inputs
    r the residual sequence.

    Outputs
    Dict with the run count, its expected value, the z-score, and the p-value.
    """
    r = np.asarray(r, float); s = np.sign(r - np.median(r)); s = s[s != 0]
    n = len(s); runs = 1 + int(np.sum(s[1:] != s[:-1]))
    n1 = int(np.sum(s > 0)); n2 = n - n1
    mu = 1 + 2 * n1 * n2 / n
    var = 2 * n1 * n2 * (2 * n1 * n2 - n) / (n * n * (n - 1))
    z = (runs - mu) / np.sqrt(var) if var > 0 else 0.0
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    return dict(runs=runs, expected=float(mu), z=float(z), pvalue=float(p))


# ===========================================================================
# Kalman filter and innovation consistency (NIS / NEES)
# ===========================================================================
def kalman_filter(y, F, H, Q, R, x0, P0, u=None, B=None):
    """
    Purpose
    A linear Kalman filter that returns its innovation sequence and innovation
    covariance at every step, the raw material of observer-based detection. The
    innovation is the measurement minus its one-step prediction; under the correct
    model it is zero-mean and white with the covariance the filter reports.

    Inputs
    y the measurement sequence (steps by outputs), F H Q R the system and noise
    matrices, x0 P0 the initial state and covariance, optional u and B for inputs.

    Outputs
    Dict with the innovations, the innovation covariances S, the filtered states,
    and the filtered covariances.
    """
    y = np.atleast_2d(np.asarray(y, float))
    F, H, Q, R = map(lambda M: np.atleast_2d(np.asarray(M, float)), (F, H, Q, R))
    n = len(y); nx = F.shape[0]
    x = np.asarray(x0, float).reshape(nx); P = np.asarray(P0, float).copy()
    innov = np.zeros((n, H.shape[0])); S = np.zeros((n, H.shape[0], H.shape[0]))
    xs = np.zeros((n, nx)); Ps = np.zeros((n, nx, nx))
    for k in range(n):
        x = F @ x + (B @ u[k] if (u is not None and B is not None) else 0.0)
        P = F @ P @ F.T + Q
        nu = y[k] - H @ x
        Sk = H @ P @ H.T + R
        K = P @ H.T @ np.linalg.inv(Sk)
        x = x + K @ nu
        P = (np.eye(nx) - K @ H) @ P
        innov[k] = nu; S[k] = Sk; xs[k] = x; Ps[k] = P
    return dict(innov=innov, S=S, x=xs, P=Ps)


def nis(innov, S):
    """
    Purpose
    The Normalized Innovation Squared, the Mahalanobis length of each innovation
    in its own predicted covariance. Under the correct model it follows a
    chi-square with as many degrees of freedom as outputs, so a NIS that drifts
    above its band exposes a model or sensor fault without needing the true state.

    Inputs
    innov the innovation sequence, S the innovation covariances.

    Outputs
    Dict with the per-step NIS, the time-average NIS, the output dimension, and the
    two-sided 95 percent consistency band for the average.
    """
    innov = np.atleast_2d(np.asarray(innov, float)); n, m = innov.shape
    vals = np.array([innov[k] @ np.linalg.inv(S[k]) @ innov[k] for k in range(n)])
    lo = stats.chi2.ppf(0.025, n * m) / n
    hi = stats.chi2.ppf(0.975, n * m) / n
    return dict(nis=vals, mean=float(vals.mean()), dof=m,
                band=(float(lo), float(hi)), single=(float(stats.chi2.ppf(0.025, m)),
                                                      float(stats.chi2.ppf(0.975, m))))


def nees(err, P):
    """
    Purpose
    The Normalized Estimation Error Squared, the Mahalanobis length of the true
    estimation error in the filter's reported covariance. It needs ground truth,
    so it is a Monte Carlo consistency check during design: a NEES above its band
    means the filter is overconfident (covariance too small), below means it is
    conservative.

    Inputs
    err the true estimation error (steps by states), P the filtered covariances.

    Outputs
    Dict with the per-step NEES, its time-average, the state dimension, and the
    two-sided 95 percent band for the average.
    """
    err = np.atleast_2d(np.asarray(err, float)); n, nx = err.shape
    vals = np.array([err[k] @ np.linalg.inv(P[k]) @ err[k] for k in range(n)])
    lo = stats.chi2.ppf(0.025, n * nx) / n
    hi = stats.chi2.ppf(0.975, n * nx) / n
    return dict(nees=vals, mean=float(vals.mean()), dof=nx, band=(float(lo), float(hi)))


def innovation_whiteness(innov, lags=10):
    """
    Purpose
    A whiteness test on the (scalar or first-output) innovation sequence, the
    time-correlation half of the innovation consistency check. The innovations
    should be uncorrelated in time as well as correctly scaled; correlation here
    points to an unmodeled dynamic rather than a pure bias.

    Inputs
    innov the innovation sequence, lags the lags to pool.

    Outputs
    Dict from the Ljung-Box test applied to the innovations.
    """
    innov = np.atleast_2d(np.asarray(innov, float))
    return ljung_box(innov[:, 0], lags=lags)


# ===========================================================================
# parity space: structured residuals for detection and isolation
# ===========================================================================
def parity_matrix(A, C, s):
    """
    Purpose
    Build a parity-space projection from a discrete state-space pair over a window
    of length s+1. The rows of the returned matrix annihilate the extended
    observability matrix, so when applied to a window of outputs and inputs they
    yield a residual that depends only on noise and faults, not on the unknown
    state.

    Inputs
    A the state-transition matrix, C the output matrix, s the parity-window order.

    Outputs
    The parity matrix W whose rows span the left null space of the extended
    observability matrix, and that observability matrix O.
    """
    A = np.atleast_2d(np.asarray(A, float)); C = np.atleast_2d(np.asarray(C, float))
    nx = A.shape[0]; rows = []
    Apow = np.eye(nx)
    for i in range(s + 1):
        rows.append(C @ Apow); Apow = Apow @ A
    O = np.vstack(rows)                                   # (s+1)*ny by nx
    U, sv, Vt = np.linalg.svd(O)
    tol = max(O.shape) * np.finfo(float).eps * sv[0]
    rank = int(np.sum(sv > tol))
    W = U[:, rank:].T                                    # left null space rows
    return dict(W=W, O=O, rank=rank)


def parity_residual(W, Y):
    """
    Purpose
    Apply a parity matrix to a stacked window of outputs to produce the parity
    residual. With no fault and no noise it is zero; a fault drives it away from
    zero along a direction set by which signal failed.

    Inputs
    W the parity matrix, Y a stacked output window (or an array of windows, one
    per row).

    Outputs
    The residual vector (or array of residual vectors).
    """
    Y = np.asarray(Y, float)
    return (W @ Y.T).T if Y.ndim > 1 else W @ Y


def isolate_by_signature(fired, signature):
    """
    Purpose
    Isolate a fault by matching the observed residual firing pattern to the
    columns of a fault-signature (incidence) matrix. Each column is the pattern a
    given fault should produce; the best-matching column names the fault. This is
    the isolation step structured residuals are designed for.

    Inputs
    fired a 0/1 vector of which residuals exceeded their threshold, signature a
    residuals-by-faults 0/1 incidence matrix with named columns.

    Outputs
    Dict with the index of the best-matching fault and the per-fault match score.
    """
    fired = np.asarray(fired, int)
    sig = np.asarray(signature, int)
    scores = sig.shape[0] - np.sum(np.abs(sig - fired[:, None]), axis=0)
    best = int(np.argmax(scores))
    return dict(fault=best, scores=scores.tolist(), unique=bool(np.sum(scores == scores[best]) == 1))


# ===========================================================================
# GOING FURTHER 1: RESIDUAL GENERATION (observers, UIO, observer banks)
# ===========================================================================
def luenberger_observer(A, C, poles):
    """
    Purpose
    Design an observer gain L by pole placement so the estimation-error dynamics
    A - L C have the chosen eigenvalues. The observer then drives a residual,
    measurement minus its estimate, that is the dual of the parity relation and the
    starting point of observer-based fault detection.

    Inputs
    A the state-transition matrix, C the output matrix, poles the desired
    error-dynamics eigenvalues (inside the unit circle for discrete time).

    Outputs
    The observer gain L.
    """
    from scipy.signal import place_poles
    A = np.atleast_2d(np.asarray(A, float)); C = np.atleast_2d(np.asarray(C, float))
    res = place_poles(A.T, C.T, np.asarray(poles, float))
    return res.gain_matrix.T


def observer_residual(A, B, C, L, u, y):
    """
    Purpose
    Run a Luenberger (or fault-detection) observer and return its output residual.
    The observer predicts the state from the model and corrects it with the
    measurement; the residual it leaves is near zero under the no-fault model and
    swings away when a fault appears, in a direction the design can shape.

    Inputs
    A B C the system matrices, L the observer gain, u the input sequence (steps by
    inputs, or None), y the measurement sequence (steps by outputs).

    Outputs
    Dict with the residual sequence and the estimated states.
    """
    A, C, L = map(lambda M: np.atleast_2d(np.asarray(M, float)), (A, C, L))
    y = np.atleast_2d(np.asarray(y, float)); n = len(y); nx = A.shape[0]
    if u is not None:
        u = np.atleast_2d(np.asarray(u, float)); B = np.atleast_2d(np.asarray(B, float))
    x = np.zeros(nx); r = np.zeros((n, C.shape[0])); xs = np.zeros((n, nx))
    for k in range(n):
        yh = C @ x
        r[k] = y[k] - yh
        x = A @ x + (B @ u[k] if u is not None else 0.0) + L @ r[k]
        xs[k] = x
    return dict(residual=r, x=xs)


def unknown_input_observer(A, B, C, E, poles):
    """
    Purpose
    Design a full-order unknown-input observer that decouples the residual from a
    disturbance entering through direction E, so the residual responds to faults but
    not to the modelled disturbance. It is the classic route to a robust residual
    that does not false-alarm on known disturbances.

    Inputs
    A B C the system matrices, E the disturbance input direction, poles the desired
    observer eigenvalues. Requires rank(C E) = rank(E).

    Outputs
    Dict with the observer matrices F, T, K, and H for use by uio_residual.
    """
    from scipy.signal import place_poles
    A, B, C, E = map(lambda M: np.atleast_2d(np.asarray(M, float)), (A, B, C, E))
    CE = C @ E
    if np.linalg.matrix_rank(CE) < E.shape[1]:
        raise ValueError("UIO existence condition rank(CE)=rank(E) fails")
    H = E @ np.linalg.pinv(CE)
    T = np.eye(A.shape[0]) - H @ C
    A1 = T @ A
    K1 = place_poles(A1.T, C.T, np.asarray(poles, float)).gain_matrix.T
    F = A1 - K1 @ C
    K = K1 + F @ H
    return dict(F=F, T=T, K=K, H=H, B=B, C=C)


def uio_residual(uio, u, y):
    """
    Purpose
    Run an unknown-input observer and return its disturbance-decoupled residual. By
    construction the residual is blind to the disturbance the observer was designed
    to reject, so a residual that fires points to a fault rather than the disturbance.

    Inputs
    uio the dict from unknown_input_observer, u the input sequence (or None), y the
    measurement sequence.

    Outputs
    Dict with the residual sequence and the reconstructed states.
    """
    F, T, K, H, B, C = uio["F"], uio["T"], uio["K"], uio["H"], uio["B"], uio["C"]
    y = np.atleast_2d(np.asarray(y, float)); n = len(y); nx = F.shape[0]
    z = np.zeros(nx); r = np.zeros((n, y.shape[1])); xs = np.zeros((n, nx))
    if u is not None:
        u = np.atleast_2d(np.asarray(u, float))
    for k in range(n):
        xh = z + H @ y[k]
        xs[k] = xh
        r[k] = y[k] - C @ xh
        z = F @ z + (T @ B @ u[k] if u is not None else 0.0) + K @ y[k]
    return dict(x=xs, residual=r)


def _uio_unused():
    return None


def generalized_observer_scheme(A, B, C, poles, u, y):
    """
    Purpose
    A generalized observer scheme for sensor-fault isolation. It builds one observer
    per sensor, each driven by all outputs except that one, so a fault in sensor i
    disturbs every observer except the one that ignores sensor i. The observer that
    stays clean names the faulty sensor.

    Inputs
    A B C the system matrices, poles the observer eigenvalues, u the input sequence
    (or None), y the measurement sequence (steps by outputs).

    Outputs
    Dict with the per-observer residual-norm sequences and the index of the cleanest
    observer over the record.
    """
    A, C = np.atleast_2d(np.asarray(A, float)), np.atleast_2d(np.asarray(C, float))
    y = np.atleast_2d(np.asarray(y, float)); ny = C.shape[0]; n = len(y)
    norms = np.zeros((ny, n))
    for j in range(ny):
        keep = [i for i in range(ny) if i != j]
        Cj = C[keep, :]; yj = y[:, keep]
        L = luenberger_observer(A, Cj, poles)
        rr = observer_residual(A, B, Cj, L, u, yj)["residual"]
        norms[j] = np.linalg.norm(rr, axis=1)
    cleanest = int(np.argmin(norms.mean(axis=1)))
    return dict(norms=norms, cleanest=cleanest)


# ===========================================================================
# GOING FURTHER 2: ROBUST EVALUATION AND THRESHOLDS
# ===========================================================================
def glr_detector(r, sigma, m_max=40):
    """
    Purpose
    A generalized likelihood ratio detector for a step change in the residual mean
    of unknown size and onset (Willsky-Jones). At each time it maximizes the
    log-likelihood ratio over all recent onset times, giving a statistic that is
    flat under the no-fault hypothesis and grows sharply once a bias appears, a
    matched detector for an abrupt fault in the residual.

    Inputs
    r the (scalar) residual sequence, sigma the no-fault residual standard
    deviation, m_max the maximum window length searched for an onset.

    Outputs
    Dict with the GLR statistic over time and the chi-square (1 dof) threshold.
    """
    r = np.asarray(r, float).ravel(); n = len(r)
    g = np.zeros(n)
    cs = np.concatenate([[0], np.cumsum(r)])
    for k in range(n):
        lo = max(0, k - m_max + 1)
        best = 0.0
        for theta in range(lo, k + 1):
            length = k - theta + 1
            s = cs[k + 1] - cs[theta]
            stat = (s * s) / (length * sigma * sigma)
            if stat > best:
                best = stat
        g[k] = best
    return dict(glr=g, threshold=float(stats.chi2.ppf(0.999, 1)))


def adaptive_threshold(r, u, base, k_u):
    """
    Purpose
    An operating-point-dependent threshold. Model uncertainty makes the no-fault
    residual grow with the input or load, so a fixed threshold either misses faults
    at low load or false-alarms at high load. This threshold scales with the input
    magnitude, holding the false-alarm rate roughly constant across the envelope.

    Inputs
    r the residual sequence, u the input or load magnitude per step, base the
    baseline threshold, k_u the sensitivity of the threshold to the input.

    Outputs
    Dict with the threshold sequence and the boolean alarm flags.
    """
    r = np.abs(np.asarray(r, float).ravel())
    u = np.abs(np.asarray(u, float).ravel())
    tau = base + k_u * u
    return dict(threshold=tau, alarm=r > tau)


def interval_observer(A, B, C, L, u, y, w_bound, v_bound):
    """
    Purpose
    A set-membership (interval) residual evaluator. Given bounded process and
    measurement disturbances, it propagates a guaranteed envelope for the output
    through the observer error dynamics; as long as the measurement stays inside the
    envelope no fault is possible, so an exceedance is a guaranteed detection rather
    than a statistical one.

    Inputs
    A B C the system matrices, L the observer gain, u the input sequence (or None),
    y the measurement sequence, w_bound and v_bound the process and measurement
    bound magnitudes.

    Outputs
    Dict with the residual, the guaranteed envelope, and the boolean alarm flags.
    """
    A, C, L = map(lambda M: np.atleast_2d(np.asarray(M, float)), (A, C, L))
    F = A - L @ C
    Fabs = np.abs(F)
    nx = A.shape[0]
    # steady-state error bound: e <= (I - |F|)^-1 (|L| v + w)
    one = np.ones(nx)
    rhs = np.abs(L) @ (v_bound * np.ones(C.shape[0])) + w_bound * one
    ebound = np.linalg.solve(np.eye(nx) - Fabs, rhs)
    env = np.abs(C) @ ebound + v_bound          # output envelope per channel
    rr = observer_residual(A, B, C, L, u, y)["residual"]
    alarm = np.any(np.abs(rr) > env, axis=1)
    return dict(residual=rr, envelope=env, alarm=alarm)


# ===========================================================================
# GOING FURTHER 3: FAULT ESTIMATION (augmented KF, PI observer, IMM)
# ===========================================================================
def augmented_fault_kalman(A, B, C, Q, R, fault_dir, y, u=None, qf=1e-4):
    """
    Purpose
    Estimate a fault's magnitude, not just its presence, by augmenting the state
    with the fault as an extra slowly-varying state and running a Kalman filter on
    the enlarged model. The estimated fault state tracks an additive bias in the
    process or sensor, turning detection into identification.

    Inputs
    A B C the system matrices, Q R the process and measurement covariances,
    fault_dir the column through which the fault enters the state, y the
    measurements, optional u the input, qf the fault random-walk variance.

    Outputs
    Dict with the estimated fault sequence and the filtered (augmented) states.
    """
    A, B, C = map(lambda M: np.atleast_2d(np.asarray(M, float)), (A, B, C))
    fd = np.asarray(fault_dir, float).reshape(-1, 1)
    nx = A.shape[0]
    Aa = np.block([[A, fd], [np.zeros((1, nx)), np.ones((1, 1))]])
    Ca = np.hstack([C, np.zeros((C.shape[0], 1))])
    Qa = np.block([[np.atleast_2d(Q), np.zeros((nx, 1))], [np.zeros((1, nx)), qf * np.ones((1, 1))]])
    Ba = np.vstack([B, np.zeros((1, B.shape[1]))]) if u is not None else None
    kf = kalman_filter(y, Aa, Ca, Qa, R, x0=np.zeros(nx + 1), P0=np.eye(nx + 1),
                       u=u, B=Ba)
    return dict(fault=kf["x"][:, -1], x=kf["x"])


def pi_observer(A, B, C, L, Kf, fault_dir, u, y):
    """
    Purpose
    A proportional-integral observer that reconstructs an additive fault online. The
    proportional term corrects the state from the output error as usual; an integral
    term accumulates that error into a fault estimate, so a persistent residual is
    absorbed into a reconstructed fault signal rather than biasing the state. It is
    the linear cousin of the sliding-mode observer used for fault reconstruction.

    Inputs
    A B C the system matrices, L the proportional gain, Kf the integral (fault) gain,
    fault_dir the fault input direction, u the input sequence (or None), y the
    measurements.

    Outputs
    Dict with the reconstructed fault sequence, the residual, and the states.
    """
    A, B, C, L = map(lambda M: np.atleast_2d(np.asarray(M, float)), (A, B, C, L))
    fd = np.asarray(fault_dir, float).ravel()
    Kf = np.asarray(Kf, float).ravel()
    y = np.atleast_2d(np.asarray(y, float)); n = len(y); nx = A.shape[0]
    if u is not None:
        u = np.atleast_2d(np.asarray(u, float))
    x = np.zeros(nx); f = 0.0
    fault = np.zeros(n); r = np.zeros((n, C.shape[0])); xs = np.zeros((n, nx))
    for k in range(n):
        e = y[k] - C @ x
        r[k] = e; fault[k] = f; xs[k] = x
        x = A @ x + (B @ u[k] if u is not None else 0.0) + fd * f + L @ e
        f = f + Kf @ e
    return dict(fault=fault, residual=r, x=xs)


def imm_filter(y, models, Pi, mu0=None, u=None, B=None):
    """
    Purpose
    An interacting multiple-model filter: a bank of Kalman filters, one per
    hypothesized mode (healthy and one or more faulty models), mixed at each step
    according to a Markov transition matrix. It returns the posterior probability of
    each mode over time, so a rising probability for a faulty model both detects and
    isolates the fault.

    Inputs
    y the measurements, models a list of dicts with F H Q R x0 P0 per mode, Pi the
    mode-transition matrix, mu0 the initial mode probabilities, optional u and B for
    a shared deterministic input.

    Outputs
    Dict with the per-step mode probabilities and the most likely mode at the end.
    """
    y = np.atleast_2d(np.asarray(y, float)); n = len(y); M = len(models)
    mu = np.ones(M) / M if mu0 is None else np.asarray(mu0, float)
    Pi = np.asarray(Pi, float)
    if u is not None:
        u = np.atleast_2d(np.asarray(u, float)); B = np.atleast_2d(np.asarray(B, float))
    x = [np.asarray(m["x0"], float).copy() for m in models]
    P = [np.asarray(m["P0"], float).copy() for m in models]
    prob = np.zeros((n, M))
    for k in range(n):
        cbar = Pi.T @ mu
        mix = (Pi * mu[:, None]) / (cbar[None, :] + 1e-300)      # mix[i,j]
        x0 = [sum(mix[i, j] * x[i] for i in range(M)) for j in range(M)]
        P0 = [sum(mix[i, j] * (P[i] + np.outer(x[i] - x0[j], x[i] - x0[j])) for i in range(M))
              for j in range(M)]
        lk = np.zeros(M)
        bu = (B @ u[k]) if u is not None else 0.0
        for j, m in enumerate(models):
            F, H, Q, R = map(lambda M_: np.atleast_2d(np.asarray(M_, float)),
                             (m["F"], m["H"], m["Q"], m["R"]))
            xp = F @ x0[j] + bu; Pp = F @ P0[j] @ F.T + Q
            nu = y[k] - H @ xp; S = H @ Pp @ H.T + R
            Kk = Pp @ H.T @ np.linalg.inv(S)
            x[j] = xp + Kk @ nu; P[j] = (np.eye(F.shape[0]) - Kk @ H) @ Pp
            lk[j] = stats.multivariate_normal.pdf(nu, mean=np.zeros(len(nu)), cov=S) + 1e-300
        mu = cbar * lk; mu /= mu.sum()
        prob[k] = mu
    return dict(mode_prob=prob, final_mode=int(np.argmax(prob[-1])))


# ===========================================================================
# GOING FURTHER 4: SHARPER WHITENESS AND CONSISTENCY TESTS
# ===========================================================================
def cumulative_periodogram(r):
    """
    Purpose
    Bartlett's cumulative periodogram test for whiteness in the frequency domain.
    The normalized cumulative sum of the periodogram of a white residual follows the
    diagonal; periodic or colored structure makes it bow away beyond a
    Kolmogorov-type band. It catches narrowband structure the autocorrelation can
    smear across lags.

    Inputs
    r the residual sequence.

    Outputs
    Dict with the cumulative periodogram, the diagonal reference, the confidence
    band half-width, and a white flag.
    """
    r = np.asarray(r, float).ravel() - np.mean(r)
    n = len(r); m = n // 2
    P = (np.abs(np.fft.rfft(r))[1:m + 1]) ** 2
    C = np.cumsum(P) / (np.sum(P) + 1e-300)
    diag = np.arange(1, m + 1) / m
    band = 1.36 / np.sqrt(m - 1)
    return dict(cum=C, diag=diag, band=band, white=bool(np.max(np.abs(C - diag)) < band))


def arch_test(r, lags=5):
    """
    Purpose
    Engle's test for autoregressive conditional heteroscedasticity: a check for
    time-varying residual variance. A residual can pass mean-whiteness tests yet have
    its variance cluster or grow, the signature of an intermittent or developing
    fault; regressing the squared residual on its own lags exposes it.

    Inputs
    r the residual sequence, lags the number of squared-residual lags tested.

    Outputs
    Dict with the LM statistic, its p-value, and a heteroscedastic flag.
    """
    r = np.asarray(r, float).ravel(); e2 = (r - r.mean()) ** 2
    n = len(e2)
    Y = e2[lags:]
    X = np.column_stack([np.ones(n - lags)] + [e2[lags - i - 1:n - i - 1] for i in range(lags)])
    beta, *_ = np.linalg.lstsq(X, Y, rcond=None)
    resid = Y - X @ beta
    r2 = 1 - np.sum(resid ** 2) / (np.sum((Y - Y.mean()) ** 2) + 1e-300)
    lm = (n - lags) * r2
    p = 1 - stats.chi2.cdf(lm, lags)
    return dict(lm=float(lm), pvalue=float(p), heteroscedastic=bool(p < 0.05))


def cusum_residual(r):
    """
    Purpose
    The Brown-Durbin-Evans cumulative-sum test of standardized residuals for
    structural stability. The running sum of standardized residuals should stay
    within a widening pair of boundary lines if the model holds throughout; crossing
    them signals that the residual mean drifted, a slow fault or a model that has
    stopped fitting.

    Inputs
    r the residual sequence.

    Outputs
    Dict with the CUSUM path, the upper and lower boundary lines, and a stable flag.
    """
    r = np.asarray(r, float).ravel(); n = len(r)
    s = np.std(r, ddof=1) + 1e-12
    W = np.cumsum(r) / s                                 # residual is zero-mean under no fault
    t = np.arange(1, n + 1)
    a = 0.948                                            # 5% significance
    bound = a * (np.sqrt(n) + 2 * t / np.sqrt(n))
    return dict(cusum=W, upper=bound, lower=-bound, stable=bool(np.all(np.abs(W) < bound)))


def turning_point_test(r):
    """
    Purpose
    A distribution-free randomness test counting turning points (local maxima and
    minima). A white sequence has a known expected number of turning points; far
    fewer means trend or smoothness, far more means alternation, either a departure
    from randomness that autocorrelation may miss.

    Inputs
    r the residual sequence.

    Outputs
    Dict with the turning-point count, its expected value, the z-score, and a random
    flag.
    """
    r = np.asarray(r, float).ravel(); n = len(r)
    tp = int(np.sum((r[1:-1] > r[:-2]) & (r[1:-1] > r[2:]) |
                    (r[1:-1] < r[:-2]) & (r[1:-1] < r[2:])))
    mu = 2 * (n - 2) / 3.0; var = (16 * n - 29) / 90.0
    z = (tp - mu) / np.sqrt(var)
    return dict(count=tp, expected=mu, z=float(z), random=bool(abs(z) < 1.96))


# ===========================================================================
# GOING FURTHER 5: DATA-DRIVEN RESIDUAL GENERATION
# ===========================================================================
def dd_parity(U, Y, s, W=None, mean=None):
    """
    Purpose
    Data-driven parity-space residual generation. Instead of deriving parity
    relations from a state-space model, it finds them directly from healthy
    input-output data: the left null space of a stacked data Hankel matrix gives
    vectors that annihilate the normal data, so applied to new data they yield a
    residual that grows under a fault. It is the model-free counterpart to the
    parity space. Pass a learned W and mean to apply it to fresh data.

    Inputs
    U the input record (steps by inputs), Y the output record (steps by outputs),
    s the window order, optional W a parity space and mean a window-mean both
    learned on healthy data.

    Outputs
    Dict with the parity (residual-generator) vectors, the per-window residual norm,
    and the window mean used for centering.
    """
    U = np.atleast_2d(np.asarray(U, float)); Y = np.atleast_2d(np.asarray(Y, float))
    if U.shape[0] < U.shape[1]:
        U = U.T
    if Y.shape[0] < Y.shape[1]:
        Y = Y.T
    n = len(Y); ny = Y.shape[1]
    cols = []
    for k in range(n - s):
        w = np.concatenate([np.concatenate([U[k + i] for i in range(s + 1)]),
                            np.concatenate([Y[k + i] for i in range(s + 1)])])
        cols.append(w)
    D = np.array(cols)
    mu = D.mean(axis=0) if mean is None else mean
    Dc = D - mu
    if W is None:
        Usv, sv, Vt = np.linalg.svd(D - D.mean(axis=0), full_matrices=False)
        W = Vt[-ny:]
    resid = Dc @ W.T
    return dict(W=W, residual=np.linalg.norm(resid, axis=1), mean=mu)


def reconstruction_residual(X_train, X_test, k):
    """
    Purpose
    A reconstruction residual from a linear autoencoder, equivalently principal
    component analysis. Healthy data are projected onto their leading subspace and
    reconstructed; the reconstruction error, the squared-prediction-error or Q
    statistic, is small for normal operation and large when a fault pushes data off
    the learned manifold. A nonlinear autoencoder generalizes the same idea.

    Inputs
    X_train healthy training data (samples by features), X_test data to score, k the
    number of retained components.

    Outputs
    Dict with the per-sample reconstruction error on the test data and the
    healthy-data control limit.
    """
    X_train = np.atleast_2d(np.asarray(X_train, float))
    X_test = np.atleast_2d(np.asarray(X_test, float))
    mu = X_train.mean(axis=0); Xc = X_train - mu
    U, sv, Vt = np.linalg.svd(Xc, full_matrices=False)
    Vk = Vt[:k]                                          # leading subspace
    def spe(X):
        Xc2 = X - mu; rec = (Xc2 @ Vk.T) @ Vk
        return np.sum((Xc2 - rec) ** 2, axis=1)
    q_train = spe(X_train)
    limit = np.quantile(q_train, 0.99)
    return dict(spe=spe(X_test), limit=float(limit))


def _demo():
    rng = np.random.default_rng(0)
    n = 400
    # ---- whiteness on a white vs correlated residual ----
    white = rng.normal(0, 1, n)
    corr = np.zeros(n)
    for i in range(1, n):
        corr[i] = 0.6 * corr[i - 1] + rng.normal(0, 1)
    print("Ljung-Box white  ", ljung_box(white, 10)["pvalue"] > 0.05, "p=%.3f" % ljung_box(white, 10)["pvalue"])
    print("Ljung-Box corr   ", ljung_box(corr, 10)["white"], "p=%.3g" % ljung_box(corr, 10)["pvalue"])
    print("Durbin-Watson w/c", "%.2f / %.2f" % (durbin_watson(white)["dw"], durbin_watson(corr)["dw"]))
    print("Runs test white p", "%.3f" % runs_test(white)["pvalue"])

    # ---- Kalman innovations + NIS on a constant-velocity model ----
    dt = 1.0
    F = np.array([[1, dt], [0, 1]]); H = np.array([[1.0, 0.0]])
    q = 0.01; Qk = q * np.array([[dt**3/3, dt**2/2], [dt**2/2, dt]]); Rk = np.array([[1.0]])
    xt = np.array([0.0, 1.0]); ys = []; errs = []
    K = 300; xs_true = []
    P0 = np.eye(2)
    for k in range(K):
        xt = F @ xt + np.random.default_rng(k).multivariate_normal([0, 0], Qk)
        meas = H @ xt + rng.normal(0, 1)
        ys.append(meas); xs_true.append(xt.copy())
    ys = np.array(ys)
    kf = kalman_filter(ys, F, H, Qk, Rk, x0=[0, 1], P0=P0)
    ns = nis(kf["innov"], kf["S"])
    print("NIS mean %.2f (band %.2f-%.2f, dof %d)" % (ns["mean"], ns["band"][0], ns["band"][1], ns["dof"]))
    print("Innovation whiteness white?", innovation_whiteness(kf["innov"])["white"])
    err = np.array(xs_true) - kf["x"]
    ne = nees(err, kf["P"])
    print("NEES mean %.2f (band %.2f-%.2f, dof %d)" % (ne["mean"], ne["band"][0], ne["band"][1], ne["dof"]))

    # ---- parity space + isolation ----
    A = np.array([[0.7, 0.1], [0.0, 0.8]]); C = np.array([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])
    pm = parity_matrix(A, C, s=2)
    print("Parity rows:", pm["W"].shape, "rank O:", pm["rank"])
    sig = np.array([[1, 0, 1], [0, 1, 1], [1, 1, 0]])      # residuals x faults
    iso = isolate_by_signature([0, 1, 1], sig)
    print("Isolate ->", iso["fault"], "unique:", iso["unique"])

    # ---- going further: shared small LTI ----
    Ad = np.array([[0.6, 0.2], [0.0, 0.5]]); Bd = np.array([[0.0], [1.0]])
    Cd = np.array([[1.0, 0.0], [0.0, 1.0]])
    N = 320; uu = rng.normal(0, 1, (N, 1)); xs = np.zeros(2); ys = []
    for k in range(N):
        ys.append(Cd @ xs + rng.normal(0, 0.05, 2))
        xs = Ad @ xs + Bd @ uu[k] + rng.normal(0, 0.02, 2)
    ys = np.array(ys)
    yf = ys.copy(); yf[160:, 0] += 0.8                    # sensor-1 bias fault

    # generation: observer + UIO
    L = luenberger_observer(Ad, Cd, [0.2, 0.25])
    r_h = observer_residual(Ad, Bd, Cd, L, uu, ys)["residual"]
    r_f = observer_residual(Ad, Bd, Cd, L, uu, yf)["residual"]
    print("observer resid norm healthy %.2f vs fault %.2f" %
          (np.linalg.norm(r_h[170:]), np.linalg.norm(r_f[170:])))
    E = np.array([[1.0], [0.0]]); dd = rng.normal(0, 0.5, N); xd = np.zeros(2); yd = []
    for k in range(N):
        yd.append(Cd @ xd + rng.normal(0, 0.05, 2))
        xd = Ad @ xd + Bd @ uu[k] + E.ravel() * dd[k] + rng.normal(0, 0.02, 2)
    yd = np.array(yd)
    uio = unknown_input_observer(Ad, Bd, Cd, E, [0.2, 0.25])
    r_uio = uio_residual(uio, uu, yd)["residual"]
    r_obs = observer_residual(Ad, Bd, Cd, L, uu, yd)["residual"]
    print("under disturbance: UIO resid %.2f vs plain observer %.2f" %
          (np.linalg.norm(r_uio[20:]), np.linalg.norm(r_obs[20:])))
    # GOS isolation (3 sensors)
    C3 = np.array([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])
    y3 = (xs * 0 + 0)  # rebuild with 3 sensors
    xs2 = np.zeros(2); y3 = []
    for k in range(N):
        y3.append(C3 @ xs2 + rng.normal(0, 0.05, 3))
        xs2 = Ad @ xs2 + Bd @ uu[k] + rng.normal(0, 0.02, 2)
    y3 = np.array(y3); y3[160:, 1] += 0.9                 # sensor-2 fault
    gos = generalized_observer_scheme(Ad, Bd, C3, [0.2, 0.25], uu, y3)
    print("GOS cleanest observer (excludes faulty sensor 1-idx):", gos["cleanest"])

    # robust: GLR, adaptive threshold, interval
    rr = rng.normal(0, 1, N); rr[180:] += 1.2
    glr = glr_detector(rr, sigma=1.0, m_max=40)
    print("GLR max before %.1f after %.1f (thr %.1f)" %
          (glr["glr"][:170].max(), glr["glr"][185:].max(), glr["threshold"]))
    at = adaptive_threshold(r_f[:, 0], uu.ravel(), base=0.2, k_u=0.15)
    print("adaptive-threshold alarms:", int(at["alarm"][170:].sum()))
    iv = interval_observer(Ad, Bd, Cd, L, uu, yf, w_bound=0.06, v_bound=0.15)
    print("interval-observer alarms healthy-seg %d fault-seg %d" %
          (int(iv["alarm"][:150].sum()), int(iv["alarm"][165:].sum())))

    # estimation: augmented KF, PI observer, IMM
    bias = 0.6; xb = np.zeros(2); yb = []
    for k in range(N):
        yb.append(Cd @ xb + rng.normal(0, 0.05, 2))
        fk = bias if k >= 140 else 0.0
        xb = Ad @ xb + Bd @ (uu[k] + fk) + rng.normal(0, 0.02, 2)
    yb = np.array(yb)
    Qk = 0.02 ** 2 * np.eye(2); Rk = 0.05 ** 2 * np.eye(2)
    af = augmented_fault_kalman(Ad, Bd, Cd, Qk, Rk, fault_dir=Bd.ravel(), y=yb, u=uu)
    print("augmented-KF fault est (true %.2f): %.2f" % (bias, af["fault"][-1]))
    pio = pi_observer(Ad, Bd, Cd, L, Kf=[0.0, 0.18], fault_dir=Bd.ravel(), u=uu, y=yb)
    print("PI-observer fault recon (true %.2f): %.2f" % (bias, pio["fault"][-1]))
    xi = np.zeros(2); yi = []
    for k in range(N):
        rn = 0.05 if k < 150 else 0.6
        xi = Ad @ xi + Bd @ uu[k] + rng.normal(0, 0.02, 2)
        yi.append(Cd @ xi + rng.normal(0, rn, 2))
    yi = np.array(yi)
    m0 = dict(F=Ad, H=Cd, Q=Qk, R=0.05 ** 2 * np.eye(2), x0=[0, 0], P0=np.eye(2))
    m1 = dict(F=Ad, H=Cd, Q=Qk, R=0.6 ** 2 * np.eye(2), x0=[0, 0], P0=np.eye(2))
    imm = imm_filter(yi, [m0, m1], np.array([[0.97, 0.03], [0.03, 0.97]]), u=uu, B=Bd)
    print("IMM P(faulty) before %.2f after %.2f" %
          (imm["mode_prob"][:150, 1].mean(), imm["mode_prob"][160:, 1].mean()))

    # sharper tests
    sine = white + np.sin(2 * np.pi * 0.12 * np.arange(n))
    print("cum-periodogram white? %s sine? %s" %
          (cumulative_periodogram(white)["white"], cumulative_periodogram(sine)["white"]))
    het = white.copy(); het[n // 2:3 * n // 4] *= 4.0    # clustered volatility
    print("ARCH hetero? homo=%s het=%s" %
          (arch_test(white)["heteroscedastic"], arch_test(het)["heteroscedastic"]))
    drift = white + np.linspace(0, 3, n)
    print("CUSUM stable white=%s drift=%s" %
          (cusum_residual(white)["stable"], cusum_residual(drift)["stable"]))
    print("turning-point white random?", turning_point_test(white)["random"])

    # data-driven
    ddw = dd_parity(uu, ys, s=2)
    ddf = dd_parity(uu, yf, s=2, W=ddw["W"], mean=ddw["mean"])
    print("dd-parity residual healthy %.3f vs fault %.3f" %
          (ddw["residual"].mean(), ddf["residual"][160:].mean()))
    Z = rng.normal(0, 1, (360, 2)); Lmix = rng.normal(0, 1, (2, 6))
    Xall = Z @ Lmix + 0.1 * rng.normal(0, 1, (360, 6))   # 6 features from 2 latents
    Xtr = Xall[:300]; Xte = Xall[300:].copy(); Xte[30:, 3] += 6.0   # break correlation
    rc = reconstruction_residual(Xtr, Xte, k=2)
    print("reconstruction SPE over-limit frac %.2f" % np.mean(rc["spe"] > rc["limit"]))


if __name__ == "__main__":
    _demo()
