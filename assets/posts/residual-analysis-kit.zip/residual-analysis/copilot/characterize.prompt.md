---
mode: agent
description: 'After a residual alarm, characterize the fault: is it an unmodeled dynamic, a covariance/sensor fault, and which channel?'
tools: ['codebase', 'search', 'runCommands']
---

# /characterize

A residual or innovation has alarmed. Turn the alarm into a description of the
fault rather than a yes or no.

Steps:
1. Separate the cause. Run whiteness (`ljung_box`, `durbin_watson`) and magnitude
   (`nis`) tests: whiteness firing points to an unmodeled dynamic; NIS firing
   while whiteness stays clean points to a covariance or noise-variance fault.
2. Localize. Normalize each sensor's own innovation channel, or apply a bank of
   structured / parity residuals, to get a firing pattern.
3. Isolate. Match the pattern to the signature matrix with `isolate_by_signature`
   and report whether the match is unique.
4. Check assumptions. Confirm Q and R were estimated from healthy data and that
   the signature columns are distinct. Cross-check `references/pitfalls.md`.

Output: the fault class (dynamic vs covariance/sensor), the channel involved, the
isolation result and whether it is unique, and the governing assumption.

The task to solve: ${input:question:Describe the alarmed residual and what you need characterized}
