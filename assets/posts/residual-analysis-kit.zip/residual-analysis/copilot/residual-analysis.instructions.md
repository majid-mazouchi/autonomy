---
applyTo: '**/*.py'
---

# Model-based FDI conventions

When writing code that detects or isolates faults from residuals or innovations,
follow these.

Use the project engine. Call `ljung_box`, `durbin_watson`, `residual_acf`,
`runs_test`, `kalman_filter`, `nis`, `nees`, `parity_matrix`, `parity_residual`,
and `isolate_by_signature` from `scripts/residuals.py` rather than reimplementing.

Estimate the noise covariances Q and R from healthy data, never from the record
under test. A wrong R makes the consistency tests misfire with no fault present.

Run whiteness and magnitude tests together, since each is blind to the other's
fault. Judge a residual on a window, not a single sample.

Label assumptions in the code. Note the model, the healthy reference, and the
window length next to the call, and confirm signature columns are distinct before
claiming isolation.
