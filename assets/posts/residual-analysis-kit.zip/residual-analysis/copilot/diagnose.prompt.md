---
mode: agent
description: 'Detect, confirm, and isolate a fault from residuals or Kalman innovations using the verified engine.'
tools: ['codebase', 'search', 'runCommands']
---

# /diagnose

Run model-based FDI on a residual or innovation sequence and return runnable code
from the project engine.

Inputs the user may give: the residual or innovation sequence (and its covariance
for NIS), or a state-space model and measurements to build a filter; a healthy
reference; and what is suspected. If any is missing, ask once, then proceed with a
stated assumption.

Steps:
1. Restate the residual source and the fault suspected in one line.
2. Test whiteness with `ljung_box` and `durbin_watson`; report the verdict.
3. Test magnitude with the windowed `nis` against its band; report the verdict.
4. If several residuals are available, isolate with `isolate_by_signature`.
5. State which tests fired and what that combination implies (unmodeled dynamic,
   covariance or sensor fault, or which sensor), and the one assumption that would
   change the conclusion. Cross-check `references/pitfalls.md`.

The task to solve: ${input:question:Describe the residual or model and what fault you suspect}
