---
mode: 'proposal-architect'
description: 'Generate and embed a house-style block diagram into the proposal.'
---

Add a block diagram to the proposal.

What it should show: ${input:figure:Describe the diagram (a loop, an architecture, a before/after, a timeline)}

Load the `block-diagrams` skill and pick the matching archetype from `figkit.py`:
- a staged process or feedback loop  -> process_loop
- layered/tiered system architecture -> tiered_architecture
- a before/after cost or value contrast -> before_after
- a phased plan over time             -> phased_timeline

Render the PNG into `out/figs/`, then embed it via the `docx-builder` `figure()`
helper with a numbered, descriptive caption. Use the figure only if it genuinely
aids understanding — never as decoration.
