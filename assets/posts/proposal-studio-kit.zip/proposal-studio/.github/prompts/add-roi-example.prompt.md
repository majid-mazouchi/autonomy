---
mode: 'proposal-architect'
description: 'Add a transparent worked numerical example with ROI to an existing proposal section.'
---

Add a worked numerical example with ROI to the proposal.

Scenario to quantify: ${input:scenario:Which scenario? (e.g., warranty cost avoided)}
Known parameters: ${input:params:Any known numbers — fleet/unit size, rates, unit costs}

Load the `business-case-roi` skill and produce:
1. An assumptions table — base value AND a plausible range for every input.
2. The step-by-step arithmetic, ending in a single headline figure.
3. A cost-to-build / cost-to-run / ROI / payback table.
4. The "two honest readings" framing and the "floor, not ceiling" note.

Every number is illustrative. Show the math so a reviewer can drop in their own
actuals and re-run it. Do not present a single-point estimate as fact.
