---
mode: 'proposal-architect'
description: 'Start a new technical program proposal from a topic and a few parameters.'
---

Draft a decision-ready technical program proposal.

Topic / capability: ${input:topic:What is the proposal about?}
Decision requested: ${input:ask:What are we asking the reviewer to approve?}
Audience: ${input:audience:Who reviews this? (e.g., engineering leadership, finance)}
Source material to ground in: ${input:sources:Files, links, or "none"}
ROI parameters (if known): ${input:roi:e.g., fleet size, incidence rate, unit cost — or "estimate"}

Follow the Proposal Architect workflow:
1. Confirm scope and outline before writing prose (ask only what changes the doc).
2. Draft the sections per the `proposal-structure` blueprint.
3. Add figures via the `block-diagrams` skill where they aid understanding.
4. Build a transparent worked ROI example via the `business-case-roi` skill.
5. Generate the `.docx` via the `docx-builder` skill into `out/`.
6. Run an honest-review pass and report the page count, headline ROI, and the
   top reviewer objections.

Stay practicality-first and honest. Label all estimates as illustrative with ranges.
