# Copilot instructions — Proposal Studio

This repository is a kit for drafting decision-ready technical program proposals
as polished Word documents, with block diagrams and transparent ROI.

## How the pieces fit

- Chat modes (`.github/chatmodes/`): the agents.
  - `proposal-architect` — drives the whole drafting workflow.
  - `proposal-reviewer` — an honest critique pass.
- Prompts (`.github/prompts/`): one-shot entry points (new proposal, add ROI,
  add figure). Run with `/new-proposal`, etc.
- Skills (`skills/`): the reusable know-how, loaded on demand.
  - `proposal-structure` — the section blueprint.
  - `business-case-roi` — the worked-example and ROI method.
  - `block-diagrams` — figure generator (`figkit.py`) and palette.
  - `docx-builder` — the `.docx` generation library (`docxkit.cjs`).
  - `honest-review` — the review checklist.

## Defaults for all work here

Practicality first, honest by default, evidence over adjectives. Estimates are
illustrative and carry ranges. Load-bearing constraints are stated, not glossed.
The advocate's case is always paired with the opposing read and named risks.

## Dependencies

- Node: `npm install docx` (for `docxkit.cjs`).
- Python: `pip install cairosvg` (for `figkit.py`).
- Optional, for preview: LibreOffice + Poppler to convert `.docx` to PDF/images.

Outputs go in `out/`; figures in `out/figs/`.
