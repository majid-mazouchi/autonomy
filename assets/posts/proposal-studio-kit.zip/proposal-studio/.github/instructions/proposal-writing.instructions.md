---
applyTo: '**/proposals/**,**/out/**,**/*.proposal.*'
description: 'House rules for technical program proposals.'
---

# Proposal house rules

These apply whenever you are drafting or editing proposal content.

Voice and structure. Write prose, not bullet soup. Lead each section with the
point. Keep an executive summary a skim-reader can act on: the ask, the cost,
the payback, all visible in the summary plus one table.

Honesty. Label every estimate illustrative and give it a range. State assumptions
explicitly. Present the advocate's case, then the opposing read and the risks
with mitigations. Never let a single-point number pose as fact. If a constraint
is load-bearing (safety, regulatory, resource), name it — do not gloss it.

Evidence. Each value claim ties to a mechanism, a scenario, or a number. Delete
adjectives that aren't backed by one of those.

Figures and tables. Use figures only when they aid understanding; caption and
number them. Tables for assumptions, ROI, risks, KPIs, and dependencies. House
palette is warm scientific monograph: Arial body, teal accents, light rules.

Deliverable. Final output is a `.docx` built with `docxkit.cjs`. Remind the user
to update the Table of Contents field in Word to populate page numbers.
