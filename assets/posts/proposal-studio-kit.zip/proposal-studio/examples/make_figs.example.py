"""Example: render figures for the demo proposal into examples/out/figs/."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "skills", "block-diagrams", "scripts"))
import figkit as fk

OUT = os.path.join(HERE, "out", "figs")
os.makedirs(OUT, exist_ok=True)

fk.process_loop(
    [("1 \u00b7 Observe", "monitor state"), ("2 \u00b7 Decide", "form a plan"),
     ("3 \u00b7 Act", "do the work"), ("4 \u00b7 Learn", "bank the result")],
    out=os.path.join(OUT, "loop"), title="EXAMPLE METHOD LOOP", edge_index=2,
    return_label="repeat - each pass is cheaper", legend=("plan", "act"))

fk.before_after(
    out=os.path.join(OUT, "value"), title="EXAMPLE VALUE PICTURE",
    left_title="Today", right_title="Proposed",
    left_notes=["broad and slow", "mostly wasted"],
    right_notes=["narrow and fast", "high-value only"],
    caption="\u2192 lower cost, faster answer")

print("example figures ->", OUT)
