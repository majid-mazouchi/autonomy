// Example: build a minimal proposal with docxkit. Run make_figs.example.py first.
//   node examples/build.example.cjs
const path = require("path");
const k = require(path.join(__dirname, "..", "skills", "docx-builder", "scripts", "docxkit.cjs"));

const figs = path.join(__dirname, "out", "figs");
const c = [];

c.push(...k.titleBlock({
  kicker: "PROGRAM PROPOSAL",
  title: "Example Capability",
  subtitle: "a minimal end-to-end demo of the Proposal Studio kit",
  meta: [["Status", "Draft for review"], ["Date", "June 2026"]],
}));
c.push(k.abstractBox("In one sentence: this short document shows the title block, abstract, headings, prose, a figure, a table, and a worked ROI assembled by docxkit."));
c.push(k.pageBreak(), k.tocHeading(), k.toc(), k.pageBreak());

c.push(k.h1("1.  Executive summary"));
c.push(k.p("This is a demonstration proposal. It exists to prove the kit builds a valid, styled .docx from a handful of helper calls. Replace this content with a real proposal via the proposal-architect agent."));
c.push(...k.figure(path.join(figs, "value.png"), 600, 264, 1, "The value picture: a broad, slow process replaced by a narrow, fast one."));

c.push(k.h1("2.  Approach"));
c.push(k.p("The approach is a short loop, shown below."));
c.push(...k.figure(path.join(figs, "loop.png"), 600, 216, 2, "The example method loop. Each pass banks a reusable result."));

c.push(k.h1("3.  Worked ROI (illustrative)"));
c.push(k.p("All figures are illustrative; swap in real actuals."));
c.push(k.table([4680, 2340, 2340], ["Item", "One-time", "Annual"], [
  ["Build", "~ $2.0 M", "-"],
  ["Run", "-", "~ $0.3 M"],
  ["Saving (portfolio)", "-", "~ $5.0 M"],
  ["Net annual (portfolio)", "-", "~ $4.7 M"],
  ["Payback at scale", "-", "< 6 months"],
]));
c.push(k.runs(k.t("Floor, not ceiling: ", { bold: true }), k.t("the quantified lever is the most measurable one; others stack on top.")));

const out = path.join(__dirname, "out", "example.docx");
k.render(c, out, { footer: "Example Capability - Proposal Studio demo", title: "Example Capability" })
  .then((p) => console.log("wrote", p));
