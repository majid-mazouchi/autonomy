# Proposal Studio

A VS Code Copilot kit that drafts decision-ready technical program proposals as
polished Word documents — with house-style block diagrams, a transparent worked
ROI, and an honest, practicality-first voice. It encodes the exact method used to
produce the sample adaptive-data-acquisition proposal.

## What you get

- Two agents (Copilot chat modes): `proposal-architect` (drafts) and
  `proposal-reviewer` (critiques).
- Five skills (SKILL.md, progressive disclosure): structure, ROI, diagrams,
  docx-build, review.
- Two reusable generators that do the heavy lifting:
  - `skills/docx-builder/scripts/docxkit.cjs` — the Word document library.
  - `skills/block-diagrams/scripts/figkit.py` — the figure generator.
- Prompt files and auto-applied instructions.

## Install

1. Copy this folder's contents into your repo root (or a workspace folder). The
   `.github/` files and the `skills/` folder are what Copilot reads.
2. Install dependencies:

       npm install docx
       pip install cairosvg
       # optional, for PDF/image preview: LibreOffice + Poppler

3. In VS Code, make sure custom chat modes, prompt files, and instructions are
   enabled in your Copilot settings (exact toggle names vary by version). The
   files live in the conventional locations:
   - chat modes -> `.github/chatmodes/*.chatmode.md`
   - prompts -> `.github/prompts/*.prompt.md`
   - instructions -> `.github/instructions/*.instructions.md` and
     `.github/copilot-instructions.md`
   - skills -> `skills/<name>/SKILL.md`

   If your Copilot version expects skills elsewhere, move the `skills/` folder to
   match; the contents are portable.

## Use

- Fastest: in Copilot Chat run `/new-proposal` and answer the few scoping
  questions. The architect outlines, confirms, drafts, adds figures and a worked
  ROI, builds the `.docx` into `out/`, and reports the headline number and the
  likely reviewer objections.
- Or select the `proposal-architect` chat mode and describe what you want.
- Add pieces to an existing draft with `/add-figure` and `/add-roi-example`.
- Pressure-test with the `proposal-reviewer` chat mode before you circulate.

## How the generators work

The agent writes a short build script that requires `docxkit.cjs`, pushes content
blocks (title block, headings, prose, tables, figures, callouts, TOC), and calls
`render()`. Figures come from `figkit.py`'s four archetypes (process loop, tiered
architecture, before/after, phased timeline) rendered to PNG and embedded. Both
share one warm-scientific palette so figures sit naturally in the page. Run
`python skills/block-diagrams/scripts/figkit.py` to see the four demo figures,
and see `examples/` for a minimal end-to-end build.

## Principles baked in

Practicality first, honest by default, evidence over adjectives. Estimates are
illustrative with ranges; load-bearing constraints are stated, not glossed; the
advocate's case is paired with the opposing read and named risks. This is what
makes the output read as engineering, not marketing.

## Notes

- The document library is `docxkit.cjs` (CommonJS). It uses the `.cjs` extension
  rather than `.js` on purpose: Gmail and some mail systems block `.js` files even
  inside `.zip` archives, so `.cjs` lets the kit be emailed as-is. It runs
  identically in Node — `require('./docxkit.cjs')`. Rename to `.js` only if your
  toolchain insists (and update the `require` paths to match).
- Generated Word TOCs show page numbers only after you open the file and update
  the TOC field once.
- The kit is domain-agnostic; it was built around a vehicle-health example but
  the structure, ROI method, and figures work for any technical program proposal.
