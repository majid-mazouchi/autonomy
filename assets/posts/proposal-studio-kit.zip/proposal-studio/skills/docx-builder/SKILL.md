---
name: docx-builder
description: >
  Use when generating or editing the final Word (.docx) deliverable for a proposal
  or report. Provides docxkit.cjs — a helper library for title blocks, headings,
  prose, tables, figures, callouts, TOC, and the house style — plus conventions.
---

# docx builder

The deliverable is a polished `.docx` built with `scripts/docxkit.cjs`
(needs `npm install docx`). The library encodes the house style so you only
write content, not formatting.

## Pattern

Write a short build script that requires `docxkit`, pushes content blocks into an
array, and calls `render`. Outline:

    const k = require('./docxkit.cjs');
    const c = [];
    c.push(...k.titleBlock({ kicker:'PROGRAM PROPOSAL', title:'...', subtitle:'...',
                             meta:[['Date','June 2026'],['Status','Draft for review']] }));
    c.push(k.abstractBox('In one sentence: ...'));
    c.push(k.pageBreak(), k.tocHeading(), k.toc(), k.pageBreak());
    c.push(k.h1('1.  Executive summary'));
    c.push(k.p('...'), k.p('...'));
    c.push(...k.figure('out/figs/loop.png', 600, 216, 1, 'Caption.'));
    c.push(k.h2('Direct cost'));
    c.push(k.table([4200,5160], ['A','B'], [['x','y'],['z','w']]));
    k.render(c, 'out/proposal.docx', { footer:'My Proposal — Program Proposal' });

## Helpers (all exported by docxkit)

- `titleBlock({kicker,title,subtitle,meta})` -> array of paragraphs (spread it).
- `abstractBox(text)` / `calloutBox(children,{color,fill})` -> a left-bordered box.
- `tocHeading()`, `toc()` -> Table of Contents (uses H1/H2 outline levels).
- `h1(text)`, `h2(text)` -> headings (also feed the TOC).
- `p(text,{before,after,bold,italics,color,align})` -> a body paragraph.
- `runs(...textRuns)` + `t(text,{bold,italics,color})` -> a paragraph with mixed
  inline styling (e.g., a bold lead-in then normal prose).
- `bullet(text)`, `numbered(text)` -> list items (real list numbering, not glyphs).
- `figure(pngPath, widthPx, heightPx, number, caption)` -> image + caption (spread).
- `table(columnWidths, headers, rows)` -> a styled table. columnWidths are DXA and
  must sum to 9360 (US Letter, 1" margins); rows is an array of string arrays.
- `pageBreak()` -> a page break.
- `render(children, outPath, {footer,title,creator})` -> writes the .docx.

## Conventions

US Letter, 1" margins, Arial body, teal H2 accents, captioned figures, light
tables with a teal header row and alternating row fill. Number sections in H1
text ("1.  Executive summary"). Prose over bullets. See
`references/docx-conventions.md` for the table-width math and gotchas.

## After building

Validate, and optionally preview by converting to PDF/images. Tell the user to
open the file in Word and update the Table of Contents field to populate page
numbers (generated TOCs need one refresh).
