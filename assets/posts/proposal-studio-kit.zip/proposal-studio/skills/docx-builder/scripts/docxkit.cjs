/*
 * docxkit.cjs — reusable helpers for building polished, professional .docx
 * proposals/reports in the "warm scientific" house style.
 *
 *   npm install docx
 *
 * Usage (in a build script):
 *   const k = require('./docxkit.cjs');
 *   const c = [];
 *   c.push(...k.titleBlock({ kicker:'PROGRAM PROPOSAL', title:'...', subtitle:'...',
 *                            meta:[['Date','June 2026'],['Status','Draft']] }));
 *   c.push(k.abstractBox('In one sentence: ...'));
 *   c.push(k.pageBreak(), k.tocHeading(), k.toc(), k.pageBreak());
 *   c.push(k.h1('1.  Executive summary'));
 *   c.push(k.p('...'));
 *   c.push(...k.figure('figs/loop.png', 600, 216, 1, 'Caption.'));
 *   c.push(k.table([4200,5160], ['A','B'], [['x','y'],['z','w']]));
 *   k.render(c, 'out/proposal.docx', { footer:'My Proposal' });
 */
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun,
  Footer, AlignmentType, LevelFormat, TabStopType, TabStopPosition,
  TableOfContents, HeadingLevel, BorderStyle, WidthType, ShadingType,
  VerticalAlign, PageNumber, PageBreak,
} = require("docx");

// ---- house palette (warm scientific monograph) ----
const C = {
  ink: "1F2A37", inkSoft: "5C5446", faint: "8A8170", rule: "DDD2BB",
  rust: "BD4F2C", teal: "1F6F6B", ochre: "C2891B", indigo: "3A4A8C", plum: "7A3F6B",
  band: "F3F6F5",
};
const CONTENT_W = 9360; // US Letter, 1" margins (DXA)

// ---- inline text ----
const t = (text, o = {}) => new TextRun({
  text, bold: o.bold, italics: o.italics, color: o.color, size: o.size,
});
const runs = (...arr) => new Paragraph({ spacing: { after: 120, line: 276 }, children: arr });

// ---- paragraphs ----
const p = (text, o = {}) => new Paragraph({
  spacing: { after: o.after ?? 120, line: 276, ...(o.before ? { before: o.before } : {}) },
  alignment: o.align,
  children: Array.isArray(text) ? text
    : [new TextRun({ text, bold: o.bold, italics: o.italics, color: o.color, size: o.size })],
});

const h1 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_1, spacing: { before: 320, after: 160 },
  children: [new TextRun(text)],
});
const h2 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_2, spacing: { before: 220, after: 120 },
  children: [new TextRun(text)],
});

const bullet = (text, level = 0) => new Paragraph({
  numbering: { reference: "bul", level }, spacing: { after: 90, line: 276 },
  children: Array.isArray(text) ? text : [new TextRun({ text })],
});
const numbered = (text, level = 0) => new Paragraph({
  numbering: { reference: "num", level }, spacing: { after: 90, line: 276 },
  children: Array.isArray(text) ? text : [new TextRun({ text })],
});

const pageBreak = () => new Paragraph({ children: [new PageBreak()] });

// ---- figure (image + caption) ----
const figure = (file, w, h, num, cap) => ([
  new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { before: 140, after: 40 },
    children: [new ImageRun({
      type: "png", data: fs.readFileSync(file),
      transformation: { width: w, height: h },
      altText: { title: cap, description: cap, name: file },
    })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { after: 180 },
    children: [new TextRun({ text: `Figure ${num}.  ${cap}`, italics: true, size: 17, color: C.faint })],
  }),
]);

// ---- table ----
const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const cell = (children, w, o = {}) => new TableCell({
  width: { size: w, type: WidthType.DXA },
  borders: { top: border, bottom: border, left: border, right: border },
  shading: o.fill ? { fill: o.fill, type: ShadingType.CLEAR } : undefined,
  margins: { top: 80, bottom: 80, left: 120, right: 120 },
  verticalAlign: VerticalAlign.CENTER,
  children: (Array.isArray(children) ? children : [children]).map((x) =>
    typeof x === "string"
      ? new Paragraph({ spacing: { after: 0, line: 264 }, children: [new TextRun({ text: x, size: o.size ?? 19, bold: o.bold, color: o.color })] })
      : x),
});
const headerCell = (text, w) => cell(text, w, { fill: C.teal, bold: true, color: "FFFFFF", size: 19 });

/**
 * table(widths, headers, rows)
 *  widths : array of column widths in DXA (must sum to 9360 for full width)
 *  headers: array of header strings
 *  rows   : array of arrays of cell strings (or Paragraphs)
 */
const table = (widths, headers, rows) => new Table({
  width: { size: CONTENT_W, type: WidthType.DXA },
  columnWidths: widths,
  rows: [
    new TableRow({ tableHeader: true, children: headers.map((hh, i) => headerCell(hh, widths[i])) }),
    ...rows.map((r, ri) => new TableRow({
      children: r.map((cv, i) => cell(cv, widths[i], { fill: ri % 2 ? C.band : undefined, size: 19 })),
    })),
  ],
});

// ---- callout / abstract box ----
const calloutBox = (children, o = {}) => new Paragraph({
  shading: { fill: o.fill ?? C.band, type: ShadingType.CLEAR },
  border: { left: { style: BorderStyle.SINGLE, size: 18, color: o.color ?? C.teal, space: 12 } },
  spacing: { before: 80, after: 120, line: 276 },
  indent: { left: 200, right: 200 },
  children: Array.isArray(children) ? children : [new TextRun({ text: children })],
});
const abstractBox = (text, leadIn = "In one sentence: ") =>
  calloutBox([new TextRun({ text: leadIn, bold: true }), new TextRun({ text })]);

// ---- title block ----
const titleBlock = ({ kicker, title, subtitle, meta = [] }) => {
  const out = [];
  if (kicker) out.push(new Paragraph({ spacing: { before: 400, after: 60 }, children: [new TextRun({ text: kicker, color: C.rust, bold: true, size: 20, characterSpacing: 60 })] }));
  out.push(new Paragraph({ spacing: { after: 100 }, children: [new TextRun({ text: title, bold: true, size: 48, color: C.ink })] }));
  if (subtitle) out.push(new Paragraph({ spacing: { after: 220 }, children: [new TextRun({ text: subtitle, italics: true, size: 26, color: C.inkSoft })] }));
  out.push(new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: C.teal, space: 4 } }, spacing: { after: 160 }, children: [new TextRun("")] }));
  meta.forEach(([k, v]) => out.push(new Paragraph({
    tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
    spacing: { after: 60 },
    children: [new TextRun({ text: k, bold: true }), new TextRun({ text: `\t${v}` })],
  })));
  return out;
};

const tocHeading = () => new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { after: 120 }, children: [new TextRun("Contents")] });
const toc = () => new TableOfContents("Contents", { hyperlink: true, headingStyleRange: "1-2" });

// ---- assemble + write ----
const render = (children, outPath, opts = {}) => {
  const doc = new Document({
    creator: opts.creator || "Proposal Studio",
    title: opts.title || "Proposal",
    styles: {
      default: { document: { run: { font: "Arial", size: 22, color: C.ink } } },
      paragraphStyles: [
        { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 30, bold: true, font: "Arial", color: C.ink },
          paragraph: { spacing: { before: 320, after: 160 }, outlineLevel: 0 } },
        { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 25, bold: true, font: "Arial", color: C.teal },
          paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 1 } },
      ],
    },
    numbering: {
      config: [
        { reference: "bul", levels: [
          { level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 280 } } } },
          { level: 1, format: LevelFormat.BULLET, text: "\u25E6", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 1080, hanging: 280 } } } },
        ] },
        { reference: "num", levels: [
          { level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 280 } } } },
        ] },
      ],
    },
    sections: [{
      properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      footers: {
        default: new Footer({ children: [new Paragraph({
          tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
          border: { top: { style: BorderStyle.SINGLE, size: 4, color: C.rule, space: 6 } },
          children: [
            new TextRun({ text: opts.footer || "Proposal", size: 16, color: C.faint }),
            new TextRun({ text: "\tPage ", size: 16, color: C.faint }),
            new TextRun({ children: [PageNumber.CURRENT], size: 16, color: C.faint }),
          ],
        })] }),
      },
      children,
    }],
  });
  return Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(outPath, buf); return outPath; });
};

module.exports = {
  C, CONTENT_W, t, runs, p, h1, h2, bullet, numbered, pageBreak,
  figure, table, calloutBox, abstractBox, titleBlock, tocHeading, toc, render,
};
