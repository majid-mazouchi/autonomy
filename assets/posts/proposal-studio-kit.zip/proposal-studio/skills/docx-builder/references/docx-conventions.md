# docx conventions and gotchas

Page and width math (US Letter)
- Page 12240 x 15840 DXA; 1" margins = 1440 DXA each side.
- Content width = 12240 - 2*1440 = 9360 DXA. Table columnWidths must sum to 9360.
- 1440 DXA = 1 inch. Image sizes in docxkit `figure()` are in pixels at 96 DPI
  (600 px ~ 6.25").

Tables
- Always set both the table width and each column width (docxkit does this).
- Use the teal header row + alternating light-band rows (docxkit does this).
- Keep cell text concise; long cells wrap and inflate row height.

Figures
- Render PNGs at 2x for crispness, display at ~600 px wide.
- Aspect ratios from figkit archetypes at 600 wide: loop ~216, architecture ~336,
  before/after ~264, timeline ~180. Pass matching height to `figure()`.
- Every figure gets a number and a one-line descriptive caption.

Headings and TOC
- Use `h1`/`h2` for everything that should appear in the TOC.
- The TOC is a field; it shows page numbers only after Word updates fields once
  (right-click -> Update Field). Say this to the user on delivery.

Lists
- Use `bullet`/`numbered` — never paste bullet glyphs into text.

Validation and preview (if tooling available)
- Validate the generated file before delivery.
- Preview: convert to PDF, rasterize pages to images, eyeball for overflow,
  table breaks, and figure placement. Fix and rebuild rather than shipping blind.

Common failures
- Columns not summing to 9360 -> misaligned table. Recompute widths.
- Forgetting to spread `titleBlock(...)` / `figure(...)` (they return arrays).
- Newlines in a run -> use separate `p(...)` paragraphs, not "\n".
