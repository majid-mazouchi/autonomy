---
name: honest-review
description: >
  Use to critique a draft proposal before delivery, or whenever asked to review,
  pressure-test, or red-team a proposal or business case. Provides a checklist
  for practicality, honesty, evidence, balance, and reviewer-readiness.
---

# Honest review

Run this pass before any proposal ships. The goal is to find what a real review
committee will attack — and to make sure the document is honest with itself.
Do not rewrite; report issues and fixes.

## Checklist

Practicality
- Does any claim assume something that cannot be built, certified, or operated?
- Are load-bearing constraints (safety, regulatory, resource) stated, not glossed?
- Does it promise capability or autonomy the platform can't actually support?

Honesty of numbers
- Is every estimate labeled illustrative with a range?
- Are assumptions explicit and individually defensible?
- Does any single-point number pose as a fact?
- Does the ROI survive a pessimistic reading of its own assumptions?

Evidence
- Does each value claim tie to a mechanism, a scenario, or a number?
- Which adjectives are doing work that evidence should do? (List them.)

Balance
- Is the opposing case represented, not just the advocate's?
- Are risks named with mitigations, or buried? A risk-free proposal reads as a pitch.
- Is the pessimistic reading of the ROI present alongside the optimistic one?

Reviewer-readiness
- Is there one explicit ask, tied to the cheapest, lowest-risk next step?
- Can a skim-reader get the decision, cost, and payback from the summary + one table?
- Do figures aid understanding, or decorate? Are they captioned and numbered?

## Output

Report: (1) the single strongest objection a committee will raise, and how to
answer it; (2) a prioritized issue list, each tagged
practicality / honesty / evidence / balance / clarity, with a concrete fix;
(3) what is already strong and should be kept. Be direct; skip flattery.

## Reference files

- `references/review-checklist.md` — the same checklist as a copyable rubric for
  pasting into a review comment.
