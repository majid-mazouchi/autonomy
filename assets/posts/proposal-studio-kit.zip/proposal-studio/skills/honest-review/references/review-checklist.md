# Review rubric (copyable)

Score each pass / flag / fail and attach the fix.

PRACTICALITY
[ ] No claim assumes the unbuildable, uncertifiable, or unoperable
[ ] Load-bearing constraints (safety / regulatory / resource) stated, not glossed
[ ] No promised capability the platform can't support

HONESTY
[ ] Every estimate labeled illustrative, with a range
[ ] Assumptions explicit and individually defensible
[ ] No single-point number posing as fact
[ ] ROI survives a pessimistic reading of its own inputs

EVIDENCE
[ ] Each value claim tied to a mechanism, scenario, or number
[ ] Unsupported adjectives removed

BALANCE
[ ] Opposing case represented
[ ] Risks named with mitigations, not buried
[ ] Pessimistic ROI reading present alongside the optimistic one

REVIEWER-READINESS
[ ] One explicit ask, tied to the cheapest low-risk next step
[ ] Decision + cost + payback visible from summary + one table
[ ] Figures aid understanding, captioned and numbered

DELIVERY
[ ] .docx validates
[ ] TOC-refresh note given to the author

Strongest objection a committee will raise:
How to answer it:
