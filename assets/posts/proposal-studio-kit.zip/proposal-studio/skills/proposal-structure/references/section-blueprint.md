# Section blueprint — the question each section answers

Executive summary
Question: should I keep reading, and if I only read this, what am I deciding?
Must contain the ask, the order-of-magnitude cost, and the payback. Failure mode:
burying the ask, or describing the solution before the problem.

Problem statement
Question: why does this need solving now, and what does it cost to not solve it?
Use 2-4 structural facts. Quantify the pain if you can. Failure mode: vague pain,
or leaping to the solution.

Proposed approach
Question: what is the idea, in one mental model?
Prefer a small number of stages or a loop the reader can hold in their head.
Failure mode: a feature list instead of a concept.

System architecture
Question: how is it built, and where are the hard boundaries?
Name the tiers/components and the separations that matter (especially safety).
Failure mode: a box-and-line diagram with no boundaries called out.

Design invariants
Question: what will this never do, and what enforces that?
A table mapping each constraint to its enforcing mechanism. This is the section
that converts a skeptic. Failure mode: aspirations stated as guarantees.

Worked example
Question: what does one real run look like, start to finish?
Pick a representative case and walk the whole loop. Failure mode: an abstract
restatement of the approach.

Business case
Question: what is it worth, and along which dimensions?
Cost, speed, risk/reputation, competitive position, and (where relevant)
regulatory posture. Failure mode: only listing money, or only listing strategy.

Illustrative impact scenarios
Question: where does this pay off, concretely?
Several short vignettes, each ending in a named lever, plus a summary table
(situation / saving or advantage / mechanism). Failure mode: scenarios with no
dollar or advantage attached.

Phased plan
Question: how do we de-risk before we spend?
Phases with explicit exit gates; validation first, vehicle/field contact and
spend last. Failure mode: a schedule with no gates.

Success metrics
Question: how will we know it worked?
Include at least one hard gate (safety/quality) that must hold. Failure mode:
vanity metrics that always look good.

Risks and mitigations
Question: what goes wrong, and what do we do about it?
Table form. Distinguish recoverable (cost) from non-recoverable (safety) risks.
Failure mode: no honest downside — reads as a sales pitch.

Dependencies and prerequisites
Question: what must already exist for this to work?
Be explicit about foundations and sequencing. Failure mode: hidden assumptions
that surface mid-build.

Governance, safety, and data handling
Question: what are the operating rules?
Human gates on irreversible actions, least privilege, data minimization.

Recommendation
Question: what exactly am I approving, and why now?
A single clear ask tied to the cheapest, lowest-risk next step.
