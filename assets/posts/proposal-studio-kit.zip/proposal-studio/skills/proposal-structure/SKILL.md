---
name: proposal-structure
description: >
  Use when drafting or outlining a technical program proposal, business case, or
  decision document. Provides the section blueprint, what each section must
  answer, and an outline template. Load this before writing proposal prose.
---

# Proposal structure

A decision-ready technical proposal follows a fixed arc. Each section answers
one question; if a section does not answer its question, cut it.

The standard fourteen-section arc (drop or merge for shorter docs):

1. Executive summary — the whole story in three short paragraphs: the problem,
   the proposed capability, and the ask. A skim-reader must get the decision,
   the cost, and the payback from here plus one table.
2. Problem statement — the structural facts that create the opportunity. Make the
   pain concrete and, where possible, quantified.
3. Proposed approach — the concept, ideally as a small set of stages or a loop.
4. System architecture — how it is built; where the hard boundaries are.
5. Design invariants — the non-negotiable constraints, each mapped to the
   mechanism that enforces it. This is what earns a skeptical reviewer's trust.
6. Worked example — one concrete end-to-end walk-through.
7. Business case — the value across dimensions (cost, speed, risk, competitive).
8. Illustrative impact scenarios — several short vignettes, each ending in the
   specific lever it pulls, plus a summary table.
9. Phased plan — phases with explicit exit gates; front-load validation, back-load
   risk and spend.
10. Success metrics — what is measured, including a hard safety/quality gate.
11. Risks and mitigations — honest, as a table; every risk has a mitigation.
12. Dependencies and prerequisites — what must exist first.
13. Governance, safety, and data handling — the rules of operation.
14. Recommendation — the explicit ask and why now.

## How to fill it

Write prose, not bullet soup. Lead each section with its point. Pair the
advocate's case with the opposing read. Put assumptions, ROI, risks, KPIs, and
dependencies in tables. Keep one worked example fully transparent.

## Reference files

- `references/section-blueprint.md` — the question each section must answer and
  common failure modes. Load when drafting a specific section.
- `templates/outline.md` — a fill-in outline to confirm scope before writing.
