# Outline — confirm before writing prose

Fill this in with the user, then write. Keep it to one screen.

Title:
Subtitle (one line):
Decision requested (the ask):
Audience:
Status / classification:

One-sentence abstract (the whole thing in a breath):

Problem — 2 to 4 structural facts:
-
-

Proposed approach — the mental model (stages or a loop):

Architecture — the tiers/components and the hard boundary:

Design invariants — constraint -> enforcing mechanism:
-
-

Worked example — the one case to walk through:

Business-case dimensions in scope (circle): cost · speed · risk/reputation · competitive · regulatory

Impact scenarios — list the situations to quantify:
-
-

ROI worked example — which scenario, and the parameters:

Phases and gates:
- Phase 0:
- Phase 1:
- Phase 2:
- Phase 3:

Top risks to surface honestly:
-

Recommendation / cheapest first step:
