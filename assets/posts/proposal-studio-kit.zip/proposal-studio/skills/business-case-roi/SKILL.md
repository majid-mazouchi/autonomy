---
name: business-case-roi
description: >
  Use when a proposal needs a worked numerical example, a cost-savings estimate,
  an ROI, or a payback figure for reviewers. Provides the transparent-assumptions
  method, the table shapes, and the honest "floor, not ceiling" framing.
---

# Business case and ROI

Reviewers fund numbers, not adjectives. Give them one fully transparent worked
example they can re-run with their own actuals.

## Method

1. State every input as an assumption with a base value AND a plausible range.
   Never bury an assumption inside prose.
2. Show the arithmetic step by step, ending in a single headline figure. Each
   step is one multiply and one labeled result.
3. Extrapolate honestly. If one instance returns X, and the capability covers a
   portfolio of N similar instances, say so as an order of magnitude — and flag
   it as an extrapolation, not a measurement.
4. Cost it. A build (one-time) and a run (annual) line. If the capability reduces
   an existing cost (e.g., data volume), note net-neutral or negative running cost.
5. Compute ROI / payback against the build cost. Give both the single-instance
   case and the portfolio case.
6. Give two honest readings: the pessimistic one (often: a single instance does
   not justify the build) and the realistic one (the portfolio does, and quickly).
7. Frame the headline as a floor, not a ceiling: name the other value levers that
   stack on top, especially any that can dwarf the quantified one in a single event.

## Table shapes

Assumptions:  | Assumption | Base | Plausible range |
Calculation:  | Step | Result |   (last row is the headline figure)
ROI:          | Item | One-time | Annual |   (build, run, saving, net, payback)

## Rules

Every figure is illustrative — say so. Use round numbers and approximate signs
(~). Make the math visible so a reviewer can substitute actuals. Never present a
single-point estimate as a fact, and never let the optimistic reading stand
without its pessimistic twin.

## Reference files

- `references/roi-method.md` — a fully worked example (warranty cost avoided)
  with the exact numbers and framing, as a model to adapt. Load when building one.
