# Worked ROI example (model to adapt)

This is the warranty-cost-avoided example from the sample proposal. Reuse its
shape; swap in the domain and numbers for a new case.

## 1. Assumptions (base + range)

| Assumption | Base | Plausible range |
| Population in scope | 1,000,000 units | 0.5 - 2 M |
| Annual incidence of the issue | 0.3 % / yr | 0.1 - 0.5 % |
| Share currently No-Trouble-Found / misdiagnosed | 40 % | 25 - 50 % |
| Avoidable cost per bad cycle (diagnosis, wrong part, repeat visit, goodwill) | $700 | $400 - $1,500 |
| Share the capability converts to a correct first-time fix | 60 % | 40 - 75 % |

## 2. Calculation (single instance)

| Step | Result |
| Annual events (1,000,000 x 0.3 %) | 3,000 / yr |
| Currently NTF / misdiagnosed (x 40 %) | 1,200 / yr |
| Converted to correct first-time fix (x 60 %) | 720 / yr |
| Avoided cost (x $700) | ~ $0.5 M / yr |

## 3. Portfolio extrapolation (labeled as such)

One failure mode ~ $0.5 M/yr. Across ~10 comparable failure-mode families the
order of magnitude is ~ $5 M/yr. This is an extrapolation, not a measurement.

## 4. ROI / payback

| Item | One-time | Annual |
| Build (small team + infrastructure) | ~ $2.0 M | - |
| Run (compute, models, ops, maintenance) | - | ~ $0.3 M |
| Saving - single mode | - | ~ $0.5 M |
| Saving - portfolio (~10 modes) | - | ~ $5.0 M |
| Net annual - single mode | - | ~ $0.2 M |
| Net annual - portfolio | - | ~ $4.7 M |
| Simple payback - portfolio, at scale | - | < 6 months |

## 5. Two honest readings

Pessimistic: a single failure mode (~$0.2 M net/yr) takes most of a decade to
repay a ~$2 M build — do not approve it to fix one issue.
Realistic: the portfolio repays the build in well under a year; each added mode
is near-pure margin because run cost is largely fixed.

## 6. Floor, not ceiling

The quantified lever (warranty NTF) is the most measurable one. Others stack on
top — recall containment, supplier cost recovery, hardware-campaign avoidance,
inspection/teardown targeting — and several can each exceed the entire quantified
portfolio in a single avoided event. Read the headline as a conservative floor.
