# House palette — warm scientific monograph

Shared by figkit.py (figures) and docxkit.cjs (document) so figures sit naturally
in the page. Light paper, deep ink, saturated accents.

| Role | Hex |
| paper (figure background) | #f5efe1 |
| card (box fill) | #fbf7ec |
| ink (body text) | #2a2620 |
| ink-soft (secondary text) | #5c5446 |
| faint (captions, footer) | #8a8170 |
| rule (hairlines, borders) | #ddd2bb |
| rust (accent / warnings / kickers) | #bd4f2c |
| teal (primary accent / headings) | #1f6f6b |
| ochre (secondary accent) | #c2891b |
| indigo (tertiary accent) | #3a4a8c |
| plum (quaternary accent) | #7a3f6b |
| band (light table row / callout fill) | #f3f6f5 |

Document body font: Arial (universally available). Figure font: a clean
sans-serif (DejaVu Sans / Arial) so PNGs render without bundled webfonts.

Cycle order for multi-stage figures: teal, indigo, ochre, rust, plum.

Tone of the aesthetic: calm, technical, monograph-like. Light mode renders
reliably across viewers and reads as serious engineering documentation.
