"""
figkit.py - block-diagram generator in the "warm scientific monograph" palette.
Renders crisp PNGs for embedding in docx proposals.

    pip install cairosvg

Four archetypes:
    process_loop(...)        - a left-to-right staged loop with a return arrow
    tiered_architecture(...) - stacked horizontal bands with cross-tier arrows
    before_after(...)        - two-panel volume / value comparison
    phased_timeline(...)     - phases left-to-right with gate notes

Each writes <name>.png at 2x. Colors and fonts match docxkit.cjs.
"""
import cairosvg

PAPER="#f5efe1"; CARD="#fbf7ec"; INK="#2a2620"; INKS="#5c5446"; FAINT="#8a8170"
RULE="#ddd2bb"; RUST="#bd4f2c"; TEAL="#1f6f6b"; OCHRE="#c2891b"; INDIGO="#3a4a8c"; PLUM="#7a3f6b"
FONT="font-family='DejaVu Sans, Arial, sans-serif'"
CYCLE=[TEAL, INDIGO, OCHRE, RUST, PLUM]

def _defs():
    return (f"<defs>"
            f"<marker id='a' markerWidth='9' markerHeight='9' refX='6.5' refY='3' orient='auto' markerUnits='strokeWidth'><path d='M0,0 L7,3 L0,6 Z' fill='{INKS}'/></marker>"
            f"<marker id='ar' markerWidth='9' markerHeight='9' refX='6.5' refY='3' orient='auto' markerUnits='strokeWidth'><path d='M0,0 L7,3 L0,6 Z' fill='{RUST}'/></marker>"
            f"</defs>")

def _render(name, w, h, body, scale=2):
    svg=f"<svg viewBox='0 0 {w} {h}' xmlns='http://www.w3.org/2000/svg'>{_defs()}<rect x='0' y='0' width='{w}' height='{h}' fill='{PAPER}'/>{body}</svg>"
    cairosvg.svg2png(bytestring=svg.encode(), write_to=f"{name}.png", output_width=int(w*scale))
    return f"{name}.png"

def _kicker(text):
    return f"<text x='30' y='34' fill='{RUST}' font-size='14' font-weight='bold' letter-spacing='2' {FONT}>{text}</text>"


def process_loop(stages, out="loop", title="PROCESS LOOP",
                 edge_index=None, return_label="loop continues", legend=None):
    """stages: list of (title, subtitle). edge_index: stage drawn in rust + 'EDGE' tag."""
    n=len(stages); W=1000; H=360; m=30; gap=25
    bw=(W-2*m-(n-1)*gap)/n; y=150; h=80
    b=_kicker(title)
    if legend:
        b+=f"<rect x='640' y='22' width='16' height='16' rx='3' fill='{TEAL}'/><text x='662' y='35' fill='{INKS}' font-size='12.5' {FONT}>{legend[0]}</text>"
        b+=f"<rect x='800' y='22' width='16' height='16' rx='3' fill='{RUST}'/><text x='822' y='35' fill='{INKS}' font-size='12.5' {FONT}>{legend[1]}</text>"
    xs=[m+i*(bw+gap) for i in range(n)]
    for i,(tt,sb) in enumerate(stages):
        c = RUST if i==edge_index else CYCLE[i % len(CYCLE)]
        x=xs[i]; cx=x+bw/2
        b+=f"<rect x='{x}' y='{y}' width='{bw}' height='{h}' rx='11' fill='{CARD}' stroke='{c}' stroke-width='2'/>"
        b+=f"<text x='{cx}' y='{y+h/2-3}' text-anchor='middle' fill='{c}' font-size='17.5' font-weight='bold' {FONT}>{tt}</text>"
        b+=f"<text x='{cx}' y='{y+h/2+17}' text-anchor='middle' fill='{INKS}' font-size='12' {FONT}>{sb}</text>"
        if i==edge_index:
            b+=f"<rect x='{x+bw-52}' y='{y-15}' width='52' height='20' rx='10' fill='{RUST}'/><text x='{x+bw-26}' y='{y-1}' text-anchor='middle' fill='#fff' font-size='11' font-weight='bold' {FONT}>EDGE</text>"
        if i<n-1:
            b+=f"<line x1='{x+bw}' y1='{y+h/2}' x2='{xs[i+1]-3}' y2='{y+h/2}' stroke='{INKS}' stroke-width='2' marker-end='url(#a)'/>"
    b+=f"<path d='M{xs[-1]+bw/2} {y+h} C {xs[-1]+bw/2} {y+h+78}, {xs[0]+bw/2} {y+h+78}, {xs[0]+bw/2} {y+h+3}' fill='none' stroke='{RUST}' stroke-width='2' stroke-dasharray='6 5' marker-end='url(#ar)'/>"
    b+=f"<text x='500' y='{y+h+72}' text-anchor='middle' fill='{RUST}' font-size='13' {FONT}>{return_label}</text>"
    return _render(out,W,H,b)


def tiered_architecture(tiers, out="arch", title="ARCHITECTURE",
                        down_label="request \u2193", up_label="result \u2191", footnote=None):
    """tiers: list of dicts {label, color, boxes:[...], note?, dashed_first?}. Top-to-bottom."""
    W=1000; H=560; BX=190; BW=620; b=_kicker(title)
    colors={"teal":TEAL,"indigo":INDIGO,"rust":RUST,"ochre":OCHRE,"plum":PLUM}
    rgba={"teal":"rgba(31,111,107,0.07)","indigo":"rgba(58,74,140,0.07)","rust":"rgba(189,79,44,0.06)","ochre":"rgba(194,137,27,0.07)","plum":"rgba(122,63,107,0.07)"}
    ys=[60, 250, 372]; hs=[120, 92, 135]
    for ti,tier in enumerate(tiers[:3]):
        col=colors.get(tier.get("color","teal"),TEAL); y=ys[ti]; hh=hs[ti]
        b+=f"<rect x='{BX}' y='{y}' width='{BW}' height='{hh}' rx='13' fill='{rgba.get(tier.get('color','teal'))}' stroke='{col}' stroke-width='1.6'/>"
        b+=f"<text x='{BX+14}' y='{y+22}' fill='{col}' font-size='13.5' font-weight='bold' {FONT}>{tier['label']}</text>"
        boxes=tier.get("boxes",[]); bw=(BW-28-(min(len(boxes),3)-1)*12)/min(max(len(boxes),1),3)
        for bi,box in enumerate(boxes):
            row=bi//3; col_i=bi%3
            bx=BX+14+col_i*(bw+12); by=y+34+row*40
            dashed = tier.get("dashed_first") and bi==0
            stroke = INKS if dashed else RULE
            dash = "stroke-dasharray='5 4'" if dashed else ""
            b+=f"<rect x='{bx}' y='{by}' width='{bw}' height='32' rx='7' fill='{CARD}' stroke='{stroke}' {dash}/>"
            b+=f"<text x='{bx+bw/2}' y='{by+20}' text-anchor='middle' fill='{INK}' font-size='11.5' {FONT}>{box}</text>"
        if tier.get("note"):
            b+=f"<text x='{BX+BW-14}' y='{y+hh-12}' text-anchor='end' fill='{INKS}' font-size='10.5' font-style='italic' {FONT}>{tier['note']}</text>"
    # rails
    topc=ys[0]+60; botc=ys[2]+58
    b+=f"<line x1='150' y1='{topc}' x2='150' y2='{botc}' stroke='{TEAL}' stroke-width='2.2' marker-end='url(#a)'/>"
    b+=f"<text x='40' y='270' fill='{TEAL}' font-size='12' font-weight='bold' {FONT}>{down_label}</text>"
    b+=f"<line x1='850' y1='{botc}' x2='850' y2='{topc}' stroke='{RUST}' stroke-width='2.2' marker-end='url(#ar)'/>"
    b+=f"<text x='868' y='270' fill='{RUST}' font-size='12' font-weight='bold' {FONT}>{up_label}</text>"
    b+=f"<line x1='{BX}' y1='{topc}' x2='150' y2='{topc}' stroke='{TEAL}' stroke-width='1.4'/><line x1='{BX}' y1='{botc}' x2='150' y2='{botc}' stroke='{TEAL}' stroke-width='1.4'/>"
    b+=f"<line x1='{BX+BW}' y1='{topc}' x2='850' y2='{topc}' stroke='{RUST}' stroke-width='1.4'/><line x1='{BX+BW}' y1='{botc}' x2='850' y2='{botc}' stroke='{RUST}' stroke-width='1.4'/>"
    if footnote:
        b+=f"<text x='500' y='535' text-anchor='middle' fill='{INKS}' font-size='12' {FONT}>{footnote}</text>"
    return _render(out,W,H,b)


def before_after(out="value", title="COMPARISON",
                 left_title="Today", right_title="Proposed",
                 left_notes=None, right_notes=None, caption="", same_label="same answer"):
    W=1000; H=440; b=_kicker(title)
    b+=f"<text x='60' y='80' fill='{INK}' font-size='16' font-weight='bold' {FONT}>{left_title}</text>"
    b+=f"<rect x='110' y='104' width='110' height='244' rx='6' fill='{RULE}'/><rect x='110' y='326' width='110' height='22' rx='3' fill='{TEAL}'/>"
    b+=f"<text x='165' y='368' text-anchor='middle' fill='{INKS}' font-size='12' {FONT}>high volume</text>"
    for i,note in enumerate(left_notes or []):
        b+=f"<text x='255' y='{150+i*20}' fill='{INKS}' font-size='12.5' {FONT}>{note}</text>"
    b+=f"<line x1='500' y1='92' x2='500' y2='356' stroke='{RULE}' stroke-width='1.5' stroke-dasharray='4 4'/>"
    b+=f"<text x='500' y='226' text-anchor='middle' fill='{OCHRE}' font-size='26' font-weight='bold' {FONT}>=</text>"
    b+=f"<text x='500' y='252' text-anchor='middle' fill='{INKS}' font-size='11.5' {FONT}>{same_label}</text>"
    b+=f"<text x='560' y='80' fill='{INK}' font-size='16' font-weight='bold' {FONT}>{right_title}</text>"
    b+=f"<rect x='610' y='268' width='110' height='80' rx='6' fill='{TEAL}'/><rect x='610' y='260' width='110' height='10' rx='3' fill='{RULE}'/>"
    b+=f"<text x='665' y='368' text-anchor='middle' fill='{INKS}' font-size='12' {FONT}>low volume</text>"
    for i,note in enumerate(right_notes or []):
        b+=f"<text x='745' y='{298+i*18}' fill='{INKS}' font-size='12.5' {FONT}>{note}</text>"
    if caption:
        b+=f"<line x1='120' y1='390' x2='880' y2='390' stroke='{RULE}' stroke-width='1.2'/>"
        b+=f"<text x='500' y='416' text-anchor='middle' fill='{INK}' font-size='14' font-weight='bold' {FONT}>{caption}</text>"
    return _render(out,W,H,b)


def phased_timeline(phases, out="plan", title="PHASED ROLLOUT", axis="risk and cost increase  \u2192"):
    """phases: list of (tag, title, subtitle, gate)."""
    n=len(phases); W=1000; H=300; m=30; gap=35
    bw=(W-2*m-(n-1)*gap)/n; y=70; h=84; b=_kicker(title)
    xs=[m+i*(bw+gap) for i in range(n)]
    for i,(tag,tt,sb,gate) in enumerate(phases):
        c=CYCLE[i % len(CYCLE)]; x=xs[i]; cx=x+bw/2
        b+=f"<rect x='{x}' y='{y}' width='{bw}' height='{h}' rx='11' fill='{CARD}' stroke='{c}' stroke-width='2'/>"
        b+=f"<text x='{cx}' y='{y+24}' text-anchor='middle' fill='{c}' font-size='12.5' font-weight='bold' letter-spacing='1' {FONT}>{tag}</text>"
        b+=f"<text x='{cx}' y='{y+47}' text-anchor='middle' fill='{INK}' font-size='16' font-weight='bold' {FONT}>{tt}</text>"
        b+=f"<text x='{cx}' y='{y+68}' text-anchor='middle' fill='{INKS}' font-size='11.5' {FONT}>{sb}</text>"
        b+=f"<text x='{cx}' y='{y+h+24}' text-anchor='middle' fill='{FAINT}' font-size='10.5' font-style='italic' {FONT}>{gate}</text>"
        if i<n-1:
            b+=f"<line x1='{x+bw}' y1='{y+h/2}' x2='{xs[i+1]-3}' y2='{y+h/2}' stroke='{INKS}' stroke-width='2' marker-end='url(#a)'/>"
    b+=f"<line x1='30' y1='250' x2='935' y2='250' stroke='{INKS}' stroke-width='1.5' marker-end='url(#a)'/>"
    b+=f"<text x='30' y='270' fill='{INKS}' font-size='11.5' {FONT}>{axis}</text>"
    return _render(out,W,H,b)


if __name__ == "__main__":
    # demo: regenerates the four figures used in the sample proposal
    process_loop(
        [("1 \u00b7 Observe","monitor state"),("2 \u00b7 Hypothesize","form a claim"),
         ("3 \u00b7 Request","dispatch capture"),("4 \u00b7 Collect","edge captures"),
         ("5 \u00b7 Conclude","evaluate, stand down")],
        out="loop", title="THE CLOSED ACQUISITION LOOP", edge_index=3,
        return_label="loop continues - bank the outcome", legend=("cloud - reasoning","vehicle - execution"))
    tiered_architecture(
        [{"label":"CLOUD - reasoning plane","color":"indigo","boxes":["Agent","Hypothesis engine","Composer","Budget governor","Outcome store","Gated pipeline"]},
         {"label":"HIGH-COMPUTE EDGE - isolated from control","color":"teal","boxes":["Request interpreter","Capture orchestration","Payload assembly"]},
         {"label":"SAFETY ECU - real-time","color":"rust","boxes":["Control logic (not in loop)","Feature/residual","Trigger eval","Ring buffer"],"dashed_first":True,"note":"passive tap - no actuation"}],
        out="arch", title="THREE-TIER ARCHITECTURE", down_label="request \u2193", up_label="capture \u2191",
        footnote="The agent issues data requests only. Selectivity is reversible via the ring buffer.")
    before_after(out="value", title="WHY IT SAVES MONEY",
        left_title="Today - passive", right_title="Adaptive - targeted",
        left_notes=["mostly uninformative","steady-state data"],
        right_notes=["high-value","only the right cohort"],
        caption="\u2192 lower cost, faster answer")
    phased_timeline(
        [("Phase 0","Replay","cloud only","gate: targeting validated"),
         ("Phase 1","Channel","canary, shadow","gate: zero impact"),
         ("Phase 2","Live","bounded campaigns","gate: hit-rate, budget"),
         ("Phase 3","Scale","fleet-wide","gate: cost-per-answer down")],
        out="plan")
    print("demo figures written")
