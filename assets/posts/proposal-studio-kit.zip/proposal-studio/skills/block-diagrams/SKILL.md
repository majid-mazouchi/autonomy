---
name: block-diagrams
description: >
  Use when a proposal needs a block diagram or figure — a process/feedback loop,
  a layered system architecture, a before/after value comparison, or a phased
  timeline. Provides figkit.py (an SVG->PNG generator) and the house palette.
---

# Block diagrams

Figures earn their place only when they convey something prose can't: structure,
flow, contrast, or sequence. Never decorate. Caption and number every figure.

The generator is `scripts/figkit.py` (needs `pip install cairosvg`). It renders
crisp PNGs at 2x in the house palette, matching `docxkit.cjs`. Four archetypes:

- `process_loop(stages, edge_index, return_label, legend)` — a left-to-right
  staged loop with a dashed return arrow. For a method or feedback cycle.
- `tiered_architecture(tiers, down_label, up_label, footnote)` — stacked
  horizontal bands (top-to-bottom) with cross-tier arrows. For layered systems;
  use `dashed_first` and `note` to call out a boundary (e.g., "not in the loop").
- `before_after(left_title, right_title, left_notes, right_notes, caption)` —
  two-panel volume/value contrast. For the cost or efficiency story.
- `phased_timeline(phases)` — phases left-to-right with gate notes and a
  risk/cost axis. For the rollout plan.

## How to use

1. Pick the archetype that matches what you need to show.
2. Call it (see the `__main__` block in `figkit.py` for full examples), writing
   the PNG into `out/figs/`.
3. Embed it with the `docx-builder` `figure(path, w, h, num, caption)` helper.
   Display widths around 600 px fit the content column; height follows the
   archetype's aspect ratio (loop ~216, arch ~336, before/after ~264, plan ~180
   at 600 wide).

## Palette

Warm cream paper, deep ink text, saturated accents (rust, teal, ochre, indigo,
plum). See `references/palette.md` for exact hex values shared with the docx.
Keep fonts to a clean sans-serif so they render without bundled webfonts.
