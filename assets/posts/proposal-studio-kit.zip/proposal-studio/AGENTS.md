# AGENTS.md — Proposal Studio

An agent kit for drafting decision-ready technical program proposals as polished
Word documents, with house-style block diagrams and transparent ROI.

## Agents (chat modes)

- proposal-architect — the orchestrator. Scopes, outlines, drafts, adds figures
  and ROI, builds the .docx, and runs a review pass.
- proposal-reviewer — an honest critic. Pressure-tests a draft and returns the
  objections a committee will raise. Does not rewrite.

## Skills (loaded on demand via their description)

- proposal-structure — the fourteen-section blueprint and outline template.
- business-case-roi — the transparent worked-example and ROI method.
- block-diagrams — figkit.py figure generator and the house palette.
- docx-builder — docxkit.cjs document library and conventions.
- honest-review — the practicality/honesty/evidence/balance checklist.

## Standing principles (apply to all work here)

Practicality first — name what is and isn't feasible; never gloss a load-bearing
safety, regulatory, or resource constraint.
Honest by default — estimates are illustrative and carry ranges; the advocate's
case is always paired with the opposing read and named risks.
Evidence over adjectives — every value claim ties to a mechanism, a scenario, or
a number.

## Typical flow

1. /new-proposal (or open proposal-architect) and answer the few scoping questions.
2. The architect outlines, confirms scope, then drafts section by section.
3. It generates figures (figkit.py) and a worked ROI (business-case-roi), then
   builds the .docx (docxkit.cjs) into out/.
4. proposal-reviewer does an honest pass; the architect addresses the findings.

## Setup

    npm install docx          # docxkit.cjs
    pip install cairosvg      # figkit.py
    # optional preview: LibreOffice + Poppler (docx -> pdf -> images)

Outputs: out/proposal.docx, figures in out/figs/.
