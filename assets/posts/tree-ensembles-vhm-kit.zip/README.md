# Tree-Ensembles VHM Kit

A drop-in harness that gives **GitHub Copilot in VS Code** the doctrine, commands, and a
runnable scaffold for building **tree-ensemble fault classifiers** for vehicle health
monitoring (VHM): Decision Tree → Random Forest → gradient boosting (XGBoost / LightGBM /
CatBoost) → Extra Trees.

Companion to the post **"Tree Ensembles for Vehicle Health Monitoring."**

## What's inside

```
.github/
  copilot-instructions.md              # always-on doctrine for this repo
  instructions/
    tree-ensembles.instructions.md     # auto-applies to **/*.py
  prompts/
    train-fault-classifier.prompt.md   # /train-fault-classifier
    evaluate-classifier.prompt.md      # /evaluate-classifier
    explain-importance.prompt.md       # /explain-importance
    tune-boosting.prompt.md            # /tune-boosting
  agents/
    vhm-classifier.agent.md            # a custom "VHM Classifier" agent
scaffold/                              # a runnable mini-project
  make_fleet.py    features.py    train.py    evaluate.py
  requirements.txt    README.md
```

## Install (add it to Copilot's harness)

1. Copy the `.github/` folder into the root of your project (merge if you already have one).
   VS Code Copilot auto-loads `copilot-instructions.md`, the `*.instructions.md` files
   (by their `applyTo` glob), the `/`-slash prompt files, and the custom agents.
2. Reload VS Code. In Copilot Chat you'll now have `/train-fault-classifier`,
   `/evaluate-classifier`, `/explain-importance`, `/tune-boosting`, and a **VHM Classifier**
   agent in the agent picker.
3. The `scaffold/` is a working reference Copilot can read, run, and copy from.

## Run the scaffold (no labels or cloud needed)

```bash
cd scaffold
pip install -r requirements.txt
python make_fleet.py        # writes a synthetic labeled fleet (known ground truth)
python train.py             # trains RF (+ XGBoost if installed), prints scorecard + importance
```

Expected: ~98% accuracy on the 3-class P0AE0 problem (connector lot ~100%, firmware bug ~95%,
healthy ~98%), with `connector_resistance` leading the feature importance and the firmware bug
showing up through `firmware_version`, `cold_charge_fraction`, and throttled `peak_charge_current`.
