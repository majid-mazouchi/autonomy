---
applyTo: "**/*.py"
---
# When writing/modifying Python in this repo

- Imports: `scikit-learn` for trees/forests/Extra Trees and metrics; `xgboost` /
  `lightgbm` / `catboost` for boosting; `shap` for per-prediction explanations.
- Training scaffold any classifier must follow:
  1. `train_test_split(..., stratify=y, random_state=0)` — group/time split when a VIN or
     timestamp column exists.
  2. Fit with imbalance handling (`class_weight="balanced"` or `scale_pos_weight`).
  3. Print `classification_report` **and** `confusion_matrix` — never bare accuracy.
  4. Print a feature-importance ranking (`permutation_importance` preferred over `.feature_importances_`).
- One-hot or pass categoricals natively (CatBoost). Do not scale features for trees — it is
  unnecessary and obscures importances.
- Add a one-line comment on each engineered feature stating it is knowable *before* diagnosis
  (leakage guard).
