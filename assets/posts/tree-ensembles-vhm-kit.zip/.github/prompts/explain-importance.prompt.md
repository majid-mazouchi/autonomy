---
mode: agent
description: Explain which signals drove the classifier
---
Explain the model's decisions:
- Compute **permutation importance** (more trustworthy than built-in Gini importance) and
  rank the features.
- For individual predictions, compute **SHAP** values and summarize the top drivers per car.
- State clearly that importance shows what the model *used*, not the physical *cause* — a
  high-ranked feature may be a **confounder**. Frame the ranking as leads to confirm.
