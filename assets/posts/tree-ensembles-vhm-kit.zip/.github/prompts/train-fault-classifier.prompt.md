---
mode: agent
description: Train a tree-ensemble fault classifier from a feature table
---
Build a fault classifier for the table I point you at.

1. Load the data; list the feature columns and the label. Flag any column that looks like
   **leakage** (would not exist before diagnosis) and ask before using it.
2. `train_test_split` with `stratify=y`, `random_state=0` (group-split on VIN / time-split if
   such a column exists).
3. Train, in this order, printing a confusion matrix + per-class precision/recall for each:
   a **Decision Tree** baseline, a **Random Forest** (`class_weight="balanced"`, `oob_score=True`),
   then **XGBoost**.
4. Recommend which to keep and why. End with the **permutation feature importance** ranking.
Never report accuracy without the confusion matrix.
