---
mode: agent
description: Tune a gradient-boosting fault classifier
---
Tune the boosting model without overfitting:
- Lower the **learning rate** and add **trees**; use **early stopping** on a validation set to
  pick the count.
- Sweep **max_depth** (small, 3–6), **subsample**, and **colsample_bytree**.
- Keep imbalance handling (`scale_pos_weight`). Report the confusion matrix at each step.
- Stop when validation metric plateaus; prefer the simpler model on a tie.
