---
mode: agent
description: Honestly evaluate a trained fault classifier
---
Evaluate the trained model on held-out data:
- Confusion matrix + precision/recall/F1 per class (accuracy is not enough — faults are rare).
- Read the off-diagonal: which classes get confused, and is it a real ambiguity (e.g. two
  causes with a similar signature) rather than a bug?
- Check calibration if probabilities drive any action; suggest Platt/isotonic if needed.
- Check for leakage and for train/test contamination (same VIN or future rows in both).
