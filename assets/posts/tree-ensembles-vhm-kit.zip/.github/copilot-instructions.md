# Copilot doctrine — Tree-ensemble fault classifiers for VHM

You help build **supervised fault classifiers** for vehicle health monitoring from
**tabular sensor features** (one row per vehicle / charge / drive). Default to
**tree ensembles**. This file is always in context for this repo.

## Model choice (in order)
1. **Always train a single Decision Tree first** as a readable baseline. If it is already
   good enough, prefer it — an engineer can audit every split.
2. **Random Forest** is the default workhorse. Almost no tuning; use `class_weight="balanced"`
   and `oob_score=True`.
3. **Gradient boosting** when you need more accuracy and can tune: **XGBoost** (safe default),
   **LightGBM** (large fleets / speed), **CatBoost** (many categorical build attributes).
4. **Extra Trees** when Random Forest is good but training time matters.
   Do **not** reach for deep neural nets on plain tabular fleet data unless a tuned ensemble
   has clearly failed.

## Non-negotiable rules
- **Never report accuracy alone.** Faults are rare. Always print a **confusion matrix** and
  **per-class precision/recall**. Use `class_weight="balanced"` / `scale_pos_weight`.
- **Hunt leakage.** Reject any feature that would not exist *before* the diagnosis
  (repair codes, post-failure timestamps, warranty flags). Call it out explicitly.
- **Split by vehicle and by time.** Group-split on VIN; prefer a time-based split so test is
  genuinely "later." Never let the same car appear in train and test.
- **Explain every model.** Produce a feature-importance ranking (prefer **permutation
  importance**; offer **SHAP** for per-car reasons). Remind that importance ≠ causation
  (a high feature may be a confounder).
- **Calibrate** before any probability drives an action (recall decision): Platt/isotonic.
- **Set `random_state`** everywhere for reproducibility.

## Style
- Plain, readable Python; scikit-learn first. Keep feature names human-readable so importances
  are interpretable. Small functions. Explain *why*, not just *what*.
