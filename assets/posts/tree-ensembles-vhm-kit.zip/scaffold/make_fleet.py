"""Generate a synthetic labeled EV fleet with KNOWN ground truth.

Three classes around the P0AE0 charging code:
  healthy, firmware_bug (cold-throttle, fw>=5.1), connector_lot (Supplier-B high resistance).
The two real causes are encoded in connector_resistance and firmware_version, so a good
classifier should rank those features on top.
"""
import numpy as np, pandas as pd

def _has_pyarrow():
    try:
        import pyarrow  # noqa
        return True
    except Exception:
        return False

def make_fleet(n=6000, seed=0):
    rng = np.random.default_rng(seed)
    firmware = rng.choice([5.0, 5.1, 5.2], size=n, p=[0.45, 0.40, 0.15])
    supplier = rng.choice(["A", "B"], size=n, p=[0.7, 0.3])
    cold = np.clip(rng.beta(2, 5, n), 0, 1)            # cold-charge fraction
    age = rng.integers(50, 1200, n)                    # pack age (cycles)
    peak_i = rng.normal(220, 25, n)                    # peak charge current (A)
    base_R = rng.normal(4.0, 0.6, n)                   # healthy connector resistance (mOhm)

    label = np.array(["healthy"] * n, dtype=object)
    R = base_R.copy()

    # cause 1: bad connector lot — Supplier B, raises resistance
    lot = (supplier == "B") & (rng.random(n) < 0.55)
    R[lot] += rng.normal(6.0, 1.2, lot.sum())
    label[lot] = "connector_lot"

    # cause 2: firmware cold-throttle bug — fw>=5.1 AND cold charging.
    # Physical signature: the bug THROTTLES peak charge current in the cold.
    bug = (firmware >= 5.1) & (cold > 0.30) & (rng.random(n) < 0.8) & (label == "healthy")
    peak_i[bug] -= rng.normal(60.0, 10.0, bug.sum())   # throttled -> lower current
    label[bug] = "firmware_bug"

    return pd.DataFrame({
        "vin": [f"VIN{i:06d}" for i in range(n)],
        "connector_resistance": R.round(2),
        "firmware_version": firmware,
        "cold_charge_fraction": cold.round(3),
        "supplier_code": supplier,
        "peak_charge_current": peak_i.round(1),
        "pack_age_cycles": age,
        "label": label,
    })

if __name__ == "__main__":
    df = make_fleet()
    if _has_pyarrow():
        df.to_parquet("fleet_features.parquet")
    else:
        df.to_csv("fleet_features.csv", index=False)
    print(df["label"].value_counts())
    print("wrote fleet_features.*")
