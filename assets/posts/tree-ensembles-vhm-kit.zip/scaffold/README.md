# Scaffold — runnable reference

```bash
pip install -r requirements.txt
python make_fleet.py    # synthetic labeled fleet with known ground truth
python train.py         # Decision Tree -> Random Forest (+ XGBoost if installed) + importance
```

`make_fleet.py` plants two causes: a Supplier-B high-resistance connector lot and an
fw>=5.1 cold-throttle firmware bug (which throttles charge current in the cold). A good
model recovers ~98% accuracy; `connector_resistance` leads the importance and the firmware
bug is revealed by `firmware_version` + `cold_charge_fraction` + a throttled
`peak_charge_current` — the importance points straight at the real causes. Copy these files
as the starting point for a real feature table.
