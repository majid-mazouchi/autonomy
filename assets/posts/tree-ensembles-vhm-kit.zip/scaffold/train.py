"""Train the baseline + ensembles, print an honest scorecard and feature importance."""
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import classification_report, confusion_matrix
from features import load

def main():
    X, y = load()
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.25, stratify=y, random_state=0)

    print("\n=== Decision Tree (readable baseline) ===")
    dt = DecisionTreeClassifier(max_depth=4, class_weight="balanced", random_state=0)
    dt.fit(X_tr, y_tr)
    print(classification_report(y_te, dt.predict(X_te)))

    print("=== Random Forest (default workhorse) ===")
    rf = RandomForestClassifier(n_estimators=400, class_weight="balanced",
                                oob_score=True, random_state=0, n_jobs=-1)
    rf.fit(X_tr, y_tr)
    print("OOB accuracy:", round(rf.oob_score_, 3))
    print(classification_report(y_te, rf.predict(X_te)))
    print("Confusion matrix (rows=true, cols=pred):", list(rf.classes_))
    print(confusion_matrix(y_te, rf.predict(X_te)))

    try:
        from xgboost import XGBClassifier
        print("\n=== XGBoost ===")
        yc = y_tr.astype("category")
        xgb = XGBClassifier(n_estimators=600, max_depth=4, learning_rate=0.05,
                            subsample=0.8, colsample_bytree=0.8,
                            eval_metric="mlogloss", random_state=0)
        xgb.fit(X_tr, yc.cat.codes)
        codes = y_te.astype("category").cat.codes
        print(confusion_matrix(codes, xgb.predict(X_te)))
    except Exception as e:
        print("\n(xgboost not installed — skipping; pip install xgboost to enable)")

    print("\n=== Permutation importance (Random Forest) ===")
    imp = permutation_importance(rf, X_te, y_te, n_repeats=10, random_state=0)
    for name, score in sorted(zip(X.columns, imp.importances_mean), key=lambda t: -t[1]):
        print(f"  {name:28s} {score:.3f}")

if __name__ == "__main__":
    main()
