"""Load the fleet table and split into X / y with a leakage-safe feature list."""
import pandas as pd, os

FEATURES = [
    "connector_resistance",   # mOhm, knowable before diagnosis
    "firmware_version",       # numeric, build record
    "cold_charge_fraction",   # share of charges < 5 C
    "supplier_code",          # categorical A/B
    "peak_charge_current",    # A
    "pack_age_cycles",        # cycles
]

def load():
    if os.path.exists("fleet_features.parquet"):
        df = pd.read_parquet("fleet_features.parquet")
    else:
        df = pd.read_csv("fleet_features.csv")
    X = pd.get_dummies(df[FEATURES])      # one-hot supplier_code
    y = df["label"]
    return X, y
