"""Standalone evaluation helper: confusion matrix + per-class report for any fitted model."""
from sklearn.metrics import classification_report, confusion_matrix

def report(model, X_te, y_te):
    pred = model.predict(X_te)
    print("Classes:", list(getattr(model, "classes_", [])))
    print("Confusion matrix (rows=true, cols=pred):")
    print(confusion_matrix(y_te, pred))
    print(classification_report(y_te, pred))
