"""
nvh_precond_rca.py
==================================================================
Root-cause analysis of a preconditioning-mode NVH complaint in an
EV traction drive.

Field symptom: a tonal "drone/whine" reported by customers ONLY when
battery preconditioning (stator/active heating) is active in cold
ambient, at standstill. Acoustic order analysis shows a tonal peak.

Physics baked into the simulation (the ground truth):

  Active heating injects a large d-axis current i_d at an electrical
  frequency f_inj to dump copper/iron loss as heat at zero torque.
  Large i_d saturates the stator teeth, which enriches the 5th and
  7th spatial harmonics of the airgap MMF/flux. Their interaction
  produces a dominant 6th-order radial Maxwell-stress (force) wave.
  Its temporal frequency is f_force = 6 * f_inj. If f_force lands
  near a stator structural mode (e.g. the ovalizing mode), a high-Q
  resonance amplifies the radial force into audible tonal NVH.

  Confounder: the aggressive thermal calibration (cal_A) commands
  BOTH high i_d AND high coolant-pump duty. Pump duty therefore
  correlates with the complaint without causing the tonal peak.

Ground-truth chain:
  cal_A -> high i_d -> saturation -> 5th/7th harmonics -> 6th-order
  radial force; amplified IF 6*f_inj ~ stator mode -> tonal SPL.
  (cal_A -> high pump duty  = the red-herring proxy.)

Deps: numpy, scipy.
==================================================================
"""
import numpy as np, csv, json
from scipy import stats

rng = np.random.default_rng(19)
N = 320
ID0 = 150.0          # reference d-axis current (A) for saturation scaling
QF  = 10.0           # structural modal quality factor

# ---------- data generation (the mockup fleet) ----------
# Upstream root: ~45% of fleet on the aggressive thermal calibration.
cal_aggressive = (rng.random(N) < 0.45).astype(int)

# i_d injection amplitude (A): set by calibration.
i_d = np.where(cal_aggressive == 1, rng.normal(240, 20, N),
                                     rng.normal(110, 18, N)).clip(20)

# Coolant-pump duty (%): the aggressive cal also ramps the pump ->
# pump duty is a PROXY for cal_A, correlated with the complaint but
# not a cause of the tonal peak.
pump_duty = np.where(cal_aggressive == 1, rng.normal(72, 7, N),
                                          rng.normal(46, 9, N)).clip(0, 100)

# Injection electrical frequency (Hz): mostly independent of cal.
f_inj = rng.normal(220, 55, N).clip(120, 340)
f_force = 6.0 * f_inj                       # dominant radial-force order

# Motor structural variant -> stator ovalizing-mode frequency (Hz).
variant = (rng.random(N) < 0.5).astype(int)
struct_mode = np.where(variant == 1, rng.normal(1680, 80, N),
                                      rng.normal(1320, 70, N))

# Cold-ambient / usage decoys (weakly related; not causal to tonal peak).
ambient_C = rng.normal(2, 8, N)
precond_frac = (0.5 - 0.02 * ambient_C + rng.normal(0, 0.08, N)).clip(0.05, 0.95)

# ---- physics ----
def res_amp(f, fn, Q=QF):                   # SDOF resonance magnification
    r = f / fn
    return 1.0 / np.sqrt((1 - r**2)**2 + (r / Q)**2)

H57 = (i_d / ID0) ** 2                       # 5th/7th harmonic content (saturation)
A_res = res_amp(f_force, struct_mode)        # structural amplification
F_radial = H57 * A_res                        # radial-force amplitude (norm.)

# Tonal sound pressure level at f_force (dB(A)).
SPL_tonal = (20 * np.log10(F_radial) + 42 + rng.normal(0, 1.6, N)).clip(28)
resonance_dB = 20 * np.log10(A_res)          # useful engineered feature

# Pump contributes broadband (NOT to the tonal peak) -> overall SPL.
SPL_pump = 0.35 * pump_duty + 30 + rng.normal(0, 1.5, N)
SPL_overall = 10 * np.log10(10**(SPL_tonal/10) + 10**(SPL_pump/10) + 10**(3.5))

# Measured tonal frequency (Hz) = 6 * f_inj + small estimation error.
tonal_freq = f_force + rng.normal(0, 8, N)

fields = ["vin","cal_aggressive","i_d_A","f_inj_Hz","f_force_Hz","struct_mode_Hz",
          "variant","pump_duty_pct","ambient_C","precond_frac","resonance_dB",
          "tonal_freq_Hz","SPL_tonal_dBA","SPL_overall_dBA"]

def write_csv(path="nvh_fleet.csv"):
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh); w.writerow(fields)
        for i in range(N):
            w.writerow([f"VIN{i:04d}", int(cal_aggressive[i]), round(float(i_d[i]),1),
                round(float(f_inj[i]),1), round(float(f_force[i]),1), round(float(struct_mode[i]),1),
                int(variant[i]), round(float(pump_duty[i]),1), round(float(ambient_C[i]),1),
                round(float(precond_frac[i]),3), round(float(resonance_dB[i]),2),
                round(float(tonal_freq[i]),1), round(float(SPL_tonal[i]),2),
                round(float(SPL_overall[i]),2)])
    print(f"wrote {path} ({N} rows)")

# ---------- analysis ----------
features = {
    "Pump duty (%)":        pump_duty,
    "i_d injection (A)":    i_d,
    "Resonance gain (dB)":  resonance_dB,
    "Inj. frequency (Hz)":  f_inj,
    "Ambient temp (C)":     ambient_C,
    "Precond fraction":     precond_frac,
}
y = SPL_tonal

def pearson(x): r,p = stats.pearsonr(x,y); return round(float(r),3), float(p)

def partial(x, z):
    rx = x - np.polyval(np.polyfit(z,x,1), z)
    ry = y - np.polyval(np.polyfit(z,y,1), z)
    r,p = stats.pearsonr(rx,ry); return round(float(r),3), float(p)

def reg(cols):
    X = np.column_stack([np.ones(N)]+cols)
    b,*_ = np.linalg.lstsq(X,y,rcond=None)
    r2 = 1 - np.sum((y-X@b)**2)/np.sum((y-y.mean())**2)
    return b, round(float(r2),3)

raw = {k: pearson(v) for k,v in features.items()}
part_id = {k: partial(v, i_d) for k,v in features.items() if k!="i_d injection (A)"}
id_ctrl_pump = partial(i_d, pump_duty)

b1,r2_1 = reg([pump_duty])
b2,r2_2 = reg([pump_duty, H57])                       # add saturation term
b3,r2_3 = reg([pump_duty, H57, A_res])                # add resonance -> jumps

# ---------- mitigation simulation ----------
# (a) Harmonic current injection (HCI): inject anti-phase 6th-order
#     current to cancel the offending force harmonic.
hci_cancel = 0.82                                     # 82% force-order cancellation
spl_drop_hci = -20*np.log10(1 - hci_cancel)           # dB reduction
# (b) Frequency dither: move f_inj 18% off resonance -> A drops.
detune = 0.18
A_detuned = res_amp(f_force*(1+detune), struct_mode)
spl_drop_dither = float(np.median(20*np.log10(A_res/A_detuned)[A_res>3]))

# force-order spectrum (temporal orders of f_inj), saturated machine, loud vehicle
orders = [2,4,6,8,10,12]
force_before = [6,9,26,7,4,3]                         # dB, 6th dominant
force_after  = [6,9,26-spl_drop_hci,7,4,3]            # 6th cut by HCI

# saturation curve: 5th & 7th harmonic vs i_d
id_axis = list(range(60, 281, 20))
h5 = [round(1.0*(a/ID0)**2.1,3) for a in id_axis]
h7 = [round(0.7*(a/ID0)**2.3,3) for a in id_axis]

# resonance curve: SPL vs f_force/struct_mode
ratio_axis = [round(0.6+0.02*i,3) for i in range(41)]   # 0.6..1.4
res_curve = [round(20*np.log10(res_amp(r,1.0))+42,2) for r in ratio_axis]

# order-tracking: tonal freq vs f_inj (slope 6), with decoy lines
def sample(x, n=150):
    idx = rng.choice(N, min(n,N), replace=False)
    return idx

idx = sample(SPL_tonal)
def pts(x, ys): return [[round(float(x[i]),2), round(float(ys[i]),2),
                         int(cal_aggressive[i]), int(resonance_dB[i]>3)] for i in idx]

out = {
  "N": N, "QF": QF,
  "raw": {k:{"r":v[0],"p":v[1]} for k,v in raw.items()},
  "partial_ctrl_id": {k:{"r":v[0],"p":v[1]} for k,v in part_id.items()},
  "id_ctrl_pump": {"r":id_ctrl_pump[0],"p":id_ctrl_pump[1]},
  "reg": {"m1_pump_coef":round(float(b1[1]),3),"m1_r2":r2_1,
          "m2_pump_coef":round(float(b2[1]),3),"m2_r2":r2_2,
          "m3_pump_coef":round(float(b3[1]),3),"m3_r2":r2_3},
  "scatter_pump": pts(pump_duty, SPL_tonal),
  "scatter_id":   pts(i_d, SPL_tonal),
  "scatter_order":[[round(float(f_inj[i]),1), round(float(tonal_freq[i]),1)] for i in idx],
  "order_decoys": {"slope6":6, "fmax":340},
  "sat_curve": {"id":id_axis, "h5":h5, "h7":h7},
  "res_curve": {"ratio":ratio_axis, "spl":res_curve, "Q":QF},
  "force_orders": {"orders":orders, "before":force_before, "after":[round(x,1) for x in force_after]},
  "spl_hist": {"loud":int((SPL_tonal>=60).sum()), "quiet":int((SPL_tonal<60).sum())},
  "mitig": {"hci_drop":round(spl_drop_hci,1), "dither_drop":round(spl_drop_dither,1),
            "hci_cancel_pct":int(hci_cancel*100), "detune_pct":int(detune*100)},
  "strat": {
     "aggr_spl":round(float(SPL_tonal[cal_aggressive==1].mean()),1),
     "cons_spl":round(float(SPL_tonal[cal_aggressive==0].mean()),1),
     "aggr_id":round(float(i_d[cal_aggressive==1].mean()),0),
     "cons_id":round(float(i_d[cal_aggressive==0].mean()),0),
     "loud_resonant_frac": round(float((resonance_dB[(cal_aggressive==1)]>3).mean()),2),
  },
}

def prognose_complaints(spl_mean, spl_sd=3.0, weeks=26, ncust=5000,
                        thresh=60.0, kspl=2.5, haz=0.02, seed=23):
    """Monte Carlo: cumulative customer-complaint probability over a
    cold season, given the at-risk tonal level. Returns P(complaint<3mo)."""
    g = np.random.default_rng(seed)
    spl = g.normal(spl_mean, spl_sd, ncust)
    pe = 1.0 / (1.0 + np.exp(-(spl - thresh) / kspl))
    ev = g.poisson(4.5, (ncust, weeks))
    first = np.full(ncust, np.nan); done = np.zeros(ncust, bool)
    for w in range(weeks):
        ann = g.binomial(ev[:, w], pe)
        hit = (g.random(ncust) < 1 - (1 - haz) ** ann) & ~done
        first[hit] = w + 1; done |= hit
    first = np.where(np.isnan(first), weeks + 1, first)
    return float(np.mean(first <= 13))    # P(complaint within ~3 months)

def run_prognosis():
    print("\n[6] COMPLAINT PROGNOSIS (Monte Carlo, at-risk cohort)")
    loud = float(SPL_tonal[(cal_aggressive == 1) & (resonance_dB > 3)].mean())
    for label, spl in [("no fix ", loud), ("HCI fix", loud - 14.9)]:
        p = prognose_complaints(spl)
        print(f"    {label}: tonal={spl:5.1f} dB(A)  P(complaint<3mo)={p:.0%}")

if __name__ == "__main__":
    write_csv()
    json.dump(out, open("nvh_data.json","w"))
    print("RAW correlation vs tonal SPL:")
    for k,(r,p) in raw.items(): print(f"  {k:22s} r={r:+.3f} p={p:.1e}")
    print("\nPARTIAL (controlling for i_d):")
    for k,(r,p) in part_id.items(): print(f"  {k:22s} r={r:+.3f} p={p:.2f}")
    print(f"\ni_d controlling for pump: r={id_ctrl_pump[0]:+.3f} p={id_ctrl_pump[1]:.1e}")
    print(f"\nRegression R^2:  pump={r2_1}  +saturation={r2_2}  +resonance={r2_3}")
    print(f"  pump coef:    m1={b1[1]:+.3f}  m3={b3[1]:+.3f}  (collapses)")
    print(f"\nStratify: aggr cal SPL={out['strat']['aggr_spl']} dB (i_d={out['strat']['aggr_id']}A)"
          f"  cons cal SPL={out['strat']['cons_spl']} dB")
    print(f"Mitigation: HCI -{out['mitig']['hci_drop']} dB,  dither -{out['mitig']['dither_drop']} dB")
    run_prognosis()
