Preconditioning-mode NVH RCA — code & data
===========================================
nvh_precond_rca.py : physics-based generator of the 320-vehicle fleet
                     (nvh_fleet.csv) + full diagnostic pipeline (screen,
                     partial-correlation confounder test, staged regression,
                     order/saturation/resonance, mitigation, complaint
                     prognosis). Run:  python nvh_precond_rca.py
nvh_prog.py        : standalone Monte Carlo complaint-prognosis simulation.
nvh_fleet.csv      : the generated mockup dataset.
Deps: numpy, scipy.
