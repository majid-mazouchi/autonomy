"""Monte Carlo complaint-emergence prognosis for the preconditioning
NVH issue: predict cumulative customer-complaint probability over a
cold season for the at-risk cohort, with vs without the HCI fix."""
import numpy as np, json
rng = np.random.default_rng(23)
WEEKS, NCUST = 26, 5000          # ~6 cold-season months
THRESH, KSPL, HAZ = 60.0, 2.5, 0.02   # audibility logistic + per-event complaint hazard

def p_event(spl):                # prob a precond event is audibly annoying
    return 1.0/(1.0+np.exp(-(spl-THRESH)/KSPL))

def simulate(spl_mean, spl_sd):
    spl = rng.normal(spl_mean, spl_sd, NCUST)
    pe = p_event(spl)
    ev_per_wk = rng.poisson(4.5, (NCUST, WEEKS))      # winter precond events
    first = np.full(NCUST, np.nan)
    cum_ann = np.zeros((NCUST, WEEKS+1))
    complained = np.zeros(NCUST, bool)
    for w in range(WEEKS):
        annoying = rng.binomial(ev_per_wk[:, w], pe)
        cum_ann[:, w+1] = cum_ann[:, w] + annoying
        ph = 1-(1-HAZ)**annoying                       # complaint prob this week
        hit = (rng.random(NCUST) < ph) & ~complained
        first[hit] = w+1; complained |= hit
    first_filled = np.where(np.isnan(first), WEEKS+1, first)
    return cum_ann, first_filled

def summarize(spl_mean, spl_sd):
    cum, first = simulate(spl_mean, spl_sd)
    wk = list(range(WEEKS+1))
    mo = [round(w/4.333,2) for w in wk]
    pct = lambda q: [round(float(np.percentile(cum[:,w],q)),1) for w in wk]
    pof = [round(float(np.mean(first<=w)),3) for w in wk]
    # weeks-to-complaint histogram -> months
    edges = list(range(0, WEEKS+3, 2))
    hist,_ = np.histogram(first[first<=WEEKS], bins=edges)
    return dict(months=mo, p10=pct(10), p50=pct(50), p90=pct(90), pof=pof,
                med_wk=float(np.median(first[first<=WEEKS])) if np.any(first<=WEEKS) else WEEKS,
                hist=[int(h) for h in hist], edges=[round(e/4.333,2) for e in edges])

out = {"weeks":WEEKS,
       "no_fix": summarize(67.0, 3.0),       # at-risk: aggressive + resonant
       "fix":    summarize(67.0-15.0, 3.0)}  # after HCI: -15 dB
out["pof_3mo_nofix"] = out["no_fix"]["pof"][13]
out["pof_3mo_fix"]   = out["fix"]["pof"][13]
out["med_mo_nofix"]  = round(out["no_fix"]["med_wk"]/4.333,1)
json.dump(out, open("nvh_prog.json","w"))
print(f"no-fix: P(complaint<3mo)={out['pof_3mo_nofix']:.0%}, median {out['med_mo_nofix']} mo")
print(f"fix   : P(complaint<3mo)={out['pof_3mo_fix']:.0%}")
print("wrote nvh_prog.json")
