---
name: 3d-camera-choreography
description: Drive Three.js cameras through named poses — smooth tweens between viewpoints bound to buttons, slide changes, or scroll steps — turning a 3D scene into a guided tour. Use whenever the user wants camera animations, "fly to" views, a guided 3D walkthrough, scroll-driven 3D, or per-slide camera angles. Builds on threejs-scene-foundation; composes with html-slide-mode and scrollytelling-figures.
---

# 3D Camera Choreography

A tour is a list of **named poses** plus one tween. Everything else is binding.

## 1. Poses & tween

```js
const poses={ overview:{p:[3,2.2,3], t:[0,0.4,0]},
              top:     {p:[0.01,5,0.01], t:[0,0,0]},
              detail:  {p:[1.2,0.6,0.4], t:[0.6,0.4,0]} };
let tw=null;
function flyTo(name,ms=900){
  const P=poses[name];
  if(REDUCED_MOTION){ camera.position.set(...P.p); controls.target.set(...P.t); return; }
  tw={p0:camera.position.clone(), t0:controls.target.clone(),
      p1:new THREE.Vector3(...P.p), t1:new THREE.Vector3(...P.t), s:performance.now(), ms};
}
// in the RAF update:
if(tw){ let u=Math.min(1,(performance.now()-tw.s)/tw.ms); u=u*u*(3-2*u);   // smoothstep
  camera.position.lerpVectors(tw.p0,tw.p1,u);
  controls.target.lerpVectors(tw.t0,tw.t1,u);
  if(u>=1) tw=null; }
```
**Tween the target too** — position-only tweens swing wildly. Smoothstep easing, 700–1200 ms; near-vertical "top" poses need a tiny x/z offset (0.01) or OrbitControls gimbal-flips.

## 2. Bindings

- **Buttons**: pose pills under the figure (`data-pose` attr → flyTo). Always include an "overview" home pose.
- **Slides** (html-slide-mode): `slide.dataset.pose` → flyTo on slide change. The deck becomes a directed tour; the audience can still grab and orbit between transitions.
- **Scroll** (scrollytelling-figures): step's `data-state` maps to a pose; IntersectionObserver calls flyTo. Scroll-position-proportional camera paths (CatmullRomCurve3 through poses, u = scroll fraction) are flashier but harder to make comfortable — default to discrete poses.

## 3. Sharing control with the user

User input during a tween: cancel the tween (`tw=null`) on `controls.start` event — fighting the user is worse than abandoning the move. Re-syncing: any binding fires flyTo again. Keep damping on; it blends tween-end into user control gracefully.

| Symptom | Fix |
|---|---|
| Camera spirals on vertical poses | offset 0.01 from the pole; or switch up-vector handling |
| Tween fights the user | cancel on controls 'start' |
| Motion sickness feedback | longer/fewer moves, smoothstep, never roll the camera |
| Pose looks wrong after content edits | poses are data — re-record by logging camera.position/target from a live session |
