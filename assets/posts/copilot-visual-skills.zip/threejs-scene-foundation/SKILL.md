---
name: threejs-scene-foundation
description: The base layer for any Three.js 3D visualization inside HTML pages — scene/camera/renderer boilerplate, OrbitControls, paper-aesthetic styling in 3D, the CDN-vs-vendored delivery decision, render-on-demand, disposal, and WebGL fallbacks. Consult this FIRST whenever the user asks for anything 3D, WebGL, three.js, a 3D plot/model/scene, or "make it 3D". All other 3D skills assume this foundation.
---

# Three.js Scene Foundation

3D is the one place this kit permits a library. That permission comes with obligations: an explicit delivery decision, a fallback, and cleanup.

## 1. First question: does it need WebGL?

Layered architecture "3D", stacked platforms, simple extruded boxes → use `isometric-svg-diagrams` (zero-dep) instead. Reach for Three.js only for: data surfaces, real models, free orbiting, lighting/depth that matters, or animation in 3D space.

## 2. Delivery policy (state it in the page footer)

```html
<script type="importmap">
{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js",
            "three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}
</script>
```
- **Connected pages**: import-map + CDN, loaded **on demand** (button or IntersectionObserver) — never block first paint on 600 KB of engine for a figure below the fold.
- **Offline-guaranteed pages** (iOS preview, air-gapped): vendor `three.module.js` (+ needed addons) next to the HTML and point the import map at relative paths. Pin the version either way.
- Wrap the dynamic `import('three')` in try/catch → on failure show a static screenshot of the scene plus one explanatory line. A broken black rectangle is never acceptable.

## 3. Boilerplate (copy verbatim)

```js
function makeScene(canvas, camPos){
  const renderer=new THREE.WebGLRenderer({canvas, antialias:true});
  renderer.setPixelRatio(Math.min(2, window.devicePixelRatio||1));
  renderer.setSize(canvas.clientWidth, +canvas.getAttribute('height'), false);
  const scene=new THREE.Scene(); scene.background=new THREE.Color(0xFFFEF9); // paper
  const camera=new THREE.PerspectiveCamera(40, canvas.clientWidth/+canvas.getAttribute('height'), 0.1, 100);
  camera.position.set(...camPos);
  scene.add(new THREE.HemisphereLight(0xfff8ec, 0xd8d0bc, 1.1));        // warm sky, parchment ground
  const dl=new THREE.DirectionalLight(0xffffff, 0.8); dl.position.set(3,5,2); scene.add(dl);
  const controls=new OrbitControls(camera, renderer.domElement); controls.enableDamping=true;
  return {renderer, scene, camera, controls};
}
```
Paper aesthetic in 3D: near-paper background, hemisphere light (no harsh black shadows), `MeshStandardMaterial` with roughness 0.6–0.9, token-palette colors, a `GridHelper` in rule/parchment grays as the ground.

## 4. Render strategy

- **Static-once-posed scenes**: render-on-demand — render once, then only on `controls.addEventListener('change', render)` and resize. Saves battery.
- **Animated scenes**: one shared RAF loop ticking every active demo `{update(t); controls.update(); renderer.render(...)}`. Stop the loop when the page is hidden (`visibilitychange`).
- Resize: `renderer.setSize(w,h,false)`; update `camera.aspect` + `updateProjectionMatrix()`.
- One renderer per figure is fine up to ~6 contexts per page; beyond that, share one renderer with scissor regions.

## 5. Cleanup & limits

Teardown order: `geometry.dispose()`, `material.dispose()`, `texture.dispose()`, `renderer.dispose()`. Leaked contexts kill mobile Safari quietly. Honor reduced motion: no auto-rotate, jump-cut camera moves.

| Symptom | Fix |
|---|---|
| Blurry on phone | setPixelRatio (capped at 2) |
| Stretched scene | buffer aspect ≠ camera.aspect — set both from the same w/h |
| Page dies after revisits | dispose on teardown; cap pixel ratio |
| Black box offline | try/catch the import; static fallback image |
