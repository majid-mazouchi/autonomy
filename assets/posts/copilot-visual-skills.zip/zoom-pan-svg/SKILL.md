---
name: zoom-pan-svg
description: Make large inline SVG diagrams explorable with zoom and pan — wheel zoom toward the cursor, drag panning, pinch zoom, and a reset button, all by manipulating the viewBox. Use whenever a diagram is too detailed to read at page width, or the user asks for a zoomable, pannable, explorable, or "map-like" diagram, system landscape, or large architecture view. No libraries.
---

# Zoom & Pan SVG

Manipulate the **viewBox**, never CSS transforms: viewBox keeps stroke widths and text crisp at every zoom and needs no inverse-transform math for hit testing.

## 1. State & helpers

```js
const base={x:0,y:0,w:900,h:420};          // the authored viewBox
let vb={...base};
function apply(){ svg.setAttribute('viewBox', vb.x+' '+vb.y+' '+vb.w+' '+vb.h); }
function toSvg(cx,cy){                      // client px → svg units
  const r=svg.getBoundingClientRect();
  return { x: vb.x+(cx-r.left)/r.width*vb.w, y: vb.y+(cy-r.top)/r.height*vb.h };
}
```

## 2. Wheel zoom (toward the cursor)

```js
svg.addEventListener('wheel',e=>{
  e.preventDefault();                                   // listener {passive:false}!
  const p=toSvg(e.clientX,e.clientY), f=e.deltaY>0?1.18:1/1.18;
  const w=Math.min(base.w*2, Math.max(base.w/8, vb.w*f));
  vb={ x:p.x-(p.x-vb.x)*(w/vb.w), y:p.y-(p.y-vb.y)*(w/vb.w)*(vb.h/vb.w)/(vb.h/vb.w), w, h:w*base.h/base.w };
  apply();
},{passive:false});
```
Clamp zoom (≈ base/8 … base×2) and keep aspect ratio (`h = w·H/W` always).

## 3. Drag pan + pinch (pointer events cover mouse AND touch)

- `touch-action:none` on the SVG, `cursor:grab/grabbing`.
- pointerdown: record start point (svg units) + setPointerCapture. pointermove with one pointer: `vb.x = startVb.x − (cur.x − start.x)` (compute cur in *base-of-gesture* coordinates). pointerup/cancel: end.
- Pinch: track two active pointers in a Map; zoom factor = currentDistance/startDistance applied about the midpoint, same math as wheel.
- A visible **⟲ Reset** button restores `vb={...base}` — mandatory; lost users must have a way home. Optionally show zoom % in a corner chip.

## 4. Checklist & pitfalls

- [ ] Page doesn't scroll while wheeling over the diagram (passive:false + preventDefault)
- [ ] One-finger drag pans on touch; page scroll still possible OUTSIDE the svg
- [ ] Zoom clamped; aspect ratio constant; Reset always works
- [ ] Text remains crisp when zoomed (you used viewBox, not transform)

| Symptom | Fix |
|---|---|
| Wheel zooms page, not diagram | addEventListener options {passive:false} |
| Pan jumps on second drag | recompute start point per gesture; use pointer capture |
| Blurry at zoom | you scaled with CSS transform — switch to viewBox |
| Mobile can't scroll past the figure | touch-action:none only on the svg, not its container; keep figure < 60vh tall |
