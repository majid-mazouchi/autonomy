---
name: concept-graphs
description: Build node-link concept/knowledge graphs as inline SVG for relationships that are NOT hierarchical — dependency maps, system interaction diagrams, idea-relationship webs — with typed edges and hover-neighborhood highlighting. Use whenever the user wants a knowledge graph, dependency graph, relationship map, "how these concepts connect" diagram, or a systems interaction web. No force simulation, no libraries.
---

# Concept Graphs

A concept graph differs from a tree (no single root) and a mind map (relations matter, not just grouping). The two design decisions are **placement** and **edge typing**.

## 1. Placement (manual, deterministic)

- ≤ 12 nodes: place by hand. Hubs (highest degree) toward the center; peripheral nodes on a loose ring; related clusters adjacent. Iterate until **zero or near-zero edge crossings** — for ≤12 nodes this is always achievable by reordering, and it matters more than any aesthetic choice.
- No force-directed simulation: results differ per run, jitter on load, and can't be code-reviewed. Determinism is a feature of hand layout.
- Nodes: stadium rects or circles sized roughly by importance (2 sizes max). Token color by node *category*, declared in a legend.

## 2. Edge typing

- Encode relation type in stroke style, not just color: solid = depends-on / requires, dashed = informs / influences, double-line or thick = composes.
- Direction matters → arrowhead; mutual → two offset parallel edges (never double-headed).
- Edge labels only where the relation isn't obvious from the legend; 10.5–11.5px, placed at the edge midpoint with a small paper-colored backing rect so lines don't strike through the text.
- Bowed quadratic curves for edges that would otherwise overlap or pass through nodes.

## 3. Interactions

Reuse `svg-interactivity-layer` wholesale: `data-links` adjacency on every node, hover/focus dims everything outside the neighborhood, tooltip carries the node's one-liner. Add a **legend that is itself interactive**: hovering a legend entry dims all edges of other types — the fastest way to read a multi-relation graph.

## 4. Checklist & pitfalls

- [ ] Edge crossings ≈ 0; no edge passes under an unrelated node
- [ ] Legend covers every stroke style and color used
- [ ] data-links audited against drawn edges (generate both from one adjacency table)
- [ ] ≤ 12 nodes per graph; bigger graphs get clustered into linked sub-graphs

| Symptom | Fix |
|---|---|
| Hairball | cluster + split; or demote weak edges to an on-demand layer toggle |
| Edge labels unreadable | backing rects; or move relation meaning into the legend |
| Hover highlight misleading | data-links must include the edges, not just neighbor nodes |
