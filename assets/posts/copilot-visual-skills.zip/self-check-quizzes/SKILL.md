---
name: self-check-quizzes
description: Build inline self-check quizzes for educational pages — multiple-choice questions with instant marking, explain-on-answer feedback, and an optional running score chip. Use whenever the user wants comprehension checks, "test yourself" blocks, quiz questions, knowledge checks, or interactive Q&A inside a monograph, course page, or onboarding doc. Vanilla JS; learning aid, not assessment.
---

# Self-Check Quizzes

Purpose: **retrieval practice**, not grading. The explanation after answering is the payload; the question exists to make the reader commit first.

## 1. Markup

```html
<div class="quiz" data-qid="q1">
  <div class="qq">Q. Raising verifier strength v primarily converts…</div>
  <button class="qopt" data-ok="1">false successes into honest retries</button>
  <button class="qopt">retries into false successes</button>
  <button class="qopt">iterations into tokens</button>
  <div class="qexp">Right — a stronger verifier catches broken attempts, so they loop again
  instead of shipping. Failure becomes recoverable. (See Lab A.)</div>
</div>
```

## 2. Behavior

On option click: mark the clicked button `.correct` or `.wrong`; ALSO mark the correct one `.correct` (the reader must always leave knowing the answer); reveal `.qexp` (`aria-live="polite"`); set all options `aria-pressed`/disabled-styled but keep them clickable for re-reading — never trap the reader in a wrong state. Optional score chip: increment shown score only on first-attempt-correct; never shame ("2/3 on first try", not "FAILED").

## 3. Authoring rules

- Distractors must be *plausible misconceptions*, not jokes — each wrong option should correspond to a real confusion the explanation then dispels.
- One concept per question; 3–4 options; the explanation cites the section/figure that teaches it.
- Place a quiz AFTER the teaching, never as a gate before it.
- Randomizing option order is optional; if done, do it once at render (stable within a session).

## 4. Checklist & pitfalls

- [ ] Correct answer revealed on any choice; explanation always shown
- [ ] Re-clicking after answering doesn't double-count score
- [ ] Keyboard: options are real <button>s (free focus/Enter handling)
- [ ] Explanations reference where in the document the concept lives

| Symptom | Fix |
|---|---|
| Quiz feels like a test | soften copy; score optional; explanation generous |
| Readers game it by clicking all | count first attempt only; that's fine — they still read the explanation |
| Distractors trivially wrong | rewrite each as a named misconception |
