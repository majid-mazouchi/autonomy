---
name: interactive-parameter-labs
description: Build dependency-free interactive "labs" inside HTML pages — canvas plots driven live by sliders, toggles, and preset buttons, with color-coded metric readouts. Use whenever the user wants an interactive chart, parameter explorer, live simulation, what-if widget, Monte-Carlo demo, tuning playground, sensitivity study, or says "let the reader move a slider and see the effect". Vanilla JS + <canvas> only; no Chart.js, no D3, no React.
---

# Interactive Parameter Labs

The pattern: **sliders → recompute → redraw**, fast enough to feel continuous (`input` events, full recompute per tick — 10³–10⁵ ops per frame is fine on phones).

## 1. Lab block structure (matches paper-monograph-shell)

```
.lab
 ├ .lt (mono uppercase label)   ├ h3 (what the knob teaches)
 ├ .presets  <button data-p="2.2,1.2,0.25">Balanced</button>…
 ├ .controls  .ctrl × N: <label>Kp <output id="kpOut"></output></label><input type=range>
 ├ .toggles   checkboxes for regime switches (saturation on/off…)
 ├ .readouts  .ro chips: uppercase label + value, class good/warn/bad by threshold
 ├ canvas.plot (height attr = CSS px) + .plotlab caption + .legend
```

## 2. DPR-correct canvas (copy verbatim)

```js
function setupCanvas(c){
  const dpr=window.devicePixelRatio||1, w=c.clientWidth, h=+c.getAttribute('height');
  c.width=Math.round(w*dpr); c.height=Math.round(h*dpr);
  const ctx=c.getContext('2d'); ctx.setTransform(dpr,0,0,dpr,0,0);
  return {ctx,w,h};
}
```
Call it at the top of every draw (resizing the backing store also clears it). A debounced `resize` listener triggers one full redraw.

## 3. Plotting method

- Map data→pixels with two arrow functions `X=t=>padL+t/T*(w-padL-padR)` and `Y=v=>padT+(vMax-clamp(v))/(vMax-vMin)*(h-padT-padB)`; pads ≈ L40 R12 T12 B24.
- Gridlines first (`#E7E0CC`, 1px) with mono 10.5px labels in muted ink; emphasize semantic lines (0 dB, setpoint) with dashes.
- Data series 2.2px in token colors; reference/baseline series 1.6px gray or dashed.
- Log axes: `Math.log10` inside `X()`/`Y()`; label decades only.
- Event markers (disturbance onset, threshold): dashed vertical line + small label in the event's color.

## 4. Computation patterns

- **ODE/step responses**: forward Euler, `dt` 1–2 ms, `Float32Array` buffers; clamp states (`|y|>1e3 → clamp`) so unstable settings draw dramatically instead of producing NaN.
- **Transport delay**: ring buffer of `round(Td/dt)` samples.
- **Monte Carlo**: 2–5k trials per slider tick; histogram into outcome-colored stacked bars; sort once for medians.
- **Closed forms** beat simulation when available — compute both ways during development to cross-check one point.

## 5. Wiring

```js
[s1,s2,s3].forEach(el=>el.addEventListener('input',update));
chk.addEventListener('change',update);
document.querySelectorAll('#labSection .presets button').forEach(b=>
  b.addEventListener('click',()=>{ /* parse b.dataset.p, set sliders, update() */ }));
```
**Scope preset selectors to the lab's section id** — page-global `.presets button` handlers collide when a page has several labs. `update()` reads sliders → writes `<output>`s → computes → sets readout text *and* `className='rv good|warn|bad'` → draws.

## 6. Readout thresholds

Pick thresholds that teach (PM>45° good, 25–45 warn, <25 bad). The chip color change IS the lesson; take boundaries from domain rules of thumb and state them in surrounding prose.

## 7. Checklist & pitfalls

- [ ] Dragging any slider end-to-end never freezes or NaNs the plot
- [ ] Presets land on instructive corners of the parameter space (calm / brisk / broken)
- [ ] Readouts and curves agree (hand-check one point)
- [ ] Resize redraws crisply (no blur = DPR handled)

| Symptom | Fix |
|---|---|
| Blurry plot on phone | missing DPR transform |
| Lab freezes at extremes | clamp states; cap trial counts |
| Preset buttons trigger wrong lab | scope selector by section id |
| Curve jitters at identical settings | accept ±1% MC noise and say so, or cache when inputs unchanged |
