---
name: exploded-model-walkthroughs
description: Build interactive exploded-view 3D model walkthroughs with Three.js — load glTF assemblies (or compose primitive mockups), animate parts apart on a slider, click-to-highlight components with annotations, and cutaway clipping planes. Use whenever the user wants an exploded view, assembly/teardown visual, component walkthrough, 3D product/hardware explainer, or cutaway. Builds on threejs-scene-foundation.
---

# Exploded Model Walkthroughs

## 1. Get a model — or fake one honestly

- Real assets: `GLTFLoader` (+ `DRACOLoader` if compressed) from `three/addons/loaders/`. Verify license; normalize scale to a ~2-unit bounding box on load; recenter to origin (`box.getCenter` → subtract).
- No asset? **Primitive mockups work shockingly well** for explanation: an e-machine is a long thin cylinder (shaft) + fat cylinder (rotor) + torus (stator) + larger torus (housing), token-colored. Schematic-but-true beats photoreal-but-unavailable.

## 2. The explode mechanic

Every part stores its rest pose and an explode direction:

```js
part.userData={ rest: part.position.clone(), dir: new THREE.Vector3(dx,dy,dz) };
// slider t ∈ [0,1]:
parts.forEach(p=> p.position.copy(p.userData.rest).addScaledVector(p.userData.dir, t));
```
Choose directions with intent: **axial** (parts slide along the shaft axis — natural for rotational machines), or **radial** (outward from centroid — natural for enclosures). Magnitudes proportional to how "outer" the part is, so the explosion reads as disassembly order.

## 3. Annotation & focus

- Click → raycast → highlight (`material.emissive.setHex(0x332200)` on a cloned material — never mutate a shared material) + write the part's entry (name, function, failure modes) to a detail panel.
- Hotspot labels: CSS2DObjects parented to parts, shown either always or only when exploded past t≈0.4 (labels on an assembled model overlap).
- Cutaway: `renderer.localClippingEnabled=true`; one `THREE.Plane` in `material.clippingPlanes` of the outer parts, driven by a second slider. Cap the open faces visually with `side:DoubleSide` at minimum.

## 4. Checklist & pitfalls

- [ ] Slider 0 reassembles EXACTLY (rest poses cloned before first explode)
- [ ] Explode order tells the disassembly story; directions don't make parts collide
- [ ] Click-highlight reversible; one part highlighted at a time
- [ ] glTF: traverse() to collect meshes — parts are often nested groups

| Symptom | Fix |
|---|---|
| Model invisible | scale/units (mm vs m) — normalize to bounding box on load |
| Highlight bleeds to other parts | clone the material before touching emissive |
| Explode looks like an explosion | fewer directions, proportional magnitudes, slower slider |
| Clipped interior looks hollow | DoubleSide; consider a darker inner material |
