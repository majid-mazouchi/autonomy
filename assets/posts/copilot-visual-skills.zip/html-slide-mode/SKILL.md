---
name: html-slide-mode
description: Turn HTML content into a keyboard-driven slide presentation — sections become slides with arrow-key/space navigation, a progress bar, slide counter, optional presenter notes, and a print stylesheet that lays out all slides for PDF export. Use whenever the user wants to present a document as slides, build an HTML deck, make a talk from a monograph, or asks for "presentation mode", a self-running demo deck, or keyboard-navigable figures. No reveal.js, no libraries.
---

# HTML Slide Mode

Two modes from one file: **document** (normal scroll) and **deck** (one slide at a time). The deck is a container + ~40 lines of JS.

## 1. Markup

```html
<div class="deck" id="deck" tabindex="0" aria-label="Slide deck — use arrow keys">
  <section class="slide">…title slide…</section>
  <section class="slide">…one idea, one figure…</section>
  <aside class="notes">presenter-only text</aside>  <!-- optional, per slide -->
  <div class="deckbar"><div class="deckprog" id="prog"></div></div>
  <div class="deckctl">
    <button id="prev">‹</button><span id="ctr">1 / N</span><button id="next">›</button>
  </div>
</div>
```

```css
.slide{display:none; min-height:380px; padding:34px}
.slide.on{display:block; animation:fadein .25s}
@keyframes fadein{from{opacity:0; transform:translateY(6px)}}
@media (prefers-reduced-motion:reduce){.slide.on{animation:none}}
.deckbar{height:5px;background:#EFE9D8}.deckprog{height:100%;width:0;background:var(--orange);transition:width .25s}
.notes{display:none}
```

## 2. Engine

```js
const slides=[...deck.querySelectorAll('.slide')]; let i=0;
function show(k){
  i=Math.max(0,Math.min(slides.length-1,k));
  slides.forEach((s,j)=>s.classList.toggle('on',j===i));
  prog.style.width=(100*(i+1)/slides.length)+'%';
  ctr.textContent=(i+1)+' / '+slides.length;
  location.hash='slide-'+(i+1);            // deep-linkable
}
deck.addEventListener('keydown',e=>{
  if(e.key==='ArrowRight'||e.key===' ') {show(i+1); e.preventDefault();}
  if(e.key==='ArrowLeft')               {show(i-1); e.preventDefault();}
});
prev.onclick=()=>show(i-1); next.onclick=()=>show(i+1);
show(parseInt((location.hash.match(/slide-(\d+)/)||[])[1]||1,10)-1);
```
Keyboard works when the deck has focus (click it once, or call `deck.focus()` on load for full-page decks). Swipe support = a 30-line touchstart/touchend deltaX check — add it for decks that will be presented from an iPad.

## 3. Converting a monograph to a deck

- Mapping: hero → title slide; each `h2` section → 1–3 slides; each `figure` or `.lab` → its own slide (interactive labs present brilliantly — the slide IS the demo).
- One idea per slide; cut prose to ≤3 lines and let the figcaption carry nuance.
- Slide-local font scale: bump body to 20–22px and h2 to 40px inside `.slide` only.
- `?notes` URL flag (or `N` key) toggles `.notes{display:block}` styled as a gold card — presenter view on your own screen, off on the projector copy.

## 4. Print / PDF export

```css
@media print{
  .slide{display:block !important; page-break-after:always; min-height:auto}
  .deckctl,.deckbar{display:none}
}
```
Browser "Print → Save as PDF" then yields a shareable deck — one artifact, three formats (doc, live deck, PDF).

## 5. Checklist & pitfalls

- [ ] Arrows, space, buttons, and hash links all navigate; counter and bar agree
- [ ] First/last slide clamp (no blank overrun)
- [ ] Interactive content on slides still works (events not swallowed by deck keydown — check sliders: arrow keys inside inputs must not change slides: guard `if(e.target.tagName==='INPUT')return;`)
- [ ] Print preview shows every slide once, controls hidden

| Symptom | Fix |
|---|---|
| Arrow keys move slides while tuning a slider | bail out of the keydown handler when target is INPUT/BUTTON |
| Keyboard dead until clicked | deck.focus() on load, tabindex=0 on container |
| Hash nav lands off-by-one | slides are 1-indexed in the hash, 0-indexed in JS |
