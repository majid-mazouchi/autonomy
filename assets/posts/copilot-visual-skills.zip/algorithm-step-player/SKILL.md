---
name: algorithm-step-player
description: Build step-through visualizations of algorithms, procedures, traces, and protocols — a synchronized pseudocode pane plus a live state view (arrays, pointers, graphs, queues, logs, gauges) advanced by Play / Step / Reset / speed controls. Use whenever the user wants to "walk through" an algorithm, animate pseudocode, replay an execution trace or agent trajectory, present an algorithm step by step in a talk, or show how state evolves over iterations. Vanilla JS only.
---

# Algorithm Step Player

Core idea: **precompute an array of immutable step snapshots, then render any index**. Never mutate live state during playback — random access (scrub, replay) comes free and rendering stays a pure function `render(steps[i])`.

## 1. Step record

```js
const steps=[
  {line:3, desc:"mid = (lo+hi)>>1 → 7", state:{lo:0, hi:14, mid:7}, log:"compare a[7]=41 vs 37"},
  …
];
```
Generate snapshots by running the real algorithm once with an instrumented `snap()` call — hand-author only the `desc`/`log` strings, never the state.

## 2. Layout

Two-pane grid (stacks under ~700px):
- **Code pane**: `<pre>` of numbered lines; current line gets `.cur` (accent left border + tinted background). Highlight by toggling classes, never by re-rendering text.
- **State pane**: DOM boxes for arrays (cheap, class-animatable), inline SVG for graphs/pointers, a mono log `<div aria-live="polite">`, gauge chips for counters (iterations, comparisons, tokens).

Array cell classes: `.in-range` (active window), `.mid` (probe), `.found` (success), `.dead` (eliminated) — colored from the shell tokens.

## 3. Transport controls

```js
let i=0, timer=null, speed=1;
function render(k){ /* code highlight + state pane + gauges from steps[k] */ }
function step(){ if(i<steps.length-1) render(++i); else pause(true); }
// play ⇄ pause via setInterval(step, 900/speed); Reset → i=0, render(0)
// Speed button cycles 1×→2×→4×
```
Buttons: ▶ Play / Step / Reset / speed in the shared `.player` pill styling. Clicking Step while playing pauses first.

## 4. Authoring guidance

- 8–25 steps is the sweet spot for a talk; collapse uninteresting iterations into one annotated step ("… 12 similar steps elided").
- Every `desc` states *why*, not just *what* ("discard left half — a[mid] < target").
- End with a summary step that freezes final state and states the invariant or complexity.
- Agent-trajectory replays: step types (user/think/tool/verify-fail/verify-pass/compact/done) each get a colored row style; side gauges track context tokens and loop iterations.

## 5. Checklist & pitfalls

- [ ] Reset→end→Reset leaves no stale classes (render is pure)
- [ ] Code line numbers match the highlighted logic at every step
- [ ] Plays to completion, stops cleanly, replay works
- [ ] Buttons focusable; log uses aria-live

| Symptom | Fix |
|---|---|
| State drifts after replay | you mutated during playback — precompute snapshots |
| Highlight lags the state | one render(k) updates both panes from one record |
| Timer keeps running after done | clearInterval in the end branch |
