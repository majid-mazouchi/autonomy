---
name: 3d-system-diagrams
description: Build 3D block/system diagrams with Three.js — extruded component boxes on a ground grid, an isometric-feel camera, crisp HTML labels via CSS2DRenderer, tube connections, and animated flow particles traveling between blocks. Use whenever the user wants a 3D architecture diagram, 3D version of a block diagram, system landscape with depth, or "blocks with particles flowing between them". Builds on threejs-scene-foundation.
---

# 3D System Diagrams

The 3D sibling of `animated-svg-block-diagrams`: same semantic colors, same one-meaning-per-color rule — plus depth, orbit, and particle flow.

## 1. Layout & camera

- Blocks: `BoxGeometry` on a ground-plane grid (snap positions to 0.5–1.0 unit pitch), heights may encode a quantity (state it if so). `MeshStandardMaterial` in token colors, roughness ~0.7.
- Default camera: isometric-feel perspective from `(d, 0.75d, d)` looking at the centroid — readable like a drawing, still orbit-able. Add `GridHelper` ground in parchment grays.

## 2. Labels: CSS2DRenderer, not textures

```js
import {CSS2DRenderer, CSS2DObject} from 'three/addons/renderers/CSS2DRenderer.js';
// overlay renderer: position:absolute over the canvas, pointer-events:none, same size
const lab=document.createElement('div'); lab.className='lbl3d'; lab.textContent='Gateway';
block.add(new CSS2DObject(lab));   // offset via lab object's position
```
Real HTML labels stay crisp at every zoom, use the page's mono font, and can hold two lines — sprite/canvas-texture text cannot. The overlay div must track canvas size on resize, and labels need a small CSS class (mono 11–12px, paper background pill, ink text).

## 3. Connections & flow

- Paths: `CatmullRomCurve3` (or `LineCurve3` for straight runs) + `TubeGeometry` (radius ≈ 1–2% of scene span), ink for neutral, token color for semantic paths.
- Flow particles: N small spheres advanced along the curve each frame: `curve.getPointAt((t*speed + i/N)%1, sphere.position)`. 4–8 particles per path; direction of travel = direction of data. This is the 3D dash-flow animation.
- Picking: raycast on click → highlight block (emissive bump) + write its description to a detail panel below (same panel pattern as interactive-flowcharts).

## 4. Checklist & pitfalls

- [ ] Colors match the page's 2D token semantics exactly
- [ ] Labels legible at default zoom AND after orbiting (they billboard for free)
- [ ] Particle direction equals data direction on every path
- [ ] Reduced motion: particles parked, not orbit-locked

| Symptom | Fix |
|---|---|
| Labels misaligned after resize | resize the CSS2DRenderer with the WebGL one |
| Labels steal mouse drags | pointer-events:none on the overlay |
| Tubes invisible | radius scaled to scene units, not pixels |
| Diagram unreadable from some angles | constrain OrbitControls polar/azimuth range |
