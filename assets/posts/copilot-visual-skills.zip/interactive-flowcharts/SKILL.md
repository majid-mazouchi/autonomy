---
name: interactive-flowcharts
description: Build interactive decision flowcharts and process flows as inline SVG — diamond decision nodes with yes/no branches, clickable nodes that open detail panels, and animated path-walking that highlights a route through the chart step by step. Use whenever the user asks for a flowchart, decision tree, triage flow, diagnostic logic, troubleshooting guide, process map, or "if/then" diagram — especially when readers should click nodes for detail or watch a scenario traced through the chart. No Mermaid, no libraries.
---

# Interactive Flowcharts

Static structure follows `animated-svg-block-diagrams` (tokens, markers, manual layout). This skill adds three interaction layers: **click-to-detail**, **path walking**, and **state styling**.

## 1. Node and edge markup

Give every node a group with a stable id and every edge a `data-edge="from-to"`:

```html
<g class="fnode" id="n-start" tabindex="0" role="button" aria-label="Start: tests failing?">
  <path d="…diamond or rect…"/><text>…</text>
</g>
<line class="fedge" data-edge="n-start-n-doom" … marker-end="url(#ah)"/>
<text class="elabel" …>yes</text>
```

- **Decision** = diamond: `path d="M cx,cy-h L cx+w,cy L cx,cy+h L cx-w,cy z"` (w≈70–85, h≈34–40). Keep diamond text to ≤3 short words; longer questions go in the detail panel.
- **Action/terminal** = rounded rect, same as block diagrams; terminals stroked green (resolution) or red (escalate).
- Branch labels ("yes"/"no") sit just off the edge's first third, in muted ink, 11–12px.
- Layout: top-down for decisions (vertical pitch 95–115), branches fan left/right; never let edges cross if ≤8 nodes — reorder instead.

## 2. Click-to-detail

A single `.detailpanel` div below the SVG. JS: clicking (or Enter on) a `.fnode` sets `aria-pressed`, adds `.sel` to it (and removes from siblings), and writes that node's entry from a `details = {id:{title,body}}` map into the panel. Cursor pointer on nodes via CSS; `:focus-visible` outline on groups.

## 3. Path walking (the signature move)

A preset scenario = an ordered list of node and edge ids:

```js
const walk=['n-start','n-start-n-same','n-same','n-same-n-doom','n-doom'];
```
"Walk scenario" button steps through it on a timer: each tick adds `.hot` to the next element (nodes: thicker stroke + tinted fill; edges: accent stroke + dash flow class) and writes the node's one-liner to the detail panel. Reset clears all `.hot/.sel`. Honor reduced-motion by jumping straight to the fully-highlighted path.

```css
.fnode.hot path{stroke-width:3.5; fill:#FBF0E3}
.fedge.hot{stroke:#D2611C; stroke-width:3}
```

## 4. Authoring guidance

- ≤9 nodes per chart; bigger logic becomes one overview chart linking to sub-charts.
- Phrase decisions so "yes" goes the same direction (e.g., always down) — readers learn the geometry once.
- Every leaf states an *action*, not a category ("improve error legibility, cap retries", not "doom loop").
- Pair the chart with a card listing the walkable scenarios so presenters know what to demo.

## 5. Checklist & pitfalls

- [ ] Tab reaches every node; Enter opens its detail
- [ ] Walk → Reset → Walk is idempotent (no stuck classes)
- [ ] Yes/no labels unambiguous at 360px; no edge crossings
- [ ] Diamond text fits (≤3 words) — overflow goes to the panel

| Symptom | Fix |
|---|---|
| Clicks don't register on text | put handler on the `<g>`, not the shapes; `pointer-events:bounding-box` on the group helps |
| Walk highlights wrong edge | edge `data-edge` ids must match walk list exactly — generate both from one table |
| Diamond labels overflow | move question to detail panel; diamond holds a keyword |
