---
name: risk-and-heat-matrices
description: Build risk matrices (likelihood × severity grids with banded coloring and clickable risk markers) and heatmap matrices (confusion matrices, coverage maps, correlation grids) in HTML/SVG. Use whenever the user wants a risk matrix, risk register visual, 4x4 or 5x5 likelihood-severity grid, confusion matrix, heat map, or any colored cell grid with values. No libraries.
---

# Risk & Heat Matrices

## 1. Risk matrix (likelihood × severity)

- CSS grid: `auto repeat(S, 1fr)`; rows = likelihood **descending** (highest at top), columns = severity ascending; axis labels on the left edge and bottom row.
- Band coloring by cell index per your org's scheme (default: L+S ≥ 7 red, 5–6 gold, ≤ 4 green for a 4×4). Use *muted fills* (mix token colors toward paper) so markers stay readable on top.
- **Color never carries meaning alone**: print the band letter or score in each cell corner (colorblind-safe + printable in grayscale).
- Risks are chips (`R1, R2…`) placed inside their cell; clicking a chip writes its register entry (description, owner, mitigation, target cell after mitigation) to a detail panel. Showing the *mitigation arrow* — a small arrow from current to target cell — is the single highest-value upgrade.

## 2. Heatmaps / confusion matrices

- Cell shade ∝ value via inline `background:rgba(31,95,168,α)` with α mapped from the (row-normalized, say so!) value; print the number in every cell — shade is for scanning, number is the data.
- Confusion matrices: predicted = columns, actual = rows (state the convention in the caption); emphasize the diagonal with a border; per-row recall and per-column precision as a final row/column if space allows.
- Past ~12×12 a heatmap stops being readable inline; aggregate or link out.

## 3. Checklist & pitfalls

- [ ] Every colored cell also carries text (band/score/value)
- [ ] Axis direction stated; likelihood top-down high→low
- [ ] Chip click ↔ detail panel idempotent; mitigation targets drawn if data exists
- [ ] Normalization (row/col/none) declared in the caption

| Symptom | Fix |
|---|---|
| Red/green indistinguishable for some readers | band letters in cells; saturation differences, not hue alone |
| Markers unreadable on saturated fills | mute fills toward paper; chips on white pills |
| Heatmap lies | declare normalization; never mix normalized and raw cells |
