---
name: exec-dashboard-figures
description: Build executive-facing visual summaries inside HTML pages — stat cards with deltas, SVG gauges, sparklines, comparison bars, and compact KPI rows for pitch documents, one-pagers, proposals, and status reports. Use whenever the user wants a dashboard look, KPI cards, "numbers at a glance", ROI visuals, before/after comparisons, or an executive summary panel — even inside a longer monograph. No charting libraries; SVG + CSS only.
---

# Exec Dashboard Figures

Rule zero: an exec figure earns its place by being readable in **3 seconds from 2 meters**. One message per element; the number is the hero, the chart is the garnish.

## 1. Stat cards

```
.statrow (flex/grid, 2–4 cards)
 └ .stat: tiny mono uppercase label → big serif/mono number (28–40px)
          → delta line: ▲/▼ + value, colored green/red BY MEANING not by sign
          (cost down = green ▼; downtime up = red ▲)
```
Always state the comparison basis in the delta line ("vs. Q1", "vs. baseline fleet"). 3–7 significant characters per number — "$2.4M", "−12.3%", "8,400" — never raw floats.

## 2. Gauges (SVG arc, no JS needed)

A circle stroke trick: dash the arc to the percentage.

```html
<svg viewBox="0 0 120 70">
  <path d="M10,62 A52,52 0 0 1 110,62" fill="none" stroke="#EFE9D8" stroke-width="11"/>
  <path d="M10,62 A52,52 0 0 1 110,62" fill="none" stroke="#2E7D4F" stroke-width="11"
        stroke-linecap="round" pathLength="100" stroke-dasharray="73 100"/>
  <text x="60" y="58" text-anchor="middle" font-size="22">73%</text>
</svg>
```
`pathLength="100"` makes the dasharray read directly in percent. Color the value arc by threshold band (green ≥ target, gold near, red below) and print the target as a tick or caption.

## 3. Sparklines

`<polyline>` from data mapped into a 120×34 viewBox; 1.8px token stroke; end-dot circle; min/max faint labels only if they matter. No axes — sparklines show shape, the stat card next to it shows the number.

## 4. Comparison bars

Horizontal paired bars (baseline gray vs. proposal token-color), labels left, values at bar ends. Same scale across all pairs in a group; if one value would dwarf the rest, switch to indexed values (baseline = 100) and say so.

## 5. Composition rules

- A dashboard band = one `.statrow` + at most one gauge/spark group + at most one comparison block. If it doesn't fit one screen, it's two figures.
- One accent color per band; everything else paper/ink/gray. Executives read color as urgency — spend it on the single number that decides the meeting.
- Every band ends with a one-line takeaway in prose ("Recall scope cut 38% at equal detection coverage"). The figure supports the sentence, never replaces it.
- For ROI: a simple 3–4 segment horizontal waterfall (cost → savings components → net) beats any pie.

## 6. Checklist & pitfalls

- [ ] Legible zoomed out to ~50% (the 2-meter test)
- [ ] Delta colors encode good/bad, not up/down
- [ ] All paired bars share one scale; units stated once per band
- [ ] No more than ~7 numbers per band

| Symptom | Fix |
|---|---|
| Gauge arc length wrong | use pathLength="100"; dasharray "P 100" |
| Card numbers wrap | shorten to ≤7 chars; move detail to caption |
| Dashboard feels like chartjunk | delete every element that doesn't change the takeaway sentence |
