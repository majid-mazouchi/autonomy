---
name: timelines-and-roadmaps
description: Build horizontal timelines and Gantt-lite roadmaps as inline SVG — swimlanes per workstream, phase bars, milestone diamonds, a today marker, and dependency arrows. Use whenever the user wants a timeline, roadmap, project plan visual, milestone chart, program schedule, history-of-X strip, or phases-and-gates figure for a proposal. No libraries.
---

# Timelines & Roadmaps

## 1. Scale first

Define one function `X(date)` mapping time→pixels, linear, and derive EVERYTHING (bars, milestones, gridlines, today) from it — mixed hand-placed and computed positions is how roadmaps end up lying. Gridlines at natural units (quarters/months) with labels in the bottom margin; shade alternating periods faintly (`#F1EBDA` at 40%) for scanability.

## 2. Elements

- **Swimlanes**: one row per workstream (pitch 56–70), lane label left-aligned in the left margin, faint separator rules between lanes. ≤ 5 lanes per figure.
- **Phase bars**: rounded rects (h 22–28) in the owning lane, token color per workstream or per phase type; label inside if it fits (the 0.6×font-size budget), else just above-left.
- **Milestones**: diamonds (`path M0,-9 L9,0 L0,9 L-9,0 z` translated) on the lane line, label above or below alternating to dodge collisions. Gates/decision points get gold diamonds.
- **Today marker**: dashed red vertical line, small "today" tag at top. Mandatory on any roadmap shown live — it's the credibility anchor.
- **Dependencies**: thin elbow arrows from bar-end to bar-start, gray, only where the dependency is the point; a roadmap webbed with arrows reads as spaghetti.

## 3. Checklist & pitfalls

- [ ] Every x-position derived from X(date); spot-check two
- [ ] Labels collision-free at 360px (alternate above/below)
- [ ] Today marker present and correct
- [ ] ≤ 5 lanes, ≤ ~12 bars; bigger plans get a summary roadmap linking to detail

| Symptom | Fix |
|---|---|
| Bars don't match stated dates | one X() function, no hand-placed bars |
| Milestone labels collide | alternate sides; abbreviate; legend for repeated types |
| Roadmap looks aspirational | today marker + shade elapsed time slightly darker |
