---
name: trade-study-matrices
description: Build interactive trade-study / decision matrices in HTML — options vs. weighted criteria with live weight sliders, recomputed scores, winner highlighting, and sensitivity awareness. Use whenever the user wants to compare alternatives, rank options or proposals, build a Pugh matrix, weighted scoring model, vendor/idea comparison, or "which should we pick" table. Vanilla JS.
---

# Trade-Study Matrices

The honest version of a comparison table: raw scores visible, weights adjustable in front of the audience, ranking recomputed live. The interactivity is the credibility — stakeholders can test their own weightings on the spot.

## 1. Structure

```
table.trade
  thead: Option | crit1 | crit2 | crit3 | Weighted score
  tbody: one row per option; raw scores in .num cells; score cell <b id="sc-opt1">
weights: one .ctrl slider per criterion (0–10), <output> showing current weight
```
Raw scores stay visible at all times — a matrix that shows only weighted totals invites (justified) suspicion. State the scoring scale and provenance in a caption ("1–10, scored by panel of 4, 2026-05").

## 2. Computation

```js
score(opt) = Σ_k w[k]·s[opt][k] / Σ_k w[k]     // normalized: rescaling weights is invariant
```
On any slider input: recompute all scores, write them (1 decimal), find the max, toggle `tr.win` on the winning row (tinted background + bold). Handle ties: highlight all tied rows and say "tie" in the caption line.

## 3. Sensitivity (what makes it a *study*)

After each recompute, check whether any single weight moved to its slider extreme would change the winner; surface the result in one mono line: "Ranking is stable across all single-weight extremes" or "⚠ winner flips to OPT-B if Feasibility weight ≥ 8". This one line preempts the entire weights-are-rigged argument.

## 4. Checklist & pitfalls

- [ ] Raw scores visible; scale and provenance stated
- [ ] All-zero weights handled (show "—", don't divide by zero)
- [ ] Winner highlight and sensitivity line update on every input
- [ ] Mobile: table scrolls horizontally rather than wrapping cells

| Symptom | Fix |
|---|---|
| Scores feel arbitrary | provenance caption + keep raw scores on screen |
| Winner flickers between near-ties | show Δ to runner-up; declare ties under 0.2 |
| Stakeholder disputes a weight | that's the feature — hand them the slider |
