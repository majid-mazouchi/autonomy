---
name: physics-and-motion-demos
description: Build animated 3D physics and motion demonstrations with Three.js — rotating reference frames and vector diagrams (dq/space-vector animations), spinning machine parts, trajectory replays from logged or simulated data, and equation-driven mechanisms. Use whenever the user wants to animate vectors, rotating frames, Clarke/Park transforms, rotor motion, vehicle trajectories, or "show the dynamics moving". Builds on threejs-scene-foundation.
---

# Physics & Motion Demos

Rule one: motion comes from **equations or logged data evaluated against a clock**, never from per-frame increments — frame-rate independence is correctness, not polish.

```js
const clock=new THREE.Clock();
d.update=()=>{ const t=clock.getElapsedTime();   // seconds, monotonic
  theta = omega*t;                                // or interpolate logged data at time t
  …apply to objects…
};
```

## 1. Vector & frame animations (the dq workhorse)

`THREE.ArrowHelper` is the cheapest honest vector: `setDirection(unitVec)` + `setLength(mag, headLen, headWidth)` per frame.
- Static context first: stator phase axes at 0°/120°/240° in gray, a unit circle `Line`.
- Animated layer: the current space vector (orange), the rotating d–q frame (blue/green, q ⊥ d), all driven by one θ(t). Pair with live 2D readout chips (θ, |i|, i_d, i_q) so the animation is quantitative.
- Speed slider scales ω, not the frame step. Pause button = stop advancing t (store offset), not stop rendering.

## 2. Trajectory replays

- Path so far: a `Line` whose BufferGeometry is preallocated to N points; advance `geometry.setDrawRange(0,k)` as time passes — no reallocation.
- Moving marker: mesh positioned by interpolating the logged samples at clock time; orient with `lookAt(nextPoint)`.
- Time scrubber: a range input mapping to log time; replay = scrub driven by the clock. Decimate logs >10k points for the Line (keep full data for readouts).

## 3. Mechanisms

Rotor spin, gear pairs, linkages: parent parts into `Group`s so one rotation drives children correctly; gear ratios as exact multipliers of the same θ(t). If two parts must mesh, derive both from one angle — never animate them separately and hope.

## 4. Checklist & pitfalls

- [ ] Pausing the tab and returning doesn't jump the animation (clock-based, with pause offset)
- [ ] Speed slider changes ω smoothly without a position jump (rebase: θ0 += (ω_old−ω_new)·t)
- [ ] Vectors annotated with live numeric readouts
- [ ] Reduced motion: render a meaningful static pose (θ at a labeled instant)

| Symptom | Fix |
|---|---|
| Speed varies by device | clock-based motion, not per-frame += |
| Slider causes angle jump | rebase the phase when ω changes |
| Long trajectory kills FPS | preallocate + setDrawRange; decimate |
