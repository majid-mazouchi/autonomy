---
name: scrollytelling-figures
description: Build scroll-driven explanations — a sticky figure that changes state as the reader scrolls through step paragraphs beside it, using IntersectionObserver with no libraries. Use whenever the user wants scrollytelling, a guided tour of a diagram, "the figure updates as you read", step-by-step narrative explanation of an architecture or process, or an explorable explanation. Honors reduced motion with a static fallback.
---

# Scrollytelling Figures

One sticky figure + N step blocks; the step currently in view drives the figure's state. State changes are **class toggles on the SVG** (reuse svg-interactivity-layer's highlight/dim/layer vocabulary), so the figure logic stays declarative.

## 1. Structure

```html
<div class="scrolly">
  <div class="steps">
    <div class="stp" data-state="st1"><p>First, context is gathered…</p></div>
    <div class="stp" data-state="st2"><p>Then the model acts…</p></div>
    <div class="stp" data-state="st3"><p>Finally the verifier…</p></div>
  </div>
  <div class="sticky-fig"><svg id="scfig">…one figure, all states drawn…</svg></div>
</div>
```
CSS: two-column grid (steps | figure), `position:sticky; top:…` on the figure wrapper; each `.stp` gets generous `min-height` (40–60vh full-page, ~230px embedded) so exactly one is "current" at a time. Under ~700px: single column, figure sticky at top.

## 2. Engine (entire thing)

```js
const io=new IntersectionObserver(es=>es.forEach(e=>{
  if(e.isIntersecting){
    document.querySelectorAll('.stp').forEach(s=>s.classList.toggle('active',s===e.target));
    scfig.className.baseVal = e.target.dataset.state;   // SVG: className.baseVal, not className
  }
}),{threshold:0.55});
document.querySelectorAll('.stp').forEach(s=>io.observe(s));
```
CSS does the rest: `#scfig.st2 .phase2{…highlight…}`, inactive steps dimmed. Author states so each adds to or shifts emphasis from the last — pure swap-everything states feel like a slideshow, not a narrative.

## 3. Fallbacks

- `prefers-reduced-motion` / no IntersectionObserver: skip the observer, set all steps `.active`, fix the figure to its final (most complete) state. The content must read fully without scroll effects.
- Print: figure repeats per step is overkill — final state once, steps as plain prose.

## 4. Checklist & pitfalls

- [ ] Scrolling up replays states correctly (observer is stateless — it should)
- [ ] Exactly one step active at any scroll position (min-heights generous enough)
- [ ] Mobile single-column order: step text NOT hidden behind the sticky figure
- [ ] Reduced-motion fallback verified

| Symptom | Fix |
|---|---|
| Figure doesn't update | SVG class needs className.baseVal or setAttribute('class',…) |
| Two steps fight at boundaries | raise threshold to ~0.55; increase step min-height |
| Sticky doesn't stick | parent must be taller than the figure; no overflow:hidden ancestors |
