---
name: flow-quantity-diagrams
description: Build quantity-flow visuals as inline SVG — waterfall charts (baseline → ± contributions → net) and small Sankey-style ribbon diagrams where width encodes magnitude. Use whenever the user wants a waterfall, bridge chart, cost breakdown, savings decomposition, budget flow, token/energy flow, funnel, or "where does it all go" figure. No libraries.
---

# Flow-Quantity Diagrams

Both forms share one law: **widths/heights are exactly proportional to values, and the totals reconcile**. Compute every coordinate from the data array; assert `sum(parts) === total` while building.

## 1. Waterfall (the executive workhorse)

- Columns: start bar (full height from zero), floating contribution segments (each spanning `prev → prev±value`), end bar (net, full height). Connect consecutive tops with thin dashed gray rules — the connectors are what make it read as a bridge.
- Color by *meaning*: contributions that improve the outcome green, that worsen it red, neutral structure gray/blue — not by sign.
- Label every segment with its value at the segment, and the start/net bars with bold totals. 3–6 contributions max; aggregate the tail into "other".
- Y scale starts at zero, always. A truncated waterfall is a lie with connectors.

## 2. Mini-Sankey (≤ 6 flows: hand layout)

- Nodes: vertical bars whose height = total flow through them. Stack each node's incoming/outgoing flow allocations top-down; ribbons connect matching slots.
- Ribbon = filled path between two vertical segments: straight-edged trapezoids are fine and honest; for curves use two cubic Béziers (`C` with control points at horizontal midpoint) top and bottom.
- Ribbon fill = source node's token color at ~35% opacity so crossings stay legible; draw biggest ribbons first (underneath).
- Label ribbons with value (and % of source) at the wider end. More than ~6 flows → aggregate or use a table; hand-laid Sankeys do not scale and library Sankeys are banned here.

## 3. Checklist & pitfalls

- [ ] Totals reconcile (assert during generation); zero-based scales
- [ ] Segment/ribbon sizes proportional — measure two against each other
- [ ] Color encodes good/bad, not up/down or sign
- [ ] Every quantity printed; the geometry is for shape, the numbers are the data

| Symptom | Fix |
|---|---|
| Waterfall floats look random | connectors missing — add the dashed rules |
| Ribbons unreadable where they cross | opacity ~35%, big-first draw order |
| Numbers don't add up | build from one data array; assert reconciliation |
