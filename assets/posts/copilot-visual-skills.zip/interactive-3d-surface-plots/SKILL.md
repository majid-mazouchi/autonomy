---
name: interactive-3d-surface-plots
description: Build interactive 3D surface plots with Three.js — efficiency maps, flux-linkage surfaces, loss maps, response surfaces, any z=f(x,y) or gridded data — with per-vertex colormaps, orbiting, raycaster hover readouts, and slider-linked regeneration. Use whenever the user wants a 3D surface, mesh plot, "matlab surf"-style figure, efficiency/flux/loss map, or 3D scatter of engineering data. Builds on threejs-scene-foundation.
---

# Interactive 3D Surface Plots

A surface is a displaced `PlaneGeometry` with per-vertex colors. No plotting library — you control axes, colormap, and units.

## 1. Build the surface

```js
const n=70, geo=new THREE.PlaneGeometry(2.4,2.4,n,n);   // unit-ish cube; normalize data into it
geo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(geo.attributes.position.count*3),3));
function rebuild(){
  const pos=geo.attributes.position, col=geo.attributes.color;
  for(let i=0;i<pos.count;i++){
    const x=pos.getX(i), y=pos.getY(i);
    const z=F(x,y);                          // your function or bilinear lookup into a data grid
    pos.setZ(i,z);
    const c=ramp(z/zMax); col.setXYZ(i,c[0],c[1],c[2]);
  }
  pos.needsUpdate=true; col.needsUpdate=true; geo.computeVertexNormals();
}
const mesh=new THREE.Mesh(geo, new THREE.MeshStandardMaterial({vertexColors:true, side:THREE.DoubleSide, roughness:0.85}));
mesh.rotation.x=-Math.PI/2;                  // data z becomes world up
```
**Normalize data to a ~2-unit cube** and keep the real units in the readout/labels — raw engineering ranges (amps vs. webers) make unusable camera defaults. Colormap: a 3–4 stop token ramp (blue→green→gold→red) interpolated in JS; print the scale meaning in the figure caption.

## 2. Hover readout (the feature that makes it a tool)

Raycast on pointermove; intersect the mesh; convert `hit.point` back through your normalization to real units; write to a `.ro` chip: `id 142 A · iq 88 A · ψd 0.083 Wb`. This single feature turns a pretty surface into an instrument.

## 3. Live regeneration

Sliders mutate parameters → `rebuild()` (same buffers, `needsUpdate`, recompute normals — never recreate geometry per tick). 70×70 rebuilds run at slider rate on phones.

## 4. Axes & context

GridHelper at z=0 plane; three `Line`s for axes with 4–6 tick labels as small CSS2D elements or sprite texts; axis titles carry units. A wireframe toggle (`material.wireframe`) helps read curvature on flat-ish maps.

| Symptom | Fix |
|---|---|
| Faceted/black patches after edits | computeVertexNormals after every rebuild; DoubleSide |
| Colors washed out | colors are linear-space; build the ramp from the token hexes directly and verify against the 2D palette |
| Hover readout wrong units | invert the SAME normalization used to build; test a known corner |
| Spiky data surfaces | render data grid as-is; never smooth silently — offer a labeled smoothing toggle |
