---
name: mind-maps
description: Build radial mind maps as inline SVG — a central topic, theme-colored curved branches, and collapsible sub-branches. Use whenever the user wants a mind map, idea map, topic overview, brainstorm visual, portfolio overview, "everything around X" diagram, or a radial summary of a domain. No libraries, no MindMeister exports — hand-coded SVG with deterministic layout.
---

# Mind Maps

A mind map is a **radial tree**: root at center, first-level branches on rays, leaves fanned around their branch. The craft is angular allocation and label discipline.

## 1. Layout method

1. Count leaves per first-level branch; allocate each branch an **angular sector proportional to its leaf count** (min 30°). Place branch nodes at radius r1 ≈ 170–210, leaves at r2 ≈ 300–340, spread evenly inside their sector with ≥ 16° between adjacent leaf rays.
2. Convert polar→cartesian once (`x = cx + r·cos(θ)`), then hand-tune collisions. For ≤ ~20 leaves, precomputing coordinates in a small script (or by hand) beats any runtime layout — deterministic and reviewable.
3. Edges are quadratic curves bowing outward: `M root Q control branch` with the control point at ~55% radius, offset perpendicular by 20–35. Branch→leaf curves are shallower.
4. **Never rotate labels.** Text stays horizontal; use `text-anchor="end"` on the left hemisphere, `"start"` on the right, and nudge `y` ±4 so labels sit just outside their node.

## 2. Structure & color

- Root: larger stadium/ellipse, ink stroke, bold serif or mono label.
- Each first-level branch gets ONE token color used by its node, its edge, and all its leaves — the color IS the grouping cue.
- Leaf nodes: small circles (r 4–6) or no node at all (label-on-line, classic mind-map style).
- Depth limit 3 (root→branch→leaf). Deeper hierarchies are trees, not mind maps — switch to `interactive-tree-diagrams`.

## 3. Collapse / expand

```html
<g class="branch" data-target="lv-agentic" tabindex="0" role="button" aria-expanded="true">…node…</g>
<g class="leaves" id="lv-agentic">…leaf edges + labels…</g>
```
Click/Enter toggles `.closed{display:none}` on the target group and flips a −/＋ glyph inside the branch node. Collapsed state must leave the remaining map balanced — that's another reason for generous sectors.

## 4. Checklist & pitfalls

- [ ] No label overlaps at 360 px width; no label upside-down or rotated
- [ ] One color per branch family, traceable to tokens
- [ ] Collapse/expand idempotent; aria-expanded kept in sync
- [ ] ≤ 7 first-level branches; ≤ ~24 leaves total per map

| Symptom | Fix |
|---|---|
| Tangled spokes | sectors proportional to leaf count; min angular gaps |
| Labels collide near vertical axis | reserve dead zones ±12° around 90°/270°, or shift those leaves outward |
| Map unbalanced after collapse | bigger min sector; or re-render positions per state |
