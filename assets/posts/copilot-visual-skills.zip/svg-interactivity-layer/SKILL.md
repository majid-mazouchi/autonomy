---
name: svg-interactivity-layer
description: Add interactivity to any static inline SVG diagram — hover tooltips, highlight-connected-elements-on-hover (dim everything else), show/hide layer toggles (e.g., "show fault paths", "show data flow"), and click-to-pin annotations. Use whenever the user wants an existing or new diagram to respond to the reader — hover effects, togglable overlays, tooltips, "explore the diagram" behavior. Composes with animated-svg-block-diagrams; no libraries.
---

# SVG Interactivity Layer

Three primitives cover almost every request: **connection highlighting**, **layer toggles**, **tooltips**. All are class-toggling + one shared div — no SVG-internal foreignObject, no libraries.

## 1. Connection highlighting (hover one node → its neighborhood lights, rest dims)

Annotate connectivity in markup, not JS:

```html
<g class="inode" id="b-ctl"  data-links="e1 e2 b-plant b-sensor">…</g>
<line class="iedge" id="e1" …/>
```

```js
svg.querySelectorAll('.inode').forEach(n=>{
  n.addEventListener('mouseenter',()=>focus(n));
  n.addEventListener('mouseleave',clear);
  n.addEventListener('focus',()=>focus(n)); n.addEventListener('blur',clear);
});
function focus(n){
  const keep=new Set([n.id,...n.dataset.links.split(' ')]);
  svg.querySelectorAll('.inode,.iedge').forEach(el=>
    el.classList.toggle('dim', !keep.has(el.id)));
}
```
```css
.dim{opacity:.18; transition:opacity .15s}
```
Dim-others reads far better than brighten-self on a paper background. Give nodes `tabindex="0"` so keyboard focus triggers the same effect.

## 2. Layer toggles

Group optional content: `<g id="layer-faults" class="layer">…dashed red injection arrows…</g>`. A labeled checkbox per layer:

```js
chk.addEventListener('change',()=> g.classList.toggle('off', !chk.checked));
/* .layer.off{display:none} */
```
Start teaching-overlays hidden, structural layers shown. Typical layers: fault/attack paths, data vs. control flow, bandwidth annotations, "what changed in v2".

## 3. Tooltips

One absolutely-positioned div per page, repositioned on hover:

```js
tip.textContent = n.dataset.tip;
tip.style.left = (evt.clientX+14)+'px'; tip.style.top=(evt.clientY+10)+'px';
tip.classList.add('on');   // .tooltip{position:fixed; pointer-events:none; …}
```
`pointer-events:none` on the tooltip is mandatory (else it flickers by stealing the hover). On touch devices hover doesn't exist: tap = focus → also show the tooltip pinned under the node, second tap elsewhere clears. Keep tips ≤ 1 sentence; longer content belongs in a click-to-pin annotation panel (see interactive-flowcharts §2 — same pattern).

## 4. Pointer-events notes (the usual traps)

- Handlers go on the `<g>`; add an invisible hit-area rect if the group is mostly thin lines: `<rect fill="transparent" …/>` inside the group.
- `text` elements swallow hovers — fine if inside the group, problem if floating; set `pointer-events:none` on pure labels.
- Never attach listeners to elements inside `<defs>`.

## 5. Checklist & pitfalls

- [ ] Hover, keyboard focus, and touch all trigger the highlight
- [ ] data-links audited: every referenced id exists (assert in a dev-only loop)
- [ ] Toggling layers doesn't shift layout (groups overlay, they don't reflow)
- [ ] Tooltip never traps the pointer or overflows the viewport edge

| Symptom | Fix |
|---|---|
| Tooltip flickers | pointer-events:none on the tooltip div |
| Hover dead zones | transparent hit-rect inside the group |
| Highlight leaves orphans | ids in data-links drifted — generate from one adjacency table |
