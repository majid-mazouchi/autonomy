---
name: isometric-svg-diagrams
description: Build 2.5D isometric diagrams in pure inline SVG — extruded-looking boxes from three shaded faces, stacked architecture layers, platform/landscape views — with zero libraries and full offline reliability. Use whenever the user wants a "3D-looking" diagram, isometric architecture, layered stack, or depth without WebGL; this is the first option to consider BEFORE reaching for three.js. Composes with animated-svg-block-diagrams and svg-interactivity-layer.
---

# Isometric SVG Diagrams

True 3D is often unnecessary: an isometric projection gives depth, keeps the zero-dependency rule, prints perfectly, and weighs nothing. This covers stacks, platforms, and box-scapes — anything that doesn't need orbiting.

## 1. The projection (memorize these two lines)

```
sx = X0 + (x − y)·0.866·k          // 0.866 = cos 30°
sy = Y0 + (x + y)·0.5·k − z·k
```
World axes: x runs down-right, y down-left, z straight up. Pick k so the scene fills the viewBox; compute EVERY point through this function (a tiny generator script is worth it past ~6 boxes — hand-arithmetic drifts).

## 2. An iso box = three faces

For a box with footprint (x0..x1, y0..y1) and height h at elevation e, draw exactly three polygons:
- **Top** (z=e+h): the diamond through the four projected footprint corners — **lightest** shade.
- **Left face** (the y=y1 edge dropped by h): 4 points, two top two bottom — **mid** shade.
- **Right face** (the x=x1 edge dropped by h): — **darkest** shade.

Shades: mix the box's token color toward paper (top ≈ 75% toward paper, left ≈ 45%, right ≈ 25%); thin ink strokes (1–1.5) on all faces. **One light direction for the whole page** — the top-lightest/right-darkest convention above, never mixed.

## 3. Composition rules

- **Painter's order**: draw back-to-front, sorted by (x + y + z) of each box's near corner — wrong order is the #1 iso bug and it's silently wrong.
- Layered stacks (the killer use): wide thin slabs at increasing elevation with vertical gaps = "exploded layers" architecture view; label each layer with horizontal text to the side. Small boxes sit ON a slab when their base elevation equals the slab's top.
- Labels are always horizontal (never along iso axes); place beside, not on, faces when faces are small.
- Flat 2D arrows mix badly with iso; route connection arrows as iso lines (computed through the same projection) or vertical dashed drop-lines between layers.
- Interactivity (hover-dim, layer toggles, tooltips) comes free from `svg-interactivity-layer` — iso faces are just polygons with ids.

## 4. Checklist & pitfalls

- [ ] Every coordinate from the projection function; spot-check two boxes
- [ ] Light direction consistent; three distinct shades per box
- [ ] Draw order verified by overlapping two boxes intentionally during dev
- [ ] Reads correctly in grayscale (shade differences ≥ noticeable)

| Symptom | Fix |
|---|---|
| Box looks inside-out | face shades swapped, or draw order wrong |
| Scene "leans" | one of the two projection constants typo'd — recompute all |
| Text unreadable | horizontal labels beside the geometry, mono 11–13px |
| Needs orbiting after all | that's the threejs-scene-foundation threshold — switch |
