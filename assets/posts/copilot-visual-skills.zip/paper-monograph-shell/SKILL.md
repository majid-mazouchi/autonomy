---
name: paper-monograph-shell
description: The foundational page system for educational HTML monographs, research explainers, proposals, and interactive concept pages in the light "paper" aesthetic (warm cream background, deep ink text, saturated semantic accents). Use this skill whenever building ANY standalone HTML page meant to explain, teach, propose, or present — interactive explainers, pitch documents, concept guides, lab pages — even if the user doesn't say "monograph". Every other visual skill (diagrams, labs, flowcharts, dashboards, slides) plugs into this shell; consult it first to get tokens, typography, layout, and figure conventions.
---

# Paper Monograph Shell

One self-contained HTML file. No libraries, no external fonts, no network requests. Must render correctly opened directly from the filesystem, in iOS/Safari file previews, and at 360 px width.

## 1. Token system (declare once, never deviate)

```css
:root{
  --paper:#F7F3E8; --panel:#FFFDF6; --ink:#21242E; --ink-soft:#5A5E6B; --rule:#D8D0BC;
  --violet:#6B45A8; /* model / reasoning   */  --orange:#D2611C; /* actions / commands */
  --blue:#1F5FA8;   /* feedback / context  */  --green:#2E7D4F;  /* environment / good */
  --red:#B6382E;    /* errors / failures   */  --gold:#A8842C;   /* gates / cautions   */
  --mono:"SF Mono",ui-monospace,"Cascadia Mono",Consolas,monospace;
  --serif:"Iowan Old Style","Palatino Linotype",Palatino,Georgia,serif;
}
```

Semantic colors mean the same thing in every figure, chart, and chip on the page. Body text serif 17–18 px, line-height 1.6–1.7; ALL diagram/label/data text uses the mono stack at 11–14 px.

## 2. Page anatomy (in this order)

1. `header.hero` — mono uppercase kicker, large serif `h1` (accent italic on the subtitle line), 1–2 paragraph dek, optionally a signature animated SVG beside the intro text in a 2-column grid.
2. `nav.toc` — two-column ordered list, mono numerals in orange, dotted-underline links to `#s1…#sN`.
3. `main.wrap` (`max-width:960px`) — numbered `<section id="sN">`, each opening `<div class="secno">§ NN</div>` then `h2`.
4. `footer` — mono small print: provenance, "runs locally, no libraries".

## 3. Component conventions

- **Figures**: `<figure>` (panel background, 1px rule border, radius 10) wrapping an `svg.diagram`; `<figcaption>` starts `<b>Fig. N — Title.</b>` then 1–2 sentences of *insight*, mono 12.5px, dashed top rule. Number sequentially page-wide.
- **Callout cards**: `.card` with a 5px left border in a semantic color + mono uppercase `.ct` label ("The core trade", "Failure smell").
- **Labs** (interactive blocks): `.lab` gradient panel containing `.lt` label → `h3` → `.presets` pill buttons → `.controls` (flex `.ctrl` slider groups with `<output>`) → `.readouts` (`.ro` chips: tiny uppercase label + big value colored `.good/.warn/.bad`) → `canvas.plot` → `.plotlab` caption → `.legend`.
- **Tables**: panel background, mono uppercase headers; used for vocabularies and fault catalogs.
- **Equations/code**: `.eq` mono block with colored left border; inline `code` on a parchment chip.

## 4. Hard rules

- Zero `<script src>`, `<link>`, `@import`, or web-font loads. Vanilla JS in one `<script>` at end of `<body>`, wrapped in an IIFE with `"use strict"`.
- Responsive by construction: `viewBox`-only SVGs, `canvas{width:100%}` with a DPR-corrected backing store, `.wrap` padding 22px, hero/grids collapse under ~780px.
- Honor `prefers-reduced-motion` for every animation.
- `:focus-visible` outlines on all interactive elements; `aria-label` on every SVG and canvas.
- Prose max-width 72ch. No bullets inside figcaptions.

## 5. QA checklist

- [ ] Opens from filesystem with zero console errors and zero network requests
- [ ] Readable at 360px; hero grid stacks; TOC collapses to one column
- [ ] Figure numbers sequential; every section reachable from TOC
- [ ] All colors traceable to tokens; reduced-motion verified
