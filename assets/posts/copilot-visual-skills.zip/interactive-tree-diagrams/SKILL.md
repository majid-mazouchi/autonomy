---
name: interactive-tree-diagrams
description: Build top-down hierarchical tree diagrams as inline SVG — taxonomies, org charts, decomposition trees, and especially fault trees (FTA) with AND/OR gate symbols, basic-event circles, and minimal-cut-set highlighting. Use whenever the user wants a tree, hierarchy, breakdown structure, fault tree, FMEA/FTA visual, or expandable org/taxonomy chart. No libraries.
---

# Interactive Tree Diagrams

## 1. Layout method (layered, leaf-partitioned)

- Levels at fixed y (pitch 95–125). Each node's x = midpoint of its leaves' x-range; leaves spaced evenly across the width with margins. Compute once (by hand for ≤15 nodes, tiny script otherwise).
- Parent→child connectors: vertical-elbow polylines (down, across, down) — straight diagonals read poorly past 2 children.
- Node sizing: rects 130–180×46–58 for labeled nodes; keep labels ≤2 lines (the block-diagram label rules apply).

## 2. Fault-tree (FTA) conventions

- **Top event**: rect at the apex. **Intermediate events**: rects. **Basic events**: circles (r 26–34) with the label *below* the circle, two short lines max.
- **Gates** sit between an event and its children, drawn as paths translated into place:
  - OR (any input suffices): pointed arch `M-28,22 Q0,-26 28,22 Q0,8 -28,22 z`
  - AND (all inputs required): flat-bottom dome `M-26,22 L-26,6 Q0,-26 26,6 L26,22 z`
  Label the gate type beside it in mono 10–11px the first time each appears.
- Stroke semantics: top event red, intermediates ink, basic events by subsystem token color.

## 3. Interactions

- **Cut-set highlighting**: store each minimal cut set as an id list; a button adds `.hl` (thick stroke + tinted fill) to those events and the connectors between them, plus writes the set to a caption line ("Cut set 2: {flux map stale, temp est. error} — AND gate ⇒ both required"). Reset clears.
- **Expand/collapse**: subtree wrapped in a `<g id="sub-x">`; clicking the parent toggles `.closed` and a ＋/− glyph (same pattern as mind-maps).
- **Click-for-detail**: node detail panel below the SVG (same pattern as interactive-flowcharts §2).

## 4. Checklist & pitfalls

- [ ] No connector crosses a node; siblings ordered to avoid edge crossings
- [ ] Every gate's children are actually drawn beneath it (validate: gate id ↔ child list)
- [ ] Cut-set button is idempotent; highlights include the path, not just the leaves
- [ ] Basic-event labels fit below circles at 360 px

| Symptom | Fix |
|---|---|
| Tree wider than viewBox | deepen instead: stack distant cousins on a second row, or split into linked sub-trees |
| Gates look alike | exaggerate: OR pointed, AND flat-shouldered; add the text label |
| Highlight misses connectors | give connector lines ids derived from parent-child pairs and include them in cut-set lists |
