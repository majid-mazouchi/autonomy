---
name: animated-svg-block-diagrams
description: Hand-code publication-quality, optionally animated SVG block diagrams (signal-flow, feedback loops, pipelines, architecture diagrams) as inline SVG inside HTML pages — no Mermaid, no diagram libraries, no images. Use this skill whenever the user asks for a block diagram, flow diagram, control loop figure, agent loop figure, architecture sketch, signal path, or "a figure like the loop diagram", and whenever building educational/monograph-style HTML pages that need labeled boxes connected by arrows, especially with animated "flowing" connections. Also use it when asked to add diagrams to an existing HTML document or to make a static diagram animated.
---

# Animated SVG Block Diagrams

Produce diagrams as **hand-written inline `<svg>`** with semantic color tokens, a shared arrowhead marker, two-line labeled boxes, and an optional CSS dash-flow animation. The result must render identically offline, in iOS/Safari file previews, and inside any HTML page — therefore: **zero libraries, zero external fonts, zero raster images.**

## 1. Non-negotiable rules

1. Inline `<svg>` only. Never Mermaid, never PlantUML, never `<img>`, never canvas for static diagrams.
2. One `viewBox`, no `width`/`height` attributes on the `<svg>`; size with CSS (`width:100%; height:auto`). This makes the diagram responsive for free.
3. Define **one arrowhead marker per SVG** and reuse it for every arrow.
4. Colors come from the document's token palette and carry **consistent meaning across all figures** in the document (see §3). Never introduce ad-hoc hex values.
5. Every `<svg>` gets `role="img"` and a one-sentence `aria-label` describing the flow.
6. If anything animates, include a `prefers-reduced-motion` override that disables it.
7. Fonts: `font-family` via the page's mono token for diagram text (`svg.diagram text { font-family: var(--mono); }`); sizes 11–14px in viewBox units.

## 2. Skeleton (copy this, then edit)

```html
<style>
  svg.diagram{width:100%;height:auto;display:block}
  svg.diagram text{font-family:"SF Mono",ui-monospace,Consolas,monospace}
  .flow{stroke-dasharray:7 9; animation:flow 1.5s linear infinite}
  @keyframes flow{to{stroke-dashoffset:-32}}
  @media (prefers-reduced-motion: reduce){.flow{animation:none}}
</style>

<svg class="diagram" viewBox="0 0 880 300" role="img"
     aria-label="Model sends tool calls to tools; environment results return through verifiers into the next context.">
  <defs>
    <marker id="ah" markerWidth="9" markerHeight="9" refX="7" refY="4.5" orient="auto">
      <path d="M0,0 L8,4.5 L0,9 z" fill="#21242E"/>
    </marker>
  </defs>

  <!-- a box: rect + title line + caption line -->
  <rect x="74" y="58" width="104" height="56" rx="10"
        fill="#FFFDF6" stroke="#6B45A8" stroke-width="2.5"/>
  <text x="96" y="83"  font-size="14" fill="#6B45A8">Model</text>
  <text x="90" y="101" font-size="11" fill="#5A5E6B">decides next act</text>

  <!-- an animated arrow between boxes -->
  <line x1="178" y1="86" x2="240" y2="86"
        stroke="#D2611C" stroke-width="2.5" marker-end="url(#ah)" class="flow"/>
  <text x="186" y="72" font-size="12" fill="#D2611C">tool call</text>
</svg>
```

## 3. Semantic color tokens

Declare once per document and never deviate between figures. Default palette (light "paper" aesthetic — cream `#F7F3E8` background, panel `#FFFDF6`, ink `#21242E`, muted `#5A5E6B`):

| Token  | Hex       | Reserved meaning (agentic/control diagrams)        |
|--------|-----------|----------------------------------------------------|
| violet | `#6B45A8` | model / reasoning / controller                     |
| orange | `#D2611C` | actions / commands / tool calls                    |
| blue   | `#1F5FA8` | context / feedback / measurement paths             |
| green  | `#2E7D4F` | environment / plant / verified-good                |
| red    | `#B6382E` | errors / failures / disturbances / untrusted input |
| gold   | `#A8842C` | gates / budgets / limits / cautions                |

A box's `stroke` and its title `fill` use the same token; captions use muted ink. Arrows are ink (`#21242E`) unless the *signal itself* has semantic meaning (feedback paths blue, commands orange).

## 4. Layout method (do this before writing any markup)

SVG has no auto-layout — you are the layout engine. Work on graph paper logic:

1. Pick a viewBox sized to content, not to the screen: `0 0 880 H` for wide multi-box rows, `0 0 420 H` for compact square loops. Height = whatever the rows need; never leave large empty bands.
2. Place boxes on a coarse grid. Standard box: **104–160 wide × 48–62 tall, rx 8–10**. Horizontal gap between boxes: 40–50 (enough for an arrow + its label). Row pitch: 90–120.
3. Arrows connect edge-midpoints: from `x = boxRight` to `x = nextBoxLeft`, same `y = boxCenterY`. Vertical drops connect bottom-center to top-center. Orthogonal (L-shaped) routes are 2–3 `<line>` segments meeting at shared corner coordinates — only the **final** segment carries `marker-end`.
4. **Text placement is manual** — SVG text does not wrap or center itself. Title line at `boxY + ~25`, caption at `boxY + ~43`, both `font-size` 13–14 / 11. Estimate width at ~0.6×font-size per character and nudge `x` to optically center. After drafting, re-read every label and check it fits inside its box at the viewBox proportions; shorten text before enlarging boxes.
5. Arrow labels sit 12–14 units above the line, in the arrow's color.
6. Feedback/return paths route **around** the boxes (below or beside), never through them, and are drawn in blue with the same dash treatment if animated.

### Stock topologies
- **Pipeline**: one row, left→right, arrows between; inputs enter from far left with a small lead-in arrow and label.
- **Feedback loop**: forward row left→right, then a return path: down from the output, horizontally right→left under everything, up into the first summing point/box.
- **Summing junction** (control diagrams): `<circle r="13–16">` stroked red, `Σ` or `+` text centered, signs labeled just outside.
- **Nested loops**: dashed rounded rects (`stroke-dasharray="7 6"`, no fill) drawn *behind* content, each with a small caption at its top-left; inner boxes solid.
- **Injection points** (disturbance, noise, attacks): dashed red arrows entering from outside the main flow into a junction.

## 5. The flow animation

Animated dashes that "travel" along a connection = three ingredients on the line: `class="flow"`, the keyframes, the reduced-motion guard (all in §2 skeleton).

- `stroke-dashoffset` delta must be an exact multiple of (dash+gap) — `7+9=16`, offset `-32` — or the loop visibly jumps.
- Dashes travel **from start point toward end point** of each `<line>`; draw feedback segments in the direction the signal flows (e.g., right→left), not the direction that's convenient.
- Animate only paths where motion conveys meaning (the active signal loop). Static structure stays static. One animation class, one speed, per document.
- Markers don't animate; keep `marker-end` on the final segment so the arrowhead sits still while dashes flow into it.

## 6. Integration into documents

- Wrap in `<figure class="...">` with a `<figcaption>` beginning `<b>Fig. N — Title.</b>` followed by one or two sentences that state the *insight*, not a restatement of the boxes.
- Number figures sequentially across the whole document; renumber when inserting.
- Markers need **unique ids per SVG** when multiple SVGs share a page (`#ah`, `#a2`, `#a3` …) — duplicate ids silently break arrowheads in some renderers.

## 7. QA checklist (run before declaring done)

- [ ] Renders standalone: open the HTML file directly; no console errors, no network requests.
- [ ] No text overflows any box or collides with a line at narrow widths (~360 px).
- [ ] Every arrow has a visible head; heads point the correct direction; no arrow crosses through a box.
- [ ] Colors used appear in the token table; same concept = same color in every figure.
- [ ] `aria-label` present; animation freezes under reduced-motion (test by toggling the OS setting or commenting the keyframes).
- [ ] Dash animation loops seamlessly (watch one full cycle).

## 8. Common failure modes

| Symptom | Cause | Fix |
|---|---|---|
| Arrowheads missing | `marker` id mismatch or duplicated across SVGs | unique id per SVG; check `url(#…)` spelling |
| Arrowhead wrong color | markers don't inherit stroke | accept ink-colored heads (intended), or define per-color marker variants sparingly |
| Labels overflow boxes | trusting text to fit | shorten label; ~0.6×font-size per char budget; widen box last |
| Diagram looks cramped/stretched on phone | fixed px sizing | viewBox + CSS width 100% only |
| Animation stutters at loop point | dashoffset not a multiple of pattern length | offset = −2×(dash+gap) |
| Boxes misaligned | freehand coordinates | snap to grid: column x's and row y's declared once, reused |
