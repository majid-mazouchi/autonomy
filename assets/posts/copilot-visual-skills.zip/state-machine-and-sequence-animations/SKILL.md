---
name: state-machine-and-sequence-animations
description: Animate state machines (FSMs) and message-sequence diagrams in inline SVG — states with a live "current state" glow driven by a scripted event sequence, transition flashes, an event log, and sequence diagrams whose lifeline messages appear in order with animated arrows. Use whenever the user wants to show a state machine, mode logic, fault-state transitions, protocol handshake, agent-to-agent or multi-agent message flow, MCP/A2A interaction, or any "first this talks to that" narrative. No libraries.
---

# State Machine & Sequence Animations

Both are **scripted replays**: a data array of events, a timer, and pure render steps — the same transport pattern as `algorithm-step-player` (reuse its Play/Step/Reset controls).

## 1. FSM diagram

- States: circles (r 34–44) or stadium rects; id `st-IDLE` etc.; token-colored strokes by state semantics (green run, red fault, ink idle).
- Transitions: straight or single-bend lines with arrowheads and small mono event labels; self-loops as small arcs (`path` with one quadratic bend).
- Layout: ≤6 states; place to minimize crossings (triangle for 3, square for 4). Bidirectional pairs get two offset parallel lines, not double-headed arrows.

### Driving it

```js
const script=[
  {ev:"start",          from:"IDLE", to:"RUN"},
  {ev:"fault_detected", from:"RUN",  to:"FAULT"},
  {ev:"reset",          from:"FAULT",to:"IDLE"},
];
```
Each tick: remove `.cur` from old state, flash the transition edge (`.fire` class for ~500ms), add `.cur` to the new state, append "ev → STATE" to a mono event log.

```css
.fsm .cur circle{stroke-width:4; fill:#F3EDFB}
.fsm .fire{stroke:#D2611C; stroke-width:3.5}
@media (prefers-reduced-motion:reduce){ .fire{transition:none} }
```
The glow is class-based styling, not SMIL — it survives every renderer.

## 2. Sequence diagram

- Lifelines: actor boxes across the top (mono labels, token strokes by role), dashed vertical lines descending.
- Messages: horizontal arrows between lifelines at increasing y (pitch 34–44), label above each; replies dashed; activations as thin filled rects on the lifeline.
- **Reveal animation**: render all messages with `class="msg"` at `opacity:0`; the script shows them one per tick (`.show { opacity:1; transition:opacity .3s }`), optionally with the dash-flow class on the arrow while it is "in flight". Step/Play/Reset as usual; reduced-motion = show all immediately.
- Self-messages: small rectangular loop arrow on one lifeline.

## 3. Authoring guidance

- Scripts of 4–10 events read best; longer protocols get chaptered into multiple diagrams.
- The event log is not optional — it is the textual transcript that makes the animation citable and screenshot-able.
- For multi-agent flows, color messages by initiator (orchestrator orange, workers blue/green) and keep the verifier/judge lifeline visually distinct (red).
- A "happy path" script and a "fault path" script on the same diagram teach more than two diagrams.

## 4. Checklist & pitfalls

- [ ] Reset returns the FSM to the initial state and clears the log
- [ ] Every scripted from/to pair has a drawn edge (validate programmatically: script ids ⊆ edge ids)
- [ ] Sequence arrows never overlap labels; pitch ≥ 34
- [ ] Reduced motion: final frame visible without animation

| Symptom | Fix |
|---|---|
| Transition flash sticks | clear `.fire` on a timeout AND on Reset |
| Script and diagram disagree | generate edges and script from one transition table |
| Sequence diagram too tall | merge request/ack pairs; chapter the protocol |
