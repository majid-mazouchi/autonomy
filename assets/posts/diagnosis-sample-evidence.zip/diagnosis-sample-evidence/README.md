# Diagnosis Sample Evidence — dry-run pack

Fabricated, self-consistent data to **dry-run the diagnosis-copilot-kit skills** end to end. Two cases:
a single vehicle and a 240-car fleet. Everything is fake but shaped like the real artifact, and the data
hides a known ground truth so you can check the agents got it right.

## Files
```
single-vehicle/                 # for the /rca-* skills and the Diagnostician agent
  dtc_freeze_frame.json         # DTC + freeze-frame (cold + DC fast-charge + balancing ACTIVE, fw 5.1.2)
  ecu_charge_control.c          # the firmware bug (signed/unsigned cold-derate)
  vehicle_signals.csv           # one charge session: current clamps when cold + balancing
  customer_reports.md           # three low-trust complaints
  service_history.csv           # OTA timeline + a 12V red herring
fleet/                          # for the /fleet-* skills and the Fleet Analyst agent
  fleet_table.csv               # one row per car (240): build attrs, throttle_temp_C, code_P0AE0
  weekly_code_rate.csv          # 20 weeks of the emerging code rate (for CUSUM surveillance)
  connector_failure_times.csv   # months-to-failure for the connector cluster (for Weibull/B10)
```

## Ground truth (the answer the skills should recover)
Two causes hide behind one code, **P0AE0**:
1. **Firmware cold-throttle bug** (fw >= 5.1) — a signed/unsigned cast over-derates charge current in the cold.
   Affected = `firmware 5.1.2 AND climate cold AND high cold_fastcharge_count`. Signature: throttling at **cold**
   temperatures (throttle_temp_C around -6 C).
2. **Bad charge-connector lot** — `connector_lot B AND build_week 12-18`. Signature: throttling at **warm**
   temperatures (throttle_temp_C around +26 C), driven by connector resistance/current, not cold.

Two confounds are baked in on purpose:
- **Simpson's paradox:** Plant A's raw code rate looks worse than Plant B's, but only because Plant A shipped
  more new-firmware cars. Stratify by firmware and the plant effect disappears.
- A **12V battery repair** on VIN0142 is a red herring with no bearing on the charge fault.

## Dry-run script (run these in VS Code chat)

### Single vehicle (Diagnostician agent, or the /rca-* commands)
Open `single-vehicle/` and run in order:
1. `/rca-intake` on the five files -> a provenance table; the freeze-frame and C source are HIGH, the P0AE0
   text and complaints are LOW.
2. `/rca-frame` -> chains; the leading one is the cold-derate firmware bug -> over-derated charge -> P0AE0.
3. `/rca-impostor` -> "balancing active" correlates, but it is a *co-effect* of cold; partial correlation
   should not unseat cold+firmware.
4. `/rca-impostor` / referee: trace `charge_control.c` -> the cast makes the cold branch fire at -8.4 C with
   balancing ACTIVE -> matches the freeze-frame and the current clamp in `vehicle_signals.csv`.
5. `/rca-sufficiency` -> CONFIRMED. `/rca-report` -> chain + confidence + kill-switch (clear the OTA / patch the
   cast; if cold-charge derate persists, re-open).

### Fleet (Fleet Analyst agent, or the /fleet-* commands)
Point the skills at `fleet/fleet_table.csv` (the stats tools read it):
- `/fleet-demix` -> `bic_select` on `throttle_temp_C` of affected cars should pick **2 clusters** (~ -6 C and ~ +26 C).
- `/fleet-cohort` + `/fleet-rigor` -> firmware split is real: roughly **new ~41% vs old ~8%, chi-square ~32,
  p ~ 1.6e-8** (your numbers will match the file). Then `mantel_haenszel` across firmware strata should show the
  **plant effect collapse** (raw Plant A ~33% > Plant B ~21% is the Simpson artifact).
- `/fleet-surveillance` -> `cusum` on `weekly_code_rate.csv` should **alarm around week 9-11** (the rate lifts after week 8).
- `/fleet-remediate` -> two campaigns: an **OTA** for the firmware cluster, a **targeted recall** for the
  connector-lot cluster. Forecast the connector cluster with `weibull_b10` on `connector_failure_times.csv`
  (expect **beta < 1 -> infant-mortality**).

If the agents reproduce the two causes, the cohort boundaries, the Simpson collapse, the CUSUM alarm, and the
infant-mortality hazard, the harness is wired correctly.
