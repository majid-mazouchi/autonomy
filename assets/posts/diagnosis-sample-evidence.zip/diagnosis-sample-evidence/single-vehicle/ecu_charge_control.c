/* charge_control.c -- charge-rate limiter (BMS, fw 5.1.2). High trust for CAPABILITY, silent on OCCURRENCE. */
#define CHG_TMIN_dC   50    /* 5.0 C  -- below this, derate to protect cold cells */
#define CHG_DERATE_A  40

void charge_step(Pack *p) {
    int16_t t = p->temp_dC;                 /* pack temp, signed deci-degrees C */
    /* BUG (introduced fw 5.1.0): negative temp cast to unsigned wraps high, so the
       cold-derate branch is taken far more aggressively than intended whenever
       balancing is active -- charge current is clamped to CHG_DERATE_A in the cold. */
    if ((uint16_t)t < CHG_TMIN_dC && p->balancing) {   /* -84 -> 65452, condition mis-evaluates */
        p->current_limit_A = CHG_DERATE_A;             /* throttles charge in the cold */
        set_dtc(P0AE0);
    }
}
