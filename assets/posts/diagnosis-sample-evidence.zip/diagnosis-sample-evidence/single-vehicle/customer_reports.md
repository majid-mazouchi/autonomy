# Dealer / customer reports for VIN0142 (LOW trust: high recall, low precision)
- 2026-01-09 - "Charges way slower at the fast charger when it's freezing out. Fine once it warms up."
- 2026-01-18 - "Reduced power warning came on after a cold-morning Supercharge."
- 2026-02-02 - "Range and charge speed both down in the cold snap this month."
Common thread: cold + fast charging. Use for onset dating and hypothesis generation only.
