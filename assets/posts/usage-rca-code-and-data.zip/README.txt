Brake-rotor corrosion usage/behavior RCA — code & data
======================================================
brake_corrosion_rca.py : usage-and-corrosion generator of the 500-vehicle
                         fleet (brake_fleet.csv) + full diagnostic pipeline:
                         service-flag Pareto, correlation screen,
                         partial-correlation confounder test, staged
                         regression, corrosion-vs-apply-frequency knee, the
                         disuse sawtooth, and prognosis (susceptibility curve
                         + annual flag-day forecast with/without auto-scrub).
                         Run:  python brake_corrosion_rca.py
brake_fleet.csv        : the generated mockup dataset (one row per vehicle).
Deps: numpy, scipy.
