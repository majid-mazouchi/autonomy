---
name: interactive-monograph
description: >
  Use when creating a self-contained interactive HTML educational monograph or
  explainer in the established cream-paper house style, with genuine in-browser
  simulations and a verification-first workflow. Triggers include requests to
  build a monograph, explainer, or interactive teaching page; to add a new part
  to an existing series; or to insert sections or figures into an existing page.
  Covers the fixed design language, the canvas-simulation patterns, the figure
  and section structure, and the three-gate validation. Not for ordinary web
  apps, dashboards, or dark-mode UIs.
version: 1.0.0
---

# Interactive monograph

Build a single self-contained `.html` file: a long-form, illustrated, interactive explainer in the cream-paper house style, every figure a genuine computation in vanilla JavaScript, verified before it ships.

<autodoc>
Purpose
Produce self-contained interactive HTML educational monographs in the fixed cream-paper house style. Each page teaches one topic through prose and live, genuinely computed simulations, and is validated to a fixed standard before delivery.

Behavior
On invocation the skill starts from the reusable scaffold, applies the house style without alteration, writes prose and figures for the requested topic, implements each figure as a real computation rather than a recording, and runs the three verification gates until they pass with zero failures. For edits to an existing page it inserts sections at safe anchors, renumbers sections and figures, and revalidates.

Core Functionalities
Scaffold a new monograph from the template with hero, table of contents, numbered sections, practical notes, and references.
Author genuine canvas simulations using the shared helper set, one self-contained closure per figure, with sliders, toggles, a live readout, a legend, and a caption.
Insert sections or figures into an existing page and renumber sections and figures back into sequence.
Verify every page: zero em-dashes, balanced tags, and a headless run with no errors and no empty readouts.

Inputs
A topic and intended depth. Optionally a series part number and subtitle. Optionally an existing page to extend and the anchors where new sections belong.

Outputs
One self-contained HTML file that opens in any browser with no build step and no network beyond Google Fonts. When extending a page, the updated file plus a validation report.
</autodoc>

## When to use

A reader-facing teaching artifact that someone will open, scroll, and play with: a concept explainer, a method walkthrough, a part in a series. Reach for it whenever the answer wants illustrated prose plus interactive figures rather than a chat reply, an app, or a slide deck.

## Workflow

1. Read `reference/house-style.md` for the fixed design tokens, typography, structure, and editorial rules. These do not change between pages.
2. Copy `assets/scaffold.html` to the output path. It is a minimal valid monograph that already passes validation. Edit prose and figures only; leave the CSS and helper block intact.
3. For each figure, read `reference/simulations.md` and follow the figure HTML pattern and the one-closure-per-figure JS pattern. Compute the real quantity; never animate a recording. State any equivalent shortcut honestly in the prose.
4. Keep the editorial rules in view while writing: no em-dashes anywhere, the exact byline, terms in `<em class="term">`, prose over bullets outside the practical-notes list.
5. Verify per `reference/verification.md`. Run `node scripts/validate.mjs <page>.html` and fix until it prints PASS.
6. When extending an existing page, insert sections at distinct comment anchors, add table-of-contents and figure JS, reword any bare-number cross references, run `python3 scripts/renumber.py <page>.html`, then revalidate.

## Hard rules (do not relax)

- Light paper aesthetic only. The design tokens and fonts are fixed.
- No em-dashes anywhere, including code comments.
- Byline exactly: `By Majid Mazouchi · Drafted with Claude`.
- Every simulation is genuinely computed. Every figure populates its readout on first draw.
- A page is not done until `validate.mjs` prints PASS with zero failures.

## Files

- `assets/scaffold.html` starting template (hero, one genuine sim, practical notes, references). Passes validation as shipped.
- `reference/house-style.md` design tokens, typography, structure, editorial rules, component classes.
- `reference/simulations.md` figure pattern, helper catalog, genuine-sim rules, proven recipes.
- `reference/verification.md` the three gates, how to run the scripts, how to read failures, the insert-and-renumber procedure.
- `scripts/validate.mjs` headless validator (needs `jsdom`).
- `scripts/renumber.py` resequences sections and figures after inserts.

## Setup note

The validator needs `jsdom`: run `npm i jsdom` once in the folder where you validate, or symlink an existing `node_modules`. Node 18 or newer.
