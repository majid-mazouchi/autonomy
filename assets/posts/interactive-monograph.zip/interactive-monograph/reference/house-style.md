# House style reference

The fixed visual and editorial language for every monograph. Copy `assets/scaffold.html` and keep all of this intact; only the prose and the simulations change.

## Design tokens (CSS :root, never alter)

    --paper:#F4F1EA;  --panel:#FBF9F4;  --panel-2:#EDE8DD;
    --ink:#2A2724;    --ink-soft:#5A554C;
    --rust:#B0542B;   --teal:#2F6B6B;   --ochre:#C8962C;
    --line:#D9D2C5;   --line-strong:#C3BAA8;

Light paper aesthetic only. No dark mode: it renders unreliably in iOS/Safari file previews and reads wrong for a scientific monograph.

Colour roles in figures: rust is the primary signal or the thing under study; teal is the derived or model quantity; ochre is the highlight, optimum, or selected element; ink-soft / grey is the reference, ground truth, or context.

## Typography (Google Fonts, three families)

Fraunces for display (h1-h4), Spectral for body, IBM Plex Mono for utility text (eyebrow, byline, figure heads, captions inside controls, readouts, axis labels). The exact `<link>` is in the scaffold. Fonts load only in the reader's browser; a headless validator has no network and that is expected.

## Page skeleton (in order)

1. `header.hero` with eyebrow, h1 (one accent word in `.em` rust italic), `.lede`, `.byline`, and a hero canvas card.
2. `nav.toc` listing every section.
3. Numbered `<section>` blocks, each opening with `<p class="sec-num">Section NN</p>` then an `<h2>`.
4. Figures inside sections (see simulations reference).
5. A "Practical notes" section: short prose lead, a `<ul>` of bold-led lessons, and a `.note.field` one-sentence summary.
6. A "References and further reading" section using `<ol class="refs">`, closing with the muted "written from first principles" disclaimer.
7. `<footer>`.

Optional `.seriesnote` block at the end ties the page back to the rest of a series.

## Editorial rules (non-negotiable)

- NO em-dashes anywhere, including code comments. Use commas, the middot `·` (`&middot;`), parentheses, or rewrite. The validator greps for `\u2014` and any hit fails.
- Byline is exactly: `By Majid Mazouchi · Drafted with Claude`.
- Eyebrow pattern for a series part: `A field guide · part N / short subtitle`.
- Define terms with `<em class="term">term</em>` (rust, not italic). Emphasis with `<strong>`.
- Prose over bullets in the body. Bullets belong only in Practical notes and `.defs` cards.
- Captions name every colour, state the takeaway, and point at the control that shows it.
- Equations go in `.eq` blocks using HTML entities (`&minus;`, `&Sigma;`, `&part;`, `&radic;`, superscripts), never a literal em-dash or minus glyph.

## Component classes available in the scaffold

`.fig`, `.fig-head` (+ `.tag`), `.fig-body`, `.fig-cap`, `.controls` + `.ctrl`, `.toggle-row` + `.toggle` (`.on` when active), `.readout` (+ `span.ok` / `span.warn`), `.legend` (+ `i` swatch), `.note` and `.note.field`, `.eq` (+ `.c` rust, `.g` teal), `.defs` + `.def`, `.refs`, `nav.toc`, `.seriesnote`.

## Figure numbering

Two forms share one running counter in document order:
- Canvas figures: `<span class="tag">FIGURE N</span>` in the fig-head, and the caption opens with the figure's subject (no number needed there).
- SVG or static figures: a `<p class="fig-cap">Figure N. ...</p>` caption.

Insert sections out of order freely, then run `scripts/renumber.py` to make Section NN and FIGURE N sequential again.
