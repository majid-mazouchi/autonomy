# Verification reference

Verification is part of authoring, not an afterthought. A monograph is not done until it passes all three gates with zero failures.

## One-time setup

The validator needs `jsdom`. In the skill folder (or wherever the page lives) run once:

    npm i jsdom

or symlink an existing `node_modules` that already has it. Node 18+ (developed on Node 22).

## The three gates

Gate 1 and Gate 2 and Gate 3 are all run by `scripts/validate.mjs`:

    node scripts/validate.mjs path/to/page.html

It reports and then prints PASS or FAIL (exit 0 / 1):

1. Em-dash count must be 0. Any `\u2014` fails. Fix by rewording or using `·` / commas.
2. Tag balance outside the `<script>` block must match for every structural tag. A mismatch usually means an unclosed `<section>` or `<div>` from an insert.
3. Headless run in jsdom: the canvas 2d context is stubbed via a Proxy, layout width is forced to 800, devicePixelRatio to 2, and matchMedia is stubbed. The harness fires every range across five values, clicks every `.toggle`, refires the ranges at max, then asserts that every `.readout` has content and that no JS error was thrown. The forced `process.exit` at the end is required because hero `setInterval` animations keep the event loop alive.

## Reading a failure

- `mean is not defined` (or any `X is not defined`): a figure used a helper that this page does not define. Add it to the page IIFE.
- `empty: fooRead`: that figure threw before populating its readout, or never populated it on first draw. Check the draw path runs end to end on load.
- `MISMATCH section`: an inserted block left a tag unbalanced. Re-check the insert.
- Em-dash hits often hide in pasted references or prose; search and replace.

## Inserting sections into an existing page

1. Insert the new `<section>` blocks at the right anchors using distinct HTML comments (for example `<!-- order tracking -->`) so they do not collide with the numeric `<!-- NN -->` markers.
2. Add matching `nav.toc` entries.
3. Add each new figure's JS IIFE before the closing `})();` of the page script.
4. Reword any prose that references a section or figure by bare number, since the renumber step will otherwise rewrite it wrongly.
5. Run `python3 scripts/renumber.py page.html` to make Section NN and FIGURE N sequential again, then `grep -o 'Figure [0-9]*' page.html` to confirm no prose reference got renumbered.
6. Run `node scripts/validate.mjs page.html` and confirm PASS.

## Quick manual checks (optional but cheap)

    grep -c $'\u2014' page.html      # expect 0
    grep -o 'Section [0-9][0-9]' page.html | tr '\n' ' '   # expect 01..NN, sequential
    grep -o 'FIGURE [0-9]*' page.html                       # expect 1..M with captions filling gaps

For a sim whose correctness matters (a PINN, a Koopman fit, a coverage claim), instrument a small jsdom script that sets the relevant sliders and prints the readout text, to confirm the numbers move the right way rather than merely not erroring.
