# Simulations reference

Every figure is a genuine computation in vanilla JS, never a pre-recorded animation. The reader changes a control and the math actually reruns.

## The two halves of a figure

HTML (inside a section):

    <div class="fig">
      <div class="fig-head"><span class="tag">FIGURE N</span> · caption · interactive</div>
      <div class="fig-body"><canvas id="fooCanvas" height="300"></canvas></div>
      <div class="toggle-row"><span class="lbl">mode:</span>
        <span class="toggle on" id="fooA">a</span><span class="toggle" id="fooB">b</span></div>
      <div class="readout" id="fooRead"></div>
      <div class="controls">
        <div class="ctrl"><label>Param <b><span id="fooPv">1.0</span></b></label>
          <input type="range" id="fooP" min="0" max="3" value="1" step="0.1"></div>
      </div>
      <div class="legend"><span><i style="background:#B0542B"></i>signal</span></div>
      <div class="fig-cap">Name the colours, state the takeaway, point at the control.</div>
    </div>

JS (one IIFE per figure, inside the single page-level IIFE):

    (function(){
      var c=document.getElementById("fooCanvas"); if(!c)return;
      var pS=document.getElementById("fooP"), pv=document.getElementById("fooPv"), read=document.getElementById("fooRead");
      function draw(){ var ctx=c._ctx,w=c._W,h=c._H; if(!ctx)return; clear(ctx,w,h);
        var P=parseFloat(pS.value); pv.textContent=P.toFixed(1);
        /* ...genuine computation, then plot... */
        read.innerHTML='<span class="ok">result: <b>'+/*value*/+'</b></span>';
      }
      pS.addEventListener("input",draw); setup(c,draw)();
    })();

Each `.ctrl` label must mirror the slider value into its `<span>` so the reader sees the number. Each figure must populate its `.readout` on the first draw (the validator fails on an empty readout).

## Shared helper catalog

Always present (top of the page IIFE): `setup(canvas, drawFn)` (handles devicePixelRatio, clientWidth, stores `_ctx/_W/_H`, returns a resize fn you call once), `clear`, `axis`, `gauss` (standard normal), `label`, `mean`, `makeEps(n)`.

Add per page only when needed:
- `fft(re, im)` in-place radix-2 (length a power of two). Build the inverse with the conjugate trick: negate `im`, `fft`, then divide by N and negate `im` again.
- `solveLin(A, b, n)` Gaussian elimination with partial pivoting, for normal equations.
- `matInv(A, n)` Gauss-Jordan inverse, for small operators (DMD, covariance).
- `quantile`, `bounds`, `linsolve` variants as a figure requires.

Keep helpers self-contained. Do not assume a helper exists across pages: if a figure needs `mean` or a matrix routine, confirm it is defined in that file (a missing global is the most common runtime failure).

## Genuine-simulation rules

- Compute the real thing. Real FFTs, real least squares, real gradient descent, real recurrence, real softmax. If a quantity is claimed in the caption, it must be the value the code produced.
- Honest framing for shortcuts. If a sim uses an equivalent shortcut (for example a linear autoencoder computed as PCA, or fixed attention features instead of learned ones), say so in the prose. Never imply learning that did not happen.
- Animated training is fine via `setInterval` doing a few steps per tick (see the MLP recipe). Guard with `prefers-reduced-motion` and run a fixed number of steps synchronously in the reduced case.
- Stochastic sims that redraw fresh noise will jitter run to run. That is faithful to uncertainty; note it in the prose or fix a noise seed array when you want determinism.

## Recipes that have worked (genuine, cheap enough for the browser)

- Function fit by backprop: 1-H-1 tanh MLP, full-batch gradient descent, animate loss + fit.
- 1D convolution: sliding dot product, then ReLU, then max-pool; selectable kernels.
- Recurrence: leaky-integrator hidden state `h = a*h + (1-a)*x`; 1D search for the best `a`.
- Autoencoder: PCA via power iteration with deflation on a small covariance; reconstruction error as anomaly score.
- Attention: query/key dot products, softmax rows, weighted value sum; heatmap of the matrix.
- PINN: linear-in-parameters basis (Fourier), enforce the ODE residual at collocation points plus data plus initial conditions, solve by normal equations; a physics-weight slider trades data vs equation.
- Koopman/DMD: lift state to observables, fit the one-step linear operator by least squares (`A = G' Gᵀ (G Gᵀ)⁻¹`), iterate to predict.
- Kalman / particle filter / CUSUM / control charts / survival (Weibull) / quantile pinball regression: all implemented directly from their defining equations.

## Performance and validation friendliness

Keep per-draw work cheap (the validator fires every slider many times). Heavy one-time fitting (covariance, DMD operator, training data) should run once on load, not inside `draw`. Use canvas sizes around 200 to 340 px tall. Powers of two for any FFT length.
