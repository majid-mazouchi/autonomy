#!/usr/bin/env node
// Headless validator for interactive monographs.
// Usage: node validate.mjs path/to/page.html
// Requires: npm i jsdom   (run once in the folder, or symlink node_modules)
//
// Checks performed:
//   1. zero em-dash characters anywhere in the file
//   2. balanced HTML tags outside the <script> block
//   3. headless run in jsdom: stubs canvas 2d context, forces a layout width,
//      fires every range across 5 values, clicks every .toggle, refires ranges,
//      then asserts every .readout is populated and no JS error fired.
//
// Exit code 0 = PASS, 1 = FAIL.

import { JSDOM } from "jsdom";
import fs from "fs";

const file = process.argv[2];
if (!file) { console.error("usage: node validate.mjs page.html"); process.exit(2); }
const html = fs.readFileSync(file, "utf8");

// ---- 1. em-dash ----
const emDashes = (html.match(/\u2014/g) || []).length;

// ---- 2. tag balance (ignore script bodies) ----
const body = html.replace(/<script[\s\S]*?<\/script>/g, " ");
const tags = ["section","div","nav","ol","ul","li","p","h2","h3","span","header","footer","g","svg"];
const mismatched = tags.filter(t =>
  (body.match(new RegExp("<" + t + "[\\s>]", "g")) || []).length !==
  (body.match(new RegExp("</" + t + ">", "g")) || []).length);

// ---- 3. headless behavioural run ----
function makeCtx() {
  const noop = () => {};
  const methods = ["setTransform","clearRect","beginPath","moveTo","lineTo","stroke","fill",
    "arc","fillRect","strokeRect","fillText","setLineDash","rect","closePath","save","restore",
    "translate","rotate","scale","quadraticCurveTo","bezierCurveTo","clip","ellipse","arcTo",
    "createLinearGradient","addColorStop"];
  return new Proxy({}, {
    get(t, p) {
      if (p === "canvas") return {};
      if (p === "measureText") return () => ({ width: 10 });
      if (typeof p === "string" && methods.includes(p)) return noop;
      return t[p];
    },
    set(t, p, v) { t[p] = v; return true; }
  });
}

const errors = [];
const dom = new JSDOM(html, {
  runScripts: "dangerously",
  pretendToBeVisual: true,
  beforeParse(window) {
    window.HTMLCanvasElement.prototype.getContext = function () { return makeCtx(); };
    Object.defineProperty(window.HTMLElement.prototype, "clientWidth", { get() { return 800; } });
    window.matchMedia = window.matchMedia || function () {
      return { matches: false, addEventListener() {}, removeEventListener() {} };
    };
    window.requestAnimationFrame = (cb) => setTimeout(() => cb(Date.now()), 0);
    window.devicePixelRatio = 2;
    window.onerror = (m, s, l, c, e) => { errors.push(String((e && e.stack) || m)); };
  }
});

const { window } = dom;
const { document } = window;

setTimeout(() => {
  const ranges = [...document.querySelectorAll("input[type=range]")];
  let states = 0;
  for (const r of ranges) {
    const mn = parseFloat(r.min), mx = parseFloat(r.max);
    for (const v of [mn, (mn + mx) / 2, mx, mn + (mx - mn) * 0.3, mx - (mx - mn) * 0.2]) {
      r.value = v; r.dispatchEvent(new window.Event("input", { bubbles: true })); states++;
    }
  }
  const toggles = [...document.querySelectorAll(".toggle")];
  for (const el of toggles) el.dispatchEvent(new window.Event("click", { bubbles: true }));
  for (const r of ranges) { r.value = r.max; r.dispatchEvent(new window.Event("input", { bubbles: true })); }

  const readouts = [...document.querySelectorAll(".readout")];
  const empty = readouts.filter(e => !e.innerHTML.trim()).map(e => e.id || "(no id)");

  const pass = emDashes === 0 && mismatched.length === 0 && errors.length === 0 && empty.length === 0;

  console.log("em-dashes      :", emDashes, emDashes === 0 ? "OK" : "FAIL");
  console.log("tag balance    :", mismatched.length === 0 ? "OK" : "MISMATCH " + mismatched.join(","));
  console.log("sliders        :", ranges.length, "(" + states + " states fired)");
  console.log("toggles        :", toggles.length);
  console.log("readouts       :", readouts.length, "| empty:", empty.length ? empty.join(",") : "none");
  console.log("JS errors      :", errors.length);
  if (errors.length) console.log(errors.slice(0, 6).join("\n---\n"));
  console.log(pass ? "PASS" : "FAIL");
  process.exit(pass ? 0 : 1); // forced exit: hero setInterval keeps the loop alive
}, 600);
