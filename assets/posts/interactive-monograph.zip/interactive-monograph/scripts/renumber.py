#!/usr/bin/env python3
"""Renumber sections and figures after surgical inserts.

Usage: python3 renumber.py page.html

Renumbers, in document order:
  - <p class="sec-num">Section NN</p>   -> sequential, 2-digit
  - <span class="tag">FIGURE N</span>   -> sequential, shared counter
  - Figure N.  (SVG/plain caption form) -> same shared counter, case preserved

Both figure forms share ONE running counter so interleaved tag-figures and
caption-figures stay globally sequential.

CRITICAL: prose cross-references like "the funnel of Figure 5." also match the
caption pattern and will be renumbered wrongly. Before running, reword any prose
figure/section reference to remove the bare number (e.g. "the conformal funnel"
instead of "Figure 5"). Verify with:  grep -o 'Figure [0-9]*' page.html
"""
import re, sys

if len(sys.argv) != 2:
    print("usage: python3 renumber.py page.html"); sys.exit(2)

path = sys.argv[1]
html = open(path).read()

# split off the <script> block so figure/section regexes never touch JS
idx = html.index("<script>")
body, tail = html[:idx], html[idx:]

sec = [0]
def sec_rep(m):
    sec[0] += 1
    return '<p class="sec-num">Section %02d</p>' % sec[0]
body = re.sub(r'<p class="sec-num">Section \d+</p>', sec_rep, body)

fig = [0]
def fig_rep(m):
    fig[0] += 1
    if m.group(0).startswith("<span"):
        return '<span class="tag">FIGURE %d</span>' % fig[0]
    return "Figure %d." % fig[0]
body = re.sub(r'<span class="tag">FIGURE \d+</span>|Figure \d+\.', fig_rep, body)

open(path, "w").write(body + tail)
print("sections: %d  figures: %d" % (sec[0], fig[0]))
