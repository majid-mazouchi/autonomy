# diagnostic-dependence

A VS Code Copilot skill for choosing and computing the right statistical
dependence or association measure in system health management diagnostics:
detection, isolation, and root-cause.

## Layout (progressive disclosure)

    SKILL.md                     Layer 1: routing and overview (read first)
    references/                  Layer 2: open only what the task needs
      01-core-dependence.md
      02-agreement-redundancy.md
      03-categorical-mixed.md
      04-nonlinear-detectors.md
      05-directional-causal.md
      06-conditional-nonlinear.md
      07-set-level.md
      decision-map.md            question -> measure, escalation order
      pitfalls.md                assumptions and failure modes
    scripts/                     Layer 3: the engine
      measures.py                tested implementations of every measure
      requirements.txt
    copilot/                     VS Code Copilot integration
      diagnostics-dependence.chatmode.md
      dependence.prompt.md
      dependence.instructions.md
    assets/
      dependence-measures.html   the full illustrated monograph

## Use the engine

    pip install -r scripts/requirements.txt
    python scripts/measures.py          # self-test on synthetic diagnostic data

    from scripts.measures import partial_corr, distance_correlation, recommend
    recommend("direct_vs_confounded")   # -> candidate measures

## Wire into VS Code Copilot

Copy the files in `copilot/` into your workspace `.github/` tree:

    .github/chatmodes/diagnostics-dependence.chatmode.md
    .github/prompts/dependence.prompt.md
    .github/instructions/dependence.instructions.md

Then select the "Diagnostics Dependence Analyst" chat mode, or run the
`/dependence` prompt, and Copilot will route through the skill and call the
engine.
