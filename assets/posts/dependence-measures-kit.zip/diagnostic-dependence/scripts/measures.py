"""
diagnostic dependence toolkit

Purpose
A single tested module that computes the dependence and association measures
used in system health management diagnostics: detection, isolation, and
root-cause work. Every function answers a version of one of three questions.
Are two signals coupled. Is the coupling direct or borrowed from a shared
driver. Which way does the influence flow.

Behavior
Each measure is implemented with numpy, scipy, scikit-learn, and statsmodels
only. Distance correlation, partial distance correlation, HSIC, the
intraclass correlation, and a binned transfer entropy are implemented in
plain numpy so the module has no fragile third-party dependencies and runs
anywhere those four packages are present. Run the module directly to execute
a self-test on synthetic diagnostic data.

Inputs
Most functions take one-dimensional numpy arrays of equal length. Categorical
helpers take integer or string label arrays. Set-level helpers take
two-dimensional arrays shaped samples by features.

Outputs
Scalars in a documented range, or small tuples. Functions never raise on
ordinary numeric input; degenerate cases return nan.

Notes
Implementations are reference quality and readable rather than maximally
optimized. Check the stated assumptions before trusting a number: sample
size, stationarity for the time-series measures, and kernel bandwidth for
the kernel measures.
"""
from __future__ import annotations

import numpy as np
from scipy import signal, stats
from scipy.stats import norm, multivariate_normal as _mvn
from scipy.optimize import brentq
from sklearn.linear_model import LinearRegression
from sklearn.cross_decomposition import CCA
from sklearn.feature_selection import mutual_info_regression
from sklearn.kernel_ridge import KernelRidge


# ===========================================================================
# group A. core dependence
# ===========================================================================
def pearson(x, y):
    """
    Purpose
    Linear coupling between two numeric signals.

    Inputs
    x, y are equal-length arrays.

    Outputs
    Correlation in minus one to plus one. Sees straight-line relationships
    only.
    """
    return float(stats.pearsonr(x, y)[0])


def spearman(x, y):
    """
    Purpose
    Rank correlation. Robust to nonlinearity that is still monotonic, and to
    outliers.

    Outputs
    Coefficient in minus one to plus one computed on the ranks.
    """
    return float(stats.spearmanr(x, y).correlation)


def kendall_tau(x, y):
    """
    Purpose
    Rank correlation based on the balance of concordant and discordant pairs.

    Outputs
    Tau in minus one to plus one.
    """
    return float(stats.kendalltau(x, y).correlation)


def _residual(target, controls):
    controls = np.atleast_2d(controls)
    if controls.shape[0] != len(target):
        controls = controls.T
    model = LinearRegression().fit(controls, target)
    return target - model.predict(controls)


def partial_corr(x, y, controls):
    """
    Purpose
    Correlation of x and y after the linear influence of a controlling set is
    removed from both. The core tool for telling a direct link from a shared
    driver.

    Inputs
    x, y are arrays. controls is an array or list of arrays to regress out of
    both x and y.

    Outputs
    Partial correlation in minus one to plus one. A value near zero after
    controlling means the raw link was carried by the controls.
    """
    rx = _residual(np.asarray(x, float), np.asarray(controls, float))
    ry = _residual(np.asarray(y, float), np.asarray(controls, float))
    return float(stats.pearsonr(rx, ry)[0])


def semipartial_corr(x, y, x_controls):
    """
    Purpose
    Correlation of x and y after the controlling set is removed from x only.
    Reads as the unique contribution of x to y beyond the controls.

    Outputs
    Semi-partial correlation in minus one to plus one.
    """
    rx = _residual(np.asarray(x, float), np.asarray(x_controls, float))
    return float(stats.pearsonr(rx, np.asarray(y, float))[0])


def cross_correlation_lag(a, b, max_lag=None):
    """
    Purpose
    Find the time shift at which two signals align best, recovering
    propagation delay and lead-lag direction.

    Inputs
    a, b are equal-length time series. max_lag optionally clips the search.

    Outputs
    Tuple of best_lag in samples and the normalized peak correlation. A
    positive lag means a leads b.
    """
    a = np.asarray(a, float) - np.mean(a)
    b = np.asarray(b, float) - np.mean(b)
    xc = signal.correlate(b, a, mode="full")
    xc /= (np.std(a) * np.std(b) * len(a) + 1e-12)
    lags = signal.correlation_lags(len(b), len(a), mode="full")
    if max_lag is not None:
        keep = np.abs(lags) <= max_lag
        xc, lags = xc[keep], lags[keep]
    i = int(np.argmax(np.abs(xc)))
    return int(lags[i]), float(xc[i])


def _dist_matrix(v):
    v = np.asarray(v, float).reshape(len(v), -1)
    return np.sqrt(((v[:, None, :] - v[None, :, :]) ** 2).sum(-1))


def _double_center(d):
    return d - d.mean(0, keepdims=True) - d.mean(1, keepdims=True) + d.mean()


def distance_correlation(x, y):
    """
    Purpose
    Dependence of any shape, linear or not, monotonic or not. Zero only when x
    and y are statistically independent.

    Outputs
    Distance correlation in zero to one.
    """
    A = _double_center(_dist_matrix(x))
    B = _double_center(_dist_matrix(y))
    dcov = np.sqrt(max((A * B).mean(), 0.0))
    dvx = np.sqrt(max((A * A).mean(), 0.0))
    dvy = np.sqrt(max((B * B).mean(), 0.0))
    denom = np.sqrt(dvx * dvy)
    return float(dcov / denom) if denom > 0 else 0.0


def mutual_information(x, y, n_neighbors=3):
    """
    Purpose
    Information-theoretic dependence of any shape, in nats.

    Outputs
    Non-negative mutual information estimate using a k-nearest-neighbor
    estimator. Larger means more shared information.
    """
    x = np.asarray(x, float).reshape(-1, 1)
    return float(mutual_info_regression(x, np.asarray(y, float),
                                        n_neighbors=n_neighbors, random_state=0)[0])


def coherence_peak(a, b, fs, nperseg=256):
    """
    Purpose
    Frequency-domain correlation. Finds the frequency where two signals are
    most strongly coupled.

    Inputs
    a, b are time series. fs is the sample rate in hertz.

    Outputs
    Tuple of peak_frequency in hertz and the coherence at that frequency in
    zero to one.
    """
    f, cxy = signal.coherence(a, b, fs=fs, nperseg=min(nperseg, len(a)))
    i = int(np.argmax(cxy))
    return float(f[i]), float(cxy[i])


# ===========================================================================
# group B. agreement and redundancy
# ===========================================================================
def icc(ratings):
    """
    Purpose
    Agreement among repeated or redundant measurements of the same quantity.
    Penalizes a constant offset between sensors, unlike correlation.

    Inputs
    ratings is a two-dimensional array shaped subjects by raters. Each row is
    one measured target seen by every sensor.

    Outputs
    ICC(2,1), the two-way random single-rater absolute-agreement coefficient,
    in minus small to one.
    """
    Y = np.asarray(ratings, float)
    n, k = Y.shape
    gm = Y.mean()
    ms_rows = k * ((Y.mean(1) - gm) ** 2).sum() / (n - 1)
    ms_cols = n * ((Y.mean(0) - gm) ** 2).sum() / (k - 1)
    resid = Y - Y.mean(1, keepdims=True) - Y.mean(0, keepdims=True) + gm
    ms_err = (resid ** 2).sum() / ((n - 1) * (k - 1))
    denom = ms_rows + (k - 1) * ms_err + k * (ms_cols - ms_err) / n
    return float((ms_rows - ms_err) / denom) if denom != 0 else float("nan")


def ccc(x, y):
    """
    Purpose
    Lin's concordance correlation. Agreement with a reference, penalizing both
    random scatter and systematic bias relative to the line y equals x.

    Outputs
    Concordance coefficient in minus one to plus one.
    """
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    cov = np.cov(x, y, bias=True)[0, 1]
    return float(2 * cov / (x.var() + y.var() + (x.mean() - y.mean()) ** 2))


def kendall_w(ranks):
    """
    Purpose
    Agreement among several rankers on an ordering of items.

    Inputs
    ranks is a two-dimensional integer array shaped raters by items.

    Outputs
    Coefficient of concordance in zero to one.
    """
    ranks = np.asarray(ranks, float)
    m, n = ranks.shape
    R = ranks.sum(0)
    S = ((R - R.mean()) ** 2).sum()
    return float(12 * S / (m ** 2 * (n ** 3 - n)))


# ===========================================================================
# group C. categorical and mixed-type
# ===========================================================================
def cramers_v(table):
    """
    Purpose
    Strength of association between two categorical variables.

    Inputs
    table is a contingency count matrix.

    Outputs
    Cramer's V in zero to one.
    """
    table = np.asarray(table, float)
    chi2 = stats.chi2_contingency(table, correction=False)[0]
    n = table.sum()
    r, k = table.shape
    return float(np.sqrt(chi2 / (n * (min(r, k) - 1))))


def point_biserial(binary_flag, continuous):
    """
    Purpose
    Association between a continuous signal and a zero or one flag. Equivalent
    to Pearson with the flag coded numerically.

    Outputs
    Coefficient in minus one to plus one.
    """
    return float(stats.pointbiserialr(np.asarray(binary_flag), np.asarray(continuous))[0])


def _entropy(v):
    _, counts = np.unique(v, return_counts=True)
    p = counts / counts.sum()
    return float(-(p * np.log(p)).sum())


def theils_u(x, y):
    """
    Purpose
    Directional categorical dependence. U of x given y is how much knowing y
    reduces uncertainty about x. Asymmetric: U(x|y) need not equal U(y|x).

    Inputs
    x, y are equal-length label arrays.

    Outputs
    Uncertainty coefficient in zero to one.
    """
    x = np.asarray(x)
    y = np.asarray(y)
    hx = _entropy(x)
    if hx == 0:
        return float("nan")
    hxy = 0.0
    for yv in np.unique(y):
        sub = x[y == yv]
        hxy += (len(sub) / len(y)) * _entropy(sub)
    return float((hx - hxy) / hx)


def tetrachoric(table2x2):
    """
    Purpose
    Correlation of the latent continuous variables behind two zero or one
    flags, undoing the loss from thresholding.

    Inputs
    table2x2 is a two by two count matrix [[n11, n10], [n01, n00]].

    Outputs
    Latent correlation in minus one to plus one.
    """
    t = np.asarray(table2x2, float)
    n = t.sum()
    hx = norm.ppf(t[0].sum() / n)
    hy = norm.ppf(t[:, 0].sum() / n)
    target = t[0, 0] / n

    def f(r):
        return _mvn(mean=[0, 0], cov=[[1, r], [r, 1]]).cdf([hx, hy]) - target

    return float(brentq(f, -0.999, 0.999))


# ===========================================================================
# group D. stronger nonlinear detectors
# ===========================================================================
def _rbf_kernel(v):
    v = np.asarray(v, float).reshape(-1, 1)
    d2 = (v - v.T) ** 2
    med = np.median(d2[d2 > 0]) if np.any(d2 > 0) else 1.0
    sigma2 = med / 2 + 1e-12
    return np.exp(-d2 / (2 * sigma2))


def hsic(x, y):
    """
    Purpose
    Kernel independence statistic. A general nonlinear dependence detector,
    zero only when x and y are independent.

    Outputs
    Non-negative HSIC value. Compare against hsic_pvalue for a test.
    """
    n = len(x)
    H = np.eye(n) - 1.0 / n
    K = _rbf_kernel(x)
    L = _rbf_kernel(y)
    return float(np.trace(K @ H @ L @ H) / (n - 1) ** 2)


def hsic_pvalue(x, y, n_perm=200, seed=0):
    """
    Purpose
    Permutation p-value for the HSIC independence test.

    Outputs
    Fraction of label-shuffled permutations whose HSIC meets or exceeds the
    observed value. Small means dependence.
    """
    rng = np.random.default_rng(seed)
    obs = hsic(x, y)
    y = np.asarray(y)
    count = sum(hsic(x, y[rng.permutation(len(y))]) >= obs for _ in range(n_perm))
    return float((count + 1) / (n_perm + 1))


def xicor(x, y):
    """
    Purpose
    Chatterjee's xi. Near zero under independence, near one when y is a
    possibly noisy function of x. Asymmetric and consistent against any
    dependence.

    Outputs
    Coefficient roughly in zero to one. Compute both directions for the
    asymmetry.
    """
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    n = len(x)
    order = np.argsort(x, kind="mergesort")
    r = stats.rankdata(y[order], method="max")
    return float(1 - 3 * np.abs(np.diff(r)).sum() / (n ** 2 - 1))


def lower_tail_dependence(a, b, q=0.05):
    """
    Purpose
    Tendency of two signals to hit low extremes together, the joint-failure
    risk that bulk correlation misses.

    Inputs
    a, b are arrays. q is the lower quantile that defines an extreme.

    Outputs
    Empirical lower-tail dependence, roughly in zero to one.
    """
    u = (stats.rankdata(a)) / (len(a) + 1)
    v = (stats.rankdata(b)) / (len(b) + 1)
    return float(((u <= q) & (v <= q)).mean() / q)


def rdc(x, y, k=20, s=1.0 / 6, seed=0):
    """
    Purpose
    Randomized dependence coefficient. Fast nonlinear dependence at near
    correlation cost. Suited to screening wide feature matrices.

    Outputs
    Coefficient in zero to one.
    """
    rng = np.random.default_rng(seed)

    def feat(z):
        z = stats.rankdata(z) / len(z)
        W = rng.standard_normal((1, k)) * s
        b = rng.uniform(0, 2 * np.pi, k)
        return np.sin(z[:, None] * W + b)

    u, v = CCA(1).fit_transform(feat(x), feat(y))
    return float(abs(np.corrcoef(u.ravel(), v.ravel())[0, 1]))


# ===========================================================================
# group E. directional and causal
# ===========================================================================
def granger_min_pvalue(cause, effect, maxlag=5):
    """
    Purpose
    Test whether the past of cause improves prediction of effect. Linear
    workhorse for fault-propagation chains.

    Outputs
    Smallest p-value across lags one to maxlag. Small means cause Granger
    causes effect.
    """
    from statsmodels.tsa.stattools import grangercausalitytests
    data = np.column_stack([np.asarray(effect, float), np.asarray(cause, float)])
    res = grangercausalitytests(data, maxlag=maxlag, verbose=False)
    return float(min(res[l][0]["ssr_ftest"][1] for l in res))


def _symbolize(v, bins=4):
    edges = np.quantile(v, np.linspace(0, 1, bins + 1)[1:-1])
    return np.digitize(v, edges)


def transfer_entropy(source, dest, bins=4):
    """
    Purpose
    Directed information flow from source to dest, beyond what dest's own past
    explains. Model-free and nonlinear. Compute both directions and compare.

    Inputs
    source, dest are time series. They are symbolized into bins internally.

    Outputs
    Transfer entropy in nats, non-negative.
    """
    s = _symbolize(np.asarray(source, float), bins)
    d = _symbolize(np.asarray(dest, float), bins)
    d_fut, d_past, s_past = d[1:], d[:-1], s[:-1]
    te = 0.0
    n = len(d_fut)
    for a in np.unique(d_fut):
        for b in np.unique(d_past):
            for c in np.unique(s_past):
                p_abc = np.mean((d_fut == a) & (d_past == b) & (s_past == c))
                if p_abc == 0:
                    continue
                p_bc = np.mean((d_past == b) & (s_past == c))
                p_ab = np.mean((d_fut == a) & (d_past == b))
                p_b = np.mean(d_past == b)
                te += p_abc * np.log((p_abc * p_b) / (p_bc * p_ab + 1e-12) + 1e-12)
    return float(max(te, 0.0))


# ===========================================================================
# group F. conditional nonlinear
# ===========================================================================
def _u_center(d):
    n = d.shape[0]
    rs = d.sum(1, keepdims=True)
    cs = d.sum(0, keepdims=True)
    total = d.sum()
    U = d - rs / (n - 2) - cs / (n - 2) + total / ((n - 1) * (n - 2))
    np.fill_diagonal(U, 0.0)
    return U


def _u_inner(A, B):
    n = A.shape[0]
    return (A * B).sum() / (n * (n - 3))


def partial_distance_correlation(x, y, z):
    """
    Purpose
    Nonlinear analogue of partial correlation. Dependence of x and y that
    remains after removing z, with no linearity assumption.

    Outputs
    Partial distance correlation, roughly in minus one to plus one.
    """
    A = _u_center(_dist_matrix(x))
    B = _u_center(_dist_matrix(y))
    Cz = _u_center(_dist_matrix(z))
    cc = _u_inner(Cz, Cz)
    Px = A - (_u_inner(A, Cz) / cc) * Cz if cc != 0 else A
    Py = B - (_u_inner(B, Cz) / cc) * Cz if cc != 0 else B
    num = _u_inner(Px, Py)
    denom = np.sqrt(_u_inner(Px, Px) * _u_inner(Py, Py))
    return float(num / denom) if denom > 0 else 0.0


def conditional_hsic(x, y, z, n_perm=200, seed=0):
    """
    Purpose
    Kernel test of whether x and y are independent given z. Residualizes x and
    y on z with kernel regression, then tests the residuals with HSIC.

    Outputs
    Tuple of conditional HSIC value and its permutation p-value. A large
    p-value supports x independent of y given z.
    """
    z = np.asarray(z, float).reshape(-1, 1)
    rx = np.asarray(x, float) - KernelRidge(kernel="rbf").fit(z, x).predict(z)
    ry = np.asarray(y, float) - KernelRidge(kernel="rbf").fit(z, y).predict(z)
    return hsic(rx, ry), hsic_pvalue(rx, ry, n_perm=n_perm, seed=seed)


# ===========================================================================
# group G. set-level linear
# ===========================================================================
def multiple_r2(X, y):
    """
    Purpose
    How well a panel of predictors jointly tracks one target.

    Inputs
    X is samples by features. y is the target.

    Outputs
    Tuple of multiple R and R squared.
    """
    X = np.atleast_2d(np.asarray(X, float))
    if X.shape[0] != len(y):
        X = X.T
    r2 = LinearRegression().fit(X, y).score(X, y)
    return float(np.sqrt(max(r2, 0.0))), float(r2)


def partial_canonical_corr(set_x, set_y, control):
    """
    Purpose
    Strongest association between two groups of variables after a controlling
    set is removed from both.

    Inputs
    set_x, set_y, control are each samples by features arrays.

    Outputs
    First partial canonical correlation in zero to one.
    """
    def res(M):
        M = np.atleast_2d(np.asarray(M, float))
        if M.shape[0] != control_arr.shape[0]:
            M = M.T
        return M - LinearRegression().fit(control_arr, M).predict(control_arr)

    control_arr = np.atleast_2d(np.asarray(control, float))
    if control_arr.shape[1] > control_arr.shape[0]:
        control_arr = control_arr.T
    u, v = CCA(1).fit_transform(res(set_x), res(set_y))
    return float(abs(np.corrcoef(u.ravel(), v.ravel())[0, 1]))


# ===========================================================================
# decision map
# ===========================================================================
DECISION_MAP = {
    "coupled_linear": ["pearson"],
    "coupled_monotonic": ["spearman", "kendall_tau"],
    "coupled_any_shape": ["distance_correlation", "mutual_information", "hsic", "xicor"],
    "direct_vs_confounded": ["partial_corr", "partial_distance_correlation", "conditional_hsic"],
    "unique_contribution": ["semipartial_corr"],
    "which_first_or_propagation": ["cross_correlation_lag", "granger_min_pvalue", "transfer_entropy"],
    "coupled_at_frequency": ["coherence_peak"],
    "sensor_agreement": ["icc", "ccc", "kendall_w"],
    "categorical_or_flag": ["cramers_v", "point_biserial", "theils_u", "tetrachoric"],
    "group_to_group": ["multiple_r2", "partial_canonical_corr"],
    "joint_extreme_risk": ["lower_tail_dependence"],
    "fast_nonlinear_screen": ["rdc"],
}


def recommend(question_key):
    """
    Purpose
    Map a diagnostic question to the measures that answer it.

    Inputs
    question_key is one of the keys of DECISION_MAP.

    Outputs
    List of function names to apply, most appropriate first.
    """
    return DECISION_MAP.get(question_key, [])


# ===========================================================================
# significance and multiple testing (fleet-scale screening)
# ===========================================================================
def permutation_pvalue(stat_fn, x, y, n_perm=499, seed=0):
    """
    Purpose
    Distribution-free p-value for any symmetric dependence statistic, by
    shuffling one variable to build the null. Use for the nonlinear and kernel
    measures that have no closed-form null.

    Inputs
    stat_fn is a function of (x, y) returning a non-negative score. n_perm is
    the number of shuffles.

    Outputs
    p-value in zero to one. Small means dependence.
    """
    rng = np.random.default_rng(seed)
    y = np.asarray(y)
    obs = stat_fn(x, y)
    count = sum(stat_fn(x, y[rng.permutation(len(y))]) >= obs for _ in range(n_perm))
    return float((count + 1) / (n_perm + 1))


def benjamini_hochberg(pvals, alpha=0.05):
    """
    Purpose
    Control the false discovery rate across many tests. Essential when
    screening thousands of feature pairs, where uncorrected p-values declare
    far too many discoveries.

    Inputs
    pvals is an array of p-values. alpha is the target FDR.

    Outputs
    Tuple of a boolean array of rejections and the adjusted q-values.
    """
    p = np.asarray(pvals, float)
    m = len(p)
    order = np.argsort(p)
    ranked = p[order]
    q = ranked * m / np.arange(1, m + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    qvals = np.empty(m)
    qvals[order] = np.clip(q, 0, 1)
    return qvals <= alpha, qvals


def screen_pairs(X, names=None, measure=None, n_perm=199,
                 alpha=0.05, effect_floor=0.1, seed=0):
    """
    Purpose
    Screen every column pair of a feature matrix. Combines an effect size, a
    permutation p-value, a Benjamini-Hochberg correction, and an effect-size
    floor, the discipline that keeps fleet-scale screening honest.

    Inputs
    X is samples by features. measure defaults to distance_correlation.
    effect_floor is the minimum operationally meaningful effect size.

    Outputs
    List of dicts with the pair, effect, p-value, q-value, and a keep flag that
    is true only when the pair passes both the FDR and the effect floor.
    """
    X = np.asarray(X, float)
    pcount = X.shape[1]
    names = names or [f"x{i}" for i in range(pcount)]
    measure = measure or distance_correlation
    pairs, effects, pv = [], [], []
    for i in range(pcount):
        for j in range(i + 1, pcount):
            pairs.append((names[i], names[j]))
            effects.append(measure(X[:, i], X[:, j]))
            pv.append(permutation_pvalue(measure, X[:, i], X[:, j],
                                         n_perm=n_perm, seed=seed))
    rejected, qvals = benjamini_hochberg(pv, alpha)
    effects = np.asarray(effects)
    keep = rejected & (effects >= effect_floor)
    return [dict(pair=pr, effect=float(e), p=float(p), q=float(q), keep=bool(k))
            for pr, e, p, q, k in zip(pairs, effects, pv, qvals, keep)]


# ===========================================================================
# self-test on synthetic diagnostic data
# ===========================================================================
def _demo():
    rng = np.random.default_rng(0)
    n = 400
    load = rng.normal(0, 1, n)
    temp = 0.5 * load + rng.normal(0, 0.5, n)
    # A and B both driven by load -> raw corr high, partial corr ~ 0
    A = 1.2 * load + rng.normal(0, 0.4, n)
    B = 1.1 * load + rng.normal(0, 0.4, n)
    # nonlinear pair
    x = rng.uniform(-2, 2, n)
    yc = x ** 2 + rng.normal(0, 0.3, n)
    # lagged pair: stationary AR(1) driver, response delayed by 6 samples
    drv = np.zeros(n)
    eps = rng.normal(0, 1, n)
    for t in range(1, n):
        drv[t] = 0.6 * drv[t - 1] + eps[t]
    rsp = np.r_[np.zeros(6), drv[:-6]] + rng.normal(0, 0.5, n)

    print("== core ==")
    print(f"pearson(A,B)            = {pearson(A, B):+.3f}")
    print(f"partial_corr(A,B|load)  = {partial_corr(A, B, load):+.3f}   (expect ~0)")
    print(f"semipartial(A,B|A~load) = {semipartial_corr(A, B, load):+.3f}")
    print(f"spearman(x, x^2)        = {spearman(x, yc):+.3f}   (monotonic fails)")
    print(f"distance_corr(x, x^2)   = {distance_correlation(x, yc):.3f}   (catches it)")
    print(f"mutual_info(x, x^2)     = {mutual_information(x, yc):.3f}")
    lag, pk = cross_correlation_lag(drv, rsp)
    print(f"cross-corr lag          = {lag} samples, peak {pk:.2f}   (expect +6: drv leads rsp)")

    print("== agreement ==")
    truth = rng.normal(25, 2, n)
    s1 = truth + rng.normal(0, 0.3, n)
    s2 = truth + rng.normal(0, 0.3, n)
    s3 = truth + 3.0  # biased
    print(f"icc(unbiased 3 sensors) = {icc(np.column_stack([s1, s2, truth])):.3f}")
    print(f"icc(with biased sensor) = {icc(np.column_stack([s1, s2, s3])):.3f}   (drops)")
    print(f"ccc(ref, biased)        = {ccc(truth, s3):.3f}")

    print("== nonlinear / categorical ==")
    print(f"hsic(x, x^2)            = {hsic(x, yc):.4f}  p={hsic_pvalue(x, yc, 100):.3f}")
    print(f"xicor(x->x^2)           = {xicor(x, yc):.3f}   xicor(x^2->x)={xicor(yc, x):.3f}")
    print(f"rdc(x, x^2)             = {rdc(x, yc):.3f}")
    table = np.array([[40, 5, 2], [6, 35, 4], [3, 8, 30]])
    print(f"cramers_v(DTC x mode)   = {cramers_v(table):.3f}")
    print(f"theils_u                = {tetrachoric(np.array([[40, 12], [10, 38]])):.3f} (tetrachoric)")

    print("== directional ==")
    print(f"granger p (drv->rsp)    = {granger_min_pvalue(drv, rsp):.2e}   (small = causal)")
    print(f"granger p (rsp->drv)    = {granger_min_pvalue(rsp, drv):.2e}   (larger)")
    print(f"TE drv->rsp             = {transfer_entropy(drv, rsp):.3f}")
    print(f"TE rsp->drv             = {transfer_entropy(rsp, drv):.3f}")

    print("== conditional / set-level ==")
    print(f"pdcor(A,B | load)       = {partial_distance_correlation(A, B, load):+.3f}   (expect ~0)")
    chsic_v, chsic_p = conditional_hsic(A, B, load, n_perm=100)
    print(f"cond-HSIC(A,B|load)     = {chsic_v:.4f}  p={chsic_p:.3f}   (large p => A _|_ B | load)")
    X = np.column_stack([load, temp, x])
    R, R2 = multiple_r2(X, A)
    print(f"multiple R / R^2        = {R:.3f} / {R2:.3f}")
    setX = np.column_stack([A, B])
    setY = np.column_stack([A + rng.normal(0, 0.5, n), B + rng.normal(0, 0.5, n)])
    print(f"partial canonical corr  = {partial_canonical_corr(setX, setY, load):.3f}")


if __name__ == "__main__":
    _demo()
