---
name: diagnostic-dependence
description: >-
  Choose and apply the right statistical dependence or association measure for
  system health management diagnostics: detection, isolation, and root-cause.
  Use when the task is to decide whether two signals are coupled, whether a
  coupling is direct or driven by a shared confounder, or which signal leads,
  and to generate correct Python for correlation, partial correlation,
  rank/nonlinear dependence, agreement and redundancy metrics, categorical
  association, directional and causal measures, or set-level coupling.
---

# Diagnostic dependence measures

A progressive-disclosure skill for picking the correct dependence statistic in
diagnostics and producing verified Python. Read this file first, then open only
the reference doc you need.

Overview
This skill organizes twenty nine dependence and association measures by the
diagnostic question they answer. There are three framing questions. Are two
signals coupled, and in what shape. Is the coupling direct or borrowed from a
shared driver. Which way does the influence flow. A tested engine implements
every measure with numpy, scipy, scikit-learn, and statsmodels only.

When to use this skill
Use it whenever a diagnostics task involves relating signals: screening
sensor pairs, isolating a root cause from a confounded set, tracing
fault propagation, validating redundant sensors, associating fault codes with
operating modes, or scoring how a feature panel tracks a target.

How to route a request
First identify the framing question, then open the matching reference.
1. Coupled at all, any shape: references/01-core-dependence.md and references/04-nonlinear-detectors.md
2. Direct versus confounded: references/06-conditional-nonlinear.md plus partial_corr in references/01-core-dependence.md
3. Direction and propagation: references/05-directional-causal.md
4. Redundant sensor agreement: references/02-agreement-redundancy.md
5. Labels, flags, fault codes: references/03-categorical-mixed.md
6. Group-to-group coupling: references/07-set-level.md
Always consult references/decision-map.md to confirm the choice and
references/pitfalls.md before trusting a number.

Reference docs
- `references/01-core-dependence.md` covers core dependence.
- `references/02-agreement-redundancy.md` covers agreement & redundancy.
- `references/03-categorical-mixed.md` covers categorical & mixed-type coupling.
- `references/04-nonlinear-detectors.md` covers stronger nonlinear detectors.
- `references/05-directional-causal.md` covers directional / causal extensions.
- `references/06-conditional-nonlinear.md` covers conditional nonlinear analogues.
- `references/07-set-level.md` covers set-level linear.
- `references/decision-map.md` maps every question to its measures and the escalation order.
- `references/rules-of-thumb.md` gives general heuristics and a scenario-to-measure table.
- `references/case-study.md` walks one fault end to end through the full ladder, a worked example of the method.
- `references/multiple-testing.md` covers permutation nulls, Benjamini-Hochberg FDR, and effect-size floors for fleet-scale screening.
- `references/references.md` is the bibliography.
- `references/pitfalls.md` lists the assumptions and failure modes.

When screening many pairs at once, read references/multiple-testing.md and use
screen_pairs; raw per-pair p-values are not trustworthy at scale. For a model of
how to chain the measures on a single problem, read references/case-study.md.

Engine
scripts/measures.py is the single source of truth for computation. Import the
function named in each reference doc. Run it directly for a self-test:

    python scripts/measures.py

Core functionalities
Compute any of the twenty nine measures on equal-length numpy arrays. Map a
diagnostic question to candidate measures with recommend(question_key). Get a
permutation p-value for the kernel independence tests. Recover lead-lag delay
and directional information flow for time series. Screen every pair of a wide
feature matrix with screen_pairs, combining an effect size, a permutation
p-value, Benjamini-Hochberg FDR control, and an effect-size floor.

Inputs
One-dimensional arrays for pairwise measures, label arrays for categorical
helpers, two-dimensional arrays for agreement and set-level helpers, and a
sample rate for the frequency measure.

Outputs
Scalars in documented ranges or small tuples, suitable to log, threshold, or
feed into an isolation graph.

Conventions for generated answers
Prefer the engine functions over ad hoc code. State the assumption being made
(linearity, stationarity, control set) alongside any reported value. When the
relationship may be nonlinear, escalate past Pearson. When asked whether a link
is real, default to a partial or conditional measure, and remind that it only
controls for the variables included.

Assets
assets/dependence-measures.html is the full illustrated monograph for these
measures, with a figure and worked example for each.
