---
mode: agent
description: 'Recommend and compute the right dependence measure for a diagnostics question, using the verified engine.'
tools: ['codebase', 'search', 'runCommands']
---

# /dependence

Pick and apply the correct dependence or association measure for a system
health management question, then return runnable code from the project engine.

Inputs the user may give: the two (or more) signals or variables involved, their
type (continuous, ordinal, categorical, binary flag, time series), and the
question (coupled? direct? which leads?). If any of these is missing, ask once,
then proceed with a stated assumption.

Steps:
1. Restate the framing question in one line.
2. Open `references/decision-map.md` and name the recommended measure(s),
   strongest first.
3. Open the relevant group reference for the interpretation and caveats.
4. Produce the exact call into `scripts/measures.py`, wired to the user's
   variable names.
5. State the result range and the single assumption that would flip the
   conclusion. Cross-check against `references/pitfalls.md`.

The task to solve: ${input:question:Describe the signals and what you want to know about their relationship}
