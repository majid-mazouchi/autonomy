---
applyTo: '**/*.py'
---

# Dependence analysis conventions

When writing code that relates signals for diagnostics, follow these rules.

Use the project engine. Call the functions in `scripts/measures.py`
(`pearson`, `partial_corr`, `distance_correlation`, `hsic`,
`granger_min_pvalue`, `partial_distance_correlation`, and the rest) instead of
re-implementing a dependence measure.

Match the measure to the data type. Continuous pairs start with `pearson`, then
escalate to rank or nonlinear measures if the relationship can bend. Use the
categorical helpers for labels and flags. Use `icc` or `ccc` for redundant
sensors, never plain correlation.

Challenge apparent links. Before reporting that two signals are related, remove
plausible shared drivers with `partial_corr` (or the conditional-nonlinear
measures), and comment that the result controls only for the included variables.

Label assumptions in the code. Note linearity, stationarity, and the control set
in a comment next to the call, so a reviewer can see what would change the
conclusion.

For directional claims, prefer `cross_correlation_lag` for delay and
`granger_min_pvalue` or `transfer_entropy` for propagation, and only after
checking the series are roughly stationary.
