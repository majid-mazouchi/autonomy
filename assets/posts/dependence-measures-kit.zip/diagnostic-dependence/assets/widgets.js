/* Interactive explorers for the dependence monograph. Vanilla JS, no deps. */
(function () {
  "use strict";
  var INK = "#221d17", MUTE = "#7a6f5e", RUST = "#b0492f",
      TEAL = "#1f6f6a", OCHRE = "#c4922b", LINE = "#d9cfb8", CREAM = "#fbf7ee";

  // ---- math ---------------------------------------------------------------
  function mean(a){var s=0,i;for(i=0;i<a.length;i++)s+=a[i];return s/a.length;}
  function pearson(x,y){var mx=mean(x),my=mean(y),c=0,sx=0,sy=0,i,dx,dy;
    for(i=0;i<x.length;i++){dx=x[i]-mx;dy=y[i]-my;c+=dx*dy;sx+=dx*dx;sy+=dy*dy;}
    return (sx>0&&sy>0)?c/Math.sqrt(sx*sy):0;}
  function ranks(a){var idx=a.map(function(v,i){return i;});
    idx.sort(function(i,j){return a[i]-a[j];});
    var r=new Array(a.length),k;for(k=0;k<idx.length;k++)r[idx[k]]=k+1;return r;}
  function spearman(x,y){return pearson(ranks(x),ranks(y));}
  function distanceCorrelation(x,y){
    var n=x.length,i,j;
    var A=[],B=[];
    for(i=0;i<n;i++){A.push(new Float64Array(n));B.push(new Float64Array(n));}
    for(i=0;i<n;i++)for(j=0;j<n;j++){A[i][j]=Math.abs(x[i]-x[j]);B[i][j]=Math.abs(y[i]-y[j]);}
    function center(M){
      var rm=new Float64Array(n),cm=new Float64Array(n),gm=0,s;
      for(i=0;i<n;i++){s=0;for(j=0;j<n;j++)s+=M[i][j];rm[i]=s/n;gm+=s;}gm/=n*n;
      for(j=0;j<n;j++){s=0;for(i=0;i<n;i++)s+=M[i][j];cm[j]=s/n;}
      for(i=0;i<n;i++)for(j=0;j<n;j++)M[i][j]=M[i][j]-rm[i]-cm[j]+gm;
    }
    center(A);center(B);
    var dcov=0,dvx=0,dvy=0;
    for(i=0;i<n;i++)for(j=0;j<n;j++){dcov+=A[i][j]*B[i][j];dvx+=A[i][j]*A[i][j];dvy+=B[i][j]*B[i][j];}
    dcov/=n*n;dvx/=n*n;dvy/=n*n;
    var denom=Math.sqrt(Math.sqrt(dvx)*Math.sqrt(dvy));
    return denom>0?Math.sqrt(Math.max(dcov,0))/denom:0;
  }
  function micApprox(x,y){
    var n=x.length,rx=ranks(x),ry=ranks(y),best=0,res=[2,3,4,5,6],bi,bj,i,j,a,b;
    for(bi=0;bi<res.length;bi++)for(bj=0;bj<res.length;bj++){
      var bx=res[bi],by=res[bj];if(bx*by>16)continue;
      var joint=[];for(i=0;i<bx;i++)joint.push(new Float64Array(by));
      for(i=0;i<n;i++){a=Math.min(bx-1,Math.floor((rx[i]-1)/n*bx));
        b=Math.min(by-1,Math.floor((ry[i]-1)/n*by));joint[a][b]++;}
      var px=new Float64Array(bx),py=new Float64Array(by);
      for(i=0;i<bx;i++)for(j=0;j<by;j++){joint[i][j]/=n;px[i]+=joint[i][j];py[j]+=joint[i][j];}
      var mi=0,p;for(i=0;i<bx;i++)for(j=0;j<by;j++){p=joint[i][j];if(p>0)mi+=p*Math.log(p/(px[i]*py[j]));}
      var norm=Math.log(Math.min(bx,by));if(norm>0)best=Math.max(best,mi/norm);
    }
    return Math.max(0,Math.min(1,best));
  }
  function partialCorr(A,B,C){
    var rab=pearson(A,B),rac=pearson(A,C),rbc=pearson(B,C);
    var d=Math.sqrt((1-rac*rac)*(1-rbc*rbc));
    return d>0?(rab-rac*rbc)/d:0;
  }
  // seeded gaussian (Box-Muller with a tiny LCG so figures are stable)
  function rng(seed){var s=seed>>>0;return function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
  function gaussArr(n,seed){var r=rng(seed),out=new Float64Array(n),i;
    for(i=0;i<n;i++){var u=Math.max(1e-9,r()),v=r();out[i]=Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}return out;}

  // ---- canvas helpers -----------------------------------------------------
  function fit(canvas){var dpr=window.devicePixelRatio||1;var w=canvas.clientWidth||620,h=canvas.clientHeight||280;
    canvas.width=w*dpr;canvas.height=h*dpr;var ctx=canvas.getContext("2d");ctx.setTransform(dpr,0,0,dpr,0,0);
    return {ctx:ctx,w:w,h:h};}
  function scatter(canvas,xs,ys,color){
    var f=fit(canvas),ctx=f.ctx,w=f.w,h=f.h,pad=26,i;
    ctx.clearRect(0,0,w,h);
    var xmin=Math.min.apply(null,xs),xmax=Math.max.apply(null,xs),
        ymin=Math.min.apply(null,ys),ymax=Math.max.apply(null,ys);
    var px=function(v){return pad+(v-xmin)/(xmax-xmin||1)*(w-2*pad);};
    var py=function(v){return h-pad-(v-ymin)/(ymax-ymin||1)*(h-2*pad);};
    ctx.strokeStyle=LINE;ctx.lineWidth=1;ctx.beginPath();
    ctx.moveTo(pad,h-pad);ctx.lineTo(w-pad,h-pad);ctx.moveTo(pad,pad);ctx.lineTo(pad,h-pad);ctx.stroke();
    ctx.fillStyle=color;
    for(i=0;i<xs.length;i++){ctx.beginPath();ctx.arc(px(xs[i]),py(ys[i]),2.6,0,2*Math.PI);ctx.fill();}
  }
  function bars(el,items){ // items: [{label, val, color}]  val in 0..1
    var html="";items.forEach(function(it){
      var pct=Math.round(Math.max(0,Math.min(1,it.val))*100);
      html+='<div class="gauge"><span class="g-lab">'+it.label+'</span>'+
            '<span class="g-track"><span class="g-fill" style="width:'+pct+'%;background:'+it.color+'"></span></span>'+
            '<span class="g-val">'+it.val.toFixed(2)+'</span></div>';
    });el.innerHTML=html;
  }

  // ========================================================================
  // 1. SHAPE EXPLORER: linear -> U -> ring, with 4 measures live
  // ========================================================================
  (function shape(){
    var cv=document.getElementById("ex-shape-canvas");if(!cv)return;
    var sl=document.getElementById("ex-shape-slider");
    var read=document.getElementById("ex-shape-read");
    var cap=document.getElementById("ex-shape-cap");
    var N=130, u=new Float64Array(N), th=new Float64Array(N);
    var nx=gaussArr(N,11), ny=gaussArr(N,29), i;
    for(i=0;i<N;i++){u[i]=-1.8+3.6*i/(N-1);th[i]=2*Math.PI*i/N;}
    function coords(t){ // t in 0..2
      var xs=new Float64Array(N),ys=new Float64Array(N),frac,k;
      // shape endpoints
      function lin(k){return [u[k], 0.85*u[k]+0.30*nx[k]];}
      function ush(k){return [u[k], (u[k]*u[k]-1.8)/1.4+0.22*ny[k]];}
      function rng_(k){return [Math.cos(th[k])+0.05*nx[k], Math.sin(th[k])+0.05*ny[k]];}
      for(k=0;k<N;k++){
        var p,q;
        if(t<=1){frac=t;p=lin(k);q=ush(k);}
        else {frac=t-1;p=ush(k);q=rng_(k);}
        xs[k]=p[0]+(q[0]-p[0])*frac;ys[k]=p[1]+(q[1]-p[1])*frac;
      }
      return [xs,ys];
    }
    function update(){
      var t=parseFloat(sl.value)/100;
      var c=coords(t),xs=c[0],ys=c[1];
      scatter(cv,xs,ys,TEAL);
      bars(read,[
        {label:"Pearson r",color:OCHRE,val:Math.abs(pearson(xs,ys))},
        {label:"Spearman \u03c1",color:OCHRE,val:Math.abs(spearman(xs,ys))},
        {label:"distance corr",color:TEAL,val:distanceCorrelation(xs,ys)},
        {label:"MIC (approx)",color:RUST,val:micApprox(xs,ys)}
      ]);
      var msg;
      if(t<0.5) msg="Linear: Pearson and Spearman both fire. Everyone agrees.";
      else if(t<1.3) msg="U-shape: Pearson collapses toward 0, but distance correlation and MIC still see the dependence.";
      else msg="Ring: a real relationship with Pearson \u2248 0. Only the nonlinear measures survive.";
      cap.textContent=msg;
    }
    sl.addEventListener("input",update);window.addEventListener("resize",update);update();
  })();

  // ========================================================================
  // 2. CONFOUNDER EXPLORER: A-B-C triangle, raw vs partial correlation
  // ========================================================================
  (function confounder(){
    var svg=document.getElementById("ex-conf-svg");if(!svg)return;
    var sCA=document.getElementById("ex-conf-ca"),
        sCB=document.getElementById("ex-conf-cb"),
        sD =document.getElementById("ex-conf-d");
    var rawEl=document.getElementById("ex-conf-raw"),
        parEl=document.getElementById("ex-conf-partial"),
        cap=document.getElementById("ex-conf-cap");
    var eCA=document.getElementById("edge-ca"),
        eCB=document.getElementById("edge-cb"),
        eAB=document.getElementById("edge-ab");
    var N=260, C=gaussArr(N,3), L=gaussArr(N,7), nA=gaussArr(N,13), nB=gaussArr(N,17);
    function update(){
      var aCA=parseFloat(sCA.value)/100*1.6,
          aCB=parseFloat(sCB.value)/100*1.6,
          aD =parseFloat(sD.value)/100*1.6;
      var A=new Float64Array(N),B=new Float64Array(N),i;
      for(i=0;i<N;i++){A[i]=aCA*C[i]+aD*L[i]+0.5*nA[i];B[i]=aCB*C[i]+aD*L[i]+0.5*nB[i];}
      var raw=pearson(A,B), par=partialCorr(A,B,C);
      rawEl.textContent=raw.toFixed(2);
      parEl.textContent=par.toFixed(2);
      eCA.setAttribute("stroke-width",(1+aCA*5).toFixed(1));
      eCB.setAttribute("stroke-width",(1+aCB*5).toFixed(1));
      eAB.setAttribute("stroke-width",(1+Math.abs(par)*8).toFixed(1));
      eAB.setAttribute("stroke",Math.abs(par)>0.18?RUST:LINE);
      eAB.setAttribute("stroke-dasharray",Math.abs(par)>0.18?"none":"5 5");
      var msg;
      if(aD<0.25 && (aCA>0.5||aCB>0.5))
        msg="High raw correlation, near-zero partial: the link is an illusion created by the shared driver C.";
      else if(aD>0.6)
        msg="The partial correlation holds up: there is a direct A\u2013B link that survives removing C.";
      else
        msg="Dial up C\u2192A and C\u2192B with no direct link, then watch raw rise while partial stays flat.";
      cap.textContent=msg;
    }
    [sCA,sCB,sD].forEach(function(s){s.addEventListener("input",update);});
    update();
  })();

  // ========================================================================
  // 3. LAG EXPLORER: shift B vs A, recover the delay
  // ========================================================================
  (function lagWidget(){
    var cv=document.getElementById("ex-lag-canvas");if(!cv)return;
    var cc=document.getElementById("ex-lag-corr");
    var sl=document.getElementById("ex-lag-slider");
    var read=document.getElementById("ex-lag-read");
    var N=220, base=new Float64Array(N), noise=gaussArr(N,5), i;
    for(i=0;i<N;i++){base[i]=Math.sin(2*Math.PI*i/26)+0.6*Math.sin(2*Math.PI*i/11);}
    function shifted(k){var B=new Float64Array(N),j;
      for(j=0;j<N;j++){var s=j-k;B[j]=(s>=0&&s<N?base[s]:0)+0.35*noise[j];}return B;}
    function drawSignals(A,B){
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=10;ctx.clearRect(0,0,w,h);
      function line(arr,color,off){ctx.strokeStyle=color;ctx.lineWidth=1.6;ctx.beginPath();
        var j;for(j=0;j<N;j++){var x=pad+j/(N-1)*(w-2*pad);var y=off-arr[j]*(h*0.18);
          if(j===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.stroke();}
      line(A,TEAL,h*0.30);line(B,RUST,h*0.74);
      ctx.fillStyle=MUTE;ctx.font="11px monospace";ctx.fillText("A (reference)",pad,h*0.30-h*0.20);
      ctx.fillText("B (delayed)",pad,h*0.74-h*0.20);
    }
    function drawCorr(A,B){
      var f=fit(cc),ctx=f.ctx,w=f.w,h=f.h,pad=22;ctx.clearRect(0,0,w,h);
      var L=30, xc=[], lags=[], mx=-1e9, best=0, ai=mean(A), bi=mean(B), k;
      for(k=-L;k<=L;k++){var s=0,sa=0,sb=0,j;
        for(j=0;j<N;j++){var jj=j+k;if(jj<0||jj>=N)continue;var da=A[j]-ai,db=B[jj]-bi;s+=da*db;sa+=da*da;sb+=db*db;}
        var c=(sa>0&&sb>0)?s/Math.sqrt(sa*sb):0;xc.push(c);lags.push(k);if(c>mx){mx=c;best=k;}}
      ctx.strokeStyle=LINE;ctx.beginPath();ctx.moveTo(pad,h-pad);ctx.lineTo(w-pad,h-pad);ctx.stroke();
      ctx.strokeStyle=INK;ctx.lineWidth=1.6;ctx.beginPath();
      for(k=0;k<xc.length;k++){var x=pad+k/(xc.length-1)*(w-2*pad);var y=h-pad-(xc[k]*0.5+0.5)*(h-2*pad);
        if(k===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.stroke();
      var bx=pad+(best+L)/(2*L)*(w-2*pad);
      ctx.strokeStyle=OCHRE;ctx.lineWidth=1.6;ctx.setLineDash([4,3]);
      ctx.beginPath();ctx.moveTo(bx,pad);ctx.lineTo(bx,h-pad);ctx.stroke();ctx.setLineDash([]);
      ctx.fillStyle=OCHRE;ctx.font="11px monospace";ctx.fillText("peak @ lag "+best,bx+6,pad+12);
      return best;
    }
    function update(){var k=parseInt(sl.value,10);var A=new Float64Array(base),B=shifted(k);
      drawSignals(A,B);var det=drawCorr(A,B);
      read.innerHTML="true delay <b>"+k+"</b> samples &nbsp;\u2192&nbsp; recovered <b>"+det+"</b>";}
    sl.addEventListener("input",update);window.addEventListener("resize",update);update();
  })();

  // ========================================================================
  // 4. COHERENCE EXPLORER: two-band mixer + Welch coherence (hand FFT)
  // ========================================================================
  (function coherenceWidget(){
    var cv=document.getElementById("ex-coh-canvas");if(!cv)return;
    var sShared=document.getElementById("ex-coh-shared"),
        sB=document.getElementById("ex-coh-bonly"),
        sNoise=document.getElementById("ex-coh-noise");
    var cap=document.getElementById("ex-coh-cap");
    var fs=256, N=1024, nseg=128;
    var t=new Float64Array(N), s30=new Float64Array(N), s80=new Float64Array(N), i;
    var na=gaussArr(N,41), nb=gaussArr(N,53);
    for(i=0;i<N;i++){t[i]=i/fs;s30[i]=Math.sin(2*Math.PI*30*t[i]);s80[i]=Math.sin(2*Math.PI*80*t[i]);}
    function fft(re,im){var n=re.length,i,j,bit,len;
      for(i=1,j=0;i<n;i++){for(bit=n>>1;j&bit;bit>>=1)j^=bit;j^=bit;
        if(i<j){var tr=re[i];re[i]=re[j];re[j]=tr;var ti=im[i];im[i]=im[j];im[j]=ti;}}
      for(len=2;len<=n;len<<=1){var ang=-2*Math.PI/len,wr=Math.cos(ang),wi=Math.sin(ang);
        for(i=0;i<n;i+=len){var cr=1,ci=0,k;
          for(k=0;k<len/2;k++){var ur=re[i+k],ui=im[i+k];
            var vr=re[i+k+len/2]*cr-im[i+k+len/2]*ci,vi=re[i+k+len/2]*ci+im[i+k+len/2]*cr;
            re[i+k]=ur+vr;im[i+k]=ui+vi;re[i+k+len/2]=ur-vr;im[i+k+len/2]=ui-vi;
            var ncr=cr*wr-ci*wi;ci=cr*wi+ci*wr;cr=ncr;}}}
    }
    function coherence(a,b){var half=nseg/2,step=nseg/2,
      Pxx=new Float64Array(half),Pyy=new Float64Array(half),Pr=new Float64Array(half),Pi=new Float64Array(half);
      var win=new Float64Array(nseg),i;for(i=0;i<nseg;i++)win[i]=0.5-0.5*Math.cos(2*Math.PI*i/(nseg-1));
      var s,segs=0;
      for(s=0;s+nseg<=a.length;s+=step){segs++;
        var ar=new Float64Array(nseg),ai=new Float64Array(nseg),br=new Float64Array(nseg),bi=new Float64Array(nseg);
        for(i=0;i<nseg;i++){ar[i]=a[s+i]*win[i];br[i]=b[s+i]*win[i];}
        fft(ar,ai);fft(br,bi);
        for(i=0;i<half;i++){Pxx[i]+=ar[i]*ar[i]+ai[i]*ai[i];Pyy[i]+=br[i]*br[i]+bi[i]*bi[i];
          Pr[i]+=ar[i]*br[i]+ai[i]*bi[i];Pi[i]+=ai[i]*br[i]-ar[i]*bi[i];}}
      var C=new Float64Array(half),fr=new Float64Array(half);
      for(i=0;i<half;i++){var num=Pr[i]*Pr[i]+Pi[i]*Pi[i],den=Pxx[i]*Pyy[i];
        C[i]=den>0?num/den:0;fr[i]=i*fs/nseg;}
      return {fr:fr,C:C};
    }
    function update(){
      var sh=parseFloat(sShared.value)/100*1.5,
          bo=parseFloat(sB.value)/100*1.5,
          no=parseFloat(sNoise.value)/100*2+0.2;
      var a=new Float64Array(N),b=new Float64Array(N),i;
      for(i=0;i<N;i++){a[i]=sh*s30[i]+no*na[i];b[i]=0.9*sh*s30[i]+bo*s80[i]+no*nb[i];}
      var r=coherence(a,b);
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=30;ctx.clearRect(0,0,w,h);
      // 30 Hz band highlight
      var fmax=r.fr[r.fr.length-1];
      function fx(freq){return pad+freq/fmax*(w-2*pad);}
      ctx.fillStyle="rgba(196,146,43,0.16)";ctx.fillRect(fx(25),pad,fx(35)-fx(25),h-2*pad);
      ctx.strokeStyle=LINE;ctx.beginPath();ctx.moveTo(pad,h-pad);ctx.lineTo(w-pad,h-pad);
      ctx.moveTo(pad,pad);ctx.lineTo(pad,h-pad);ctx.stroke();
      ctx.strokeStyle=TEAL;ctx.lineWidth=1.8;ctx.beginPath();
      for(i=0;i<r.C.length;i++){var x=fx(r.fr[i]);var y=h-pad-r.C[i]*(h-2*pad);
        if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.stroke();
      ctx.fillStyle=MUTE;ctx.font="11px monospace";
      ctx.fillText("0",pad-3,h-pad+14);ctx.fillText("128 Hz",w-pad-30,h-pad+14);
      ctx.fillText("coherence 1.0",pad+4,pad+10);
      ctx.fillStyle=OCHRE;ctx.fillText("shared 30 Hz band",fx(36),pad+12);
      // coherence value at 30 Hz
      var i30=Math.round(30*nseg/fs);
      cap.textContent="Coherence at 30 Hz is "+r.C[i30].toFixed(2)+
        ". The 80 Hz tone lives only in B, so it never raises coherence, no matter how loud.";
    }
    [sShared,sB,sNoise].forEach(function(s){s.addEventListener("input",update);});
    window.addEventListener("resize",update);update();
  })();
})();
