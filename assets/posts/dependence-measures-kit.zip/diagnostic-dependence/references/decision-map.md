# Decision map

Start from the question you have, not the method you know.

| If you are asking | Reach for |
| --- | --- |
| Are two numeric signals coupled at all, linearly? | Pearson r |
| Coupled but the curve bends (still always rising)? | Spearman rho / Kendall tau |
| Coupled in any shape, even U-shapes and rings? | Distance correlation, MIC, HSIC, Chatterjee xi |
| Is the link DIRECT, or borrowed from a shared driver? | Partial correlation; conditional MI / partial dCor / cond. HSIC if nonlinear |
| How much UNIQUE value does one predictor add? | Semi-partial correlation |
| Which signal moves first / where does it propagate? | Cross-correlation, Granger, transfer entropy, CCM |
| Coupled at a specific frequency, and who leads there? | Coherence; PDC / DTF for direction; wavelet coherence if non-stationary |
| Do redundant sensors AGREE in value (not just shape)? | ICC, Lin's CCC, Kendall's W |
| At least one variable is a label or flag? | Cramer's V, point-biserial, Theil's U, tetrachoric |
| Coupling between whole GROUPS of variables? | Multiple R / R-squared, partial canonical correlation |
| Risk that two systems fail TOGETHER at the extremes? | Copula tail dependence |
| Fast nonlinear screen across a wide feature matrix? | RDC, then confirm hits with HSIC / dCor |

## Escalation order

1. Start linear: `pearson` for a quick read on numeric pairs.
2. Distrust straight lines: `spearman`/`kendall_tau`, then `distance_correlation`, `mutual_information`, `hsic`, `xicor`.
3. Challenge every link: re-run with `partial_corr` (or `partial_distance_correlation` / `conditional_hsic` when nonlinear) to kill shared-driver illusions.
4. Find the direction: `cross_correlation_lag` for delay, `granger_min_pvalue` and `transfer_entropy` for propagation.
5. Special cases: `icc`/`ccc`/`kendall_w` for sensor agreement, the categorical block for codes and flags, `lower_tail_dependence` for joint-extreme risk.
