# Set-level linear

_Coupling between whole groups of variables, not just single pairs._

## Multiple correlation R / R-squared

**Essence.** Coupling of one target to a linear combination of predictors.

**In plain words.** Multiple R is the correlation between a target and the best linear blend of several predictors at once; R-squared is its square, read as the fraction of the target's variance the predictors jointly explain. It tells you how well a whole panel of sensors, together, tracks one quantity.

**Diagnostic example.** You want to know how much remaining useful life is explained by temperature, current, vibration and voltage combined. An R-squared of 0.82 says these four together capture most of the variation, a green light to build a model on that panel.

**Engine call.** `multiple_r2(X, y)`

```python
import numpy as np
from sklearn.linear_model import LinearRegression

X = np.column_stack([temp, current, vibration, voltage])
r2 = LinearRegression().fit(X, rul).score(X, rul)
print(f"R = {np.sqrt(r2):.3f}   R^2 = {r2:.3f}")
```

**Practical note.** R-squared always rises as predictors are added, so judge a panel by adjusted R-squared or cross-validation. High R-squared with multicollinear inputs hides which sensor matters, pair it with semi-partial correlations. It measures fit, not generalization.

**Reference.** Cohen, Cohen, West & Aiken (2003); Hotelling (1936), Biometrika 28.

## Partial canonical correlation

**Essence.** Association between two variable sets after removing a controlling set.

**In plain words.** Canonical correlation finds the strongest link between two GROUPS of variables by combining each group into a single best-aligned summary. The partial version first removes a control set from both groups, so you see set-to-set coupling that is not just a shared response to the controls.

**Diagnostic example.** Relate the actuator-command set to the response-sensor set, after removing operating-condition variables from both. A strong partial canonical correlation says the commands and responses are coupled beyond what conditions alone explain, evidence the control path itself is the link.

**Engine call.** `partial_canonical_corr(set_x, set_y, control)`

```python
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.cross_decomposition import CCA
def resid(M, C): return M - LinearRegression().fit(C, M).predict(C)

u, v = CCA(1).fit_transform(resid(set_X, control), resid(set_Y, control))
print("partial canonical corr =", abs(np.corrcoef(u.ravel(), v.ravel())[0, 1]))
```

**Practical note.** Regularize when either set is wide relative to the sample, or the canonical correlations overfit, and validate on held-out data. The control set is removed from both sides before the canonical fit.

**Reference.** Hotelling (1936), Biometrika 28; Rao (1973), Linear Statistical Inference (partial CCA).
