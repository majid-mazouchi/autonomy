# Conditional nonlinear analogues

_Partial correlation and conditional MI, but without the linearity assumption._

## Partial / conditional distance correlation

**Essence.** Controls for a third variable set nonlinearly; the distance-correlation counterpart to partial correlation.

**In plain words.** Partial correlation removes a confounder assuming straight-line relationships. Partial distance correlation does the same job but for ANY shape: it measures the dependence of X and Y that remains after nonlinearly accounting for Z. It is the tool when both the confounding and the link are curved.

**Diagnostic example.** Two signals are coupled through a nonlinear dependence on load. Linear partial correlation might leave a misleading residual link; partial distance correlation, removing load nonlinearly, correctly shrinks the X-Y association to near zero.

**Engine call.** `partial_distance_correlation(x, y, z)`

```python
import dcor
# nonlinear association of x and y after removing z
pdc = dcor.partial_distance_correlation(x, y, z)
print("partial distance correlation =", pdc)
```

**Practical note.** Inherits distance correlation's order n-squared cost and large-sample appetite. The control can itself be multivariate. Like all conditioning, it removes only the confounders you supply.

**Reference.** Szekely & Rizzo (2014). Partial distance correlation with methods for dissimilarities. Ann. Statist. 42.

## Conditional HSIC

**Essence.** Kernel conditional-independence test; the isolation primitive when you need 'A independent of B given C' without linearity assumptions.

**In plain words.** Conditional HSIC tests whether A and B are independent ONCE you account for C, using kernels so it works for any nonlinear relationship. A common recipe: nonlinearly regress A and B on C, then run HSIC on the residuals. If they come out independent, C fully explained the apparent A-B link.

**Diagnostic example.** Two signals look coupled, but you suspect both merely follow operating mode C nonlinearly. Conditional HSIC on the mode-residuals returns near zero, the formal statement that A is independent of B given C, clearing them of a direct fault link.

**Engine call.** `conditional_hsic(x, y, z)`

```python
import numpy as np
from sklearn.kernel_ridge import KernelRidge
def resid(t, z):
    z = z.reshape(-1, 1)
    return t - KernelRidge(kernel="rbf").fit(z, t).predict(z)
# hsic() defined earlier; run it on the C-residuals of A and B
print("conditional HSIC ~", hsic(resid(A, C), resid(B, C)))   # ~0 => A _|_ B | C
```

**Practical note.** The residualization assumes your kernel regression truly captures the dependence on the conditioning set, so choose the regressor well. The KCI test is the more rigorous option when you need calibrated p-values. Order n-squared.

**Reference.** Fukumizu, Gretton, Sun & Scholkopf (2008), NeurIPS; Zhang et al. (2011), UAI (KCI test).
