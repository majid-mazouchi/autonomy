# Directional / causal extensions

_The propagation story: not just whether two things move together, but which one moves first._

## Granger causality

**Essence.** Does A's past improve prediction of B; the linear workhorse for fault-propagation chains.

**In plain words.** A 'Granger-causes' B if adding A's recent history to a model of B's own history makes B more predictable. It is about predictive precedence, not philosophical cause, but for tracing how a disturbance moves through a system it is the practical first tool. It assumes mostly linear dynamics.

**Diagnostic example.** Suspect a sticking valve upstream is causing pressure swings downstream. If the valve signal's past significantly improves prediction of the downstream pressure (and not the reverse), Granger causality supports the upstream-to-downstream propagation hypothesis.

**Engine call.** `granger_min_pvalue(cause, effect)`

```python
import numpy as np
from statsmodels.tsa.stattools import grangercausalitytests

data = np.column_stack([B, A])            # does A (col 2) cause B (col 1)?
res = grangercausalitytests(data, maxlag=5, verbose=False)
pmin = min(res[l][0]["ssr_ftest"][1] for l in res)
print("min p-value (A -> B):", pmin)
```

**Practical note.** Requires weakly stationary series, so difference or detrend first, and choose the lag order by AIC or BIC. It is predictive precedence, not mechanism: an unobserved common driver can fake it. Sensitive to sampling rate relative to the true delay.

**Reference.** Granger, C. W. J. (1969). Investigating causal relations by econometric models and cross-spectral methods. Econometrica 37.

## Transfer entropy

**Essence.** Model-free, nonlinear directed information flow; the nonlinear generalization of Granger, strong for tracing root cause through coupled subsystems.

**In plain words.** Transfer entropy measures how many bits of B's future are explained by A's past, beyond what B's own past already explains, with no assumption about linearity. Compute it both ways and the larger direction is the dominant information flow. It is Granger causality freed from the straight-line assumption.

**Diagnostic example.** In a tightly coupled thermal-electrical subsystem the dynamics are nonlinear. Transfer entropy from the current signal to the temperature signal, exceeding the reverse, points to current disturbances driving the thermal response, narrowing the root-cause search.

**Engine call.** `transfer_entropy(source, dest)`

```python
from pyinform.transferentropy import transfer_entropy   # pip install pyinform
# symbolize continuous signals first (e.g. bin into a few levels)
te_ab = transfer_entropy(sym_A, sym_B, k=1)
te_ba = transfer_entropy(sym_B, sym_A, k=1)
print(f"A->B {te_ab:.3f}   B->A {te_ba:.3f}   net {te_ab - te_ba:+.3f}")
```

**Practical note.** Model-free but data-hungry, especially as the history length k grows. The binning or kNN choice changes the value, so compare directions on identical settings, and bias-correct with surrogates before trusting small differences.

**Reference.** Schreiber, T. (2000). Measuring information transfer. Phys. Rev. Lett. 85.

## Partial directed coherence (PDC) / DTF

**Essence.** Frequency-domain Granger causality; which subsystem drives which at which frequency. A natural fit for vibration/NVH source tracing where coherence alone cannot resolve direction.

**In plain words.** Plain coherence tells you two channels share a frequency but not who leads. PDC and the directed transfer function fit a multivariate AR model to several channels at once, then read off directed influence frequency by frequency. You get a per-frequency arrow: channel i drives channel j at this Hz.

**Diagnostic example.** Three accelerometers share energy at 120 Hz, but you need the source. PDC shows the 120 Hz influence flowing from the bearing channel to the housing channels and not back, isolating the bearing as the originating NVH source.

**Engine call.** `(optional dependency: connectivipy)`

```python
import numpy as np
import connectivipy as cp                 # pip install connectivipy

data = np.vstack([ch_A, ch_B, ch_C])      # channels x samples
conn = cp.Connect()                        # API varies by version
pdc = cp.conn.PDC().calculate(data=data, fs=fs, order=8)
print(pdc.shape)   # [freq, to, from]  -> directed coupling per frequency
```

**Practical note.** Only as good as the multivariate AR fit beneath it, so check residual whiteness and model order. Include every relevant channel or omitted-variable bias distorts the directions. Be consistent about the normalization (PDC versus generalized PDC).

**Reference.** Baccala & Sameshima (2001), Biol. Cybern. 84; Kaminski & Blinowska (1991), Biol. Cybern. 65 (DTF).

## Convergent cross mapping (CCM)

**Essence.** Causality detection for deterministic coupled dynamical systems where Granger assumptions break.

**In plain words.** In deterministic nonlinear systems (think coupled oscillators), cause and effect share a common attractor, and you can detect causation by checking whether the history of one variable can reconstruct the states of the other. The reconstruction quality must IMPROVE as you use more data ('converge'), which is the signature CCM looks for.

**Diagnostic example.** Two mechanical modes are coupled through nonlinear dynamics where Granger gives ambiguous results. CCM, by testing whether each mode's reconstructed attractor predicts the other, recovers the true coupling direction the linear test could not.

**Engine call.** `(optional dependency: causal-ccm)`

```python
from causal_ccm.causal_ccm import ccm      # pip install causal-ccm

c = ccm(A, B, tau=1, E=3, L=len(A))         # embedding dim E, lag tau
corr, p = c.causality()
print(f"A xmap B skill = {corr:.3f}  (rises with L if A drives B)")
```

**Practical note.** For deterministic, low-noise coupled dynamics; heavy measurement noise breaks it. Tune the embedding dimension E and lag tau with false-nearest-neighbor and mutual-information heuristics. The signature is convergence: skill must rise with library length.

**Reference.** Sugihara et al. (2012). Detecting causality in complex ecosystems. Science 338.

## Wavelet coherence

**Essence.** Time-localized frequency-domain coupling for non-stationary regimes (run-ups, transients).

**In plain words.** Ordinary coherence assumes the coupling holds steady over the whole record. Wavelet coherence instead gives a time-frequency map: it shows WHEN and at WHICH frequency two signals are coupled, so a band that appears only during a transient stands out clearly.

**Diagnostic example.** During an engine run-up the coupling frequency rises with speed. Wavelet coherence draws a diagonal ridge in the time-frequency plane, capturing the moving resonance that a single fixed-frequency coherence value would average away.

**Engine call.** `(optional dependency: pycwt)`

```python
import numpy as np
import pycwt                                # pip install pycwt

dt = 1 / fs
WCT, _, coi, freqs, _ = pycwt.wct(A, B, dt, sig=False)
print(WCT.shape)    # [scale, time]  coherence in 0..1, localized in time
```

**Practical note.** For non-stationary coupling such as run-ups. Mind the cone of influence, the edges are unreliable, and get significance from surrogate (red-noise) testing. The mother wavelet trades time against frequency resolution.

**Reference.** Torrence & Compo (1998), Bull. Amer. Meteor. Soc. 79; Grinsted, Moore & Jevrejeva (2004), Nonlin. Processes Geophys. 11.
