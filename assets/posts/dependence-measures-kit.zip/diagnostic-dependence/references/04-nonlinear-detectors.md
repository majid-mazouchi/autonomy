# Stronger nonlinear detectors

_When the relationship is real but neither straight nor monotonic, reach past distance correlation._

## HSIC (Hilbert-Schmidt Independence Criterion)

**Essence.** Kernel independence test; a robust general-purpose nonlinear dependence detector and a standard primitive in causal discovery.

**In plain words.** HSIC maps each variable through a kernel (think: into a rich space of smooth features) and measures the covariance between the two feature sets. It is zero only when the variables are genuinely independent, so it catches arbitrary nonlinear dependence. It is the dependence test that modern causal-discovery algorithms lean on.

**Diagnostic example.** A control residual and a load signal should be independent if the controller is healthy. A clearly non-zero HSIC (with a permutation p-value) says some unmodeled load dependence has leaked into the residual, a structural fault a linear check would pass.

**Engine call.** `hsic(x, y) / hsic_pvalue(x, y)`

```python
import numpy as np
def rbf(v):
    v = v.reshape(-1, 1); d2 = (v - v.T) ** 2
    s = np.sqrt(np.median(d2[d2 > 0]) / 2) + 1e-9
    return np.exp(-d2 / (2 * s ** 2))
def hsic(x, y):
    n = len(x); H = np.eye(n) - 1 / n
    K, L = rbf(x), rbf(y)
    return np.trace(K @ H @ L @ H) / (n - 1) ** 2
print("HSIC =", hsic(x, y))
```

**Practical note.** Use the median-distance heuristic for the bandwidth as a default but sanity-check a couple of scales, the value depends on it. Significance comes from a permutation or gamma test, not the raw number. Order n-squared, so subsample very large n; standardize inputs.

**Reference.** Gretton, Bousquet, Smola & Scholkopf (2005), ALT; Gretton et al. (2008), NeurIPS (test).

## Chatterjee's xi

**Essence.** Recent rank correlation that's asymmetric and consistent against any dependence, including noisy functional relationships; cheap, and good at flagging 'Y is a function of X' couplings that symmetric measures blur.

**In plain words.** Chatterjee's xi (2021) is near zero when two variables are independent and near one when one is a (possibly noisy) function of the other. Unlike Pearson or Spearman it is asymmetric and detects ANY functional shape. It is a few lines of code and scales to large data.

**Diagnostic example.** A sensor output is a wiggly but deterministic function of crank angle. Symmetric measures wash out across the wiggles; xi near 0.8 correctly flags that the output is essentially determined by angle, useful for spotting hidden functional dependencies in feature screening.

**Engine call.** `xicor(x, y)`

```python
import numpy as np
def xicor(x, y):                          # estimates xi(X -> Y)
    n = len(x)
    order = np.argsort(x)
    r = np.argsort(np.argsort(y[order])) + 1.0       # ranks of y by x-order
    return 1 - 3 * np.abs(np.diff(r)).sum() / (n ** 2 - 1)
print("xi(X->Y) =", xicor(x, y), "  xi(Y->X) =", xicor(y, x))
```

**Practical note.** Cheap, order n log n, and excellent for screening which variable is a function of which. Lower power than distance correlation or HSIC for weak dependence at small n. Always compute both directions and compare.

**Reference.** Chatterjee, S. (2021). A new coefficient of correlation. J. Amer. Statist. Assoc. 116.

## Maximal correlation (HGR / ACE)

**Essence.** Supremum of correlation over all transformations of each variable; the theoretical ceiling on nonlinear association.

**In plain words.** Ask: what is the best Pearson correlation you could get if you were allowed to reshape each variable through any transformation? That maximum is the Hirschfeld-Gebelein-Renyi (HGR) maximal correlation. The ACE algorithm finds the transformations that achieve it, so you both score the dependence and see the shape that straightens it.

**Diagnostic example.** A flux measurement relates to current through a saturating, nonlinear curve. Maximal correlation finds the warping that linearizes the pair, giving a clean dependence score and, as a bonus, the empirical transform you might bake into a feature.

**Engine call.** `(optional dependency: ace)`

```python
import numpy as np
from ace.ace import ACESolver            # pip install ace

s = ACESolver(); s.specify_data_set([x], y); s.solve()
rho_max = np.corrcoef(s.x_transforms[0], s.y_transform)[0, 1]
print("maximal correlation =", abs(rho_max))
```

**Practical note.** ACE returns the transforms that straighten the relationship, useful as engineered features, not just a score. Can overfit at small n, so regularize or cross-validate. Implementation-fragile, treat as optional.

**Reference.** Renyi (1959), Acta Math. Hungar. 10; Breiman & Friedman (1985), JASA 80 (ACE).

## Copula-based dependence & tail dependence

**Essence.** Separates the dependence structure from the marginals; tail dependence captures joint extreme behavior invisible to body-of-distribution correlation.

**In plain words.** A copula is the dependence pattern you get after converting each variable to its rank (uniform) scale, stripping away the individual distributions. That isolates HOW the two move together. Tail dependence is a special slice: the chance both hit extreme values at the same time, which ordinary correlation, dominated by the bulk, barely registers.

**Diagnostic example.** Two subsystem stress signals are mildly correlated in normal operation but tend to spike together at the limits. Lower-tail dependence quantifies that 'fail together' tendency, the risk that matters for redundancy, even when the everyday correlation looks comfortable.

**Engine call.** `lower_tail_dependence(a, b)`

```python
import numpy as np
def lower_tail_dep(a, b, q=0.05):
    u = (np.argsort(np.argsort(a)) + 1) / (len(a) + 1)   # pseudo-obs
    v = (np.argsort(np.argsort(b)) + 1) / (len(b) + 1)
    return ((u <= q) & (v <= q)).mean() / q              # ~ lambda_L
print("lower-tail dependence =", lower_tail_dep(stress_a, stress_b))
```

**Practical note.** Estimate tail dependence on the rank (pseudo-observation) scale, never mix marginals in. The empirical tail estimate is noisy by definition, so you need many joint extremes or fit a parametric copula (Clayton for lower tail, Gumbel for upper). Bulk correlation can be low while tail dependence is high.

**Reference.** Joe (1997), Multivariate Models and Dependence Concepts; Nelsen (2006), An Introduction to Copulas.

## Randomized dependence coefficient (RDC)

**Essence.** Scalable nonlinear, near-Pearson cost; practical for wide fleet feature matrices.

**In plain words.** RDC gets most of the nonlinear-detection power of the heavy methods for almost the price of a correlation. It rank-transforms each variable, projects through a handful of random sine features, then takes the canonical correlation between the two feature sets. Cheap enough to run across thousands of feature pairs.

**Diagnostic example.** A fleet feature matrix has hundreds of columns and you want a fast nonlinear dependence screen between every signal and the failure label. RDC ranks the candidates in one pass, and the top hits go to the more expensive HSIC or distance-correlation tests.

**Engine call.** `rdc(x, y)`

```python
import numpy as np
from sklearn.cross_decomposition import CCA
def rdc(x, y, k=20, s=1/6):
    def feat(z):
        z = (np.argsort(np.argsort(z)) + 1) / len(z)       # copula transform
        W = np.random.randn(1, k) * s; b = np.random.rand(k) * 2 * np.pi
        return np.sin(z[:, None] * W + b)
    u, v = CCA(1).fit_transform(feat(x), feat(y))
    return abs(np.corrcoef(u.ravel(), v.ravel())[0, 1])
print("RDC =", rdc(x, y))
```

**Practical note.** A fast first-pass screen, not a verdict; confirm top hits with distance correlation or HSIC. Results vary with the random seed and the feature count k, so average over a few seeds.

**Reference.** Lopez-Paz, Hennig & Scholkopf (2013). The randomized dependence coefficient. NeurIPS.
