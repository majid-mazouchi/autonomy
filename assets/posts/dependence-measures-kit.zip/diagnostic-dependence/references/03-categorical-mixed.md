# Categorical & mixed-type coupling

_DTCs, discrete modes and fault flags, where at least one variable is a label, not a number._

## Cramer's V / chi-square

**Essence.** Association between categorical variables; fault-code co-occurrence, fault-mode vs. operating-mode tables.

**In plain words.** The chi-square test asks whether two labels occur together more (or less) often than chance. Cramer's V turns that test into a strength score between zero and one, so you can compare associations across different tables, the categorical answer to 'how strongly related are these?'.

**Diagnostic example.** Cross-tabulate diagnostic trouble codes against operating mode. A high Cramer's V between a specific DTC and 'regen braking' says that fault concentrates in one mode, a strong hint about where in the duty cycle to look.

**Engine call.** `cramers_v(table)`

```python
import numpy as np
from scipy.stats import chi2_contingency

chi2, p, dof, _ = chi2_contingency(table)     # DTC x mode counts
n = table.sum(); r, k = table.shape
V = np.sqrt(chi2 / (n * (min(r, k) - 1)))
print(f"Cramer's V = {V:.3f}  (p = {p:.1e})")
```

**Practical note.** Apply a bias correction (Bergsma) for small or sparse tables; raw V is upward-biased. Keep expected cell counts around five or pool rare categories. V is strength, not direction.

**Reference.** Cramer (1946), Mathematical Methods of Statistics; Bergsma (2013), J. Korean Statist. Soc. 42 (bias correction).

## Phi / point-biserial

**Essence.** Binary-binary and continuous-binary association (a continuous signal vs. fault-present flag).

**In plain words.** Phi is correlation between two yes/no variables (a tidy 2x2 case). Point-biserial is correlation between a continuous measurement and a yes/no label, mathematically just Pearson with one side coded as 0 and 1. It tells you how cleanly a numeric feature separates the two classes.

**Diagnostic example.** Code a window as fault-present (1) or not (0) and correlate against vibration RMS. A point-biserial of 0.7 means RMS runs clearly higher when the fault is present, a candidate detector threshold lives right there.

**Engine call.** `point_biserial(flag, continuous)`

```python
from scipy.stats import pointbiserialr

r_pb, p = pointbiserialr(fault_flag, vibration_rms)   # flag in {0,1}
print(f"point-biserial r = {r_pb:.3f}")
# phi for a 2x2 table:  phi = sqrt(chi2 / n)
```

**Practical note.** Pearson with a 0/1 variable, so it inherits linearity and outlier sensitivity. Strongly affected by class balance: a rare fault inflates variance. Good to screen a detector threshold, then validate with ROC and AUC.

**Reference.** Tate, R. F. (1954). Correlation between a discrete and a continuous variable. Ann. Math. Statist. 25.

## Theil's U (uncertainty coefficient)

**Essence.** Directional categorical dependence; how much knowing the operating mode reduces uncertainty about the fault state.

**In plain words.** Theil's U measures, in information terms, how much knowing one label shrinks your uncertainty about another, and crucially it is directional. U(fault | mode) can differ from U(mode | fault). That asymmetry is exactly what you want when one variable is a cause-like driver and the other a consequence.

**Diagnostic example.** Knowing the operating mode might tell you a lot about the likely fault state, while the fault state tells you little about the mode. A high U(fault | mode) and low U(mode | fault) supports the reading that mode drives the fault distribution, not the reverse.

**Engine call.** `theils_u(x, y)`

```python
import numpy as np
from collections import Counter
def entropy(v):
    p = np.array(list(Counter(v).values()), float); p /= p.sum()
    return -(p * np.log(p)).sum()
def theils_u(x, y):                       # U(x | y): does y predict x?
    Hx = entropy(x)
    Hxy = sum((c / len(y)) * entropy([x[i] for i in range(len(y)) if y[i] == yv])
              for yv, c in Counter(y).items())
    return (Hx - Hxy) / Hx
print("U(fault|mode) =", theils_u(fault, mode))
```

**Practical note.** Report both directions, the asymmetry is the point. Estimated from a contingency table, so it needs enough counts per cell, and it is sensitive to the number of categories, keep them comparable across comparisons.

**Reference.** Theil, H. (1972). Statistical Decomposition Analysis; Press et al., Numerical Recipes.

## Tetrachoric / polychoric

**Essence.** Latent-continuous correlation behind thresholded or ordinal indicators.

**In plain words.** Sometimes a 0/1 flag (or an ordinal level) is really a hidden continuous quantity that crossed a threshold. Tetrachoric (for binary) and polychoric (for ordinal) estimate the correlation of those HIDDEN continuous variables, undoing the information you lost by thresholding. The result is usually larger and more honest than treating the flags as plain numbers.

**Diagnostic example.** Two pass/fail screens are coarse views of underlying continuous stress. The tetrachoric correlation recovers how strongly the two latent stresses move together, better for reliability modeling than the raw phi between the flags.

**Engine call.** `tetrachoric(table_2x2)`

```python
import numpy as np
from scipy.stats import norm, multivariate_normal as mvn
from scipy.optimize import brentq
def tetrachoric(t):                       # t = [[n11,n10],[n01,n00]]
    n = t.sum()
    hx = norm.ppf(t[0].sum() / n); hy = norm.ppf(t[:, 0].sum() / n)
    f = lambda r: mvn([0, 0], [[1, r], [r, 1]]).cdf([hx, hy]) - t[0, 0] / n
    return brentq(f, -0.999, 0.999)
print("tetrachoric r =", tetrachoric(np.array([[40, 12], [10, 38]])))
```

**Practical note.** Assumes the latent variables are bivariate normal, so check that. Unstable with empty or near-empty cells (add a continuity correction). Polychoric extends it to ordinal levels; both recover fairer correlations than treating codes as plain numbers.

**Reference.** Pearson (1900), Phil. Trans. R. Soc. A 195; Olsson (1979), Psychometrika 44 (polychoric).
