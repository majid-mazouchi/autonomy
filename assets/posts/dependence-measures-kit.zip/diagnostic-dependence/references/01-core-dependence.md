# Core dependence

_The everyday question: do two signals move together, and is that link real or borrowed?_

## Pearson correlation

**Essence.** Linear coupling between two signals; the baseline for sensor-pair relationships.

**In plain words.** Pearson r asks one thing: when one signal goes up by a fixed amount, does the other go up (or down) by a roughly fixed amount too? It is the slope of the best straight line, scaled to sit between minus one and plus one. It only sees straight-line relationships, so a strong curved link can still give r near zero.

**Diagnostic example.** Two temperature sensors on the same coolant loop should rise and fall together. An r of 0.95 confirms they track each other; a sudden drop to 0.3 over a week is an early sign that one sensor is drifting or the loop has a new restriction.

**Engine call.** `pearson(x, y)`

```python
import numpy as np
from scipy.stats import pearsonr

r, p = pearsonr(sensor_A, sensor_B)
print(f"Pearson r = {r:.3f}  (p = {p:.1e})")
```

**Practical note.** Scale-free, so no need to standardize, but detrend and screen outliers first: one leverage point can set the whole coefficient. Reliable from about 30 paired samples. If r is near zero, confirm with a rank or nonlinear measure before declaring independence.

**Reference.** Pearson, K. (1896). Mathematical contributions to the theory of evolution III. Phil. Trans. R. Soc. A 187.

## Spearman / Kendall's tau

**Essence.** Rank-based, robust to nonlinearity and outliers; good when the monotonic trend matters more than the exact shape.

**In plain words.** Instead of the raw values, these use the order (1st, 2nd, 3rd ...). Spearman is Pearson computed on ranks; Kendall's tau counts how often two points agree on direction (both up, or both down). Because ranks ignore the exact spacing, a curved-but-always-rising relationship scores near one, and a single wild outlier barely moves the result.

**Diagnostic example.** Wear grows with cumulative load, but the curve bends upward sharply near end of life. Pearson underrates it; Spearman rho near 0.98 correctly says the ordering is almost perfectly preserved, which is what a health trend monitor cares about.

**Engine call.** `spearman(x, y) / kendall_tau(x, y)`

```python
from scipy.stats import spearmanr, kendalltau

rho, _ = spearmanr(load, wear)     # Pearson on the ranks
tau, _ = kendalltau(load, wear)    # concordant vs discordant pairs
print(f"Spearman {rho:.3f}   Kendall {tau:.3f}")
```

**Practical note.** Reach for it when the link is monotonic but curved, or when heavy-tailed noise throws outliers. Kendall's tau is more robust with a cleaner small-sample distribution but costs more. If Pearson and Spearman diverge sharply, suspect nonlinearity or outliers.

**Reference.** Spearman (1904), Am. J. Psychol. 15; Kendall (1938), Biometrika 30.

## Partial correlation

**Essence.** Association between two variables after regressing out a controlling set; the key tool for separating direct coupling from shared-driver effects.

**In plain words.** Two signals can look coupled only because a third thing drives them both. Partial correlation strips the influence of that third set out of BOTH signals first, then measures what correlation is left. If the link survives, it is more likely a direct one; if it collapses, the third variable was the real story.

**Diagnostic example.** Battery current and inverter temperature both rise with vehicle load. Their raw correlation is high, but after removing load and ambient temperature from both, the partial correlation falls near zero, telling you they are not directly coupled, load was the shared driver.

**Engine call.** `partial_corr(x, y, controls)`

```python
import pandas as pd, pingouin as pg

df = pd.DataFrame({"A": sensor_A, "B": sensor_B,
                   "load": load, "temp": ambient})
# remove load and temp from BOTH A and B, then correlate
res = pg.partial_corr(data=df, x="A", y="B", covar=["load", "temp"])
print(res[["r", "p-val"]])
```

**Practical note.** The control set must be measured and low-noise; error in the controls leaves residual confounding. Linear by construction, so switch to partial distance correlation or conditional HSIC when the confounding bends. Avoid over-controlling: conditioning on a mediator or a collider can create a false link.

**Reference.** Baba, Shibata & Sibuya (2004). Partial correlation and conditional correlation as measures of conditional independence. Aust. N. Z. J. Stat. 46.

## Semi-partial (part) correlation

**Essence.** Removes the confounders from only one variable; useful for attributing incremental explanatory power.

**In plain words.** Same idea as partial correlation, but the controlling set is removed from just one of the two variables, not both. That answers a subtly different question: how much UNIQUE information does this one predictor add about the target, beyond what the controls already explain? It is the natural language of incremental contribution.

**Diagnostic example.** You already predict a fault indicator from load and temperature. Semi-partial correlation of a new vibration feature with the indicator (controls removed from the vibration feature only) tells you the extra explanatory power that feature buys you on top of the controls, the basis for deciding whether to keep it.

**Engine call.** `semipartial_corr(x, y, x_controls)`

```python
import pingouin as pg
# x_covar removes controls from X (the predictor) ONLY
res = pg.partial_corr(data=df, x="vibration", y="fault_idx",
                      x_covar=["load", "temp"])
print("unique contribution:", res["r"].iloc[0])
```

**Practical note.** Report it next to the full-model R-squared to express incremental value. Sensitive to multicollinearity: a useful feature can look worthless only because a correlated one already covers its information.

**Reference.** Cohen, Cohen, West & Aiken (2003). Applied Multiple Regression/Correlation Analysis, 3rd ed.

## Cross-correlation (lagged)

**Essence.** Adds time-shift, so you recover propagation delay and direction of influence between subsystems.

**In plain words.** Ordinary correlation lines up two signals at the same instant. Cross-correlation slides one signal in time and measures correlation at every shift. The shift where the match is strongest is the delay between them, and its sign tells you which signal moved first.

**Diagnostic example.** A pressure spike at the pump shows up later at a downstream valve. The cross-correlation peak at +0.7 seconds gives both the transport delay and the direction of flow, useful for locating where a transient originates in a hydraulic subsystem.

**Engine call.** `cross_correlation_lag(a, b)`

```python
import numpy as np
from scipy import signal

a = a - a.mean(); b = b - b.mean()
xc   = signal.correlate(b, a, mode="full")
lags = signal.correlation_lags(len(b), len(a), mode="full")
delay = lags[np.argmax(xc)]
print(f"B lags A by {delay} samples  (>0 means A leads)")
```

**Practical note.** Detrend and ideally pre-whiten both signals; shared slow drift inflates the peak and smears the lag. Resolution is one sample, so sample fast enough that the true delay spans several. A broad, flat peak means the delay is poorly identified.

**Reference.** Box & Jenkins (1976), Time Series Analysis; Knapp & Carter (1976), IEEE Trans. ASSP 24.

## Distance correlation / MIC

**Essence.** Capture nonlinear and non-monotonic dependence that Pearson misses.

**In plain words.** Some relationships are real but not straight or even always-rising, think of a U-shape, or points scattered on a ring. Distance correlation is zero only when two variables are truly independent, so it catches these. MIC (maximal information coefficient) scans many grid resolutions to score how cleanly one variable carves up the other, again catching curves and clusters.

**Diagnostic example.** An actuator's error is small at low and high duty but large in the mid range, a U-shape. Pearson reads near zero and would call it healthy; distance correlation of 0.55 flags the genuine dependence that a linear screen would miss.

**Engine call.** `distance_correlation(x, y)`

```python
import dcor
from minepy import MINE

dc = dcor.distance_correlation(x, y)   # 0 iff independent
m = MINE(); m.compute_score(x, y)
print(f"dCor {dc:.3f}   MIC {m.mic():.3f}")
```

**Practical note.** Distance correlation needs roughly 100-plus samples and is order n-squared in memory; use its permutation test for significance. MIC is powerful but can be unstable and slow on noisy data. Standardize heterogeneous scales first.

**Reference.** Szekely, Rizzo & Bakirov (2007). Measuring and testing dependence by correlation of distances. Ann. Statist. 35; Reshef et al. (2011), Science 334 (MIC).

## Mutual information & conditional MI

**Essence.** Information-theoretic dependence; conditional MI is the nonlinear analogue of partial correlation for fault isolation.

**In plain words.** Mutual information measures how many bits knowing one signal saves you when guessing the other, of any shape of relationship, not just linear. Conditional mutual information asks the same thing AFTER you already know a third signal: if it drops to near zero, the third signal explained the link. That is the nonlinear cousin of partial correlation.

**Diagnostic example.** A vibration band and a fault flag share high mutual information. Conditioning on operating mode, the conditional MI nearly vanishes, meaning the apparent coupling was just both responding to mode changes, exactly the isolation logic you want before declaring a root cause.

**Engine call.** `mutual_information(x, y)`

```python
from sklearn.feature_selection import mutual_info_regression
from npeet import entropy_estimators as ee   # kNN estimators

mi  = mutual_info_regression(x.reshape(-1, 1), y)[0]
cmi = ee.cmi(x.reshape(-1, 1), y.reshape(-1, 1), z.reshape(-1, 1))
print(f"MI {mi:.3f}   conditional MI I(X;Y|Z) {cmi:.3f}")
```

**Practical note.** The k-nearest-neighbor (Kraskov) estimator is the practical default with k around 3 to 5. Needs a few hundred samples, more in higher dimensions. MI has no fixed ceiling, so compare like-for-like rather than reading an absolute value.

**Reference.** Kraskov, Stogbauer & Grassberger (2004), Phys. Rev. E 69; Frenzel & Pompe (2007), Phys. Rev. Lett. 99 (conditional MI).

## Coherence

**Essence.** Frequency-domain correlation; tells you at which frequencies two signals are coupled.

**In plain words.** Coherence is correlation computed frequency by frequency. It runs from zero to one and answers: at this particular vibration frequency, do the two signals rise and fall in lockstep? Two signals can be uncorrelated overall yet strongly coherent in one narrow band.

**Diagnostic example.** A gearbox accelerometer and a motor-current sensor share strong coherence only around 30 Hz. That common band points to a single mechanical source feeding both channels, the starting thread for NVH source tracing.

**Engine call.** `coherence_peak(a, b, fs)`

```python
from scipy.signal import coherence

f, Cxy = coherence(sig_a, sig_b, fs=fs, nperseg=1024)
peak = f[Cxy.argmax()]
print(f"strongest coupling at {peak:.1f} Hz  (coherence {Cxy.max():.2f})")
```

**Practical note.** Pick the segment length to balance frequency resolution against variance, and average several segments or coherence is artificially near one. Window to limit spectral leakage. It shows coupling, never direction.

**Reference.** Carter (1987), Proc. IEEE 75; Bendat & Piersol, Random Data.
