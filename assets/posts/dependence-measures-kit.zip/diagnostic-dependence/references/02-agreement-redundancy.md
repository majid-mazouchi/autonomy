# Agreement & redundancy

_Sensor voting and calibration drift, where matching VALUES, not just shapes, is the whole point._

## Intraclass correlation (ICC)

**Essence.** Agreement among repeated or redundant measurements of the same quantity; the right metric for triple-redundant sensor consistency, not Pearson (which ignores systematic offset).

**In plain words.** When several sensors are supposed to measure the SAME thing, you do not just want their shapes to match, you want their numbers to match. Pearson happily reports r equal one even if one sensor reads a constant ten degrees high. ICC treats that constant offset as disagreement, which is what redundancy management actually needs.

**Diagnostic example.** Three redundant cell-temperature sensors feed a voting scheme. A high ICC means any of the three can be trusted; a falling ICC, even while Pearson stays near one, exposes a sensor reading consistently high, a calibration fault a correlation check would hide.

**Engine call.** `icc(ratings_matrix)`

```python
import pingouin as pg
# long format: one row per (sample, sensor, reading)
icc = pg.intraclass_corr(data=long_df, targets="sample",
                         raters="sensor", ratings="value")
print(icc[icc.Type == "ICC2"][["ICC", "CI95%"]])
```

**Practical note.** Choose the form deliberately: (2,1) for absolute agreement of single redundant sensors, (3,k) for averaged consistency. Report the confidence interval, it is noisy with few targets. A constant offset correctly lowers ICC where Pearson would not.

**Reference.** Shrout & Fleiss (1979), Psychol. Bull. 86; McGraw & Wong (1996), Psychol. Methods 1.

## Lin's concordance correlation (CCC)

**Essence.** Agreement vs. a reference, penalizing both scatter and bias; ideal for sensor-vs-truth calibration-drift monitoring.

**In plain words.** CCC measures how close paired readings sit to the perfect y equals x line, not just how tightly they cluster around SOME line. It combines two penalties: random scatter, and any systematic gap (bias). A sensor that is precise but biased gets a high Pearson and a low CCC, which is the honest verdict.

**Diagnostic example.** During end-of-line calibration you compare a production sensor against a lab reference. CCC near one passes; CCC dropping because the cloud has shifted off the y equals x diagonal flags a developing offset before it breaches a hard limit.

**Engine call.** `ccc(reference, sensor)`

```python
import numpy as np
def ccc(x, y):
    cov = np.cov(x, y, bias=True)[0, 1]
    return 2 * cov / (x.var() + y.var() + (x.mean() - y.mean()) ** 2)
print("CCC =", ccc(reference, sensor))
```

**Practical note.** Best for sensor-versus-reference checks. Decompose into precision (correlation) times accuracy (bias) to see whether a low score is scatter or drift. A narrow operating range deflates CCC even with good agreement.

**Reference.** Lin, L. (1989). A concordance correlation coefficient to evaluate reproducibility. Biometrics 45.

## Kendall's W (concordance)

**Essence.** Agreement among multiple rankers/sensors when only ordering is trusted.

**In plain words.** Kendall's W rates how much several rankers agree on an ordering, from zero (no agreement) to one (identical rankings). Use it when the absolute numbers are not comparable but the ORDER is, for example several diagnostics each ranking suspects.

**Diagnostic example.** Four technicians (or four scoring models) each rank five fault codes by severity. A W of 0.85 says they strongly agree on the priority order, so the consensus ranking is trustworthy; a low W means the triage logic disagrees and needs a tie-breaker.

**Engine call.** `kendall_w(ranks)`

```python
import numpy as np
def kendall_w(ranks):                 # ranks: raters x items
    m, n = ranks.shape
    R = ranks.sum(axis=0)
    S = ((R - R.mean()) ** 2).sum()
    return 12 * S / (m ** 2 * (n ** 3 - n))
print("Kendall W =", kendall_w(rank_matrix))
```

**Practical note.** Use when only the ordering is comparable across raters or models, and correct for ties. With many items and few raters even modest W can be significant, so check the chi-square test, not just the magnitude.

**Reference.** Kendall & Babington Smith (1939). The problem of m rankings. Ann. Math. Statist. 10.
