# Rules of thumb

Heuristics that hold across most diagnostics work.

1. Start with the cheapest measure that could answer the question, and escalate only when it fails or its assumptions do not hold.
2. If Pearson and Spearman agree, the relationship is roughly linear; if they diverge, suspect nonlinearity or outliers and move to a rank or nonlinear measure.
3. Never use plain correlation for redundant sensors: a biased sensor still scores near one. Use ICC for agreement or CCC against a reference.
4. A correlation that survives partialing on load and temperature is worth investigating; one that collapses was confounded.
5. Coupled is necessary, not sufficient, for connected. Confirm a lead-lag or causal measure before drawing a propagation arrow.
6. Standardize heterogeneous scales (and consider whitening) before any distance or kernel measure.
7. For any nonlinear or kernel measure, significance comes from a permutation test, not the raw magnitude.
8. Rough sample-size floors: Pearson and Spearman about 30; distance correlation, HSIC and MI about 100 to 200; transfer entropy, PDC and CCM want thousands.
9. Check stationarity before every time-series measure; for couplings that move in time use wavelet coherence.
10. Conditioning removes only the confounders you measured, so state your control set with every direct-link claim.

## Pick by scenario

| Scenario | Pick | Why | Kind |
| --- | --- | --- | --- |
| Fast screen of a wide fleet feature matrix | RDC, then confirm hits with distance correlation or HSIC | near-linear cost, still catches nonlinear coupling | nonlinear |
| Confirm a suspected root cause among confounded signals | Partial correlation; partial distance correlation or conditional HSIC if nonlinear | removes the shared driver so only a direct path survives | direct |
| Validate redundant sensors / detect calibration drift | ICC for agreement, Lin's CCC versus a reference | penalizes bias and offset, not just matching shape | agreement |
| Locate where a transient originates | Cross-correlation lag | recovers both the delay and which side leads | directional |
| Trace fault propagation through coupled subsystems | Granger (linear), transfer entropy (nonlinear), CCM (deterministic) | directed: who drives whom | directional |
| NVH / vibration source localization | Coherence for the band, PDC for direction, wavelet coherence if non-stationary | frequency-resolved coupling and direction | freq |
| Relate fault codes to operating modes | Cramer's V, Theil's U | categorical strength, and directional with Theil's U | categorical |
| A continuous signal versus a fault flag | Point-biserial correlation | scores how cleanly the signal separates the classes | categorical |
| Suspected nonlinear link where Pearson is near zero | Distance correlation, MIC, HSIC, Chatterjee's xi | shape-agnostic dependence detection | nonlinear |
| Joint-failure risk at the operating limits | Copula lower-tail dependence | captures co-extremes the bulk correlation misses | nonlinear |
| How well a sensor panel tracks remaining life | Multiple R / R-squared, plus semi-partial per sensor | group-to-target fit and each sensor's unique share | setlevel |
| Couple two subsystem variable groups under fixed conditions | Partial canonical correlation | set-to-set coupling beyond the shared conditions | setlevel |
| Small sample, possibly non-monotonic | Kendall's tau; be cautious with kernel methods | robust and stable at low n | rank |
| Streaming / online monitoring | Pearson or Spearman on sliding windows, with an EWMA of the statistic | cheap and incremental to update | time |
