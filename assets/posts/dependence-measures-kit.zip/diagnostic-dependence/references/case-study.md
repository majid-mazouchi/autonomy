# Worked case study: DC-DC converter

A synthetic but structured fault (rising MOSFET on-resistance) taken through the
full ladder on a 700-sample record. All numbers are produced by the
engine; see `scripts/measures.py` and the project case-study generator.

## Step 1 - screen wide and cheap (RDC vs output ripple)
Strongest associations: load, fan, EMI, inductor temp. Efficiency has a real RDC
of 0.52 but a near-zero Pearson, a nonlinear hit a linear screen
would discard.

## Step 2 - confirm the nonlinear hit (efficiency vs load)
Pearson 0.04, Spearman -0.01 (both ~0);
distance correlation 0.52, mutual information 1.09.
A near-zero Pearson is not evidence of independence.

## Step 3 - kill the confound (partial correlation)
ripple vs fan: raw 0.73 -> partial | load, ambient -0.03 (collapses; a load confound).
ripple vs EMI: raw 0.65 -> partial 0.55 (survives; a direct link).

## Step 4 - find the direction
ripple -> EMI by transfer entropy: 0.134 vs 0.077 nats; cross-correlation lag 2.
deg -> ripple: deg is a monotone trend, so TE/Granger assumptions are shaky;
the arrow rests on lead-lag (deg leads ripple by 7 samples) and exogeneity.
Granger agrees in the supported direction (p = 0.005 forward vs 0.36 reverse).

## Verdict
Root cause and path: deg -> inductor temp -> ripple -> EMI. The load couplings
were real but not causal; they are removed by partialing, not by the screen.
No single measure delivered this: screen, then confirm nonlinear, then partial
out confounds, then orient with lead-lag and transfer entropy.
