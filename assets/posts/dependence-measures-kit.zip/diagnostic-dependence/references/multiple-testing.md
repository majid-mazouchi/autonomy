# Significance at fleet scale

When screening a wide matrix, the per-test p-value misleads. Three disciplines
keep it honest: a permutation null, a false-discovery correction, and an
effect-size floor.

## The problem
In the case-study record there are 28 channel pairs. At p < 0.05,
26 are significant; Benjamini-Hochberg still passes 26. With
700 samples almost nothing fails a significance test, because significance
asks whether an effect is exactly zero, not whether it is large enough to act on.
Add an effect-size floor (distance correlation >= 0.45) and the kept
set drops to 10.

## The trap effect size does not fix
Ambient temperature vs degradation scores distance correlation 0.95
with p = 0.005, yet they are not coupled: both are slow trends, and any
two trends look dependent. Detrend or test on stationary residuals before
screening. Also: the screen finds marginal dependence, so known confounds
(ripple vs fan) still pass and must be removed by partialing in the next stage.

## The recipe
For each pair, compute the measure and a permutation p-value; apply
Benjamini-Hochberg across all pairs; keep only pairs clearing both the FDR
threshold and a pre-registered effect floor. The engine packages this as
`screen_pairs`.

```python
from measures import screen_pairs, distance_correlation
results = screen_pairs(X, names=channel_names, measure=distance_correlation,
                       n_perm=199, alpha=0.05, effect_floor=0.30)
kept = [r for r in results if r["keep"]]
```

## Practical note
Pick the effect floor from operational meaning, not the data. Use identical
permutation settings across pairs. Detrend non-stationary channels first.
Permutation cost scales with n_perm, so screen on a subsample, then re-test
survivors at full resolution.

## Reference
Benjamini & Hochberg (1995), J. R. Statist. Soc. B 57; Westfall & Young (1993),
Resampling-Based Multiple Testing.
