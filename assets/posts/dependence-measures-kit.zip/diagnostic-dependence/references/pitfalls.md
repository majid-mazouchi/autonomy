# Pitfalls and assumptions

Read this before trusting any single number.

## Unmeasured confounders
Every "controlling for C" method (`partial_corr`, `partial_distance_correlation`,
`conditional_hsic`) only removes confounding from variables you actually
included. An unmeasured shared driver still produces a spurious surviving
link. A non-zero partial result is evidence of a direct path only relative to
your control set, not proof of one.

## Linearity
`pearson`, `partial_corr`, `semipartial_corr`, `multiple_r2`,
`partial_canonical_corr`, and `granger_min_pvalue` assume mostly linear
structure. If the relationship can bend, escalate to the nonlinear and
conditional-nonlinear measures.

## Stationarity
The time-series measures (`cross_correlation_lag`, `coherence_peak`,
`granger_min_pvalue`, `transfer_entropy`) assume the coupling is roughly
stable over the record. Non-stationary regimes such as run-ups need
time-localized tools (wavelet coherence). Highly autocorrelated signals (for
example a random walk) blur lag estimates.

## Sample size and bandwidth
Kernel measures (`hsic`, `conditional_hsic`) depend on the bandwidth; the
module uses the median heuristic. Distance and kernel statistics need enough
samples to be stable. The permutation p-values cost n_perm extra evaluations.

## Agreement is not correlation
For redundant sensors use `icc` or `ccc`, not `pearson`. Correlation reports a
perfect score even when one sensor reads a constant offset; agreement metrics
treat that offset as the fault it is.

## Symbolization
`transfer_entropy` bins continuous signals into symbols. The bin count changes
the estimate; report it, and prefer comparing the two directions on the same
binning rather than reading an absolute value.
