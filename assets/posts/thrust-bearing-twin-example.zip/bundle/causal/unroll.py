#!/usr/bin/env python3
"""Time-unroll the causal graph into a DAG an agent can run causal inference on.

The physical graph is cyclic: that is what a feedback loop is. Do-calculus, backdoor
adjustment and most causal-discovery tooling assume a DAG, so applying them to the cyclic
graph is undefined. Unrolling over K time slices makes it acyclic: an edge that closes a loop
becomes node@k -> node@k+1, and each loop becomes a chain whose gain can be measured.

    python unroll.py thrust-causal-graph.json --steps 4 --out unrolled
writes unrolled.json (nodes, edges, slice index) and unrolled.dot.

Edge classification: an edge is DELAYED (crosses a time slice) if it carries a loop tag or if
it runs backwards in the layout order; otherwise it is INSTANTANEOUS within a slice.
"""
import argparse, json


def unroll(graph, steps=4):
    order = {n["id"]: i for i, n in enumerate(graph["nodes"])}
    col = {n["id"]: i for i, n in enumerate(graph["nodes"])}
    if "column" in (graph["nodes"][0] or {}):
        col = {n["id"]: n["column"] for n in graph["nodes"]}
    nodes, edges = [], []
    for k in range(steps):
        for n in graph["nodes"]:
            nodes.append({"id": f"{n['id']}@{k}", "base": n["id"], "slice": k, "type": n["type"], "label": f"{n['label']} (t{k})"})
    for k in range(steps):
        for e in graph["edges"]:
            delayed = bool(e.get("loops")) or col.get(e["to"], order[e["to"]]) < col.get(e["from"], order[e["from"]])
            if delayed:
                if k + 1 < steps:
                    edges.append({"from": f"{e['from']}@{k}", "to": f"{e['to']}@{k+1}", "variable": e["variable"],
                                  "loops": e.get("loops", []), "delayed": True})
            else:
                edges.append({"from": f"{e['from']}@{k}", "to": f"{e['to']}@{k}", "variable": e["variable"],
                              "loops": e.get("loops", []), "delayed": False})
    return {"nodes": nodes, "edges": edges, "steps": steps,
            "note": "acyclic by construction: delayed edges advance one slice. Loop gain = product of "
                    "edge sensitivities around one lap, measurable with thrust_warp.intervene.effect()."}


def to_dot(u):
    L = ["digraph unrolled {", "  rankdir=LR; node [shape=box, fontname=Helvetica, fontsize=9];"]
    for k in range(u["steps"]):
        L.append(f"  subgraph cluster_{k} {{ label=\"t{k}\"; color=\"#D9CFBA\";")
        for n in u["nodes"]:
            if n["slice"] == k:
                L.append(f'    "{n["id"]}" [label="{n["base"]}"];')
        L.append("  }")
    for e in u["edges"]:
        style = ', style=dashed, color="#B4472A"' if e["delayed"] else ""
        L.append(f'  "{e["from"]}" -> "{e["to"]}" [label="{e["variable"]}"{style}];')
    return "\n".join(L) + "\n}"


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("graph"); ap.add_argument("--steps", type=int, default=4); ap.add_argument("--out", default="unrolled")
    a = ap.parse_args()
    g = json.load(open(a.graph))
    u = unroll(g, a.steps)
    json.dump(u, open(a.out + ".json", "w"), indent=1)
    open(a.out + ".dot", "w").write(to_dot(u))
    nd = sum(1 for e in u["edges"] if e["delayed"])
    print(f"{len(u['nodes'])} nodes, {len(u['edges'])} edges ({nd} delayed) over {a.steps} slices -> {a.out}.json, {a.out}.dot")
