# Is the thrust-bearing model ready for causal root-cause analysis?

Findings from the five studies run against thrust_warp v3.3 / page v19.
By Majid Mazouchi · 26 August 2026

## Summary

The machinery is ready to build and test an RCA agent. The physics is not yet calibrated
enough to trust its conclusions about a real engine, and two of the five studies found
problems in the model itself that would have silently corrupted any agent built on it.

## 1. Discriminability through production sensors

Ten classes (healthy plus nine single faults), 14 vehicles each, aged 20–400 h with build
spread, driven through a four-point duty schedule, observed only through eight channels a
vehicle actually broadcasts (rpm, load, oil pressure, oil temperature, CKP jitter, CKP
amplitude, knock-sensor RMS, misfire rate) with noise, quantization, broadcast rate,
dropouts and drift. Features are per-segment mean, standard deviation and 95th percentile;
classifier is gradient boosting, five-fold cross-validated.

    accuracy 67.9 % against 10 % chance

    perfectly separable      preload 100 %, misalignment 100 %
    strongly separable       misfire 93 %, low oil 93 %, dilution 71 %
    partly separable         dent 64 %, aeration 64 %
    not separable            debris 36 %, healthy 43 %, washer spin 14 %

Structure of the errors matters more than the accuracy. Dent and aeration are confused with
each other (both act on supply pressure and film). Debris, washer spin and healthy form a
mutual confusion cluster: nothing in the production set sees them within this horizon.

Channel value, by mutual information with the label:

    oil_press 8.5   ckp_jitter 5.9   knock_rms 4.4   misfire_rate 2.4
    ckp_amp 0.9     engine_load 0.3  rpm 0.3         oil_temp 0.2

Adding test-cell channels (thrust-face temperature, axial accelerometer, oil debris, end
play) raises accuracy only to 70.0 % and does not rescue washer spin (7 %). Debris improves
(36 → 50 %) and misfire reaches 100 %. The conclusion an agent needs: **spin and debris are
not root-causable from these observables at this horizon**, and no amount of reasoning
sophistication changes that. Either a new sensor, a longer horizon, or a targeted test is
required.

## 2. Time-warp instability in the wear loop (model defect, fixed)

Wear relieves the contact that causes it, but the relief only reaches the solver on the next
frame. With a coarse time-warp step, the runaway wear loop (L1) over-integrates itself: a
20-hour run at 2200 rpm and light axial load produced 860 µm of wear at a coarse step and
would have gone unbounded, while the same 20 hours at a ten-times finer step produces 16.5 µm.
The coarse result looked like physics — a catastrophic failure at a mild duty — and would have
taught an agent a completely false causal ordering.

Fixed on both platforms: one step may remove at most a tenth of the local film, and the number
of clipped cells is reported as `warp_limited_cells` (page: `warp_limited`). Non-zero means the
warp is too coarse and the wear is being under-integrated, which is visible rather than silent.

## 3. Settling before ageing (procedural defect, fixed)

Applying a warped step immediately after an operating-point change ages the transient by hours.
A first frame with the crank momentarily at a limit and the film not yet established was being
multiplied by 1200 seconds of wear. All study and intervention code now settles at warp = 0
before accumulating damage. This was already in the skill's numerical rules for the interactive
page and was violated in the batch code — worth noting as a general failure mode.

## 4. Matched counterfactuals

`intervene.compare` runs every arm from the same build spread, duty schedule and seed, so the
difference between arms is the intervention and nothing else. Two results worth recording:

- **Low oil supply**, 60 h: gallery pressure −0.92 bar against the matched control, as expected.
- **Dent, dose-response 0 → 0.5 → 1.0**, 100 h including clutch-holding: gallery pressure −27 %,
  minimum pad fill −32 %, and *no* penalty in face-mean wear, end play or temperature. The dent's
  damage is local to its sector and the load-carrying pads are, if anything, slightly better off.

That second result is a genuine causal finding and a good illustration of why a graph alone is
insufficient: an agent reasoning from "dent → wear" would be wrong at this horizon. The dent is
visible hydraulically long before it is visible mechanically.

## 5. Cyclic graph unrolled

The physical graph has seven feedback loops, so it is not a DAG and do-calculus does not apply to
it as exported. `causal_unroll.py` produces a K-slice DAG: 19 nodes and 57 edges become 76 nodes
and 196 edges over four slices, of which 96 are delayed (loop-closing) edges advancing one slice.
Each loop becomes a chain whose gain can be measured by intervening on one node and reading the
response one lap later.

## What still blocks trustworthy conclusions

1. **Calibration.** Y_OV, C_PLAST, K_SCUFF, the debris and corrosion constants, K_STRUCT and the
   friction law are order-of-magnitude. The model ranks causes in a structurally sensible order and
   gets magnitudes wrong. Anchor five to ten constants against teardown or dyno data before any
   statement about a real engine.
2. **No radial main bearing.** Causes that couple through the journal — bore distortion, shell
   crush, upstream starvation — cannot be represented at all.
3. **One structural mode.** Real flexplate mode shapes need an FE input; the lumped mode gives the
   right mechanism and an assumed frequency.
4. **No assembly-variation model** beyond a scalar spread, which is where many real root causes live.

## Recommended framing for anything the agent produces

"Consistent with the model" rather than "the cause", until item 1 above is done. The studies in
this report are reproducible with `python -c "from thrust_warp.study import *"` and the numbers
above are from a single seed; repeat across seeds before quoting them.
