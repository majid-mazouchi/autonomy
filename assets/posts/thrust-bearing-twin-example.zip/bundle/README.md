# Thrust bearing digital twin — complete project

Everything built in this project: the interactive simulation page, the batched Warp physics
package, the causal graph and its unrolled DAG, the two reusable skills with their harnesses,
the RCA-readiness study, and the field survey.

## Contents

    pages/
      thrust-bearing-crank-walk-v19.html   the interactive 3D simulation (current version)
      thrust-bearing-causal-graph.html     interactive block diagram of the model's causal structure
      thrust-bearing-field-failures.html   field survey of real-world crank walk cases, with references
      history/                             every earlier version of the simulation page, v1 to v18

    warp/thrust_warp_v3_3/                 batched NVIDIA Warp package
      thrust_warp/                         calibration, geometry, combustion, kernels, simulator,
                                           drive cycles, dent shapes, fleet, dataset, calibrate, twin,
                                           campbell, sensors, study, intervene
      verify.py                            50 self-checks, all green on CPU
      run_all.sh / run_all.bat             install dependencies and run everything
      README.md                            physics, units, calibration notes, known simplifications

    skills/
      physics-sim-page/                    skill for building interactive physics simulation pages
        scripts/                           js_check, physics_harness, test_page, patch,
                                           symbolic_derive, causal_graph_build, causal_unroll
        references/                        architecture, physics checklist, house style,
                                           symbolic physics, film-gap micro view, deformation and
                                           damage, rendering pitfalls, causal graph
        assets/                            page skeleton, reference builds, example action files
      warp-physics-twin/                   skill for porting a model to batched Warp and using it
        scripts/scaffold.py                generates a runnable package with the standard kernel order
        references/                        Warp gotchas, kernel patterns, uses
        assets/reference-implementation/   the full v3.3 package
      agents/                              sim-architect and sim-tester (Copilot .agent.md)

    causal/
      build.py, template.html              regenerate the causal graph page from node/edge/loop lists
      unroll.py                            time-unroll the cyclic graph into a K-slice DAG
      thrust-causal-graph.json             19 nodes, 57 edges, 7 loops, with equations attached
      thrust-causal-unrolled.json/.dot     76 nodes, 196 edges over 4 slices

    reports/
      rca-readiness-findings.md            discriminability, sensor layer, warp stability, counterfactuals

## Quick start

Simulation page: open `pages/thrust-bearing-crank-walk-v19.html` in a browser. Nothing to install.

Warp package:

    cd warp/thrust_warp_v3_3
    pip install -r requirements.txt
    python verify.py
    ./run_all.sh          # fleet, dataset, calibration, twin, campbell sweep

Skills: copy `skills/physics-sim-page` and `skills/warp-physics-twin` into your Claude skills
directory, or into `.github/skills/` with `skills/agents/*` into `.github/agents/` for VS Code Copilot.

Causal graph: open `pages/thrust-bearing-causal-graph.html`, or rebuild with
`cd causal && python build.py`, then `python unroll.py thrust-causal-graph.json --steps 4`.

## Honest status

The physics is structurally complete: two Reynolds faces, per-cell thermal, flow-resolved
starvation, deformation and third-body debris, oil grades and cold start, a structural axial mode
and boundary chatter. The damage and structural constants are order-of-magnitude and not yet
anchored to test data, so the model ranks causes sensibly and gets magnitudes wrong. See
`reports/rca-readiness-findings.md` before drawing conclusions about a real engine.
