# Page architecture contract

Every page follows the same five objects so later versions can be patched rather than rewritten.

## P — user parameters
Sliders, selects and checkboxes bound by `bind(id, key, fmt)`. Values are numbers.
`P.fm[name] = {on, sev}` holds failure modes; `P.drive` selects a drive cycle.

## S — simulation state
Everything computed: scalars (x, v, angle, Tface, ep...), typed arrays for fields
(h, p, pasp, wear, rin, Tpad), chart histories (`S.hist`). One `physics(dt)` updates S
from P; `dt = 0` means "recompute, do not advance" (init, paused).

## CAL_DEF / CAL — calibration
`CAL_DEF = [[name, default, unit, description, group], ...]`; `CAL` is the live object.
All non-geometry constants live here. The Calibration tab renders an editable table,
highlights changed values, exports/imports JSON `{parameters:[{name,value,unit,description,group}]}`,
restores defaults. Edits apply on the next frame.

## SIG — measurement signals
`SIG = [[name, unit, getter, description], ...]`. Feeds the Measurement tab (value,
running min/max), the Recorder (CSV whose header carries mode, active failure modes and
the calibration JSON; frame divider; arm-on-trigger) and the Snapshot export. Every
internal quantity worth a chart is a signal first.

## FM_DEF — failure modes
`[[key, label, tooltip], ...]`, rendered as checkbox + severity slider. Physics reads
`P.fm.key.on` / `.sev`. Modes combine. Each gets an equation and a mechanism paragraph.

## Two-face pattern
One grid per face (`FR`, `FF`); `useFace(f)` swaps the globals before
`buildH / solve / contact`; flip the sign of tilt, runout and bending on the second
face; both faces add to end play.

## Rendering
Three.js scene with cutaway materials, sprite labels scaled by camera distance, face
texture on a canvas (grooves, taper, dent, spall, wear darkening), pressure map as
vertex colours on a polar mesh, oil particles. Rotation shown at 1/30 speed; physics
uses the true speed. Respect `prefers-reduced-motion`.

## Tabs and charts
Measurement | Recorder | Calibration | Calibration fit | Fleet. Charts: polar pressure
(face toggle), trend (end play vs engine hours, spec band, service limit, fitted points),
axial vibration + FFT, torque over 720 degrees, CKP waveform.

## Version discipline
`name-vN.html`; masthead "· vN"; an "Added in vN" section above older ones; compare
steady numbers with v(N-1) in the Node harness before presenting.
