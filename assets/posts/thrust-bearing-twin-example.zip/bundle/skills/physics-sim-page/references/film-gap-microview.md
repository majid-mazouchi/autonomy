# Film-gap micro view (page v9-v15)

A second Three.js scene that shows one pad, or the dent sector, at true film scale, driven from
the same solver state as the main view. Everything in it is computed; nothing is drawn for effect.

## Geometry
- Window: `[k GP - GW, (k+1) GP + GW]` for pad k (both grooves included), or the dent sector
  `DENT_ANG ± max(GP/2 + GW, dentW/2 + 12)` when "centre on the dent" is set.
- Resolution: SUB = 4 sub-cells per solver cell in θ and r (PlaneGeometry cols × rows), so the
  dent edge, rims and roughness ridges are resolved while the physics stays on the solver grid.
- Two surfaces from the same decomposition the solver uses:
  `washerZ = -(taper + chamfer + dent + spall + wear + plastic - pileup + tilt + coning) + rough_w`,
  `crankZ = h0(x) + runout + bending + waviness + conicity - fillet + crank_damage + rough_c`.
  Groove floors use the deformed groove depth. Heights in µm scaled by a slider (default 0.4 mm/µm).
- Roughness textures: circumferential lay `sin(r/λ_r 2π + phase(θ))` plus a hashed random
  component, amplitude 1.25·Ra of each face, multiplied by the running-in / scuffing ratio.

## Colouring (solid style = weak points; FEA style = field)
Worn cells to bronze, dent floor dark, cavitated cells pale blue, mixed regime amber, asperity
load red with a contact dot at mid-gap, plastic recess violet, rims lighter, scuffed cells torn
red-brown, crank surface darkened by its scoring map. FEA style: washer by the selected field,
crank face by the pressure it sees; legend in the HUD.

## Oil in the gap
Particles carry a height fraction ζ; velocity from the derived profile
`u_θ = ω r ζ − (h²/2μ) ζ(1−ζ) ∂p/(r∂θ)`, `u_r = −(h²/2μ) ζ(1−ζ) ∂p/∂r`, with h the LOCAL
sub-cell film between the drawn surfaces (rims, ridges and dams included). Grooves feed
outward scaled by the pad fill; the dent leaks outward and mixes; cavitated cells give pale
particles. Streaks are drawn along the velocity. Particles leaving at the outer edge in the
main view become droplets under (visual) gravity.

## Debris in the gap
Free particles as grey points sized by d, embedded ones dark and standing proud by 0.3 d.

## Controls and switching
Film gap button swaps the render target (`renderer.render(gapScene, gapCam)`); drag and wheel
route to the gap camera when active; pad selector, height scale, roughness amount, dent centring.
