# Rendering pitfalls met in this project (and the fixes)

- **Canvas texture mirrored against the physics grid.** Canvas y is down; Three.js UV v is up.
  Draw the face texture with `g.setTransform(1,0,0,-1,0,SIZE)` so canvas angle = physics angle,
  or wear shading and dents land on the opposite half from the pressure that caused them.
- **Translucent cut-away parts hiding the film.** A transparent web/block that still writes
  depth hides transparent sheets behind it wherever it draws first. Set `depthWrite=false` on
  cut-away materials and give film sheets, streaks and particles a high `renderOrder`.
- **Particles inside an exaggerated gap.** Place particles at a fraction of the LOCAL film
  height (from the solver grid), not of the nominal gap, or the tilted crank face hides them
  on half the pads.
- **Block parts intersecting the washers.** Narrow the saddle/cap at the thrust main so the
  faces and gaps are outside them.
- **FEA deformed plot vanishing.** Displace the field mesh by (h − h_min) above the face,
  never below it; share the geometry between the coloured mesh and the wireframe edges.
- **Sprite labels in a second scene.** Sprites are scaled for the main camera distance; rescale
  them for the micro scene or they fill the view.
- **Fold button inside a tab bar.** Exclude it from the tab selector (`.tabs button[data-tab]`).
- **HUD under the canvas.** Give the HUD `z-index` and `pointer-events:auto`; exclude it from
  the drag handler.
- **Undocking the stage to a pop-up.** `adoptNode` the whole stage element into the new
  document, clone the styles, route `$()` to both documents, add pointerup/resize/keydown
  listeners on the pop-up, and dock back synchronously on `pagehide`/`beforeunload`.
- **Line comments in one-line patches.** A `//` comment appended to a long single-line
  statement swallows the rest of the line; use `/* */` in patches.
- **Startup transients under SwiftShader.** Headless frames are slow; judge physics with the
  Node harness, use the browser for errors, layout and interaction.
