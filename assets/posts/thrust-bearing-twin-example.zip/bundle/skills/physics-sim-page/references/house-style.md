# House style (light paper)

    --paper:#F5EFE3; --paper2:#EDE5D4; --cream:#FBF7EE; --ink:#1F1B17; --muted:#6B6257;
    --line:#D9CFBA; --rust:#B4472A; --teal:#1E6B73; --ochre:#C48A2E;

Fonts: Fraunces (display), Spectral (body), IBM Plex Mono (data); Google Fonts link, serif/monospace fallback.

Layout: masthead (kicker "Engine tribology · vN", title, byline "By <name> · <date>"), lede,
stage (3D view + control panel) with HUD, readout tiles, tabbed measurement section, charts grid,
prose sections with h2/h3, `.eq` (monospace boxed) and `.why` (muted prose), footer.

Charts: canvas 2D, cream background, muted axes, rust/teal/ochre data, IBM Plex Mono 11-12 px.
Polar chart y-flipped to match looking at the face from the flexplate.

Mobile: single column under 860 px, view bar to the bottom, tables scroll, canvases use
`fitCanvas` with devicePixelRatio. Never add AI attribution to bylines or credits.
