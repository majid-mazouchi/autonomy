# Causal graph of a simulation (thrust-bearing-causal-graph.html)

The model's structure as data: nodes = components with their governing equations and states,
edges = physical couplings with the variable that crosses them, loops = tagged edge sets that
return to their origin. Rendered as an interactive block diagram in the house style and exported
as JSON, Mermaid, DOT and SVG for the RCA agent.

Schema (JSON):
    nodes: [{id, label, type: pde|ode|algebraic|state|input|output, equations: [[eq, why]], states: [..]}]
    edges: [{from, to, variable, loops: ["L1", ...]}]
    loops: {L1: [name, description]}

How to derive it from a simulation page or kernel set:
1. One node per solver block or state array (the physics() sections / the kernels).
2. For each node list the equation strings already in the page's `.eq` blocks.
3. For each variable read by a node and written by another, add an edge with that variable.
4. Trace cycles; tag the edges of each cycle with a loop id and describe the mechanism.
5. Lay out in columns by information flow (inputs → forces → geometry → film → thermal/oil →
   damage → signals); feedback edges run right to left.
6. Build the page with `build.py` from the node/edge lists (the template renders, highlights,
   shows the adjacency matrix and exports).

Use in root-cause analysis: start at an observed signal node, walk edges backwards, quote the
equation at each hop, and stop at loops (a loop is where a small fault becomes a failure).


## Unrolling for causal inference
The physical graph is cyclic; do-calculus and most causal tooling assume a DAG. `scripts/causal_unroll.py`
turns the exported JSON into a K-slice DAG: edges that carry a loop tag or run backwards in the layout
become node@k -> node@k+1, everything else stays inside a slice. Each loop becomes a chain whose gain can
be measured by intervening on one node and reading the response one lap later.
