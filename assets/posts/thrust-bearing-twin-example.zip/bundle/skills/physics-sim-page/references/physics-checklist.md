# Physics checklist for tribology / powertrain pages

A menu for planning: effect, its state, its signal.

## Film and contact
- Reynolds on a polar grid (NT x NR, Gauss-Seidel relax 1.4, warm start, cavitation clamp p >= 0, grooves at supply pressure, pressure cap P_CAP).
- Film height: h0 + taper(1 - s/0.6) + tilt + runout + bending + coning + dent + spall + wear + measured height map.
- Patir-Cheng phi_p = 1 - 0.9 exp(-0.56 h/sigma) on h^3 (phi_s cancels for equal roughness).
- Greenwood-Williamson: pa = E'K 4.4086e-5 (4 - lambda)^6.804 for lambda < 4, capped at PA_MAX; per-cell roughness ratio flattens by plastic work (running-in).
- Squeeze damping c = 3 mu A B^2 / h^3 clamped; stiffness from a second solve at 1.03 h0.

## Thermal
- Per-column or per-cell balance: shear mu w^2 r^2/h dA + asperity mub pa w r dA; convection hA; conduction K in implicit form.
- Local viscosity mu(T) into the solve. Thermo-elastic coning gamma = k_c (Tface - Toil).

## Oil system
- Pump Q ~ rpm, leakage G ~ sqrt(mu_ref/mu)(1 + end-play + dent terms), relief valve, groove supply fraction; aeration cuts mu_eff and supply.
- Flow-resolved starvation: Couette + Poiseuille per cell, pad inlet demand vs groove delivery + carry-over, dent leak d^3 w/(12 mu L).
- Oil ageing: oxidation (Arrhenius), soot ~ load, water in/out, TAN, fuel.

## Loads and dynamics
- Axial force: clutch release (pedal shape 1.2s - 0.2s^3), converter ~rpm^2, bias, misalignment 1x, preload.
- 25 kg mass, 4 kHz substeps, end-play limits grow with wear per face.
- Combustion: Wiebe single-zone per crank degree -> gas force and torque tables; firing order 1-8-7-2-6-5-4-3; bending toward the firing bank; misfire = motoring trace with per-cycle probability.

## Degradation
- Archard per cell (overlay then backing), debris multiplier; cavitation erosion on p = 0 cells bordering p > 0.3 MPa; Basquin-Miner fatigue -> spall sector; corrosion Arrhenius x (1 + a_TAN TAN + a_w water + a_f fuel) with contact synergy on exposed overlay; dent widening from mean wear.

## VHM signals
- Axial accelerometer RMS/FFT (1x, 4x, half-order), CKP amplitude and jitter, torque signature, oil pressure, face temperature, debris ppm, lambda, contact share, fill fraction, fatigue damage.

## Numerical traps met so far
- Explicit conduction with gain K/hA > 1 diverges: implicit form only.
- Rigid Reynolds spikes on impact: cap pressure.
- Startup transient wears the face before the film forms: warm up with warp 0.
- Reduced fleet models need own constants plus a slow defect-growth term.
- Large time-warp steps must sample the duty cycle randomly, not in order.
