# Symbolic physics: deriving the equations before coding them

The rule: no coefficient enters the page or a kernel without a derivation line that says
where it came from and what was assumed. `scripts/symbolic_derive.py` is the harness; run it,
extend it for a new effect, paste its `.eq` strings into the page.

## The derivation ladder (use every rung)
1. **Conservation law** in full: momentum, mass, energy, or a balance (wear volume, particles).
2. **Assumptions, written down**: thin film (h << B, inertia negligible, p uniform across z),
   Newtonian oil, no slip, isothermal per cell, rigid surfaces plus a pressure cap, steady per
   frame. Each assumption is a place the model can be wrong; the page's "Model notes" list them.
3. **Reduce with sympy**: solve the ODE across the film for u(z), integrate for flow rates,
   substitute into continuity for the PDE. Section 1-2 of the harness shows the pattern.
4. **Dimensionless groups and scaling**: lambda = h/sigma (regime), Sommerfeld-type mu omega/W
   (film ∝ sqrt), h^3 (channel conductance), Peclet (conduction vs convection). Scalings tell you
   which slider moves which signal before any run.
5. **Discretise** and write the stencil: finite-volume coefficients at cell faces (h at the
   face, r ± dr/2), sources from the wedge term, boundary conditions as fixed values on groove
   columns. Write the JS/Warp line right under the equation.
6. **Stability and sign checks**: derive the update gain (thermal section 6 in the harness
   shows the explicit form diverging), the sign of the stiffness perturbation, the clamp needed
   for rigid-solve pressure spikes.
7. **Units** with `sympy.physics.units` on every product of coefficients (section 10).
8. **Numerical sanity at one operating point**: evaluate the closed form (squeeze damping,
   GW fit, Walther) at the page's default case and compare with the solver's number.

## What symbolic reasoning caught in this project
- The explicit conduction update had gain K/hA ≈ 2 and diverged; the implicit-consistent form
  has gain K/(2K + hA) < 1/2. (section 6)
- The GW closed-form fit 4.4086e-5 (4-λ)^6.804 matches the exact F_3/2 integral within 3 % at
  λ = 1 but underpredicts by 10× at λ = 3: contact onset is later in the model than in GW.
  Acceptable for a demo, worth replacing with a table if contact onset matters. (section 5)
- Squeeze damping c = 3 mu A B^2 / h^3 follows from the long-annulus 1-D solution; the exact
  polar solution differs by a geometric factor near 1. (section 3)
- The stiffness perturbation must be solved after the main solve; otherwise the two solves are
  at different convergence states and the sign of dW/dh flips, giving a limit cycle. (section 4)
- Walther constants from two data points reproduce the grade spread at -20 C (0W-20 ~1500 cSt,
  20W-50 ~21000 cSt) with no extra fitting. (section 7)

## Modes and stability (added with the vibration work)
- Film mode: f = (1/2pi) sqrt(k/m) with k from the perturbation solve; damping ratio
  zeta = c/(2 sqrt(k m)) with c = 3 mu A B^2/h^3. Because both k and c rise as h falls, zeta stays
  between 20 and 200: the oil film mode is overdamped and cannot resonate. Derive this before
  looking for a peak that is not there.
- Structural mode: 2-DOF FRF, solve the 2x2 complex system for X/F and evaluate at order lines.
- Stick-slip: the effective damping of the tangential mode is c_tab + (dmu/dv) F_c r_m^2; with the
  falling Stribeck branch dmu/dv < 0, instability when |dmu/dv| F_c r_m^2 > c_tab. That inequality
  tells you which contact loads squeal before you run anything.
- Integration: a kHz mode needs its own substeps; symplectic Euler preserves the limit cycle,
  implicit Euler at the outer rate damps it away (this silently hid the chatter on the first try).

## How to add a new effect symbolically
Write the balance, list the assumptions, derive with sympy in a new section of the harness,
print the `.eq` string and the code expression, check units, evaluate at the default operating
point, then implement. Put the derivation summary in the page's `.why` paragraph. If a
coefficient cannot be derived (K_w, C_pl, K_sc, corrosion constants), say it is
order-of-magnitude and put it in CAL_DEF.

## From equations to a causal graph
Each derived block is a node (PDE / ODE / algebraic / state); each variable that crosses from
one derivation into another is an edge. `references/causal-graph.md` gives the schema and the
page that renders it; the loop tags come from tracing which edges return to their origin.
