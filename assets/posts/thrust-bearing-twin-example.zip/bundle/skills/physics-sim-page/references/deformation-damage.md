# Deformation and damage physics (page v12-v16, Warp v3.1)

All are film-height terms or roughness terms, so the Reynolds solve, the contact model and the
flow budget respond on the next frame. Rates run on the engine-hours clock (dte = dt × warp).

| Mechanism | Law | State it changes |
|---|---|---|
| Plastic flow | dδ/dt = C_pl max(0, p_a/Y − 1), Y = overlay or backing yield; rims += PILEUP·dδ/4 on 4 neighbours | plas, pile |
| Brinelling | V = K_imp ½ m v² / Y when landing v > V_imp, spread by p_a share, ≤ 5 µm/cell | plas |
| Scuffing | if T > T_scuff and λ < 1.2: dw += K_sc u dt, σ ×= (1 + ROUGH·u dt), crank += HARD·… | wear, rin, scuff, crankDmg |
| Crank scoring | crank map in the crank frame += HARD·removal on exposed bronze / debris cells | crankDmg |
| Groove loss | d_k = d₀ − rims in groove + ½ wall flow; delivery ∝ (d/d₀)³ | grooveD, grooveCond |
| Edge break-out | q_edge ∝ EDGE_LEAK·d_land³·w/(12 μ L)·p_sup when the outer land beside a groove is worn/flattened | edgeLeak |
| Third-body particles | born from DEB_FRAC of removed volume at contact cells, lognormal sizes; transported by u(z); filtered; if d > h embed (recess 0.35d, proud 0.3d) else scratch K_3B·d | DEB[], plas, pile, wear |
| Corrosion | Arrhenius in cell T × (1 + a TAN + b water + c fuel) × (1 + SYN·contact), exposed overlay only | wear, corr |
| Fatigue | Basquin–Miner on p_max → spall sector | fatD, spall |
| Cavitation erosion | on p = 0 cells bordering p > 0.3 MPa | wear |

Resets: "Reset deformation" clears plas, pile, scuff, crankDmg, particles, groove state and
impact counters without touching wear; "Reset wear" clears everything.

Calibration honesty: Y_OV, C_PLAST, PILEUP, V_IMP, K_IMP, T_SCUFF, K_SCUFF, ROUGH_SCUFF,
HARD_RATIO, DEB_*, EDGE_LEAK_K are order-of-magnitude until a dyno overload test or teardown
series sets them. Say so on the page.
