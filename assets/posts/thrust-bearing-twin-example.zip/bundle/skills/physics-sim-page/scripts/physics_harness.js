// Run a simulation page's physics in Node without a browser.
// Usage: node physics_harness.js /tmp/_page_script.js [scenario.json] [frames]
// Requires the page's IIFE to define `const P={...}`, `const S={...}`, `function physics(dt)`
// (the architecture contract). Exposes P, S, CAL, physics on globalThis.
const fs = require('fs');
const file = process.argv[2] || '/tmp/_page_script.js';
const scenario = process.argv[3] ? JSON.parse(fs.readFileSync(process.argv[3], 'utf8')) : {};
const frames = parseInt(process.argv[4] || '300');

// ---- DOM / THREE stubs: a universal "anything" proxy; every property, call and construction returns another one ----
const NUMS = { width: 800, height: 400, innerWidth: 1200, innerHeight: 800, devicePixelRatio: 1, clientWidth: 800, clientHeight: 400, length: 0 };
function any() {
  const f = function () { return any(); };
  return new Proxy(f, {
    get: (t, k) => {
      if (k === Symbol.toPrimitive) return () => 0;
      if (k === 'then') return undefined;
      if (k in NUMS) return NUMS[k];
      if (k === 'value') return '0';
      if (k === 'checked' || k === 'matches') return false;
      if (k === 'files' || k === 'cells' || k === 'children') return [];
      if (k === 'querySelectorAll') return () => [];
      if (k === 'getImageData') return () => ({ data: new Uint8ClampedArray(4) });
      if (k === 'now') return () => Date.now();
      return any();
    },
    set: () => true, apply: () => any(), construct: () => any(), has: () => true,
  });
}
global.window = any(); global.document = any(); global.navigator = { userAgent: 'node' };
global.performance = { now: () => Date.now() }; global.requestAnimationFrame = () => 0;
global.URL = { createObjectURL: () => '', revokeObjectURL() {} }; global.Blob = class {}; global.FileReader = class {};
global.alert = () => {}; global.Image = class {}; global.THREE = any();

let js = fs.readFileSync(file, 'utf8');
js = js.replace("const S={", "globalThis.S=S0={").replace("function physics(dt){", "globalThis.physics=physics; function physics(dt){")
       .replace("const P={", "globalThis.P=P0={").replace("const CAL={}", "globalThis.CAL={}").replace("'use strict';", "");
js = js.trim(); js = js.slice(js.indexOf('{') + 1, js.lastIndexOf('})();'));
eval(js);

Object.assign(P, scenario.P || {});          // set the real scenario BEFORE the first physics call
if (scenario.S) Object.assign(S, scenario.S);
const keys = scenario.keys || ['lam', 'hmin', 'W', 'Fc', 'x', 'Tface', 'ep', 'wearMax'];
const t0 = Date.now();
for (let i = 0; i < frames; i++) {
  physics(1 / 60);
  if (S.tReal !== undefined) S.tReal += 1 / 60;
  if (S.angle !== undefined && P.rpm) S.angle += P.rpm * 2 * Math.PI / 60 / 30 / 60;
  if (i % Math.max(1, Math.floor(frames / 6)) === 0 || i === frames - 1)
    console.log(String(i).padStart(5), keys.map(k => `${k}=${(+S[k]).toPrecision(4)}`).join('  '));
}
console.log(`ms/frame ${((Date.now() - t0) / frames).toFixed(1)}`);
