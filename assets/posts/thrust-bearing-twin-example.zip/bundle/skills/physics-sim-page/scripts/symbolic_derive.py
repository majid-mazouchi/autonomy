#!/usr/bin/env python3
"""Symbolic derivation harness for thin-film / contact / thermal simulation pages.

Derives, with sympy, the equations a simulation page or Warp kernel implements, checks their
dimensions, and prints them as page-ready `.eq` strings plus JavaScript / Warp expressions.
Run `python symbolic_derive.py` for the full report, or import the functions.

Sections: thin-film velocity profile and Reynolds equation (polar), flow rates for the pad budget,
squeeze-film damping, film stiffness by perturbation, Greenwood-Williamson closed form, implicit
thermal update and its stability, Walther viscosity fit, plastic-flow and Archard rate laws,
end-play thermal growth. Each section states its assumptions explicitly; a derivation that skips
an assumption is the usual source of a wrong coefficient."""
import sympy as sp
from sympy import symbols, Function, diff, integrate, simplify, Rational, exp, log, sqrt, pi, Eq

r, th, z, t, mu, om, h, p, zeta = symbols('r theta z t mu omega h p zeta', positive=True)
dpdth, dpdr = symbols('dp_dtheta dp_dr', real=True)

def section(title):
    print('\n' + '=' * 78 + f'\n{title}\n' + '=' * 78)

def velocity_profile():
    """Thin film: inertia negligible, pressure uniform across the film, Newtonian, no slip.
    Circumferential momentum: 0 = -(1/r) dp/dtheta + mu d2u/dz2, u(0)=0 (washer), u(h)=omega r (crank)."""
    section('1. Velocity profile across the film (Couette + Poiseuille)')
    u = Function('u')(z)
    ode = Eq(mu * diff(u, z, 2), dpdth / r)
    sol = sp.dsolve(ode, u, ics={u.subs(z, 0): 0, u.subs(z, h): om * r}).rhs
    sol = simplify(sol.subs(z, zeta * h))
    print('u_theta(zeta) =', sol)
    ur = Function('v')(z)
    solr = sp.dsolve(Eq(mu * diff(ur, z, 2), dpdr), ur, ics={ur.subs(z, 0): 0, ur.subs(z, h): 0}).rhs
    print('u_r(zeta)     =', simplify(solr.subs(z, zeta * h)))
    q_th = integrate(sol * h, (zeta, 0, 1))          # flow per unit radial width
    q_r = integrate(simplify(solr.subs(z, zeta * h)) * h, (zeta, 0, 1))
    print('q_theta per unit width =', simplify(q_th), '   (omega r h / 2  -  h^3/(12 mu) dp/(r dtheta))')
    print('q_r per unit arc       =', simplify(q_r), '   (-h^3/(12 mu) dp/dr)')
    print('page JS:   ut = om*r*ze - (h*h/(2*mu))*ze*(1-ze)*dpdth;  ur = -(h*h/(2*mu))*ze*(1-ze)*dpdr')
    return simplify(q_th), simplify(q_r)

def reynolds_polar(q_th, q_r):
    """Mass conservation of the flow rates over a polar cell gives Reynolds. Steady, incompressible."""
    section('2. Reynolds equation in polar coordinates from continuity of the flow rates')
    P = Function('p')(th, r); H = Function('h')(th, r)
    qth = q_th.subs({dpdth: diff(P, th), h: H}); qr = q_r.subs({dpdr: diff(P, r), h: H})
    cont = simplify(diff(qth, th) / r + diff(r * qr, r) / r)
    print('(1/r) d q_theta/d theta + (1/r) d(r q_r)/dr = 0  =>')
    print(sp.pretty(sp.expand(cont)))
    print('\nRearranged: d/dtheta( h^3/(12 mu r^2) dp/dtheta ) + (1/r) d/dr( r h^3/(12 mu) dp/dr ) = (omega/2) dh/dtheta')
    print('Add the Patir-Cheng factor phi_p on the h^3 terms; clamp p >= 0 (cavitation) and p <= P_cap (compliance).')
    print('Gauss-Seidel stencil (page):  v = (cE p_E + cW p_W + cN p_N + cS p_S - src) / (cE+cW+cN+cS),')
    print('  cE = h_e^3 phi/(12 mu r^2 dth^2),  cN = (r+dr/2) h_n^3 phi/(12 mu r dr^2),  src = (omega/2)(h_E - h_W)/(2 dth)')

def squeeze_damping():
    """Parallel annular plates approaching at speed V: Reynolds with dh/dt only. Result c = F/V."""
    section('3. Squeeze-film damping of the whole face (order-of-magnitude closed form)')
    B, RM, V, x = symbols('B R_m V x', positive=True)
    # 1-D approximation across the radial width B (long annulus): d/dx(h^3/(12mu) dp/dx) = -V  -> p = 6 mu V (B^2/4 - x^2)/h^3
    pexp = 6 * mu * V * (B**2 / 4 - x**2) / h**3
    F = integrate(pexp, (x, -B / 2, B / 2)) * 2 * pi * RM
    c = simplify(F / V)
    print('F/V =', c, '   -> page uses c = 3 mu A B^2 / h^3 with A = 2 pi R_m B * 0.77 (grooves removed), clamped')
    print('Check: c ~ mu A B^2 / h^3 has units Pa s m^2 m^2 / m^3 = N s / m.  OK')

def stiffness_perturbation():
    section('4. Film stiffness by perturbation')
    W = Function('W')(h)
    print('k = -dW/dh  ~  (W(h0) - W(1.03 h0)) / (0.03 h0)   (second solve, warm-started from the converged field)')
    print('Solve the perturbed case AFTER the main solve so both share the same convergence state; otherwise the sign can flip.')

def gw_contact():
    """GW: p_a = (4/3) E' eta beta^0.5 sigma^1.5 F_{3/2}(lambda). Fit used: F_{3/2} ~ 4.4086e-5 (4-lambda)^6.804 for lambda<4."""
    section('5. Greenwood-Williamson asperity pressure and the closed-form fit')
    lam, s = symbols('lambda s', positive=True)
    F32 = integrate((s - lam)**Rational(3, 2) * exp(-s**2 / 2) / sqrt(2 * pi), (s, lam, sp.oo))
    print('F_3/2(lambda) =', F32)
    fit = 4.4086e-5 * (4 - lam)**6.804
    for L in [1.0, 2.0, 3.0]:
        print(f'  lambda={L}: exact {float(F32.subs(lam, L)):.5e}   fit {float(fit.subs(lam, L)):.5e}')
    print('Page: pa = E\'K * 4.4086e-5 * (4-lambda)^6.804 for lambda < 4, capped at PA_MAX (yield).')

def thermal_update():
    """Per-cell energy balance with conduction; explicit vs implicit-consistent update."""
    section('6. Cell thermal update and why the conduction term must be implicit')
    C, hA, K, Toil, Tp, Tm, Ti, q, f, dt = symbols('C hA K T_oil T_p T_m T_i q f dt', positive=True)
    Tss_explicit = Toil + (f * q + K * (Tp + Tm - 2 * Ti)) / hA
    Tss_implicit = (hA * Toil + f * q + K * (Tp + Tm)) / (hA + 2 * K)
    print('explicit form  T_ss =', Tss_explicit)
    print('implicit form  T_ss =', Tss_implicit)
    gain_e = sp.diff(Tss_explicit, Tp); gain_i = sp.diff(Tss_implicit, Tp)
    print('gain dT_ss/dT_neighbour: explicit', gain_e, ' implicit', gain_i)
    print('Explicit diverges when K/hA > 1/2 (page values K=0.4/8 per ring, hA=25/960 -> ratio ~2). Use the implicit form.')
    print('Update: T += (T_ss - T)(1 - exp(-dte/tau)), tau = C/(hA + 2K)')

def walther():
    section('7. Walther viscosity law (ASTM D341) from two data points')
    nu40, nu100, T = symbols('nu40 nu100 T', positive=True)
    A, Bw = symbols('A B')
    f = lambda v: log(log(v + 0.7, 10), 10)
    sol = sp.solve([Eq(f(nu40), A - Bw * log(313.15, 10)), Eq(f(nu100), A - Bw * log(373.15, 10))], [A, Bw])
    print('A =', sol[A]); print('B =', sol[Bw])
    print('nu(T) = 10^(10^(A - B log10 T)) - 0.7 ;  mu = nu * 1e-6 * rho(T), rho = rho15 (1 - 0.00065 (T-15))')
    for name, (n40, n100) in {'0W-20': (44, 8.5), '20W-50': (170, 19)}.items():
        Av, Bv = [float(sol[k].subs({nu40: n40, nu100: n100})) for k in (A, Bw)]
        nu = lambda TC: 10**(10**(Av - Bv * sp.log(TC + 273.15, 10).evalf())) - 0.7
        print(f'  {name}: nu(-20C) = {float(nu(-20)):.0f} cSt, nu(130C) = {float(nu(130)):.1f} cSt')

def rate_laws():
    section('8. Rate laws as ODEs on the engine-hours clock')
    Kw, pa, u, Y, Cpl, dte = symbols('K_w p_a u Y C_pl dt_e', positive=True)
    print('Archard:        dw/dt = K_w p_a u               [1/Pa * Pa * m/s = m/s]  ->  dw = K_w pa om r dte')
    print('Plastic flow:   d delta/dt = C_pl max(0, p_a/Y - 1)   [m/s]; rims += PILEUP * d delta / 4 on four neighbours')
    print('Brinelling:     V = K_imp (1/2 m v^2) / Y            [J / Pa = m^3], spread by p_a share, cap per cell')
    print('Scuffing:       dw += K_sc u dt_e if T > T_sc and lambda < 1.2; sigma *= (1 + ROUGH * u dt_e)')
    print('Corrosion:      dw = K_c exp(-Ea/R (1/T - 1/T_ref)) (1 + a TAN + b water + c fuel) (1 + SYN * contact) dt_e/3600')
    print('Fatigue:        dD = (omega/2 pi) dt_e / N_f,  N_f = N_ref (S_f/p_max)^b  (Basquin + Miner)')
    print('Groove depth:   d = d0 - rims_in_groove + 0.5 wall_flow;  Q_g ∝ (d/d0)^3   (laminar channel conductance)')

def end_play_thermal():
    section('9. Thermal end play')
    aAl, aFe, L, dT = symbols('alpha_Al alpha_Fe L Delta_T', positive=True)
    print('EP(T) = EP0 + (alpha_Al - alpha_Fe) L Delta_T ;  (23e-6 - 12e-6) * 30 mm ~ 0.33 um/K  -> page K_EP_T = 0.2 um/K (part of the span is the crank flange)')

def units_check():
    section('10. Dimensional checks (sympy.physics.units)')
    from sympy.physics.units import Pa, s as sec, m, N, kg, K as kelvin, W as watt, J
    checks = {
        'mu*omega*r^2/h *dA  -> W': (Pa * sec) * (1 / sec) * m**2 / m * m**2,
        'K_w p_a u  -> m/s': (1 / Pa) * Pa * (m / sec),
        'c = 3 mu A B^2 / h^3  -> N s/m': (Pa * sec) * m**2 * m**2 / m**3,
        'h^3/(12 mu) dp/dr  -> m^2/s': m**3 / (Pa * sec) * Pa / m,
        'E_imp / Y  -> m^3': J / Pa,
    }
    for name, expr in checks.items():
        print(f'  {name}: {sp.simplify(expr)}')

if __name__ == '__main__':
    qth, qr = velocity_profile(); reynolds_polar(qth, qr); squeeze_damping(); stiffness_perturbation(); gw_contact(); thermal_update(); walther(); rate_laws(); end_play_thermal(); units_check()
    print('\nDone. Paste the .eq strings into the page; copy the stencil and rate expressions into physics() / kernels.')
