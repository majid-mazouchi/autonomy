#!/usr/bin/env python3
"""Extract the first <script> block of an HTML page and run `node --check` on it.
Usage: js_check.py page.html [out.js]"""
import re, subprocess, sys
html = open(sys.argv[1], encoding="utf-8").read()
blocks = re.findall(r"<script>(.*?)</script>", html, re.S)
if not blocks:
    sys.exit("no inline <script> block found")
out = sys.argv[2] if len(sys.argv) > 2 else "/tmp/_page_script.js"
open(out, "w").write(max(blocks, key=len))
r = subprocess.run(["node", "--check", out], capture_output=True, text=True)
print(r.stderr or f"OK  {out}  ({len(blocks)} script blocks, largest checked)")
sys.exit(r.returncode)
