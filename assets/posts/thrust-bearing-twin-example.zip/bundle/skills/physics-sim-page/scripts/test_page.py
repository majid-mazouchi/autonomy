#!/usr/bin/env python3
"""Headless browser test for a simulation page.
Usage: test_page.py page.html [--three /tmp/three.min.js] [--actions actions.json]
Reports page errors, HUD text before/after actions, downloads, screenshots at desktop and phone widths.
actions.json: [{"set":"sev","value":60}, {"check":"fm_debris"}, {"select":"drive","value":"urban"},
               {"tab":"record"}, {"click":"btnRec"}, {"wait":4000}, {"download":"btnRecDl"}, {"shot":"polar"}, {"text":"hud"}]"""
import argparse, json, os, subprocess, sys
ap = argparse.ArgumentParser(); ap.add_argument("page"); ap.add_argument("--three", default="/tmp/three.min.js")
ap.add_argument("--actions"); ap.add_argument("--out", default="/tmp/pagetest"); a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
if not os.path.exists(a.three):   # cdnjs is usually blocked in sandboxes; fetch three via npm
    subprocess.run("cd /tmp && npm pack three@0.128.0 -q && tar xzf three-0.128.0.tgz package/build/three.min.js && cp package/build/three.min.js /tmp/three.min.js", shell=True)
html = open(a.page, encoding="utf-8").read()
import re
html = re.sub(r"https://cdnjs\.cloudflare\.com/ajax/libs/three\.js/r128/three\.min\.js", "file://" + a.three, html)
test = os.path.join(a.out, "test.html"); open(test, "w", encoding="utf-8").write(html)
from playwright.sync_api import sync_playwright
acts = json.load(open(a.actions)) if a.actions else [{"wait": 3000}, {"text": "hud"}]
with sync_playwright() as p:
    b = p.chromium.launch(args=["--use-gl=swiftshader", "--enable-webgl", "--ignore-gpu-blocklist"])
    pg = b.new_page(viewport={"width": 1200, "height": 1400}, accept_downloads=True)
    errs = []; pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto("file://" + test); pg.wait_for_timeout(2500)
    for act in acts:
        if "set" in act:
            pg.evaluate(f"()=>{{const s=document.getElementById('{act['set']}'); s.value={act['value']}; s.dispatchEvent(new Event('input')); s.dispatchEvent(new Event('change'));}}")
        elif "check" in act: pg.check("#" + act["check"])
        elif "select" in act: pg.select_option("#" + act["select"], act["value"])
        elif "click" in act: pg.click("#" + act["click"])
        elif "tab" in act: pg.click(f"[data-tab={act['tab']}]")
        elif "js" in act: print("[js]", pg.evaluate(act["js"]))
        elif "wait" in act: pg.wait_for_timeout(act["wait"])
        elif "text" in act: print(f"[{act['text']}] " + pg.inner_text("#" + act["text"]).replace("\n", " | ")[:400])
        elif "download" in act:
            with pg.expect_download() as d: pg.click("#" + act["download"])
            path = d.value.path(); txt = open(path, errors="replace").read(); print(f"[download {act['download']}] {len(txt)} bytes, first line: {txt.splitlines()[0][:120]}")
        elif "shot" in act:
            pg.evaluate(f"()=>document.getElementById('{act['shot']}').scrollIntoView()"); pg.wait_for_timeout(300)
            pg.locator("#" + act["shot"]).screenshot(path=os.path.join(a.out, act["shot"] + ".png")); print(f"[shot] {act['shot']}.png")
    pg.screenshot(path=os.path.join(a.out, "desktop.png"), full_page=False)
    pm = b.new_page(viewport={"width": 390, "height": 844}); pm.goto("file://" + test); pm.wait_for_timeout(2500)
    pm.screenshot(path=os.path.join(a.out, "phone.png"))
    print("ERRORS:", errs if errs else "none"); b.close()
sys.exit(1 if errs else 0)
