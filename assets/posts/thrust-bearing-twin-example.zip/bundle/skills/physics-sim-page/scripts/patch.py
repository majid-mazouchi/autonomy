#!/usr/bin/env python3
"""Patch helper for simulation pages. Import or copy into a patch script:

    from patch import Patcher
    p = Patcher('page-v3.html', 'page-v4.html')
    p.rep(old, new)                 # asserts old occurs exactly once
    p.cal_refactor(['EP0', 'TAPER'])  # rewrite bare NAME -> CAL.NAME inside the script
    p.save()

Always grep the current text before writing `old`; never patch by line number."""
import re, sys


class Patcher:
    def __init__(self, src, dst=None):
        self.src, self.dst = src, dst or src
        self.s = open(src, encoding="utf-8").read()

    def rep(self, old, new, count=1):
        n = self.s.count(old)
        assert n == 1 or (count == n), f"expected 1 match, found {n}:\n{old[:90]}"
        self.s = self.s.replace(old, new, count)
        return self

    def cal_refactor(self, names, cal_def_marker="const CAL_DEF=["):
        """Replace bare identifiers with CAL.<name> after the CAL_DEF block, leaving strings alone."""
        i = self.s.index("<script>")
        a = self.s.index(cal_def_marker, i); b = self.s.index("const CAL={", a)
        head, block, rest = self.s[:a], self.s[a:b], self.s[b:]
        for n in names:
            rest = re.sub(r"(?<![\w.'\"])" + re.escape(n) + r"(?![\w'\"])", "CAL." + n, rest)
        self.s = head + block + rest
        return self

    def save(self):
        open(self.dst, "w", encoding="utf-8").write(self.s)
        print("saved", self.dst)


if __name__ == "__main__":
    print(__doc__)
