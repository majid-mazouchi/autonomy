---
name: physics-sim-page
description: Build, extend and test self-contained interactive 3D physics simulation pages (Three.js + a real numerical model + VHM-style signals) in Majid's house style. Use this whenever the user asks for a 3D simulation, animated physics demo, digital-twin page, engine/bearing/motor/battery simulation, "add failure modes", "make parameters calibratable", "add measurements like CANape", or wants to test/fix such a page headlessly. Also use it when adding physics (Reynolds, contact, thermal, wear, combustion) to an existing HTML page, even if the user does not say "simulation".
---

# Physics simulation page

One HTML file, no build step, Three.js r128 from cdnjs, the physics written by hand
in the page, every coefficient calibratable, every internal signal measurable and
recordable. The thrust-bearing / crank-walk page (v1 to v5) is the reference build;
`assets/page-skeleton.html` is a stripped, runnable template of the same architecture.

## Workflow

1. **Plan before code.** List the physical effects to model, the state each one
   adds, the signals it exposes, and the failure modes it enables. Show the plan
   and the formula list (equation + one paragraph of why) before building. Users
   of this style expect "plan, then formulas, then build".
1b. **Derive symbolically before coding.** Run or extend `scripts/symbolic_derive.py`
   (sympy): conservation law → written assumptions → reduced equation → stencil →
   stability/sign check → units → value at the default operating point. See
   `references/symbolic-physics.md`; it lists what this caught (explicit conduction
   divergence, stiffness-solve order, GW fit error at λ = 3). Coefficients that
   cannot be derived go in CAL_DEF and are declared order-of-magnitude.
2. **Start from the skeleton** (`assets/page-skeleton.html`) or from the latest
   version of the page being extended. Copy to a new version file
   (`name-vN.html`); never overwrite the previous version.
3. **Add physics as functions of state**, not as animation tricks. See
   `references/architecture.md` for the P / S / CAL / SIG / FM contract that keeps
   the page extensible, and `references/physics-checklist.md` for the effects that
   usually matter and the numerical traps met so far.
4. **Refactor constants into `CAL_DEF`** the moment a second version is requested;
   `scripts/patch.py` has the regex helper that rewrites `NAME` to `CAL.NAME`
   safely.
5. **Test headless before presenting.** Run `scripts/js_check.py` (syntax),
   `scripts/physics_harness.js` (physics in Node with DOM/THREE stubs, prints
   ms/frame and key state), then `scripts/test_page.py` (Playwright + SwiftShader:
   page errors, HUD text, control interaction, screenshots, downloads). Compare
   the new version's steady-state numbers with the previous version's.
6. **Write the explanation sections**: each new effect gets an `.eq` block and a
   `.why` paragraph; each failure mode gets mechanism + equation. State which
   coefficients are order-of-magnitude placeholders.
7. Present the file with `present_files`; summarise what changed, what was
   verified, and the honest caveats. No "Drafted with AI" credits anywhere.

## Reference build

`assets/thrust-bearing-crank-walk-v17.html` is the finished reference (two Reynolds faces,
per-cell thermal, flow-resolved starvation, deformation and debris, oil grades and cold
start, film-gap micro view, FEA/wireframe styles, layers, undock, folding, structural mode and boundary chatter, speed sweep with a Campbell diagram) and
`assets/thrust-bearing-causal-graph.html` is its causal block diagram. Read
`references/film-gap-microview.md`, `references/deformation-damage.md`,
`references/rendering-pitfalls.md` and `references/causal-graph.md` before extending either.

## Patching an existing page

Patches are Python scripts using an asserting `rep(old, new)` helper (see
`scripts/patch.py`). Save the script to a file before running it so a failed
assertion can be fixed and re-run; a heredoc that fails halfway leaves the file
untouched but the script lost. Grep for the exact current text first; the page
changes between versions and remembered text is often stale. Never edit with
line numbers.

## Testing checklist (all in scripts/)

- `js_check.py page.html` extracts the script block and runs `node --check`.
- `physics_harness.js` evaluates the page's IIFE with stubs, exposes `P`, `S`,
  `CAL`, `physics`; use it to compare versions and to profile. Set `P` to the
  real scenario before the first `physics()` call, or the stub's string values
  produce nonsense.
- `test_page.py page.html` runs Chromium headless with `--use-gl=swiftshader`.
  cdnjs is usually blocked in sandboxes: the script swaps the Three.js URL for a
  local copy fetched with `npm pack three@0.128.0`. Frame rate under SwiftShader
  is 1-5 fps, so judge physics with the Node harness and use the browser for
  errors, layout and interaction.
- Screenshot at 1200 px and 390 px widths; check the HUD does not overlap the
  view bar on mobile.
- Exercise downloads with Playwright's `expect_download` and check the CSV header.

## Vibration and modes
A quasi-static film solve plus a stiff axial ODE gives you excitation, not resonance. To answer
"can it resonate", add the modes that actually carry the load: a lumped structural mass on a modal
spring (flexplate / clutch pack) and, for boundary contact, the tangential mode of the part on its
own mount with a velocity-weakening friction law. Integrate a kHz mode with its own inner substeps
and a symplectic step: an implicit step at the outer rate adds numerical damping and erases the
limit cycle you are trying to find. Build the Campbell diagram analytically (settle at each speed,
read k and c from the solver, Fourier-analyse the forcing over one cycle, evaluate the 2-DOF FRF
at each order line); use a brute-force kHz sweep with FFT in the batched solver as the cross-check.

## Numerical rules learned the hard way

- Clamp frame `dt` to 50 ms; substep dynamics at 2.5e-4 s with a linearly
  implicit Euler using film stiffness from a second solve at 1.03 h0.
- Cap solved film pressure (P_CAP) as a stand-in for elastic deformation, or
  impacts spike the rigid solve.
- Conduction terms must be in the implicit denominator:
  `T = (hA*Toil + q + K*(Tp+Tm)) / (hA + 2K)`, never `Toil + K*lap/hA`.
- Per-cycle random events need a phase accumulator (`cycPh += om*dt`), not
  `floor(angle / 4pi)`, because the visual angle wraps.
- Time warp multiplies dt for wear, thermal and fatigue only.
- When a chart shows a 720 degree cycle, build a 720-entry table and index it;
  do not evaluate pulse functions per pixel.

## Style

House style tokens and typography are in `references/house-style.md`. Light
paper aesthetic, Fraunces / Spectral / IBM Plex Mono, rust / teal / ochre
accents, byline "By <name> · <date>". Explanations in plain prose; no bullet
lists inside the page body except parameter tables.
