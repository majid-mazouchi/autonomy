"""Drive cycles as (name, seconds, rpm, load %, pedal) segments; same four as the page,
plus 'steady'. schedule() expands one to per-step arrays with the driver's lag."""
import numpy as np

CYCLES = {
    "urban": [("idle, pedal down", 4, 800, 3, 1), ("launch", 5, 2500, 75, 0), ("accelerate", 6, 3200, 60, 0),
              ("shift, pedal", 1.2, 2600, 10, 1), ("cruise 50 km/h", 10, 1900, 25, 0),
              ("brake to stop, pedal", 5, 1000, 0, 1), ("idle", 4, 800, 3, 0)],
    "highway": [("merge", 8, 3800, 85, 0), ("cruise", 25, 2400, 35, 0), ("overtake", 6, 3600, 80, 0),
                ("cruise", 20, 2400, 35, 0), ("exit, pedal", 3, 1500, 5, 1)],
    "launch": [("stage, rev, pedal down", 3, 3500, 20, 1), ("launch, slipping", 2, 4200, 100, 0.5),
               ("pull", 6, 5800, 100, 0), ("shift, pedal", 0.8, 5000, 10, 1), ("pull", 5, 5800, 100, 0),
               ("lift, coast", 6, 2000, 0, 0), ("idle, pedal down", 5, 900, 3, 1)],
    "tow": [("pull away, slip", 4, 2000, 90, 0.4), ("climb", 30, 2800, 95, 0), ("downshift, pedal", 1.5, 2200, 20, 1),
            ("climb", 30, 3400, 100, 0), ("crest, cruise", 15, 2200, 40, 0)],
}


def schedule(name: str, dt: float, duration: float, rpm=1200.0, load=40.0, pedal_period=4.0):
    """Returns rpm[n], load[n], pedal[n], seg_index[n] at step dt over `duration` seconds.
    'steady' gives constant rpm/load with the page's 4 s sinusoidal pedal cycle."""
    n = int(round(duration / dt))
    t = np.arange(n) * dt
    if name == "steady":
        ped = 0.5 * (1 + np.sin(2 * np.pi * t / pedal_period))
        return (np.full(n, rpm, np.float32), np.full(n, load, np.float32), ped.astype(np.float32),
                np.zeros(n, np.int32))
    segs = CYCLES[name]
    total = sum(s[1] for s in segs)
    R = np.zeros(n, np.float32); L = np.zeros(n, np.float32); Ptgt = np.zeros(n, np.float32); SI = np.zeros(n, np.int32)
    for k in range(n):
        tt = t[k] % total
        i = 0
        while tt > segs[i][1]:
            tt -= segs[i][1]; i = (i + 1) % len(segs)
        cur, prev = segs[i], segs[i - 1]
        u = min(1.0, tt / max(0.5, cur[1] * 0.6))
        R[k] = prev[2] + (cur[2] - prev[2]) * u
        L[k] = prev[3] + (cur[3] - prev[3]) * u
        Ptgt[k] = cur[4]; SI[k] = i
    ped = np.zeros(n, np.float32); p = Ptgt[0]
    a = 1 - np.exp(-dt / 0.25)
    for k in range(n):
        p += (Ptgt[k] - p) * a; ped[k] = p
    return R, L, ped, SI
