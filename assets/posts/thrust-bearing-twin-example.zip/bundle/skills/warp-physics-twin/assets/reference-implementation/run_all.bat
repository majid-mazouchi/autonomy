@echo off
cd /d %~dp0
python -m pip install -q -r requirements.txt
echo == verify && python verify.py || exit /b 1
echo == dataset && python -c "from thrust_warp.dataset import generate; generate('thrust_dataset.npz', B=4, steps=60, cycles=('urban','launch'), pre_age_h=5)"
echo == fleet && python -c "from thrust_warp.fleet import run_fleet, summary; import numpy as np; r=run_fleet(B=8, hours=60, warp=3000); print(summary(r)); np.savez('fleet_result.npz', **{k:v for k,v in r.items()})"
echo == calibration && python -c "from thrust_warp.calibrate import fit; cal,J=fit([0,10,20,30],[0.100,0.104,0.109,0.115], free=('KW_OV','KW_BK'), iters=1, warp=3000); print('identifiability:', (J**2).sum(0)**0.5)"
echo == twin && python -c "from thrust_warp.twin import demo; print(demo(N=16, steps=20))"
echo done
