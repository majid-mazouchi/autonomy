"""Interventions and matched counterfactuals: the do-operator for this model.

A causal graph alone cannot answer "would the film have collapsed without the dent". A
simulator can, provided the factual and counterfactual runs are matched: same build spread,
same duty schedule, same random draws. This module runs both arms in one batch with the same
seed, so any difference between them is the intervention and nothing else.

    from thrust_warp.intervene import Intervention, compare
    res = compare(base=Intervention(),                       # factual
                  alt=Intervention(dent=0.0),                # counterfactual: no dent
                  schedule=[(750, 12, 0.0, 95, 200.0)], hours=400)
    print(res["summary"])

`effect(...)` sweeps one intervention over a range and returns the response curve of each
observable: the agent's "how much does this cause matter" query.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
import numpy as np
from .calibration import Calibration, IDX
from .simulator import Simulator
from . import kernels as K
from .study import MODES, FM_OF, SCHEDULE

OBS = ["end_play_mm", "lambda", "h_min_um", "wear_max_um", "T_face_C", "p_gallery_bar", "ckp_jitter_us",
       "vib_rms", "debris_ppm", "fill_min", "plastic_max_um", "scuffed_cells", "fatigue_D", "chatter_rms_rad_s"]


@dataclass
class Intervention:
    """A set of do-operations. None means 'leave at the factual value'."""
    dent: float | None = None
    fm: dict = field(default_factory=dict)          # e.g. {"lowoil": 0.8}
    cal: dict = field(default_factory=dict)         # e.g. {"KW_OV": 8e-16, "EP0": 0.12e-3}
    grade: str | None = None
    tamb: float | None = None

    def describe(self):
        p = []
        if self.dent is not None: p.append(f"dent={self.dent:.2f}")
        p += [f"{k}={v:.2f}" for k, v in self.fm.items()]
        p += [f"{k}={v:.3g}" for k, v in self.cal.items()]
        if self.grade: p.append(self.grade)
        if self.tamb is not None: p.append(f"tamb={self.tamb:g}C")
        return ", ".join(p) or "factual"


def _apply(sim, arms, n_each, base_dent, base_fm, calv):
    dent = np.repeat(base_dent, 1).astype(np.float32).copy()
    dent = np.tile(dent, len(arms) * n_each // max(1, len(dent)))[:len(arms) * n_each].copy()
    fm = np.tile(base_fm, (len(arms) * n_each // max(1, len(base_fm)), 1))[:len(arms) * n_each].copy()
    cal = calv.copy()
    for a, iv in enumerate(arms):
        sl = slice(a * n_each, (a + 1) * n_each)
        if iv.dent is not None: dent[sl] = iv.dent
        for k, v in iv.fm.items(): fm[sl, FM_OF[k]] = v
        for k, v in iv.cal.items(): cal[sl, IDX[k]] = v
    return dent, fm, cal


def compare(base: Intervention = None, alt: Intervention = None, arms=None, n_each=8, hours=300.0, stress=0.0,
            schedule=None, dent0=0.5, fm0=None, seed=0, cal=None, device=None, steps=400, verbose=True):
    """Run every arm from the same build spread and duty schedule and report the differences."""
    arms = arms or [base or Intervention(), alt or Intervention()]
    # the pedal-held segment is the damaging one; weight the hours the way a real duty cycle does
    # Duty weights. The pedal-held hot idle (last segment) is the abuse condition; with the model's
    # present wear constants it drives the face into runaway within an hour, so it is OFF by default.
    # Add it deliberately (`stress=0.01`) when the question is about that condition.
    W = [0.40, 0.40, 0.20 - stress, stress]
    schedule = schedule or [s + (hours * w,) for s, w in zip(SCHEDULE, W)]
    rng = np.random.default_rng(seed)
    B = len(arms) * n_each
    calv = (cal or Calibration()).batch(B)
    spread = rng.normal(1.0, 0.08, n_each)                       # identical build spread in every arm
    calv[:, IDX["EP0"]] *= np.tile(spread, len(arms))
    calv[:, IDX["KW_OV"]] *= np.tile(np.exp(rng.normal(0, 0.3, n_each)), len(arms))
    base_fm = np.zeros((B, K.NFM), np.float32)
    if fm0:
        for k, v in fm0.items(): base_fm[:, FM_OF[k]] = v
    dent, fm, calv = _apply(None, arms, n_each, np.full(B, dent0, np.float32), base_fm, calv)
    sim = Simulator(B, calv, device=device, seed=seed)
    for a, iv in enumerate(arms):
        if iv.grade:
            g = Simulator(1, device=device); c2 = sim.cal_np.copy()
            GR = {"0W-20": (44, 8.5), "5W-30": (64, 10.8), "10W-40": (96, 14.5), "15W-40": (108, 14.8), "20W-50": (170, 19)}
            c2[a * n_each:(a + 1) * n_each, IDX["NU40"]], c2[a * n_each:(a + 1) * n_each, IDX["NU100"]] = GR[iv.grade]
            sim.set_calibration(c2)
    per_seg = max(1, steps // len(schedule))
    for (r, l, p, t, h) in schedule:
        sim.set_scenario(rpm=r, load=l, pedal=p, toil=t, sev=dent, fm=fm)
        for _ in range(25):
            sim.step(1 / 120, warp=0.0)      # settle at the new operating point BEFORE accumulating wear:
        for _ in range(per_seg):             # a warped step taken during the transient ages the face by hours of the transient
            sim.step(1 / 60, warp=h * 3600.0 * 60.0 / per_seg)
        if verbose:
            print(f"  {r} rpm segment done")
    s = sim.signals()
    per_arm = {ob: np.array([float(np.mean(s[ob][a * n_each:(a + 1) * n_each])) for a in range(len(arms))]) for ob in OBS}
    lines = [f"{len(arms)} arms x {n_each} vehicles, {hours:.0f} engine hours, matched build spread and seed", ""]
    lines.append("observable".ljust(20) + "".join(f"{('arm'+str(i)):>12s}" for i in range(len(arms))) + "   effect vs arm0")
    for ob in OBS:
        v = per_arm[ob]
        eff = v - v[0]
        lines.append(ob.ljust(20) + "".join(f"{x:12.3f}" for x in v) + "   " + " ".join(f"{e:+.3f}" for e in eff[1:]))
    lim = float(np.max(s["warp_limited_cells"]))
    if lim > 0:
        lines += ["", f"NOTE: the wear step limiter fired on up to {lim:.0f} cells: the time warp is too coarse for",
                  "this duty and the wear is under-integrated. Increase `steps` until it reads zero."]
    cap = float(np.max(s["wear_max_um"]))
    if cap > 1100:
        lines += ["", "WARNING: wear has hit the model's 1200 um cap in at least one arm. The comparison is",
                  "saturated and the ordering between arms is meaningless; shorten `hours` or soften the schedule."]
    lines += [""] + [f"arm{i}: {iv.describe()}" for i, iv in enumerate(arms)]
    return {"arms": [iv.describe() for iv in arms], "values": per_arm, "summary": "\n".join(lines), "signals": s, "n_each": n_each}


def effect(knob="dent", values=(0.0, 0.2, 0.4, 0.6, 0.8, 1.0), n_each=6, **kw):
    """Response curve of every observable to one cause: the dose-response an agent needs to rank causes."""
    arms = [Intervention(dent=v) if knob == "dent" else
            (Intervention(fm={knob: v}) if knob in FM_OF else Intervention(cal={knob: v})) for v in values]
    res = compare(arms=arms, n_each=n_each, **kw)
    res["knob"] = knob
    res["dose"] = list(values)
    res["curves"] = {ob: [float(x) for x in res["values"][ob]] for ob in OBS}
    # monotone sensitivity: change per unit dose, normalised by the healthy value
    res["gain"] = {ob: float((res["curves"][ob][-1] - res["curves"][ob][0]) / (abs(res["curves"][ob][0]) + 1e-9)) for ob in OBS}
    return res


def effect_text(res):
    out = [f"dose-response of '{res['knob']}'", "", "observable".ljust(20) + "".join(f"{d:>10.2f}" for d in res["dose"]) + "   relative change"]
    for ob in OBS:
        c = res["curves"][ob]
        out.append(ob.ljust(20) + "".join(f"{x:10.3f}" for x in c) + f"   {res['gain'][ob]:+.2f}")
    return "\n".join(out)
