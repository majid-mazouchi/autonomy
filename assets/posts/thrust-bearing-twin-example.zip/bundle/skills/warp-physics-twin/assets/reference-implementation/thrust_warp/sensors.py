"""Production sensor layer.

The simulator reports quantities a test cell can measure. A vehicle reports far fewer, at
CAN rates, quantized, noisy and sometimes missing. Everything downstream of this module
(discriminability studies, classifiers, the RCA agent) should see only what a vehicle sees,
or the study will credit features that do not exist in the field.

    from thrust_warp.sensors import PRODUCTION, SensorBus
    bus = SensorBus(PRODUCTION, seed=0)
    row = bus.sample(sim.signals(), t_seconds)      # dict of channel -> value or nan

Channel spec: (name, source signal, unit, sigma_noise, resolution, rate_Hz, drop_prob, drift_per_h, lag_s)
`sigma_noise` is 1-sigma additive noise in the channel's own unit; `resolution` is the
quantization step; `rate_Hz` is the broadcast rate (values are held between updates);
`drop_prob` is the chance a frame is missing; `drift_per_h` is a slow bias in units per hour.
"""
from __future__ import annotations
import numpy as np

# name,             source,             unit,  sigma,  resol,  rate,  drop,   drift/h, lag_s
PRODUCTION = [
    ("rpm",         "rpm",              "rpm",   2.0,    1.0,  100.0, 0.000,  0.0,     0.00),
    ("engine_load", "load",             "%",     1.0,    0.4,   50.0, 0.000,  0.0,     0.05),
    ("oil_press",   "p_gallery_bar",    "bar",   0.06,   0.05,  10.0, 0.002,  0.01,    0.20),
    ("oil_temp",    "T_oil",            "C",     0.8,    1.0,    1.0, 0.001,  0.05,    5.00),
    ("ckp_jitter",  "ckp_jitter_us",    "us",    3.0,    0.5,   50.0, 0.005,  0.0,     0.00),
    ("ckp_amp",     "ckp_amp",          "-",     0.02,   0.004, 50.0, 0.005,  0.0,     0.00),
    ("knock_rms",   "vib_rms",          "g",     0.05,   0.01,  20.0, 0.002,  0.0,     0.00),
    ("misfire_rate","misfire",          "-",     0.01,   0.02,   1.0, 0.000,  0.0,     0.00),
]
# Channels a test cell has but a vehicle does not - kept for "what if we added this sensor" studies.
OPTIONAL = [
    ("thrust_temp", "T_face_C",         "C",     1.5,    0.5,    5.0, 0.002,  0.2,     1.00),
    ("axial_accel", "acc_inst_g",       "g",     0.01,   0.002, 500.0, 0.001, 0.0,     0.00),
    ("oil_debris",  "debris_ppm",       "ppm",   3.0,    1.0,    0.1, 0.010,  0.5,    30.00),
    ("end_play",    "end_play_mm",      "mm",    0.004,  0.001,  0.02, 0.05,  0.0,     0.00),
]


class SensorBus:
    def __init__(self, channels=PRODUCTION, seed=0, B=1):
        self.ch = list(channels); self.rng = np.random.default_rng(seed); self.B = B
        self._last_t = {c[0]: -1e9 for c in self.ch}
        self._held = {c[0]: None for c in self.ch}
        self._filt = {c[0]: None for c in self.ch}
        self._drift0 = {c[0]: self.rng.normal(0, 1, B) for c in self.ch}

    def sample(self, signals: dict, t: float, hours: float = 0.0):
        """signals: the simulator's signals() dict (arrays of length B). Returns {channel: array}."""
        out = {}
        for name, src, unit, sig, res, rate, drop, drift, lag in self.ch:
            raw = np.asarray(signals.get(src, np.zeros(self.B)), float).reshape(-1)
            if lag > 0:                                    # first-order sensor lag
                prev = self._filt[name]
                a = 1.0 - np.exp(-max(1e-6, t - max(self._last_t[name], 0.0)) / lag) if prev is not None else 1.0
                self._filt[name] = raw if prev is None else prev + a * (raw - prev)
                raw = self._filt[name]
            if t - self._last_t[name] < 1.0 / rate:        # held between broadcasts
                out[name] = self._held[name] if self._held[name] is not None else np.full(raw.shape, np.nan)
                continue
            self._last_t[name] = t
            v = raw + self.rng.normal(0, sig, raw.shape) + drift * hours * self._drift0[name][:len(raw)]
            if res > 0:
                v = np.round(v / res) * res
            if drop > 0:
                v = np.where(self.rng.random(v.shape) < drop, np.nan, v)
            self._held[name] = v
            out[name] = v
        return out

    def names(self):
        return [c[0] for c in self.ch]


def record(sim, seconds=20.0, dt=1 / 50, channels=PRODUCTION, warp=0.0, seed=0, duty=None):
    """Run the simulator and return a (B, n_samples, n_channels) array of sensor readings.
    `duty` is an optional callable (t) -> dict of set_scenario kwargs."""
    bus = SensorBus(channels, seed=seed, B=sim.B)
    n = int(seconds / dt); rows = []
    for i in range(n):
        if duty is not None:
            sim.set_scenario(**duty(i * dt))
        sim.step(dt, warp=warp)
        s = sim.signals()
        r = bus.sample(s, i * dt, hours=float(np.mean(s["t_eng_h"])))
        rows.append(np.stack([r[c] for c in bus.names()], -1))
    return np.stack(rows, 1), bus.names()
