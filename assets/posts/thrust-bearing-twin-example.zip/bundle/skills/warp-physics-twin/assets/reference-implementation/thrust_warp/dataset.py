"""Labelled dataset generation for KNO/FNO/PINN training: random failure modes and severities,
drive cycles, time warp; saves signals (N, T, NSIG), labels and pressure fields."""
from __future__ import annotations
import numpy as np
from .calibration import Calibration
from .simulator import Simulator, SIGNALS
from .drive_cycles import schedule, CYCLES
from . import kernels as K

MODES = ["dent", "aeration", "debris", "dilution", "preload", "misalignment", "misfire", "fatigue", "tilt", "runout", "spin", "lowoil"]


def random_scenarios(B: int, rng: np.random.Generator, p_healthy=0.3):
    """Each vehicle gets 0-2 active modes. Returns scenario kwargs and a (B, len(MODES)) severity label."""
    lab = np.zeros((B, len(MODES)), np.float32)
    for b in range(B):
        if rng.random() < p_healthy:
            continue
        for m in rng.choice(len(MODES), size=rng.integers(1, 3), replace=False):
            lab[b, m] = rng.uniform(0.2, 1.0)
    fm = np.zeros((B, K.NFM), np.float32)
    fm[:, K.FM_AER] = lab[:, 1]; fm[:, K.FM_DEBRIS] = lab[:, 2]; fm[:, K.FM_DIL] = lab[:, 3]; fm[:, K.FM_PRE] = lab[:, 4]
    fm[:, K.FM_MIS] = lab[:, 5]; fm[:, K.FM_MISF] = lab[:, 6]; fm[:, K.FM_FAT] = lab[:, 7]; fm[:, K.FM_SPIN] = lab[:, 10]; fm[:, K.FM_LOWOIL] = lab[:, 11]
    scen = dict(sev=lab[:, 0], fm=fm, tilt_um=lab[:, 8] * 15.0, runout_um=2.0 + lab[:, 9] * 20.0,
                ra_um=rng.uniform(0.4, 1.2, B).astype(np.float32), toil=rng.uniform(90, 125, B).astype(np.float32))
    return scen, lab


def generate(path: str, B=32, cycles=("urban", "highway", "launch", "tow"), steps=600, dt=1.0 / 30.0, warp=200.0,
             save_pressure_every=50, seed=0, device=None, cal=None, verbose=True, pre_age_h=0.0, pre_age_warp=3000.0):
    rng = np.random.default_rng(seed)
    cal = cal or Calibration()
    X, Y, PR, CYC = [], [], [], []
    for ci, cyc in enumerate(cycles):
        scen, lab = random_scenarios(B, rng)
        sim = Simulator(B, cal, device=device, seed=seed + ci)
        R, L, P, _ = schedule(cyc, dt, steps * dt)
        if pre_age_h > 0:   # age every vehicle on random duty before recording the cycle
            Ra, La, Pa, _ = schedule(cyc, dt, 600.0)
            for i in rng.integers(0, len(Ra), size=int(pre_age_h * 3600 / (dt * pre_age_warp))):
                sim.set_scenario(rpm=Ra[i], load=La[i], pedal=Pa[i], **scen); sim.step(dt, pre_age_warp)
        sig = np.zeros((B, steps, len(SIGNALS)), np.float32); pr = []
        for k in range(steps):
            sim.set_scenario(rpm=R[k], load=L[k], pedal=P[k], **scen)
            sim.step(dt, warp)
            sig[:, k] = sim.signal_matrix()
            if save_pressure_every and k % save_pressure_every == 0:
                pr.append(sim.pressure(0))
        X.append(sig); Y.append(lab); PR.append(np.stack(pr, 1)); CYC.append(np.full(B, ci))
        if verbose:
            print(f"  {cyc:8s}  {B} vehicles x {steps} steps  end play {sig[:, -1, SIGNALS.index('end_play_mm')].mean():.3f} mm mean")
    np.savez_compressed(path, signals=np.concatenate(X), labels=np.concatenate(Y), pressure=np.concatenate(PR),
                        cycle=np.concatenate(CYC), signal_names=np.array(SIGNALS), mode_names=np.array(MODES),
                        cycle_names=np.array(cycles), dt=dt, warp=warp)
    return path
