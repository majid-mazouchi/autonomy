"""Synthetic dent / damage height maps for the rear face, (NT, NR) in metres.
Positive = recess below the face, negative = raised material (rim, burr) that touches first."""
import numpy as np
from .geometry import NT, NR, radii, RI, RO


def _grid():
    th = (np.arange(NT) + 0.5) * 360.0 / NT
    r = radii()
    return np.meshgrid(th, r, indexing="ij")


def _adiff(a, b):
    return np.abs((a - b + 180.0) % 360.0 - 180.0)


def dent_with_rim(center_deg=330.0, width_deg=30.0, depth=40e-6, rim_height=6e-6, rim_frac=0.25,
                  r_center=None, radial_width=None):
    """Impact dent: cosine-squared floor with a raised rim around it (plastic pile-up)."""
    th, r = _grid()
    rc = r_center or 0.5 * (RI + RO)
    rw = radial_width or (RO - RI) * 0.8
    u = _adiff(th, center_deg) / (width_deg / 2)
    v = np.abs(r - rc) / (rw / 2)
    rho = np.sqrt(u * u + v * v)
    floor = depth * np.cos(np.clip(rho, 0, 1) * np.pi / 2) ** 2 * (rho <= 1)
    rim = -rim_height * np.exp(-((rho - 1.0) / rim_frac) ** 2) * (rho > 0.7)
    return (floor + rim).astype(np.float32)


def score_line(angle_deg=200.0, depth=8e-6, width_deg=3.0):
    """Radial scratch from a hard particle dragged across the face."""
    th, r = _grid()
    return (depth * np.exp(-(_adiff(th, angle_deg) / width_deg) ** 2)).astype(np.float32)


def pitting(n=25, depth=10e-6, size_deg=2.0, seed=0):
    """Scattered corrosion / cavitation pits."""
    rng = np.random.default_rng(seed)
    th, r = _grid()
    out = np.zeros((NT, NR), np.float32)
    for _ in range(n):
        a = rng.uniform(0, 360); rr = rng.uniform(RI, RO)
        d = np.sqrt((_adiff(th, a) / size_deg) ** 2 + ((r - rr) / 2e-3) ** 2)
        out += depth * np.exp(-d * d)
    return out


def edge_burr(groove_index=0, height=5e-6, width_deg=2.0):
    """Raised burr on the trailing edge of a groove (machining or handling damage)."""
    th, r = _grid()
    a = groove_index * 60.0 + 7.0
    return (-height * np.exp(-(_adiff(th, a) / width_deg) ** 2)).astype(np.float32)
