"""Fleet Monte Carlo with the full solver: sample vehicles, run a drive cycle with time warp,
return time-to-limit, detection lead time and a survival curve."""
from __future__ import annotations
import numpy as np
from .calibration import Calibration, IDX
from .simulator import Simulator
from .drive_cycles import schedule


def sample_fleet(B: int, cal: Calibration, rng: np.random.Generator, defect_share=0.15, ep0_sigma_mm=0.03,
                 ra_sigma=0.25, toil_sigma=8.0):
    calv = cal.batch(B)
    calv[:, IDX["EP0"]] = np.maximum(0.04e-3, cal.EP0 + ep0_sigma_mm * 1e-3 * rng.standard_normal(B))
    scen = dict(
        ra_um=np.maximum(0.2, 0.8 * (1 + ra_sigma * rng.standard_normal(B))).astype(np.float32),
        toil=(110.0 + toil_sigma * rng.standard_normal(B)).astype(np.float32),
        sev=np.where(rng.random(B) < defect_share, rng.uniform(0.25, 0.6, B), 0.0).astype(np.float32),
        clutch_kN=np.maximum(2.0, 4.0 * (1 + 0.2 * rng.standard_normal(B))).astype(np.float32),
    )
    return calv, scen


def run_fleet(B=64, cycle="urban", hours=2000.0, warp=3000.0, dt=1.0 / 30.0, cal=None, seed=0, device=None,
              limit_mm=0.30, lam_thresh=1.5, ppm_thresh=40.0, verbose=True):
    cal = cal or Calibration()
    rng = np.random.default_rng(seed)
    calv, scen = sample_fleet(B, cal, rng)
    sim = Simulator(B, calv, device=device, seed=seed)
    R, L, P, _ = schedule(cycle, dt, 600.0)                  # 10 minutes of cycle, looped
    n_steps = int(hours * 3600.0 / (dt * warp))
    t_fail = np.full(B, np.nan); t_det = np.full(B, np.nan); low = np.zeros(B, int)
    # each step advances engine time by dt*warp, far more than one schedule step, so the duty
    # cycle is sampled at random instants instead of being played in order (unbiased duty mix)
    order = rng.integers(0, len(R), size=n_steps)
    for k in range(n_steps):
        i = int(order[k])
        sim.set_scenario(rpm=R[i], load=L[i], pedal=P[i], **scen)
        sim.step(dt, warp)
        s = sim.signals()
        t = s["t_eng_h"]
        low = np.where(s["lambda"] < lam_thresh, low + 1, 0)
        det = (low >= 5) | (s["debris_ppm"] > ppm_thresh)
        t_det = np.where(np.isnan(t_det) & det, t, t_det)
        t_fail = np.where(np.isnan(t_fail) & (s["end_play_mm"] >= limit_mm), t, t_fail)
        if verbose and k % max(1, n_steps // 10) == 0:
            print(f"  {t[0]:7.0f} h   failed {np.isfinite(t_fail).sum():4d}/{B}   detected {np.isfinite(t_det).sum():4d}")
    lead = t_fail - t_det
    grid = np.linspace(0, hours, 101)
    surv = np.array([1 - np.mean(np.nan_to_num(t_fail, nan=np.inf) <= g) for g in grid])
    return dict(t_fail=t_fail, t_det=t_det, lead=lead, grid=grid, survival=surv, sev=scen["sev"], ep0=calv[:, IDX["EP0"]])


def summary(res):
    tf = res["t_fail"]; fin = np.isfinite(tf)
    out = {"failed": int(fin.sum()), "n": len(tf)}
    if fin.sum() >= 0.1 * len(tf):
        out["B10_h"] = float(np.nanpercentile(np.where(fin, tf, np.inf), 10))
    ld = res["lead"][np.isfinite(res["lead"])]
    out["median_lead_h"] = float(np.median(ld)) if len(ld) else None
    return out
