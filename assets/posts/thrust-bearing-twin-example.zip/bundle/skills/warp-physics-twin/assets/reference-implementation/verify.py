"""Runs the same steady case as the interactive page and checks the numbers.
Reference values come from the page's JavaScript solver (v5) at 1200 rpm, 40 % load,
110 C oil, Ra 0.8, 4 kN clutch, pedal fully pressed: rear face lambda 2.3-2.9,
h_min 3.2-3.9 um, film load about 4.2 kN, unloaded front face 0.3-0.6 kN."""
import sys, time, numpy as np
sys.path.insert(0, ".")
from thrust_warp import Simulator, Calibration, IDX

def check(name, val, lo, hi):
    ok = lo <= val <= hi
    print(f"  {'PASS' if ok else 'FAIL'}  {name:22s} {val:9.3f}   expected {lo} .. {hi}")
    return ok

sim = Simulator(B=2, cal=Calibration())
sim.set_scenario(rpm=1200, load=40, pedal=1.0, clutch_kN=4.0, toil=110, ra_um=0.8, sev=np.array([0.0, 0.6], np.float32))
t0 = time.time()
for _ in range(90):
    sim.step(1 / 60, warp=0.0)
dtp = (time.time() - t0) / 90
s = sim.signals()
print(f"device {sim.device}, {dtp*1e3:.1f} ms per step for B=2\nhealthy vehicle:")
ok = True
ok &= check("lambda", s["lambda"][0], 1.8, 3.5)
ok &= check("h_min um", s["h_min_um"][0], 2.5, 5.0)
ok &= check("film load kN", s["F_film_kN"][0], 3.4, 4.8)
ok &= check("front load kN", s["F_front_kN"][0], 0.1, 0.9)
ok &= check("p_film_max MPa", s["p_film_max_MPa"][0], 3.5, 20.0)
ok &= check("gallery bar", s["p_gallery_bar"][0], 1.5, 4.5)
print("dented vehicle (60 %):")
ok &= check("dent width deg", s["dent_width_deg"][1], 50, 70)
ok &= check("lambda lower than healthy", s["lambda"][1] - s["lambda"][0], -5, 0.5)
ok &= check("torque mean N m (40 %)", float(sim.gas_torque(1200, 40).mean()), 200, 400)
print("wear over 30 engine hours at 5000x:")
for _ in range(int(30 * 3600 / (5000 / 60))):
    sim.step(1 / 60, warp=5000.0)
s2 = sim.signals()
ok &= check("healthy wear_mean um", s2["wear_mean_um"][0], 0.001, 20.0)
ok &= check("dented / healthy wear", s2["wear_mean_um"][1] / max(1e-6, s2["wear_mean_um"][0]), 1.2, 100.0)
print("micro-level checks: rim dent, starvation, corrosion, oil ageing")
from thrust_warp.dent_shapes import dent_with_rim
sim3 = Simulator(B=3)
sim3.set_scenario(rpm=np.array([1200, 700, 700], np.float32), load=10, pedal=1.0, clutch_kN=4.0, toil=np.array([110, 130, 130], np.float32), sev=np.array([0, 0, 0.5], np.float32))
hm = np.zeros((3, 120, 8), np.float32); hm[0] = dent_with_rim(depth=15e-6, rim_height=4e-6); sim3.set_dent_map(hm)
for _ in range(60):
    sim3.step(1 / 60, warp=0.0)
s3 = sim3.signals()
ok &= check("rim dent: asperity load kN", s3["F_asp_kN"][0], 0.005, 2.0)
ok &= check("hot idle healthy fill_min", s3["fill_min"][1], 0.6, 1.0)
ok &= check("hot idle dented fill_min", s3["fill_min"][2], 0.3, 0.999)
ok &= check("dent starves more", s3["fill_min"][1] - s3["fill_min"][2], 0.0, 1.0)
sim3.set_scenario(rpm=1200, load=60, pedal=1.0, toil=125, fm=np.array([[0, 0, 1.0, 0, 0, 0, 0, 0, 0, 0]] * 3, np.float32))
for _ in range(200):
    sim3.step(1 / 60, warp=20000.0)
s4 = sim3.signals()
ok &= check("oil oxidation after ~18 h", s4["oxidation"][0], 1e-4, 1.0)
ok &= check("fuel fraction (dilution mode)", s4["fuel"][0], 0.01, 0.15)
ok &= check("corrosion volume um3", s4["corrosion_um3"][0], 1e3, 1e12)
ok &= check("front face max T > oil", s4["T_front_max_C"][0] - 125.0, 0.0, 200.0)
print("v3 checks: deformation, impacts, grooves, debris, oil grade, cold start")
sim5 = Simulator(B=2)
sim5.set_scenario(rpm=800, load=30, pedal=1.0, clutch_kN=9.0, toil=130, sev=np.array([0.0, 0.6], np.float32))
for _ in range(240):
    sim5.step(1 / 60, warp=5000.0)
s5 = sim5.signals()
ok &= check("plastic depth um (overload)", s5["plastic_max_um"][1], 0.05, 200.0)
ok &= check("pile-up rims um", s5["pileup_max_um"][1], 0.02, 100.0)
ok &= check("debris particles", s5["debris_particles"][1], 1, 256)
ok &= check("embedded particles", s5["debris_embedded"][1], 0, 256)
simI = Simulator(B=1)
cI = simI.cal_np.copy(); cI[:, IDX["EP0"]] = 0.30e-3; simI.set_calibration(cI)
for k in range(180):
    simI.set_scenario(rpm=800, load=30, pedal=1.0 if (k // 15) % 2 == 0 else 0.0, clutch_kN=9.0, toil=130)
    simI.step(1 / 60, warp=100.0)
ok &= check("impacts counted at 0.30 mm end play", simI.signals()["impacts"][0], 1, 1e6)
sim5.reset_deformation(); s7 = sim5.signals()
ok &= check("reset deformation clears plastic", s7["plastic_max_um"][0], 0.0, 0.0)
sim6 = Simulator(B=1); sim6.set_grade("20W-50"); sim6.cold_start(-20.0)
for _ in range(60):
    sim6.step(1 / 60, warp=60.0)
s8 = sim6.signals()
ok &= check("cold 20W-50 viscosity Pa s", s8["mu_sump_mPas"][0] / 1e3, 2.0, 60.0)
ok &= check("cold pump factor < 0.3", s8["pump_factor"][0], 0.0, 0.3)
ok &= check("cold film thicker um", s8["h_min_um"][0], 8.0, 200.0)
ok &= check("warm-up running", s8["warmup_active"][0], 1.0, 1.0)
sim6.set_grade("0W-20"); sim6.cold_start(-20.0)
for _ in range(30):
    sim6.step(1 / 60, warp=60.0)
ok &= check("0W-20 thinner than 20W-50 cold", sim6.signals()["mu_sump_mPas"][0] / 1e3, 0.1, 5.0)
print("parity checks: washer spin, dry restart, low oil, margins")
sim7 = Simulator(B=3)
fm = np.zeros((3, 10), np.float32); fm[1, 7] = 1.0; fm[2, 8] = 0.8
sim7.set_scenario(rpm=800, load=20, pedal=1.0, clutch_kN=4.0, toil=125, fm=fm)
for _ in range(90):
    sim7.step(1 / 60, warp=0.0)
s9 = sim7.signals()
ok &= check("spin: groove offset moved", s9["groove_offset_deg"][1], 0.5, 360.0)
ok &= check("spin: supply below fixed washer", s9["p_supply_bar"][1] - s9["p_supply_bar"][0], -10.0, -0.01)
ok &= check("low oil: gallery below healthy", s9["p_gallery_bar"][2] - s9["p_gallery_bar"][0], -10.0, -0.05)
sim7.hot_restart(); sim7.step(1 / 60, warp=0.0); s10 = sim7.signals()
ok &= check("dry restart: prime running", s10["prime_remaining_s"][0], 0.5, 20.0)
ok &= check("dry restart: gallery collapsed", s10["p_gallery_bar"][0], 0.0, 0.5)
mg = sim7.margins(); ok &= check("margins computed", len(mg), 11, 11)
print("vibration checks: structural mode, Campbell crossing, film damping, stick-slip chatter")
from thrust_warp.campbell import sweep, crossings
res = sweep(rpms=np.arange(1500, 5501, 500), nfft=256, verbose=False)
ok &= check("structural mode Hz", res["f_struct"][0], 150.0, 400.0)
ok &= check("squeal (tab) mode Hz", res["f_tab"][0], 800.0, 6000.0)
ok &= check("film mode overdamped (min zeta)", res["zeta_film"].min(), 3.0, 1e4)
cr = [c for c in crossings(res) if c[0].startswith("4x")]
ok &= check("4x crosses the structural mode", len(cr), 1, 4)
if cr:
    i_at = int(np.argmin(np.abs(res["rpm"] - cr[0][1])))
    ok &= check("4x response peaks at the crossing", res["order_amp"][i_at, 3] / max(1e-9, res["order_amp"][0, 3]), 2.0, 1e6)
simC = Simulator(B=2)
fmC = np.zeros((2, 10), np.float32)
simC.set_scenario(rpm=np.array([2000, 700], np.float32), load=np.array([40, 20], np.float32), pedal=np.array([0.3, 1.0], np.float32),
                  clutch_kN=np.array([4.0, 9.0], np.float32), toil=np.array([100, 135], np.float32), ra_um=np.array([0.8, 1.6], np.float32),
                  sev=np.array([0.0, 0.6], np.float32), fm=fmC)
for i in range(600):
    simC.step(1 / 4000, warp=0.0, solve_film=(i % 8 == 0))
sC = simC.signals()
ok &= check("full film: no chatter", sC["chatter_rms_rad_s"][0], 0.0, 0.5)
ok &= check("boundary contact: chatter", sC["chatter_rms_rad_s"][1], 1.0, 1e4)
print("RCA-readiness checks: sensor layer, warp stability limiter, matched counterfactual")
from thrust_warp.sensors import record, PRODUCTION
simS = Simulator(B=2); simS.set_scenario(rpm=1500, load=40, pedal=0.4, toil=100)
Xs, chn = record(simS, seconds=2.0, dt=1 / 50)
ok &= check("sensor channels", len(chn), 8, 8)
ok &= check("sensor frames", Xs.shape[1], 100, 100)
ok &= check("held/dropped samples present", float(np.isnan(Xs).mean()), 0.0, 0.5)
simW = Simulator(B=1, seed=5); simW.set_scenario(rpm=2200, load=45, pedal=0.0, toil=105)
for _ in range(30):
    simW.step(1 / 120, warp=0.0)
for _ in range(60):
    simW.step(1 / 60, warp=20 * 3600 / 60 * 60)          # coarse warp: the limiter must hold the wear finite
wcoarse = float(simW.wear_map(0)[0].max())
ok &= check("coarse warp bounded by the limiter", wcoarse, 0.0, 200.0)
simF = Simulator(B=1, seed=5); simF.set_scenario(rpm=2200, load=45, pedal=0.0, toil=105)
for _ in range(30):
    simF.step(1 / 120, warp=0.0)
for _ in range(600):
    simF.step(1 / 60, warp=20 * 3600 / 600 * 60)
ok &= check("fine warp: no cell limited", float(simF.signals()["warp_limited_cells"][0]), 0.0, 0.0)
ok &= check("fine warp wear over 20 h (um)", float(simF.wear_map(0)[0].max()), 0.5, 120.0)
from thrust_warp.intervene import Intervention, compare
rc = compare(base=Intervention(), alt=Intervention(fm={"lowoil": 0.9}), n_each=3, hours=60, steps=160, verbose=False)
ok &= check("counterfactual: low oil lowers gallery pressure", rc["values"]["p_gallery_bar"][1] - rc["values"]["p_gallery_bar"][0], -10.0, -0.05)
print("ALL PASS" if ok else "SOME CHECKS FAILED")
sys.exit(0 if ok else 1)
