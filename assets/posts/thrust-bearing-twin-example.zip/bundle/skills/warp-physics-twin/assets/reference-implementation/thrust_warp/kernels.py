"""Warp kernels for the two-face thrust bearing model.

Batch layout: b = vehicle, f = face (0 rear, 1 front), i = angular column, j = radial ring.
All lengths in metres except wear, which is stored in micrometres (float32 resolution).
"""
import math
import warp as wp
from .geometry import NT, NR, RI, RO, RM, B as BW, DTH, DR, DENT_ANG, SPALL_ANG, SPALL_W, A_PAD
from .calibration import IDX

# ---- constants -------------------------------------------------------------
C_NT = wp.constant(NT)
C_NR = wp.constant(NR)
C_DTH = wp.constant(float(DTH))
C_DR = wp.constant(float(DR))
C_RI = wp.constant(float(RI))
C_RO = wp.constant(float(RO))
C_RM = wp.constant(float(RM))
C_BW = wp.constant(float(BW))
C_DENT = wp.constant(float(DENT_ANG))
C_SPALL = wp.constant(float(SPALL_ANG))
C_SPALLW = wp.constant(float(SPALL_W))
C_APAD = wp.constant(float(A_PAD))
PI = wp.constant(math.pi)
DEG = wp.constant(math.pi / 180.0)

# calibration indices as constants
def _c(n):
    return wp.constant(IDX[n])
I_EP0, I_TAPER, I_DENT_D, I_SPALL_D, I_OVERLAY = _c("EP0"), _c("TAPER"), _c("DENT_D"), _c("SPALL_D"), _c("OVERLAY")
I_M_CR, I_MBR, I_FBM, I_FBA, I_BEND_K = _c("M_CR"), _c("M_BLOCK_RATIO"), _c("F_BIAS_MAN"), _c("F_BIAS_AUTO"), _c("BEND_K")
I_EK, I_PA_MAX, I_P_CAP, I_SIG_RA, I_PC_ON, I_K_PL, I_RUNIN_MIN = _c("EK"), _c("PA_MAX"), _c("P_CAP"), _c("SIG_RA"), _c("PC_ON"), _c("K_PL"), _c("RUNIN_MIN")
I_KW_OV, I_KW_BK, I_K_CAV, I_M_OIL = _c("KW_OV"), _c("KW_BK"), _c("K_CAV"), _c("M_OIL")
I_MUB_OV, I_MUB_BK = _c("MUB_OV"), _c("MUB_BK")
I_MU100, I_MU_SLOPE, I_P_RELIEF, I_G0, I_MU_REF, I_Q_PER_RPM, I_SUP_FRAC = _c("MU100"), _c("MU_SLOPE"), _c("P_RELIEF"), _c("G0"), _c("MU_REF"), _c("Q_PER_RPM"), _c("SUP_FRAC")
I_C_TH, I_HA, I_F_TH, I_K_CIRC, I_CONE_K = _c("C_TH"), _c("HA"), _c("F_TH"), _c("K_CIRC"), _c("CONE_K")
I_SF_FAT, I_B_FAT, I_N_REF = _c("SF_FAT"), _c("B_FAT"), _c("N_REF")
I_CKP_GAP, I_CKP_G0, I_CKP_X0, I_JIT_AMP, I_JIT_VEL = _c("CKP_GAP"), _c("CKP_G0"), _c("CKP_X0"), _c("JIT_AMP"), _c("JIT_VEL")
I_MISF_SLOT = _c("MISF_SLOT")
I_QG, I_CARRY, I_DLEAK, I_STARVE = _c("Q_GROOVE_K"), _c("CARRY"), _c("DENT_LEAK_K"), _c("STARVE_EXP")
I_K_CORR, I_EA_CORR, I_T_REF_CORR, I_A_TAN, I_A_WATER, I_A_FUEL, I_SYN = _c("K_CORR"), _c("EA_CORR"), _c("T_REF_CORR"), _c("A_TAN"), _c("A_WATER"), _c("A_FUEL"), _c("SYN_CORR")
I_K_OX, I_EA_OX, I_TAN_OX, I_V_OX, I_SOOT_R, I_V_SOOT, I_W_IN, I_W_OUT, I_TAN0 = _c("K_OX"), _c("EA_OX"), _c("TAN_PER_OX"), _c("VISC_PER_OX"), _c("SOOT_RATE"), _c("VISC_PER_SOOT"), _c("WATER_IN"), _c("WATER_OUT"), _c("TAN0")
RGAS = wp.constant(8.314)
I_TAPER_FRAC, I_CHAMFER, I_GROOVE_D, I_EDGE_LEAK = _c("TAPER_FRAC"), _c("CHAMFER_MM"), _c("GROOVE_D"), _c("EDGE_LEAK_K")
I_WAVE_AMP, I_WAVE_ORDER, I_CONE_CR, I_FILLET, I_RA_CRANK = _c("WAVE_AMP"), _c("WAVE_ORDER"), _c("CONE_CR"), _c("FILLET_INT"), _c("RA_CRANK")
I_Y_OV, I_Y_BK, I_C_PLAST, I_PILEUP, I_V_IMP, I_K_IMP, I_T_SCUFF, I_K_SCUFF, I_ROUGH_SCUFF, I_HARD = [_c(n) for n in ["Y_OV", "Y_BK", "C_PLAST", "PILEUP", "V_IMP", "K_IMP", "T_SCUFF", "K_SCUFF", "ROUGH_SCUFF", "HARD_RATIO"]]
I_DEB_FRAC, I_DEB_D, I_FILTER, I_EMBED, I_K_3B = _c("DEB_FRAC"), _c("DEB_D_MEAN"), _c("FILTER_RATE"), _c("EMBED_RATE"), _c("K_3B")
I_M_FLEX, I_K_STRUCT, I_Z_STRUCT = _c("M_FLEX"), _c("K_STRUCT"), _c("Z_STRUCT")
I_J_WASH, I_K_TAB, I_Z_TAB, I_MU_S, I_MU_K, I_V_STRIB = [_c(n) for n in ["J_WASH", "K_TAB", "Z_TAB", "MU_S", "MU_K", "V_STRIB"]]
I_NU40, I_NU100, I_RHO, I_MU_PUMP, I_K_EP_T = _c("NU40"), _c("NU100"), _c("RHO_OIL"), _c("MU_PUMP_LIM"), _c("K_EP_T")


@wp.func
def walther_mu(cal: wp.array2d(dtype=float), b: int, TC: float) -> float:
    # ASTM D341: log10 log10(nu + 0.7) = A - B log10 T, fitted to NU40 / NU100; mu = nu * rho(T)
    f40 = wp.log10(wp.log10(cal[b, I_NU40] + 0.7))
    f100 = wp.log10(wp.log10(cal[b, I_NU100] + 0.7))
    t1 = wp.log10(313.15)
    t2 = wp.log10(373.15)
    Bw = (f40 - f100) / (t2 - t1)
    Aw = f40 + Bw * t1
    t = wp.log10(wp.max(200.0, TC + 273.15))
    nu = wp.max(1.5, wp.pow(10.0, wp.pow(10.0, Aw - Bw * t)) - 0.7)
    rho = cal[b, I_RHO] * (1.0 - 0.00065 * (TC - 15.0))
    return nu * 1.0e-6 * rho


@wp.func
def crank_at(dmg: wp.array3d(dtype=float), b: int, i: int, j: int, angle: float) -> float:
    sh = int(wp.round(angle / C_DTH))
    ic = ((i - sh) % C_NT + C_NT) % C_NT
    return dmg[b, ic, j]
NPADS = wp.constant(6)
NTAB = wp.constant(16)   # inner substeps for the kHz tab mode


@wp.func
def pad_of(i: int) -> int:
    # pad k lies between groove k (at 60k deg) and groove k+1
    return int((float(i) + 0.5) * 3.0 / 60.0) % 6


@wp.func
def pad_of_off(i: int, off: float) -> int:
    d = (float(i) + 0.5) * 3.0 - off
    d = d - 360.0 * wp.floor(d / 360.0)
    return int(d / 60.0) % 6


@wp.func
def groove_of_off(i: int, off: float) -> int:
    d = (float(i) + 0.5) * 3.0 - off
    d = d - 360.0 * wp.floor(d / 360.0)
    return int(wp.round(d / 60.0)) % 6


@wp.func
def is_groove(i: int, off: float) -> int:
    d = (float(i) + 0.5) * 3.0 - off
    d = d - 60.0 * wp.floor(d / 60.0)
    if d < 7.0 or d > 53.0:
        return 1
    return 0


@wp.func
def pad_s_off(i: int, off: float) -> float:
    d = (float(i) + 0.5) * 3.0 - off
    d = d - 60.0 * wp.floor(d / 60.0)
    return (d - 7.0) / 46.0


@wp.func
def groove_of(i: int) -> int:
    return int(wp.round((float(i) + 0.5) * 3.0 / 60.0)) % 6

# failure-mode severity columns in fm[b, k] (0..1)
FM_AER, FM_DEBRIS, FM_DIL, FM_PRE, FM_MIS, FM_MISF, FM_FAT, FM_SPIN, FM_LOWOIL, FM_DRY = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
NFM = 10
K_AER = wp.constant(FM_AER); K_DEB = wp.constant(FM_DEBRIS); K_DIL = wp.constant(FM_DIL); K_PRE = wp.constant(FM_PRE)
K_MIS = wp.constant(FM_MIS); K_MISF = wp.constant(FM_MISF); K_FAT = wp.constant(FM_FAT)
K_SPIN = wp.constant(FM_SPIN); K_LOWOIL = wp.constant(FM_LOWOIL); K_DRY = wp.constant(FM_DRY)


@wp.func
def ang_diff(a: float, b: float) -> float:
    d = a - b
    d = d - 360.0 * wp.floor((d + 180.0) / 360.0)
    return wp.abs(d)


@wp.func
def bank_dir(k: int) -> float:
    # firing order 1-8-7-2-6-5-4-3: odd cylinders (left bank) push at 135 deg, even at 45 deg
    if k == 0 or k == 2 or k == 5 or k == 7:
        return 135.0 * DEG
    return 45.0 * DEG


# ---- 1. per-vehicle preparation -------------------------------------------
@wp.kernel
def k_prep(cal: wp.array2d(dtype=float), fm: wp.array2d(dtype=float),
           rpm: wp.array(dtype=float), load: wp.array(dtype=float), toil: wp.array(dtype=float),
           ra_um: wp.array(dtype=float), sev: wp.array(dtype=float),
           x: wp.array(dtype=float), angle: wp.array(dtype=float),
           Tface: wp.array(dtype=float), TfaceF: wp.array(dtype=float),
           wear_mean: wp.array2d(dtype=float), spall: wp.array(dtype=float),
           oil: wp.array2d(dtype=float),
           gf: wp.array4d(dtype=float), rpm_axis: wp.array(dtype=float), load_axis: wp.array(dtype=float),
           misfire: wp.array2d(dtype=int), step: int, seed: int, dt: float,
           # outputs
           mu: wp.array(dtype=float), muEff: wp.array(dtype=float), muBase: wp.array(dtype=float),
           aer: wp.array(dtype=float), pgal: wp.array(dtype=float), psup: wp.array(dtype=float),
           sig0: wp.array(dtype=float), dentW: wp.array(dtype=float), cone: wp.array2d(dtype=float),
           bendX: wp.array(dtype=float), bendY: wp.array(dtype=float), om: wp.array(dtype=float),
           cyc_phase: wp.array(dtype=float), pumpF: wp.array(dtype=float), ep0: wp.array(dtype=float),
           prime: wp.array(dtype=float), primeT: wp.array(dtype=float), grooveOff: wp.array(dtype=float)):
    b = wp.tid()
    w = rpm[b] * 2.0 * PI / 60.0
    om[b] = w
    # roughness: washer and crank combined
    rc = cal[b, I_RA_CRANK]
    sig0[b] = wp.sqrt(ra_um[b] * ra_um[b] + rc * rc) * 1.0e-6 * cal[b, I_SIG_RA]
    # dent width grows with mean rear wear (feedback)
    s = sev[b]
    if s > 0.0:
        se = wp.min(1.0, s + wear_mean[b, 0] * 1.0e-6 / 0.3e-3)
        dentW[b] = 28.0 + 55.0 * se
    else:
        dentW[b] = 0.0
    # viscosity
    # oil state: 0 oxidation, 1 soot, 2 water, 3 TAN, 4 fuel
    fuel = 0.1 * fm[b, K_DIL] + oil[b, 4]
    dil = 1.0 - 5.0 * wp.min(fuel, 0.15)
    age = 1.0 + cal[b, I_V_OX] * oil[b, 0] + cal[b, I_V_SOOT] * oil[b, 1]
    a = 0.15 * fm[b, K_AER]
    aer[b] = a
    mb = dil * age * (1.0 - a)                        # multiplier on the Walther viscosity for this oil
    muBase[b] = mb
    Tfilm = 0.5 * (toil[b] + Tface[b])
    m = walther_mu(cal, b, Tfilm) * dil * age
    mu[b] = m
    muEff[b] = m * (1.0 - a)
    muS = walther_mu(cal, b, toil[b])
    pumpF[b] = wp.min(1.0, cal[b, I_MU_PUMP] / wp.max(1.0e-3, muS))
    ep0[b] = wp.max(0.02e-3, cal[b, I_EP0] + cal[b, I_K_EP_T] * (toil[b] - 20.0))
    # oil pressure
    ep = ep0[b] + (wear_mean[b, 0] + wear_mean[b, 1]) * 1.0e-6
    Q = cal[b, I_Q_PER_RPM] * rpm[b] * (1.0 - a) * pumpF[b] * (1.0 - 0.9 * fm[b, K_LOWOIL])
    G = cal[b, I_G0] * wp.sqrt(cal[b, I_MU_REF] / m) * (1.0 + 0.25 * (ep / cal[b, I_EP0] - 1.0) + 0.4 * s + 0.15 * spall[b])
    pg = wp.min(cal[b, I_P_RELIEF], Q / G)
    # dry / slow-prime restart: gallery pressure ramps from zero over the prime time (set by Simulator.hot_restart)
    if prime[b] > 0.0:
        prime[b] = wp.max(0.0, prime[b] - dt)
        pg = pg * (1.0 - prime[b] / wp.max(1.0e-3, primeT[b]))
    pgal[b] = pg
    ps = cal[b, I_SUP_FRAC] * pg * (1.0 - a)
    # washer spin (sheared tab): the washer rotates at a fraction of crank speed, grooves lose alignment with the feed
    sv = fm[b, K_SPIN]
    if sv > 0.0:
        go = grooveOff[b] + sv * 0.4 * w / 30.0 * dt / DEG
        go = go - 360.0 * wp.floor(go / 360.0)
        grooveOff[b] = go
        align = 0.5 + 0.5 * wp.cos(go * DEG * 6.0)
        ps = ps * (1.0 - 0.7 * sv * (1.0 - align))
    else:
        grooveOff[b] = 0.0
    psup[b] = ps
    # coning
    cone[b, 0] = cal[b, I_CONE_K] * wp.max(0.0, Tface[b] - toil[b])
    cone[b, 1] = cal[b, I_CONE_K] * wp.max(0.0, TfaceF[b] - toil[b])
    # misfire draw once per 720-degree cycle
    ph = cyc_phase[b] + w * dt
    if ph >= 4.0 * PI or step == 0:
        ph = ph - 4.0 * PI * wp.floor(ph / (4.0 * PI))
        for k in range(8):
            misfire[b, k] = 0
        st = wp.rand_init(seed, b * 100003 + step)
        if fm[b, K_MISF] > 0.0 and wp.randf(st) < fm[b, K_MISF]:
            slot = int(cal[b, I_MISF_SLOT])
            misfire[b, wp.clamp(slot, 0, 7)] = 1
    cyc_phase[b] = ph
    # combustion bending from the gas-force table (nearest rpm/load node)
    nr = rpm_axis.shape[0]
    nl = load_axis.shape[0]
    ir = int(wp.round((rpm[b] - rpm_axis[0]) / (rpm_axis[nr - 1] - rpm_axis[0]) * float(nr - 1)))
    il = int(wp.round((load[b] - load_axis[0]) / (load_axis[nl - 1] - load_axis[0]) * float(nl - 1)))
    ir = wp.clamp(ir, 0, nr - 1)
    il = wp.clamp(il, 0, nl - 1)
    d = angle[b] / DEG
    d = d - 720.0 * wp.floor(d / 720.0)
    tx = float(0.0)
    ty = float(0.0)
    for k in range(8):
        dd = d - 90.0 * float(k)
        dd = dd - 720.0 * wp.floor(dd / 720.0)
        idx = wp.clamp(int(dd), 0, 719)
        g = gf[ir, il, misfire[b, k], idx] / 6.0e4
        dr = bank_dir(k)
        tx += g * wp.cos(dr)
        ty += g * wp.sin(dr)
    bendX[b] = cal[b, I_BEND_K] * tx
    bendY[b] = cal[b, I_BEND_K] * ty


# ---- 2. film height, roughness, flow factor --------------------------------
@wp.kernel
def k_build_h(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), pad_s: wp.array(dtype=float), rj: wp.array(dtype=float),
              x: wp.array(dtype=float), hscale: float, tilt: wp.array(dtype=float), runout: wp.array(dtype=float), angle: wp.array(dtype=float),
              bendX: wp.array(dtype=float), bendY: wp.array(dtype=float), cone: wp.array2d(dtype=float),
              sev: wp.array(dtype=float), dentW: wp.array(dtype=float), spall: wp.array(dtype=float),
              wear_um: wp.array4d(dtype=float), rin: wp.array4d(dtype=float), sig0: wp.array(dtype=float),
              dent_map: wp.array3d(dtype=float), plas: wp.array4d(dtype=float), pile: wp.array4d(dtype=float), crank_dmg: wp.array3d(dtype=float),
              grooveD: wp.array2d(dtype=float), ep0: wp.array(dtype=float), grooveOff: wp.array(dtype=float),
              h: wp.array4d(dtype=float), sigC: wp.array4d(dtype=float), phiP: wp.array4d(dtype=float), dentD: wp.array3d(dtype=float)):
    b, f, i, j = wp.tid()
    th = (float(i) + 0.5) * C_DTH
    thd = th / DEG
    e0 = ep0[b]
    if f == 0:
        h0 = wp.max(0.3e-6, e0 * 0.5 - x[b]) * hscale
        sg = 1.0
    else:
        h0 = wp.max(0.3e-6, e0 * 0.5 + x[b]) * hscale
        sg = -1.0
    go = float(0.0)
    if f == 0:
        go = grooveOff[b]
    if is_groove(i, go) == 1:
        if f == 0:
            tap = grooveD[b, groove_of_off(i, go)]
        else:
            tap = cal[b, I_GROOVE_D]
    else:
        tap = cal[b, I_TAPER] * wp.max(0.0, 1.0 - pad_s_off(i, go) / cal[b, I_TAPER_FRAC])
    dent = float(0.0)
    if f == 0:
        dw = dentW[b]
        if dw > 0.0:
            dd = ang_diff(thd, C_DENT)
            if dd < dw * 0.5:
                u = dd / (dw * 0.5)
                c = wp.cos(u * PI * 0.5)
                dent = cal[b, I_DENT_D] * sev[b] * c * c
        if spall[b] > 0.5:
            ds = ang_diff(thd, C_SPALL)
            if ds < C_SPALLW * 0.5:
                u = ds / (C_SPALLW * 0.5)
                c = wp.cos(u * PI * 0.5)
                dent += cal[b, I_SPALL_D] * c * c
        dent += dent_map[b, i, j]          # measured or synthetic height map (positive = recess, negative = raised rim)
        dentD[b, i, j] = wp.max(0.0, dent)
    r = rj[j]
    rr = r / C_RO
    ct = wp.cos(th - PI * 0.25)
    cr = wp.cos(th - angle[b])
    cb = sg * (bendX[b] * wp.cos(th) + bendY[b] * wp.sin(th))
    wave = cal[b, I_WAVE_AMP] * wp.cos(cal[b, I_WAVE_ORDER] * (th - angle[b]))
    chm = cal[b, I_CHAMFER] * 1.0e-3
    cham = float(0.0)
    if chm > 0.0 and r - C_RI < chm:
        cham = chm * wp.max(0.0, 1.0 - (r - C_RI) / chm)
    fil = float(0.0)
    if cal[b, I_FILLET] > 0.0:
        fil = -cal[b, I_FILLET] * wp.max(0.0, 1.0 - (r - C_RI) / 2.0e-3)
    dfm = float(0.0)
    if f == 0:
        dfm = plas[b, 0, i, j] - pile[b, 0, i, j] + crank_at(crank_dmg, b, i, j, angle[b])
    hv = h0 + tap + cham + sg * tilt[b] * rr * ct + sg * runout[b] * rr * cr + cb * rr + cone[b, f] * (r - C_RM) + sg * cal[b, I_CONE_CR] * (r - C_RM) / C_BW + wave + fil + dent + dfm + wear_um[b, f, i, j] * 1.0e-6
    hv = wp.max(0.3e-6, hv)
    h[b, f, i, j] = hv
    sc = sig0[b] * rin[b, f, i, j]
    sigC[b, f, i, j] = sc
    if cal[b, I_PC_ON] > 0.5:
        phiP[b, f, i, j] = 1.0 - 0.9 * wp.exp(-0.56 * hv / sc)
    else:
        phiP[b, f, i, j] = 1.0


# ---- 3. one Jacobi sweep of the Reynolds equation ----------------------------
@wp.kernel
def k_jacobi(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), rj: wp.array(dtype=float),
             h: wp.array4d(dtype=float), phiP: wp.array4d(dtype=float),
             muCell: wp.array4d(dtype=float), om: wp.array(dtype=float),
             psup: wp.array(dtype=float), psup_pad: wp.array3d(dtype=float), dentW: wp.array(dtype=float),
             p_in: wp.array4d(dtype=float), p_out: wp.array4d(dtype=float), relax: float, grooveOff: wp.array(dtype=float)):
    b, f, i, j = wp.tid()
    ip = (i + 1) % C_NT
    im = (i + C_NT - 1) % C_NT
    th = (float(i) + 0.5) * C_DTH / DEG
    go = float(0.0)
    if f == 0:
        go = grooveOff[b]
    if is_groove(i, go) == 1:
        ps = psup_pad[b, f, groove_of_off(i, go)]
        if f == 0 and dentW[b] > 0.0 and ang_diff(th, C_DENT) < dentW[b] * 0.5:
            ps = ps * 0.25
        p_out[b, f, i, j] = ps
        return
    m = muCell[b, f, i, j]
    inv = phiP[b, f, i, j] / (12.0 * m)
    r = rj[j]
    hc = h[b, f, i, j]
    hE = h[b, f, ip, j]
    hW = h[b, f, im, j]
    he = 0.5 * (hc + hE)
    hw = 0.5 * (hc + hW)
    cE = he * he * he * inv / (r * r * C_DTH * C_DTH)
    cW = hw * hw * hw * inv / (r * r * C_DTH * C_DTH)
    if j < C_NR - 1:
        hn = 0.5 * (hc + h[b, f, i, j + 1])
        pN = p_in[b, f, i, j + 1]
    else:
        hn = hc
        pN = 0.0
    cN = (r + 0.5 * C_DR) * hn * hn * hn * inv / (r * C_DR * C_DR)
    if j > 0:
        hs = 0.5 * (hc + h[b, f, i, j - 1])
        pS = p_in[b, f, i, j - 1]
    else:
        hs = hc
        pS = psup[b] * 0.5
    cS = (r - 0.5 * C_DR) * hs * hs * hs * inv / (r * C_DR * C_DR)
    src = (om[b] * 0.5) * (hE - hW) / (2.0 * C_DTH)
    v = (cE * p_in[b, f, ip, j] + cW * p_in[b, f, im, j] + cN * pN + cS * pS - src) / (cE + cW + cN + cS)
    pc = p_in[b, f, i, j]
    pn = pc + relax * (v - pc)
    p_out[b, f, i, j] = wp.min(cal[b, I_P_CAP], wp.max(0.0, pn))


# ---- 4. contact, loads, torque, minima ---------------------------------------
@wp.kernel
def k_contact(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), rj: wp.array(dtype=float),
              h: wp.array4d(dtype=float), sigC: wp.array4d(dtype=float), p: wp.array4d(dtype=float),
              muCell: wp.array4d(dtype=float), om: wp.array(dtype=float),
              pasp: wp.array4d(dtype=float),
              W: wp.array2d(dtype=float), Fc: wp.array2d(dtype=float), Tv: wp.array2d(dtype=float),
              hmin: wp.array2d(dtype=float), lam: wp.array2d(dtype=float), pmax: wp.array2d(dtype=float),
              cav: wp.array2d(dtype=float), paSum: wp.array2d(dtype=float), grooveOff: wp.array(dtype=float)):
    b, f, i, j = wp.tid()
    r = rj[j]
    go = float(0.0)
    if f == 0:
        go = grooveOff[b]
    gm = is_groove(i, go)
    dA = r * C_DR * C_DTH
    hv = h[b, f, i, j]
    pv = p[b, f, i, j]
    wp.atomic_add(W, b, f, pv * dA)
    wp.atomic_max(pmax, b, f, pv)
    m = muCell[b, f, i, j]
    wp.atomic_add(Tv, b, f, m * om[b] * r / hv * r * r * dA)
    pa = float(0.0)
    if gm == 0:
        l = hv / sigC[b, f, i, j]
        wp.atomic_min(hmin, b, f, hv)
        wp.atomic_min(lam, b, f, l)
        if l < 4.0:
            pa = wp.min(cal[b, I_PA_MAX], cal[b, I_EK] * 4.4086e-5 * wp.pow(4.0 - l, 6.804))
        if pv <= 0.0:
            wp.atomic_add(cav, b, f, dA / C_APAD)
    pasp[b, f, i, j] = pa
    wp.atomic_add(Fc, b, f, pa * dA)
    wp.atomic_add(paSum, b, f, pa)


# ---- 5a. per-cell viscosity from per-cell temperature -------------------------
@wp.kernel
def k_mu(cal: wp.array2d(dtype=float), muBase: wp.array(dtype=float), toil: wp.array(dtype=float), Tcell: wp.array4d(dtype=float),
         muCell: wp.array4d(dtype=float)):
    b, f, i, j = wp.tid()
    Tf = 0.5 * (toil[b] + Tcell[b, f, i, j])
    muCell[b, f, i, j] = muBase[b] * walther_mu(cal, b, Tf)


# ---- 5b. per-cell energy balance on both faces (engine time) ------------------
@wp.kernel
def k_thermal_cell(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), rj: wp.array(dtype=float),
                   h: wp.array4d(dtype=float), pasp: wp.array4d(dtype=float), muCell: wp.array4d(dtype=float), om: wp.array(dtype=float),
                   toil: wp.array(dtype=float), mub: wp.array2d(dtype=float), Tin: wp.array4d(dtype=float), Tout: wp.array4d(dtype=float), dte: float):
    b, f, i, j = wp.tid()
    if groove[i] == 1:
        Tout[b, f, i, j] = Tin[b, f, i, j] + (toil[b] - Tin[b, f, i, j]) * (1.0 - wp.exp(-dte / 2.0))
        return
    r = rj[j]
    w = om[b]
    dA = r * C_DR * C_DTH
    q = muCell[b, f, i, j] * w * w * r * r / h[b, f, i, j] * dA + mub[b, f] * pasp[b, f, i, j] * w * r * dA
    ncell = float(C_NT * C_NR)
    Cc = cal[b, I_C_TH] / ncell
    hAc = cal[b, I_HA] / ncell
    kt = cal[b, I_K_CIRC] / float(C_NR)          # circumferential conduction per ring
    kr = kt                                        # radial conduction, same order
    ip = (i + 1) % C_NT
    im = (i + C_NT - 1) % C_NT
    ksum = 2.0 * kt
    tn = kt * (Tin[b, f, ip, j] + Tin[b, f, im, j])
    if j < C_NR - 1:
        tn += kr * Tin[b, f, i, j + 1]
        ksum += kr
    if j > 0:
        tn += kr * Tin[b, f, i, j - 1]
        ksum += kr
    Tss = (hAc * toil[b] + cal[b, I_F_TH] * q + tn) / (hAc + ksum)
    tau = Cc / (hAc + ksum)
    T = Tin[b, f, i, j] + (Tss - Tin[b, f, i, j]) * (1.0 - wp.exp(-dte / tau))
    Tout[b, f, i, j] = wp.min(T, 400.0)


# ---- 5c. flow field, pad inlet/outlet budgets, side leakage, dent leak ---------
@wp.kernel
def k_flow(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), rj: wp.array(dtype=float),
           h: wp.array4d(dtype=float), p: wp.array4d(dtype=float), phiP: wp.array4d(dtype=float), muCell: wp.array4d(dtype=float),
           om: wp.array(dtype=float), psup: wp.array(dtype=float), dentD: wp.array3d(dtype=float),
           qin: wp.array3d(dtype=float), qout: wp.array3d(dtype=float), qside: wp.array2d(dtype=float), qleak: wp.array(dtype=float), grooveOff: wp.array(dtype=float)):
    b, f, i, j = wp.tid()
    r = rj[j]
    ip = (i + 1) % C_NT
    im = (i + C_NT - 1) % C_NT
    go = float(0.0)
    if f == 0:
        go = grooveOff[b]
    hv = h[b, f, i, j]
    m = muCell[b, f, i, j]
    # circumferential flow through the radial slice DR (m3/s), Couette + Poiseuille
    dpdth = (p[b, f, ip, j] - p[b, f, im, j]) / (2.0 * r * C_DTH)
    qth = (om[b] * r * hv * 0.5 - phiP[b, f, i, j] * hv * hv * hv / (12.0 * m) * dpdth) * C_DR
    if is_groove(i, go) == 0:
        k = pad_of_off(i, go)
        if is_groove(im, go) == 1:
            wp.atomic_add(qin, b, f, k, qth)
        if is_groove(ip, go) == 1:
            wp.atomic_add(qout, b, f, k, qth)
        if j == C_NR - 1:
            qr = phiP[b, f, i, j] * hv * hv * hv / (12.0 * m) * p[b, f, i, j] / C_DR * r * C_DTH
            wp.atomic_add(qside, b, f, wp.max(0.0, qr))
    elif f == 0:
        # dent crossing a groove: leak channel from the groove to the outer edge, conductance ~ d^3 w / (12 mu L)
        d = dentD[b, i, j]
        if d > 0.0:
            wp.atomic_add(qleak, b, cal[b, I_DLEAK] * d * d * d * (r * C_DTH) / (12.0 * m * C_BW) * psup[b] / float(C_NR))


@wp.kernel
def k_pads(cal: wp.array2d(dtype=float), psup: wp.array(dtype=float), qin: wp.array3d(dtype=float), qout: wp.array3d(dtype=float),
           qleak: wp.array(dtype=float), dentW: wp.array(dtype=float), grooveCond: wp.array2d(dtype=float), edgeLeak: wp.array2d(dtype=float),
           fill: wp.array3d(dtype=float), psup_pad: wp.array3d(dtype=float), fill_min: wp.array2d(dtype=float), qsupply: wp.array2d(dtype=float)):
    b, f = wp.tid()
    fmin = float(1.0)
    qs = float(0.0)
    for k in range(NPADS):
        gc = float(1.0)
        el = float(0.0)
        if f == 0:
            gc = grooveCond[b, k]
            el = edgeLeak[b, k]
        avail = cal[b, I_QG] * gc * psup[b] + cal[b, I_CARRY] * qout[b, f, (k + NPADS - 1) % NPADS] - el
        if f == 0 and dentW[b] > 0.0:
            # the dent at 330 deg sits on groove 0 side of pad 5 and feeds pad 0: both lose the leak
            if k == 5 or k == 0:
                avail -= 0.5 * qleak[b]
        avail = wp.max(0.0, avail)
        need = wp.max(qin[b, f, k], 1.0e-12)
        fl = wp.min(1.0, avail / need)
        fill[b, f, k] = fl
        psup_pad[b, f, k] = psup[b] * wp.pow(fl, cal[b, I_STARVE])
        fmin = wp.min(fmin, fl)
        qs += cal[b, I_QG] * psup[b]
    fill_min[b, f] = fmin
    qsupply[b, f] = qs


# ---- 5e. groove depth after deformation and break-out edge leaks (rear face) ----------
@wp.kernel
def k_grooves(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), pile: wp.array4d(dtype=float), plas: wp.array4d(dtype=float),
              wear_um: wp.array4d(dtype=float), muEff: wp.array(dtype=float), psup: wp.array(dtype=float),
              grooveD: wp.array2d(dtype=float), grooveCond: wp.array2d(dtype=float), edgeLeak: wp.array2d(dtype=float)):
    b, k = wp.tid()
    dsum = float(0.0)
    dn = float(0.0)
    land = float(0.0)
    ln = float(0.0)
    for i in range(C_NT):
        if groove[i] == 1 and groove_of(i) == k:
            dsum += cal[b, I_GROOVE_D] - pile[b, 0, i, C_NR - 1] - pile[b, 0, i, 0] + 0.5 * (plas[b, 0, i, 0] + wear_um[b, 0, i, 0] * 1.0e-6)
            dn += 1.0
            ip = (i + 1) % C_NT
            im = (i + C_NT - 1) % C_NT
            land += wear_um[b, 0, ip, C_NR - 1] * 1.0e-6 + plas[b, 0, ip, C_NR - 1] + wear_um[b, 0, im, C_NR - 1] * 1.0e-6 + plas[b, 0, im, C_NR - 1]
            ln += 2.0
    dEff = cal[b, I_GROOVE_D]
    if dn > 0.0:
        dEff = wp.max(5.0e-6, dsum / dn)
    grooveD[b, k] = dEff
    r3 = dEff / cal[b, I_GROOVE_D]
    grooveCond[b, k] = r3 * r3 * r3
    dl = float(0.0)
    if ln > 0.0:
        dl = land / ln
    q = float(0.0)
    if dl > 3.0e-6:
        q = cal[b, I_EDGE_LEAK] * dl * dl * dl * (C_RO * C_DTH * 2.0) / (12.0 * muEff[b] * C_BW * 0.3) * psup[b]
    edgeLeak[b, k] = q


# ---- 5d. oil ageing states (engine time) ---------------------------------------
@wp.kernel
def k_oil(cal: wp.array2d(dtype=float), fm: wp.array2d(dtype=float), toil: wp.array(dtype=float), load: wp.array(dtype=float),
          Tface: wp.array(dtype=float), dte: float, oil: wp.array2d(dtype=float)):
    b = wp.tid()
    hrs = dte / 3600.0
    Tk = toil[b] + 273.15
    ox_rate = cal[b, I_K_OX] * wp.exp(-cal[b, I_EA_OX] / RGAS * (1.0 / Tk - 1.0 / 373.15)) * (1.0 + 0.5 * fm[b, K_AER])
    oil[b, 0] += ox_rate * hrs
    oil[b, 1] += cal[b, I_SOOT_R] * load[b] / 100.0 * hrs
    win = cal[b, I_W_IN] * hrs
    if toil[b] > 90.0:
        oil[b, 2] = wp.max(0.0, oil[b, 2] * (1.0 - cal[b, I_W_OUT] * hrs) + win)
    else:
        oil[b, 2] += win
    oil[b, 3] = cal[b, I_TAN0] + cal[b, I_TAN_OX] * oil[b, 0]
    # fuel: dilution failure mode adds fuel, hot oil boils it off
    fadd = 0.02 * fm[b, K_DIL] * hrs
    if toil[b] > 100.0:
        oil[b, 4] = wp.max(0.0, oil[b, 4] * (1.0 - 0.1 * hrs) + fadd)
    else:
        oil[b, 4] += fadd
    oil[b, 4] = wp.min(oil[b, 4], 0.15)


# ---- 5. (legacy, kept for reference) rear face per-column energy balance ---------
@wp.kernel
def k_thermal(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), pad_s: wp.array(dtype=float), rj: wp.array(dtype=float),
              h: wp.array4d(dtype=float), pasp: wp.array4d(dtype=float), muCol: wp.array2d(dtype=float), om: wp.array(dtype=float),
              toil: wp.array(dtype=float), mub: wp.array(dtype=float), Tin: wp.array2d(dtype=float), Tout: wp.array2d(dtype=float), dte: float):
    b, i = wp.tid()
    if groove[i] == 1:
        Tout[b, i] = Tin[b, i] + (toil[b] - Tin[b, i]) * (1.0 - wp.exp(-dte / 2.0))
        return
    q = float(0.0)
    w = om[b]
    for j in range(C_NR):
        r = rj[j]
        dA = r * C_DR * C_DTH
        q += muCol[b, i] * w * w * r * r / h[b, 0, i, j] * dA + mub[b] * pasp[b, 0, i, j] * w * r * dA
    Ci = cal[b, I_C_TH] / float(C_NT)
    hAi = cal[b, I_HA] / float(C_NT)
    kc = cal[b, I_K_CIRC]
    ip = (i + 1) % C_NT
    im = (i + C_NT - 1) % C_NT
    Tss = (hAi * toil[b] + cal[b, I_F_TH] * q + kc * (Tin[b, ip] + Tin[b, im])) / (hAi + 2.0 * kc)
    tau = Ci / (hAi + 2.0 * kc)
    T = Tin[b, i] + (Tss - Tin[b, i]) * (1.0 - wp.exp(-dte / tau))
    Tout[b, i] = wp.min(T, 400.0)


# ---- 6. axial dynamics with substeps (real time) -----------------------------
@wp.kernel
def k_axial(cal: wp.array2d(dtype=float), fm: wp.array2d(dtype=float), mode: wp.array(dtype=int),
            rpm: wp.array(dtype=float), load: wp.array(dtype=float), pedal: wp.array(dtype=float), clutch_kN: wp.array(dtype=float),
            W: wp.array2d(dtype=float), Fc: wp.array2d(dtype=float), k: wp.array2d(dtype=float), c: wp.array(dtype=float),
            wear_max: wp.array2d(dtype=float), ep0: wp.array(dtype=float),
            x: wp.array(dtype=float), v: wp.array(dtype=float), angle: wp.array(dtype=float), om: wp.array(dtype=float),
            y: wp.array(dtype=float), vy: wp.array(dtype=float), psi: wp.array(dtype=float), dpsi: wp.array(dtype=float),
            dt: float, nsub: int,
            Fext: wp.array(dtype=float), acc_rms: wp.array(dtype=float), Ffront: wp.array(dtype=float), impE: wp.array(dtype=float), impN: wp.array(dtype=float),
            acc_inst: wp.array(dtype=float), chatter: wp.array(dtype=float), slipfrac: wp.array(dtype=float), mub_dyn: wp.array(dtype=float)):
    b = wp.tid()
    ds = dt / float(nsub)
    xf = x[b]
    xx = x[b]
    vv = v[b]
    th = angle[b]
    m = cal[b, I_M_CR]
    e0 = ep0[b]
    acc = float(0.0)
    ie = float(0.0)
    inn = float(0.0)
    F = float(0.0)
    Wf = float(0.0)
    lim = e0 * 0.5 - 0.3e-6
    # structural mode: the flexplate / converter (or clutch pack) mass on a modal spring to the crank flange
    mf = cal[b, I_M_FLEX]
    ks = cal[b, I_K_STRUCT]
    cs = 2.0 * cal[b, I_Z_STRUCT] * wp.sqrt(ks * mf)
    yy = y[b]
    vyy = vy[b]
    # washer tangential mode on its anti-rotation tab, driven by boundary friction with a velocity-weakening law
    J = cal[b, I_J_WASH]
    kt = cal[b, I_K_TAB]
    ct = 2.0 * cal[b, I_Z_TAB] * wp.sqrt(kt * J)
    pp = psi[b]
    dp = dpsi[b]
    chat = float(0.0)
    slip = float(0.0)
    mub_acc = float(0.0)
    an = float(0.0)
    for s in range(nsub):
        # external axial force
        if mode[b] == 0:
            pe = pedal[b]
            F = clutch_kN[b] * 1000.0 * (1.2 * pe - 0.2 * pe * pe * pe) - cal[b, I_FBM] * (1.0 - pe) + 1500.0 * fm[b, K_PRE] * (1.0 - pe)
        else:
            F = clutch_kN[b] * 1000.0 * wp.pow(rpm[b] / 3000.0, 2.0) * (1.0 + 0.5 * load[b] / 100.0) + cal[b, I_FBA]
        F += 0.04 * wp.abs(F) * wp.sin(4.0 * th) + 0.02 * load[b] * 10.0 * wp.sin(4.0 * th)
        F += fm[b, K_MIS] * (600.0 * wp.sin(th) + 500.0)
        Wf = wp.max(0.0, W[b, 1] + Fc[b, 1] - k[b, 1] * (xx - xf))
        Fr = W[b, 0] + Fc[b, 0] + k[b, 0] * (xx - xf)
        ktot = k[b, 0] + k[b, 1]
        # the external force acts on the structural mass; the crank feels it through the modal spring
        Fs = ks * (yy - xx) + cs * (vyy - vv)
        vyn = vyy + ds / mf * (F - Fs)
        yy += ds * vyn
        vyy = vyn
        Fnet = Fs - Fr + Wf
        vn = (vv + ds / m * Fnet) / (1.0 + ds * c[b] / m + ds * ds * ktot / m)
        an = (vn - vv) / ds
        vv = vn
        # tangential stick-slip: friction torque from the asperity load, Stribeck velocity weakening
        # the tab mode sits at kHz, so it is integrated with its own inner substeps (symplectic Euler,
        # which preserves the limit cycle instead of damping it away like an implicit step would)
        dst = ds / float(NTAB)
        omw = fm[b, K_SPIN] * 0.4 * om[b]        # a sheared tab lets the washer creep with the crank: relative speed falls
        mubs = float(0.0)
        for q in range(NTAB):
            if Fc[b, 0] > 1.0:
                vrel = (om[b] - omw) * C_RM - dp * C_RM
                av = wp.abs(vrel)
                # falling (mixed-regime) friction branch: dmu/dv < 0 is negative damping on the tab mode
                mub = cal[b, I_MU_K] + (cal[b, I_MU_S] - cal[b, I_MU_K]) * wp.exp(-av / cal[b, I_V_STRIB])
                Tf = mub * Fc[b, 0] * C_RM * wp.tanh(vrel / 0.01)
                mubs += mub
                if av < 0.05:
                    slip += 1.0 / float(NTAB)
            else:
                Tf = float(0.0)
                mubs += cal[b, I_MUB_OV]
            dp += dst * (Tf - kt * pp - ct * dp) / J
            dp = wp.clamp(dp, -400.0, 400.0)
            pp += dst * dp
            pp = wp.clamp(pp, -0.05, 0.05)
            chat += dp * dp / float(NTAB)
        mub_acc += mubs / float(NTAB)
        xx += ds * vn
        if xx > lim + wear_max[b, 0] * 1.0e-6:
            if vv > cal[b, I_V_IMP]:
                ie += 0.5 * m * vv * vv
                inn += 1.0
            xx = lim + wear_max[b, 0] * 1.0e-6
            if vv > 0.0:
                vv = 0.0
        if xx < -lim - wear_max[b, 1] * 1.0e-6:
            xx = -lim - wear_max[b, 1] * 1.0e-6
            if vv < 0.0:
                vv = 0.0
        acc += an * an
        th += om[b] * ds
    x[b] = xx
    v[b] = vv
    angle[b] = th
    Fext[b] = F
    Ffront[b] = Wf
    acc_rms[b] = wp.sqrt(acc / float(nsub)) * cal[b, I_MBR]
    impE[b] = ie
    impN[b] += inn
    y[b] = yy
    vy[b] = vyy
    psi[b] = pp
    dpsi[b] = dp
    acc_inst[b] = an * cal[b, I_MBR]
    chatter[b] = wp.sqrt(chat / float(nsub))
    slipfrac[b] = slip / float(nsub)
    mub_dyn[b] = mub_acc / float(nsub)


# ---- 7. wear, running-in (engine time) ---------------------------------------
@wp.kernel
def k_wear(cal: wp.array2d(dtype=float), fm: wp.array2d(dtype=float), groove: wp.array(dtype=int), rj: wp.array(dtype=float),
           pasp: wp.array4d(dtype=float), p: wp.array4d(dtype=float), om: wp.array(dtype=float), pmax: wp.array2d(dtype=float),
           wear_max_prev: wp.array2d(dtype=float), Tcell: wp.array4d(dtype=float), oil: wp.array2d(dtype=float), dte: float,
           h: wp.array4d(dtype=float), sigC: wp.array4d(dtype=float), angle: wp.array(dtype=float),
           wear_um: wp.array4d(dtype=float), rin: wp.array4d(dtype=float),
           wsum: wp.array2d(dtype=float), wmax: wp.array2d(dtype=float), dV: wp.array(dtype=float), corr: wp.array(dtype=float),
           plas: wp.array4d(dtype=float), pile: wp.array4d(dtype=float), scuff: wp.array4d(dtype=float), crank_dmg: wp.array3d(dtype=float), warp_lim: wp.array(dtype=float)):
    b, f, i, j = wp.tid()
    r = rj[j]
    if wear_max_prev[b, f] * 1.0e-6 > cal[b, I_OVERLAY]:
        kw = cal[b, I_KW_BK]
    else:
        kw = cal[b, I_KW_OV]
    kw = kw * (1.0 + 6.0 * fm[b, K_DEB])
    pa = pasp[b, f, i, j]
    dw = kw * pa * om[b] * r * dte
    # cavitation erosion along film-rupture boundaries (rear face only)
    if f == 0 and groove[i] == 0 and p[b, f, i, j] <= 0.0 and cal[b, I_K_CAV] > 0.0:
        ip = (i + 1) % C_NT
        im = (i + C_NT - 1) % C_NT
        nb = float(0.0)
        if p[b, f, ip, j] > 3.0e5 or p[b, f, im, j] > 3.0e5:
            nb = 1.0
        if j < C_NR - 1 and p[b, f, i, j + 1] > 3.0e5:
            nb = 1.0
        if j > 0 and p[b, f, i, j - 1] > 3.0e5:
            nb = 1.0
        dw += nb * cal[b, I_K_CAV] * om[b] * dte * (0.5 + pmax[b, f] / 4.0e6)
    if pa > 0.0:
        q = pa / cal[b, I_PA_MAX]
        rin[b, f, i, j] = wp.max(cal[b, I_RUNIN_MIN], rin[b, f, i, j] * wp.exp(-cal[b, I_K_PL] * q * q * om[b] * r * dte))
    # corrosion of the exposed overlay: Arrhenius in local temperature, driven by acid number, water and fuel,
    # with a synergy term where asperities strip the passive layer
    if groove[i] == 0 and wear_um[b, f, i, j] * 1.0e-6 < cal[b, I_OVERLAY]:
        Tk = Tcell[b, f, i, j] + 273.15
        Tr = cal[b, I_T_REF_CORR] + 273.15
        rate = cal[b, I_K_CORR] * wp.exp(-cal[b, I_EA_CORR] / RGAS * (1.0 / Tk - 1.0 / Tr))
        rate *= (1.0 + cal[b, I_A_TAN] * oil[b, 3] + cal[b, I_A_WATER] * oil[b, 2] + cal[b, I_A_FUEL] * oil[b, 4])
        if pa > 0.0:
            rate *= (1.0 + cal[b, I_SYN])
        dc = rate * dte / 3600.0 * 1.0e-6
        dw += dc
        wp.atomic_add(corr, b, dc * r * C_DR * C_DTH)
    if f == 0 and groove[i] == 0 and pa > 0.0:
        # plastic flow of the overlay (or the backing) under the harder crank face; displaced volume piles up on neighbours
        Y = cal[b, I_Y_OV]
        if wear_um[b, f, i, j] * 1.0e-6 > cal[b, I_OVERLAY]:
            Y = cal[b, I_Y_BK]
        ex = pa / Y - 1.0
        if ex > 0.0:
            dp = cal[b, I_C_PLAST] * ex * dte
            plas[b, 0, i, j] += dp
            rimv = dp * cal[b, I_PILEUP] * 0.25
            ip = (i + 1) % C_NT
            im = (i + C_NT - 1) % C_NT
            wp.atomic_add(pile, b, 0, ip, j, rimv)
            wp.atomic_add(pile, b, 0, im, j, rimv)
            if j < C_NR - 1:
                wp.atomic_add(pile, b, 0, i, j + 1, rimv)
            if j > 0:
                wp.atomic_add(pile, b, 0, i, j - 1, rimv)
        # scuffing: hot starved contact tears the overlay, roughens it and scores the crank
        lamc = h[b, f, i, j] / sigC[b, f, i, j]
        sl = om[b] * r * dte
        if Tcell[b, f, i, j] > cal[b, I_T_SCUFF] and lamc < 1.2:
            dw += cal[b, I_K_SCUFF] * sl
            scuff[b, 0, i, j] = 1.0
            rin[b, f, i, j] = wp.min(3.0, rin[b, f, i, j] * (1.0 + cal[b, I_ROUGH_SCUFF] * sl))
            sh = int(wp.round(angle[b] / C_DTH))
            ic = ((i - sh) % C_NT + C_NT) % C_NT
            wp.atomic_add(crank_dmg, b, ic, j, cal[b, I_HARD] * cal[b, I_K_SCUFF] * sl)
        # exposed bronze or debris score the crank at the hardness ratio
        if wear_um[b, f, i, j] * 1.0e-6 > cal[b, I_OVERLAY] or fm[b, K_DEB] > 0.0:
            sh2 = int(wp.round(angle[b] / C_DTH))
            ic2 = ((i - sh2) % C_NT + C_NT) % C_NT
            wp.atomic_add(crank_dmg, b, ic2, j, cal[b, I_HARD] * dw)
    # Time-warp stability: wear relieves the contact that causes it, but that relief only reaches the
    # solver on the next frame. A warped step long enough to remove a large share of the local film
    # therefore over-integrates the runaway loop. Limit one step's removal to a fraction of the film
    # and count the cells that hit the limit, so a too-coarse warp is visible rather than silent.
    dwmax = 0.1 * h[b, f, i, j]
    if dw > dwmax:
        dw = dwmax
        wp.atomic_add(warp_lim, b, 1.0)
    wn = wp.min(1200.0, wear_um[b, f, i, j] + dw * 1.0e6)
    wear_um[b, f, i, j] = wn
    wp.atomic_add(dV, b, dw * r * C_DR * C_DTH)
    if groove[i] == 0:
        wp.atomic_add(wsum, b, f, wn)
        wp.atomic_max(wmax, b, f, wn)


# ---- 7b. brinelling: landing energy indents the cells that carried asperity load ---------
@wp.kernel
def k_impact(cal: wp.array2d(dtype=float), rj: wp.array(dtype=float), pasp: wp.array4d(dtype=float), paSum: wp.array2d(dtype=float),
             impE: wp.array(dtype=float), wear_max: wp.array2d(dtype=float), plas: wp.array4d(dtype=float)):
    b, i, j = wp.tid()
    E = impE[b]
    if E <= 0.0 or paSum[b, 0] <= 0.0 or pasp[b, 0, i, j] <= 0.0:
        return
    Y = cal[b, I_Y_OV]
    if wear_max[b, 0] * 1.0e-6 > cal[b, I_OVERLAY]:
        Y = cal[b, I_Y_BK]
    vol = cal[b, I_K_IMP] * E / Y
    f = pasp[b, 0, i, j] / paSum[b, 0]
    dp = vol * f / (rj[j] * C_DR * C_DTH)
    plas[b, 0, i, j] += wp.min(dp, 5.0e-6)


# ---- 7c. third-body particles (dim B, NDEB): spawn from removed volume, transport, filter, embed or scratch ----
@wp.kernel
def k_debris(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), rj: wp.array(dtype=float),
             h: wp.array4d(dtype=float), p: wp.array4d(dtype=float), pasp: wp.array4d(dtype=float), om: wp.array(dtype=float), muEff: wp.array(dtype=float),
             angle: wp.array(dtype=float), debGen: wp.array(dtype=float), dte: float, dt: float, seed: int, step: int,
             d_th: wp.array2d(dtype=float), d_r: wp.array2d(dtype=float), d_z: wp.array2d(dtype=float), d_d: wp.array2d(dtype=float),
             d_alive: wp.array2d(dtype=int), d_emb: wp.array2d(dtype=int),
             wear_um: wp.array4d(dtype=float), plas: wp.array4d(dtype=float), pile: wp.array4d(dtype=float), crank_dmg: wp.array3d(dtype=float),
             debN: wp.array(dtype=float), debEmb: wp.array(dtype=float), debD: wp.array(dtype=float)):
    b, n = wp.tid()
    st = wp.rand_init(seed + 7919, b * 100003 + n * 131 + step)
    if d_alive[b, n] == 0:
        # spawn budget: each live-slot draw takes one particle volume from the vehicle's generated volume
        vOne = PI / 6.0 * wp.pow(cal[b, I_DEB_D], 3.0)
        if debGen[b] > vOne and wp.randf(st) < 0.05:
            # born where material is being removed: pick the strongest of a few random cells by asperity pressure
            best = int(0)
            bv = float(-1.0)
            for t in range(8):
                k = int(wp.randf(st) * float(C_NT * C_NR))
                k = wp.clamp(k, 0, C_NT * C_NR - 1)
                v = pasp[b, 0, k / C_NR, k % C_NR] * (0.5 + wp.randf(st))
                if v > bv:
                    bv = v
                    best = k
            if bv > 0.0:
                wp.atomic_sub(debGen, b, vOne)
                d_th[b, n] = (float(best / C_NR) + 0.5) * C_DTH
                d_r[b, n] = C_RI + (float(best % C_NR) + 0.5) * C_DR
                d_z[b, n] = 0.2 + 0.6 * wp.randf(st)
                d_d[b, n] = cal[b, I_DEB_D] * wp.exp(0.6 * (wp.randf(st) + wp.randf(st) + wp.randf(st) - 1.5))
                d_alive[b, n] = 1
                d_emb[b, n] = 0
        return
    hrs = dte / 3600.0
    if d_emb[b, n] == 1:
        d_d[b, n] = d_d[b, n] * wp.exp(-0.3 * hrs)      # embedded particles are ground flush
        if d_d[b, n] < 3.0e-6:
            d_alive[b, n] = 0
            return
        wp.atomic_add(debN, b, 1.0)
        wp.atomic_add(debEmb, b, 1.0)
        wp.atomic_add(debD, b, d_d[b, n])
        return
    if wp.randf(st) < 1.0 - wp.exp(-cal[b, I_FILTER] * hrs):
        d_alive[b, n] = 0
        return
    th = d_th[b, n]
    r = d_r[b, n]
    i = int(th / C_DTH) % C_NT
    if i < 0:
        i += C_NT
    j = wp.clamp(int((r - C_RI) / C_DR), 0, C_NR - 1)
    hl = h[b, 0, i, j]
    dd = d_d[b, n]
    if groove[i] == 0 and dd > hl:
        if wp.randf(st) < 1.0 - wp.exp(-cal[b, I_EMBED] * hrs):
            d_emb[b, n] = 1
            wp.atomic_add(plas, b, 0, i, j, dd * 0.35)
            wp.atomic_add(pile, b, 0, i, j, dd * 0.3)
        else:
            sl = om[b] * r * dte
            dw = cal[b, I_K_3B] * dd * wp.min(1.0, sl / (2.0 * PI * r))
            wp.atomic_add(wear_um, b, 0, i, j, dw * 1.0e6)
            sh = int(wp.round(angle[b] / C_DTH))
            ic = ((i - sh) % C_NT + C_NT) % C_NT
            wp.atomic_add(crank_dmg, b, ic, j, cal[b, I_HARD] * dw)
            d_d[b, n] = dd * wp.exp(-0.05 * dte)
    # transport by the film velocity at the particle height (visual clock)
    ip = (i + 1) % C_NT
    im = (i + C_NT - 1) % C_NT
    dpdth = (p[b, 0, ip, j] - p[b, 0, im, j]) / (2.0 * r * C_DTH)
    jp = wp.min(C_NR - 1, j + 1)
    jm = wp.max(0, j - 1)
    dpdr = (p[b, 0, i, jp] - p[b, 0, i, jm]) / (2.0 * C_DR)
    z = d_z[b, n]
    pois = hl * hl / (2.0 * muEff[b]) * z * (1.0 - z)
    ut = om[b] * r * z - pois * dpdth
    ur = -pois * dpdr
    if groove[i] == 1:
        ur += 0.25 * om[b] * r
    th += ut / r * dt * 0.02
    r += ur * dt * 0.02
    th = th - 2.0 * PI * wp.floor(th / (2.0 * PI))
    d_th[b, n] = th
    d_r[b, n] = r
    if r > C_RO - 0.2e-3 or r < C_RI + 0.1e-3:
        d_alive[b, n] = 0
        return
    wp.atomic_add(debN, b, 1.0)
    wp.atomic_add(debD, b, dd)


# ---- 8. per-vehicle bookkeeping and signals ----------------------------------
@wp.kernel
def k_finish(cal: wp.array2d(dtype=float), fm: wp.array2d(dtype=float), toil: wp.array(dtype=float), runout: wp.array(dtype=float),
             wsum: wp.array2d(dtype=float), wmax: wp.array2d(dtype=float), npad: float, dV: wp.array(dtype=float),
             W: wp.array2d(dtype=float), Fc: wp.array2d(dtype=float), Tv: wp.array2d(dtype=float), om: wp.array(dtype=float),
             pmax: wp.array2d(dtype=float), Tcell: wp.array4d(dtype=float), groove: wp.array(dtype=int), dte: float,
             mub: wp.array2d(dtype=float), x: wp.array(dtype=float), v: wp.array(dtype=float), acc_rms: wp.array(dtype=float), angle: wp.array(dtype=float),
             wear_mean: wp.array2d(dtype=float), wear_max: wp.array2d(dtype=float), Vworn: wp.array(dtype=float), ppm: wp.array(dtype=float),
             ep: wp.array(dtype=float), tEng: wp.array(dtype=float), Tface: wp.array(dtype=float), Tmax: wp.array(dtype=float), TfaceF: wp.array(dtype=float), TmaxF: wp.array(dtype=float),
             fatD: wp.array(dtype=float), spall: wp.array(dtype=float), Tb: wp.array2d(dtype=float), Pfric: wp.array(dtype=float),
             ckp_amp: wp.array(dtype=float), ckp_jit: wp.array(dtype=float), ep0: wp.array(dtype=float), debGen: wp.array(dtype=float),
             impE: wp.array(dtype=float), impTot: wp.array(dtype=float), plas: wp.array4d(dtype=float), pile: wp.array4d(dtype=float), scuff: wp.array4d(dtype=float), crank_dmg: wp.array3d(dtype=float),
             plasMax: wp.array(dtype=float), pileMax: wp.array(dtype=float), scuffN: wp.array(dtype=float), crankMax: wp.array(dtype=float)):
    b = wp.tid()
    for f in range(2):
        wear_mean[b, f] = wsum[b, f] / npad
        wear_max[b, f] = wmax[b, f]
        if wear_max[b, f] * 1.0e-6 > cal[b, I_OVERLAY]:
            mb = cal[b, I_MUB_BK]
        else:
            mb = cal[b, I_MUB_OV]
        mb += 0.05 * fm[b, K_DEB]
        Tb[b, f] = mb * Fc[b, f] * C_RM
        mub[b, f] = mb
    Vworn[b] += dV[b]
    ppm[b] = Vworn[b] * 2700.0 / cal[b, I_M_OIL] * 1.0e6
    ep[b] = ep0[b] + (wear_mean[b, 0] + wear_mean[b, 1]) * 1.0e-6
    tEng[b] += dte / 3600.0
    debGen[b] += dV[b] * cal[b, I_DEB_FRAC]
    impTot[b] += impE[b]
    pm = float(0.0)
    rm = float(0.0)
    sn = float(0.0)
    cm = float(0.0)
    for i in range(C_NT):
        for j in range(C_NR):
            pm = wp.max(pm, plas[b, 0, i, j])
            rm = wp.max(rm, pile[b, 0, i, j])
            sn += scuff[b, 0, i, j]
            cm = wp.max(cm, crank_dmg[b, i, j])
    plasMax[b] = pm
    pileMax[b] = rm
    scuffN[b] = sn
    crankMax[b] = cm
    # mean / max pad temperature on both faces
    for f in range(2):
        ts = float(0.0)
        tm = float(-1.0e9)
        n = float(0.0)
        for i in range(C_NT):
            if groove[i] == 0:
                for j in range(C_NR):
                    ts += Tcell[b, f, i, j]
                    n += 1.0
                    tm = wp.max(tm, Tcell[b, f, i, j])
        if f == 0:
            Tface[b] = ts / n
            Tmax[b] = tm
        else:
            TfaceF[b] = ts / n
            TmaxF[b] = tm
    Tback = 0.15 * (W[b, 0] + Fc[b, 0]) * C_RM * 0.9 * fm[b, K_SPIN]      # spinning washer rubs on its seat
    Pfric[b] = (Tv[b, 0] + Tb[b, 0] + Tv[b, 1] + Tb[b, 1] + Tback) * om[b]
    # overlay fatigue (rear)
    if fm[b, K_FAT] > 0.0 and spall[b] < 0.5:
        Sf = cal[b, I_SF_FAT] * (1.0 - 0.85 * fm[b, K_FAT])
        dp = wp.max(pmax[b, 0], 1.0e4)
        Nf = cal[b, I_N_REF] * wp.pow(Sf / dp, cal[b, I_B_FAT])
        fatD[b] += (om[b] / (2.0 * PI)) * dte / Nf
        if fatD[b] >= 1.0:
            spall[b] = 1.0
    # CKP amplitude and jitter
    ag = wp.exp(-cal[b, I_CKP_GAP] / cal[b, I_CKP_G0]) * (1.0 - 0.3 * wp.abs(x[b]) / cal[b, I_CKP_X0]) * (1.0 + 0.15 * (runout[b] / 20.0e-6) * wp.cos(angle[b]))
    amp = wp.clamp(ag / wp.exp(-1.0e-3 / 1.5e-3), 0.0, 1.3)
    ckp_amp[b] = amp
    ckp_jit[b] = (1.0 - amp) * cal[b, I_JIT_AMP] + wp.abs(v[b]) * cal[b, I_JIT_VEL] + acc_rms[b] * 0.02


@wp.kernel
def k_stiffness(W: wp.array2d(dtype=float), Fc: wp.array2d(dtype=float), W2: wp.array2d(dtype=float), Fc2: wp.array2d(dtype=float),
                cal: wp.array2d(dtype=float), x: wp.array(dtype=float), muEff: wp.array(dtype=float), hmin: wp.array2d(dtype=float),
                k: wp.array2d(dtype=float), c: wp.array(dtype=float)):
    b = wp.tid()
    ep0 = cal[b, I_EP0]
    for f in range(2):
        if f == 0:
            h0 = wp.max(0.3e-6, ep0 * 0.5 - x[b])
        else:
            h0 = wp.max(0.3e-6, ep0 * 0.5 + x[b])
        dh = h0 * 0.03
        k[b, f] = wp.max(0.0, (W[b, f] - W2[b, f]) / dh) + wp.max(0.0, (Fc[b, f] - Fc2[b, f]) / dh)
    hm = wp.max(hmin[b, 0], 2.0e-6)
    cc = 3.0 * muEff[b] * C_APAD * C_BW * C_BW / (hm * hm * hm)
    c[b] = wp.clamp(cc, 2.0e4, 5.0e7)
