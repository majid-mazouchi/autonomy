"""Calibration against measured end-play-vs-hours points by batched finite differences.

One batch = 1 nominal + 2 perturbed copies per free parameter, so a full gradient of the
misfit costs a single rollout. Gauss-Newton with a trust region on log-parameters.
"""
from __future__ import annotations
import numpy as np
from .calibration import Calibration, IDX
from .simulator import Simulator
from .drive_cycles import schedule


def rollout(calv, hours, cycle="steady", warp=20000.0, dt=1.0 / 30.0, device=None, rpm=1200.0, load=40.0, seed=0):
    """Returns (times_h, end_play_mm[B, n]) for all rows of calv."""
    B = calv.shape[0]
    sim = Simulator(B, calv, device=device, seed=seed)
    R, L, P, _ = schedule(cycle, dt, 600.0, rpm=rpm, load=load)
    n = int(hours * 3600.0 / (dt * warp))
    t, ep = np.zeros(n), np.zeros((B, n), np.float32)
    for k in range(n):
        i = k % len(R)
        sim.set_scenario(rpm=R[i], load=L[i], pedal=P[i])
        sim.step(dt, warp)
        s = sim.signals(); t[k] = s["t_eng_h"][0]; ep[:, k] = s["end_play_mm"]
    return t, ep


def fit(measured_h, measured_mm, free=("KW_OV", "KW_BK", "G0"), cal=None, iters=4, rel_step=0.2, trust=1.0,
        device=None, verbose=True, **roll_kw):
    cal = cal or Calibration()
    theta = np.log([getattr(cal, n) for n in free])
    mh, mm = np.asarray(measured_h, float), np.asarray(measured_mm, float)
    hours = float(mh.max()) * 1.02
    for it in range(iters):
        P = len(free); B = 1 + 2 * P
        calv = cal.batch(B)
        for j, n in enumerate(free):
            calv[1 + 2 * j, IDX[n]] = np.exp(theta[j] + rel_step)
            calv[2 + 2 * j, IDX[n]] = np.exp(theta[j] - rel_step)
        t, ep = rollout(calv, hours, device=device, **roll_kw)
        pred = np.stack([np.interp(mh, t, ep[b]) for b in range(B)])
        r = pred[0] - mm
        J = np.stack([(pred[1 + 2 * j] - pred[2 + 2 * j]) / (2 * rel_step) for j in range(P)], 1)
        JtJ = J.T @ J + 1e-9 * np.eye(P)
        step = -np.linalg.solve(JtJ + np.trace(JtJ) / P * 0.1 * np.eye(P), J.T @ r)
        nrm = np.linalg.norm(step)
        if nrm > trust:
            step *= trust / nrm
        theta = theta + step
        for j, n in enumerate(free):
            setattr(cal, n, float(np.exp(theta[j])))
        if verbose:
            print(f"  iter {it}: rms {np.sqrt(np.mean(r**2)):.4f} mm  " + "  ".join(f"{n}={getattr(cal, n):.3e}" for n in free))
    return cal, J
