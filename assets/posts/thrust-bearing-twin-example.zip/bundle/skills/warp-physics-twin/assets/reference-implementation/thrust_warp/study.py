"""Studies that decide whether an RCA agent can work at all on this model.

discriminability(): can the production sensor set separate the failure modes? Generates
labelled vehicles, drives each through a short multi-point duty schedule, records only the
channels a vehicle broadcasts, extracts per-segment features and fits a classifier. Returns
the confusion matrix, per-mode recall and the features that carried the decision. Run it
before building anything that reasons about causes: a mode that is not separable in the
observable projection cannot be root-caused, however clever the agent.

sobol(): variance-based global sensitivity of the observables to the calibration parameters
(Saltelli sampling, first-order and total indices). Tells the agent which parameters are worth
hypothesising about, and which are unidentifiable from the data it will see.
"""
from __future__ import annotations
import numpy as np
from .calibration import Calibration, IDX
from .simulator import Simulator
from . import kernels as K
from .sensors import PRODUCTION, OPTIONAL, SensorBus

MODES = ["healthy", "dent", "aeration", "debris", "dilution", "preload", "misalignment", "misfire", "spin", "lowoil"]
FM_OF = {"aeration": K.FM_AER, "debris": K.FM_DEBRIS, "dilution": K.FM_DIL, "preload": K.FM_PRE,
         "misalignment": K.FM_MIS, "misfire": K.FM_MISF, "spin": K.FM_SPIN, "lowoil": K.FM_LOWOIL}
# (rpm, load, pedal, toil) held for `seg_s` seconds each: an idle hold, a part-load cruise,
# a high-speed pull and a hot idle with the pedal down (the condition that exposes the thrust face)
SCHEDULE = [(750, 12, 0.0, 95), (2200, 45, 0.0, 105), (4200, 70, 0.0, 115), (800, 15, 1.0, 125)]


def _build(n_per_mode, rng, sev_lo=0.35, sev_hi=1.0):
    labels, sev = [], []
    for m in MODES:
        for _ in range(n_per_mode):
            labels.append(m); sev.append(0.0 if m == "healthy" else rng.uniform(sev_lo, sev_hi))
    return labels, np.array(sev, np.float32)


def discriminability(n_per_mode=18, channels=PRODUCTION, seg_s=2.0, dt=1 / 50, pre_age_h=(20.0, 400.0),
                     seed=0, cal=None, device=None, verbose=True, classifier=None):
    rng = np.random.default_rng(seed)
    labels, sev = _build(n_per_mode, rng)
    B = len(labels)
    calv = (cal or Calibration()).batch(B)
    calv[:, IDX["EP0"]] *= rng.normal(1.0, 0.08, B)          # build spread, or the classifier learns a constant
    calv[:, IDX["KW_OV"]] *= np.exp(rng.normal(0, 0.3, B))
    sim = Simulator(B, calv, device=device, seed=seed)
    fm = np.zeros((B, K.NFM), np.float32)
    dent = np.zeros(B, np.float32)
    for i, m in enumerate(labels):
        if m == "dent":
            dent[i] = sev[i]
        elif m in FM_OF:
            fm[i, FM_OF[m]] = sev[i]
    hours = rng.uniform(*pre_age_h, B).astype(np.float32)
    # age each vehicle on a random duty point so wear and deformation have developed
    if verbose:
        print(f"  ageing {B} vehicles")
    for k in range(40):
        r, l, p, t = SCHEDULE[k % len(SCHEDULE)]
        sim.set_scenario(rpm=r, load=l, pedal=p, toil=t, sev=dent, fm=fm)
        for _ in range(6):
            sim.step(1 / 120, warp=0.0)          # settle before ageing, or the transient is aged by hours
        sim.step(1 / 60, warp=float(np.mean(hours)) * 3600.0 / 40.0 * 60.0)
    bus = SensorBus(channels, seed=seed + 1, B=B)
    feats, names = [], None
    t0 = 0.0
    for si, (r, l, p, t) in enumerate(SCHEDULE):
        sim.set_scenario(rpm=r, load=l, pedal=p, toil=t, sev=dent, fm=fm)
        for _ in range(int(0.4 / dt)):
            sim.step(dt, warp=0.0)
        buf = []
        for i in range(int(seg_s / dt)):
            sim.step(dt, warp=0.0)
            s = sim.signals()
            row = bus.sample(s, t0, hours=float(np.mean(s["t_eng_h"])))
            buf.append(np.stack([row[c] for c in bus.names()], -1))
            t0 += dt
        A = np.stack(buf, 1)                                  # (B, n, C)
        with np.errstate(invalid="ignore"):
            mean = np.nanmean(A, 1); std = np.nanstd(A, 1); p95 = np.nanpercentile(A, 95, axis=1)
        feats += [mean, std, p95]
        if names is None:
            names = []
        names += [f"{c}_{st}_seg{si}" for st in ("mean", "std", "p95") for c in bus.names()][:0] or \
                 [f"{c}_mean_seg{si}" for c in bus.names()] + [f"{c}_std_seg{si}" for c in bus.names()] + [f"{c}_p95_seg{si}" for c in bus.names()]
        if verbose:
            print(f"  segment {si + 1}/{len(SCHEDULE)} recorded")
    X = np.concatenate(feats, 1)
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    y = np.array(labels)
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.model_selection import StratifiedKFold, cross_val_predict
    from sklearn.metrics import confusion_matrix, classification_report
    clf = classifier or HistGradientBoostingClassifier(max_iter=250, learning_rate=0.1, random_state=seed)
    cv = StratifiedKFold(5, shuffle=True, random_state=seed)
    yp = cross_val_predict(clf, X, y, cv=cv)
    cm = confusion_matrix(y, yp, labels=MODES)
    rep = classification_report(y, yp, labels=MODES, output_dict=True, zero_division=0)
    clf.fit(X, y)
    # feature relevance from mutual information with the label (stable for correlated features,
    # unlike permutation importance on a model that has memorised the training set)
    from sklearn.feature_selection import mutual_info_classif
    mi = mutual_info_classif(X, y, random_state=seed)
    order = np.argsort(mi)[::-1][:12]
    ch = [c[0] for c in channels]
    per_ch = {c: float(sum(mi[i] for i, n in enumerate(names) if n.startswith(c + "_"))) for c in ch}
    return {"X": X, "y": y, "y_pred": yp, "features": names, "confusion": cm, "modes": MODES,
            "report": rep, "accuracy": float((yp == y).mean()),
            "top_features": [(names[i], float(mi[i])) for i in order], "channel_relevance": per_ch,
            "channels": [c[0] for c in channels], "severity": sev}


def confusion_text(res):
    cm, M = res["confusion"], res["modes"]
    w = max(len(m) for m in M) + 1
    out = [f"accuracy {res['accuracy']*100:.1f} %   (chance {100/len(M):.1f} %)", "",
           " " * w + "".join(f"{m[:6]:>7s}" for m in M) + "   recall"]
    for i, m in enumerate(M):
        rec = res["report"][m]["recall"]
        out.append(f"{m:<{w}s}" + "".join(f"{cm[i,j]:7d}" for j in range(len(M))) + f"   {rec*100:5.0f} %")
    out += ["", "rows = truth, columns = predicted", "", "features carrying the most label information (mutual information):"]
    for n, v in res["top_features"]:
        out.append(f"  {n:28s} {v:.3f}")
    out += ["", "by channel:"]
    for c, v in sorted(res["channel_relevance"].items(), key=lambda kv: -kv[1]):
        out.append(f"  {c:16s} {v:6.2f}")
    return "\n".join(out)


def sobol(params=("KW_OV", "EP0", "TAPER", "Q_PER_RPM", "G0", "C_PLAST", "K_SCUFF", "DEB_FRAC"),
          observables=("ckp_jitter_us", "p_gallery_bar", "vib_rms", "end_play_mm", "lambda", "T_face_C"),
          n=64, span=0.5, hours=300.0, seed=0, device=None, verbose=True):
    """Saltelli first-order (S1) and total (ST) indices of each observable w.r.t. log-uniform
    perturbations of the listed calibration parameters, evaluated after `hours` of ageing."""
    rng = np.random.default_rng(seed)
    d = len(params)
    A = rng.random((n, d)); Bm = rng.random((n, d))
    mats = [A, Bm] + [np.where(np.arange(d)[None, :] == i, A, Bm) for i in range(d)]
    X = np.concatenate(mats, 0)
    base = Calibration().to_vector()
    calv = np.tile(base, (len(X), 1))
    for j, p in enumerate(params):
        calv[:, IDX[p]] = base[IDX[p]] * np.exp((X[:, j] * 2 - 1) * span)
    sim = Simulator(len(X), calv, device=device, seed=seed)
    sim.set_scenario(rpm=1500, load=45, pedal=0.3, toil=110, sev=0.25)
    for _ in range(30):
        sim.step(1 / 120, warp=0.0)
    steps = 60
    for _ in range(25):
        sim.step(1 / 120, warp=0.0)
    for i in range(steps):
        sim.step(1 / 60, warp=hours * 3600.0 * 60.0 / steps)
        if verbose and i % 20 == 0:
            print(f"  ageing {i}/{steps}")
    s = sim.signals()
    out = {"params": list(params), "observables": list(observables), "S1": {}, "ST": {}}
    for ob in observables:
        Y = np.asarray(s[ob], float)
        ya, yb = Y[:n], Y[n:2 * n]
        var = np.var(np.concatenate([ya, yb])) + 1e-30
        s1, st = [], []
        for i in range(d):
            yi = Y[(2 + i) * n:(3 + i) * n]
            s1.append(float(np.mean(yb * (yi - ya)) / var))
            st.append(float(np.mean((ya - yi) ** 2) / (2 * var)))
        out["S1"][ob] = np.clip(s1, 0, 1); out["ST"][ob] = np.clip(st, 0, 1)
    return out


def sobol_text(res):
    out = ["total-order Sobol indices (share of the observable's variance the parameter can explain)", ""]
    hdr = "observable".ljust(18) + "".join(f"{p[:9]:>10s}" for p in res["params"])
    out.append(hdr)
    for ob in res["observables"]:
        out.append(ob.ljust(18) + "".join(f"{v:10.2f}" for v in res["ST"][ob]))
    out += ["", "a column of zeros means that parameter is invisible in these observables: the agent",
            "cannot identify it, and should not hypothesise about it from this data."]
    return "\n".join(out)
