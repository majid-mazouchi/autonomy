"""Digital-twin interface: an ensemble Kalman estimator of hidden bearing / oil state
from the signals a vehicle actually reports.

Each ensemble member is one vehicle in the batched simulator carrying its own copy of
the hidden parameters (dent severity, wear-coefficient multiplier, initial end play,
fuel fraction). Measurements are matched against the ensemble's predicted signals and the
parameters are updated with the EnKF formula; wear and temperature states evolve inside
each member, so the estimate carries its own history.

    twin = EnsembleTwin(N=64, hidden=("sev", "kw_mult", "EP0_mm", "fuel"),
                        observed=("ckp_jitter_us", "p_gallery_bar", "T_face_C", "vib_rms"))
    for each telemetry sample: twin.assimilate(rpm, load, pedal, toil, y_measured)
    twin.estimate()  ->  mean and std of each hidden parameter
"""
from __future__ import annotations
import numpy as np
from .calibration import Calibration, IDX
from .simulator import Simulator
from . import kernels as K


class EnsembleTwin:
    def __init__(self, N=64, hidden=("sev", "kw_mult", "EP0_mm", "fuel"), observed=("ckp_jitter_us", "p_gallery_bar", "T_face_C", "vib_rms"),
                 prior_mean=None, prior_std=None, meas_std=None, cal=None, device=None, seed=0, inflation=1.02,
                 dt=1.0 / 30.0, warp=3000.0):
        self.N, self.hidden, self.observed = N, list(hidden), list(observed)
        self.cal = cal or Calibration()
        self.rng = np.random.default_rng(seed)
        pm = {"sev": 0.2, "kw_mult": 1.0, "EP0_mm": 0.10, "fuel": 0.02}
        ps = {"sev": 0.15, "kw_mult": 0.5, "EP0_mm": 0.03, "fuel": 0.02}
        ms = {"ckp_jitter_us": 3.0, "p_gallery_bar": 0.15, "T_face_C": 4.0, "vib_rms": 0.05, "end_play_mm": 0.01, "debris_ppm": 5.0}
        pm.update(prior_mean or {}); ps.update(prior_std or {}); ms.update(meas_std or {})
        self.theta = np.stack([np.clip(pm[h] + ps[h] * self.rng.standard_normal(N), *self._bounds(h)) for h in self.hidden], 1)
        self.R = np.diag([ms[o] ** 2 for o in self.observed])
        self.inflation, self.dt, self.warp = inflation, dt, warp
        self.sim = Simulator(N, self.cal, device=device, seed=seed)
        self.fm = np.zeros((N, K.NFM), np.float32)
        self._apply()

    @staticmethod
    def _bounds(h):
        return {"sev": (0.0, 1.0), "kw_mult": (0.05, 20.0), "EP0_mm": (0.04, 0.40), "fuel": (0.0, 0.15)}[h]

    def _apply(self):
        calv = self.cal.batch(self.N)
        kw = {h: self.theta[:, i] for i, h in enumerate(self.hidden)}
        if "kw_mult" in kw:
            calv[:, IDX["KW_OV"]] *= kw["kw_mult"]; calv[:, IDX["KW_BK"]] *= kw["kw_mult"]
        if "EP0_mm" in kw:
            calv[:, IDX["EP0"]] = kw["EP0_mm"] * 1e-3
        self.sim.set_calibration(calv)
        self._sev = kw.get("sev", np.zeros(self.N))
        if "fuel" in kw:
            o = self.sim.oil.numpy(); o[:, 4] = kw["fuel"]; self.sim.oil.assign(o)

    def predict(self, rpm, load, pedal, toil, steps=1):
        self.sim.set_scenario(rpm=rpm, load=load, pedal=pedal, toil=toil, sev=self._sev.astype(np.float32), fm=self.fm)
        for _ in range(steps):
            self.sim.step(self.dt, self.warp)
        s = self.sim.signals()
        return np.stack([s[o] for o in self.observed], 1)

    def assimilate(self, rpm, load, pedal, toil, y, steps=1):
        """One telemetry sample y (len(observed),). Returns the innovation."""
        Y = self.predict(rpm, load, pedal, toil, steps)
        th = self.theta
        thm, Ym = th.mean(0), Y.mean(0)
        A = (th - thm) * self.inflation; Yd = Y - Ym
        Pyy = Yd.T @ Yd / (self.N - 1) + self.R
        Pty = A.T @ Yd / (self.N - 1)
        Kg = Pty @ np.linalg.inv(Pyy)
        pert = self.rng.multivariate_normal(np.zeros(len(self.observed)), self.R, self.N)
        self.theta = th + (np.asarray(y)[None, :] + pert - Y) @ Kg.T
        for i, h in enumerate(self.hidden):
            self.theta[:, i] = np.clip(self.theta[:, i], *self._bounds(h))
        self._apply()
        return np.asarray(y) - Ym

    def estimate(self):
        return {h: (float(self.theta[:, i].mean()), float(self.theta[:, i].std())) for i, h in enumerate(self.hidden)}


def demo(N=32, steps=40, true_sev=0.45, device=None, verbose=True):
    """Synthetic truth: one vehicle with a dent; the twin starts from its prior and converges."""
    truth = Simulator(1, Calibration(), device=device, seed=7)
    twin = EnsembleTwin(N=N, hidden=("sev", "EP0_mm"), observed=("ckp_jitter_us", "p_gallery_bar", "T_face_C"), device=device)
    rng = np.random.default_rng(3)
    for k in range(steps):
        rpm, load, pedal, toil = 800 + 400 * (k % 3), 20.0, 1.0 if k % 2 == 0 else 0.0, 115.0
        truth.set_scenario(rpm=rpm, load=load, pedal=pedal, toil=toil, sev=true_sev)
        truth.step(twin.dt, twin.warp)
        s = truth.signals()
        y = np.array([s["ckp_jitter_us"][0], s["p_gallery_bar"][0], s["T_face_C"][0]]) + rng.normal(0, [3.0, 0.15, 4.0])
        twin.assimilate(rpm, load, pedal, toil, y)
        if verbose and k % 10 == 0:
            e = twin.estimate(); print(f"  step {k:3d}  sev {e['sev'][0]:.3f} ± {e['sev'][1]:.3f}   EP0 {e['EP0_mm'][0]:.4f} ± {e['EP0_mm'][1]:.4f}   (true sev {true_sev})")
    return twin.estimate()
