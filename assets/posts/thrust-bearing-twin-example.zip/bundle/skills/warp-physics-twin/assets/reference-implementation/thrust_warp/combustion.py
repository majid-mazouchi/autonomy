"""Single-zone Wiebe cylinder model, tabulated per crank degree.

Returns gas force on the piston (N) and crank torque (N m) for one cylinder over a
720-degree cycle, with index 0 at firing TDC. Tables are precomputed on a coarse
(rpm, load) grid so a batched kernel can look them up per vehicle.
"""
import math
import numpy as np
from .calibration import Calibration

FIRING = [1, 8, 7, 2, 6, 5, 4, 3]
BANK_DIR = np.array([135.0 if c % 2 == 1 else 45.0 for c in FIRING]) * math.pi / 180.0


def cylinder_tables(cal: Calibration, rpm: float, load_pct: float, fire: bool = True):
    L = load_pct / 100.0
    A = math.pi * cal.BORE_D ** 2 / 4
    r, l = cal.STROKE / 2, cal.ROD_L
    Vd = A * cal.STROKE
    Vc = Vd / (cal.CR - 1)
    g = cal.GAMMA
    pman = cal.P_MAN_MIN + (1.0e5 - cal.P_MAN_MIN) * L
    pamb, pexh = 1.0e5, 1.1e5
    Q = cal.Q_CYL * L if fire else 0.0
    dur = cal.BURN_DUR + 4.0 * (rpm - 2000) / 1000.0
    th0 = -(cal.SPARK_ADV * (0.6 + 0.4 * L))

    def V(th):
        t = math.radians(th)
        return Vc + A * (r + l - (r * math.cos(t) + math.sqrt(l * l - r * r * math.sin(t) ** 2)))

    def xb(th):
        if th < th0:
            return 0.0
        u = (th - th0) / dur
        return 1.0 if u >= 1 else 1 - math.exp(-cal.WIEBE_A * u ** (cal.WIEBE_M + 1))

    def torque(pg, th):
        t = math.radians(th)
        lr = r / l
        return (pg - pamb) * A * r * math.sin(t) * (1 + lr * math.cos(t) / math.sqrt(1 - (lr * math.sin(t)) ** 2))

    force = np.zeros(720)
    tq = np.zeros(720)
    pcur = pman
    pmax = 0.0
    for d in range(720):
        th = d - 360
        if th < -180:
            pg = pman; pcur = pman
        elif th < 180:
            V0, V1 = V(th), V(th + 1)
            dQ = Q * (xb(th + 1) - xb(th))
            dp = ((g - 1) * dQ - g * pcur * (V1 - V0)) / V0
            pcur = max(0.2e5, pcur + dp)
            pg = pcur
        else:
            pg = pexh; pcur = pexh
        idx = (d + 360) % 720
        force[idx] = (pg - pamb) * A
        tq[idx] = torque(pg, th)
        pmax = max(pmax, pg)
    return force, tq, pmax


def build_grid(cal: Calibration, rpms=None, loads=None):
    """Tables on a coarse grid. Returns rpms, loads, force[NRPM,NL,2,720], torque[...], pmax[NRPM,NL]."""
    rpms = np.array(rpms if rpms is not None else np.linspace(600, 6000, 10), dtype=np.float32)
    loads = np.array(loads if loads is not None else np.linspace(0, 100, 11), dtype=np.float32)
    F = np.zeros((len(rpms), len(loads), 2, 720), np.float32)
    T = np.zeros_like(F)
    PM = np.zeros((len(rpms), len(loads)), np.float32)
    for i, rp in enumerate(rpms):
        for j, ld in enumerate(loads):
            for k, fire in enumerate((True, False)):
                f, t, pm = cylinder_tables(cal, float(rp), float(ld), fire)
                F[i, j, k] = f; T[i, j, k] = t
                if fire:
                    PM[i, j] = pm
    return rpms, loads, F, T, PM
