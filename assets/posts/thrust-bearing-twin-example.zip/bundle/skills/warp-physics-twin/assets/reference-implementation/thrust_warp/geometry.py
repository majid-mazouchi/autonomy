"""Grid and washer geometry shared by all kernels (mirrors the page)."""
import math
import numpy as np

NT, NR = 120, 8                       # angular columns, radial rings
RI, RO = 33.5e-3, 50e-3               # m
RM, B = 0.5 * (RI + RO), RO - RI
DTH = 2 * math.pi / NT
DR = B / NR
DENT_ANG, SPALL_ANG, SPALL_W = 330.0, 150.0, 30.0   # deg
DEG = math.pi / 180.0
A_PAD = math.pi * (RO * RO - RI * RI) * 0.77         # pad area (grooves removed)


def radii() -> np.ndarray:
    return (RI + (np.arange(NR) + 0.5) * DR).astype(np.float32)


def masks():
    """groove mask (1 = groove column) and normalised pad coordinate s in [0,1]."""
    deg = (np.arange(NT) + 0.5) * 360.0 / NT
    local = deg % 60.0
    groove = ((local < 7) | (local > 53)).astype(np.int32)
    pad_s = np.where(groove == 1, 0.0, (local - 7.0) / 46.0).astype(np.float32)
    return groove, pad_s
