"""Speed sweep and Campbell diagram.

Runs one rpm per batch slot, samples the axial acceleration at a kHz rate with the film
frozen between samples (the film changes on a much slower timescale than the structural
mode), and returns the order-tracked response together with the model's natural frequencies.

    from thrust_warp.campbell import sweep, campbell_text, save
    res = sweep(rpms=np.arange(800, 6400, 200), load=45, pedal=0.35)
    print(campbell_text(res)); save(res, "campbell.npz")

Returned dict:
    rpm            (N,)                    speeds
    freq           (F,)                    FFT frequency grid, Hz
    spec           (N, F)                  axial acceleration amplitude spectrum, g
    orders         (M,)                    order numbers tracked (0.5, 1, 2, 4, lobing, grooves)
    order_amp      (N, M)                  amplitude at each order line, g
    f_film/f_struct/f_tab   (N,)           mode frequencies at each speed
    zeta_film      (N,)                    damping ratio of the film mode
    h_min, lam, chatter, slip, mu_b        (N,) steady values at each speed
"""
from __future__ import annotations
import numpy as np
from .calibration import Calibration, IDX
from .simulator import Simulator


def sweep(rpms=None, cal: Calibration | np.ndarray = None, load=45.0, pedal=0.35, toil=105.0, clutch_kN=4.0,
          runout_um=3.0, mode=0, fm=None, sev=0.0, ra_um=0.8, fs=4000.0, nfft=512, settle=0.35,
          film_every=8, device=None, verbose=True):
    rpms = np.asarray(rpms if rpms is not None else np.arange(800, 6401, 200), np.float32)
    N = len(rpms)
    sim = Simulator(N, cal, device=device)
    sim.set_scenario(rpm=rpms, load=load, pedal=pedal, toil=toil, clutch_kN=clutch_kN, runout_um=runout_um,
                     mode=mode, fm=fm, sev=sev, ra_um=ra_um)
    for _ in range(int(settle * 240)):
        sim.step(1 / 240, warp=0.0)
    dt = 1.0 / fs
    acc = np.zeros((N, nfft), np.float32)
    for i in range(nfft):
        sim.step(dt, warp=0.0, solve_film=(i % film_every == 0))
        acc[:, i] = sim.acc_inst.numpy()
        if verbose and i % max(1, nfft // 4) == 0:
            print(f"  sampling {i}/{nfft}")
    win = np.hanning(nfft)
    sp = np.abs(np.fft.rfft((acc - acc.mean(1, keepdims=True)) * win, axis=1)) * (2.0 / win.sum())
    freq = np.fft.rfftfreq(nfft, dt)
    c = sim.cal_np
    orders = np.array([0.5, 1.0, 2.0, 4.0, float(c[0, IDX["WAVE_ORDER"]]), 6.0], np.float32)
    order_amp = np.zeros((N, len(orders)), np.float32)
    for n in range(N):
        for m, o in enumerate(orders):
            f = o * rpms[n] / 60.0
            if f <= freq[-1]:
                k = int(np.argmin(np.abs(freq - f)))
                order_amp[n, m] = sp[n, max(0, k - 1):k + 2].max()
    mf = sim.mode_frequencies(); s = sim.signals()
    return {"rpm": rpms, "freq": freq.astype(np.float32), "spec": sp.astype(np.float32),
            "orders": orders, "order_amp": order_amp,
            "f_film": mf["film"], "zeta_film": mf["film_zeta"], "f_struct": mf["struct"], "f_tab": mf["tab"],
            "h_min": s["h_min_um"], "lam": s["lambda"], "chatter": s["chatter_rms_rad_s"],
            "slip": s["stick_slip_frac"], "mu_b": s["mu_boundary"], "order_names": ["0.5 (misfire)", "1x", "2x", "4x (firing)", "lobing", "groove"]}


def crossings(res, mode_key="f_struct"):
    """Speeds where an order line crosses a mode line: the rpm to watch."""
    out = []
    fm = res[mode_key]
    for m, o in enumerate(res["orders"]):
        d = o * res["rpm"] / 60.0 - fm
        for i in range(len(d) - 1):
            if d[i] == 0 or d[i] * d[i + 1] < 0:
                frac = abs(d[i]) / (abs(d[i]) + abs(d[i + 1]))
                out.append((res["order_names"][m], float(res["rpm"][i] + frac * (res["rpm"][i + 1] - res["rpm"][i])),
                            float(fm[i]), float(res["order_amp"][i, m])))
    return out


def campbell_text(res, width=64):
    lines = [f"speed sweep {res['rpm'][0]:.0f} to {res['rpm'][-1]:.0f} rpm",
             f"film mode {res['f_film'].min():.0f}-{res['f_film'].max():.0f} Hz, damping ratio {res['zeta_film'].min():.0f}-{res['zeta_film'].max():.0f} (overdamped: no peak)",
             f"structural mode {res['f_struct'][0]:.0f} Hz, squeal (tab) mode {res['f_tab'][0]:.0f} Hz", "",
             "  rpm  h_min  lambda   4x amp    0.5x amp  chatter  slip"]
    for i in range(len(res["rpm"])):
        lines.append(f"{res['rpm'][i]:6.0f} {res['h_min'][i]:6.2f} {res['lam'][i]:7.2f} {res['order_amp'][i,3]:9.4f} {res['order_amp'][i,0]:9.4f} {res['chatter'][i]:8.2f} {res['slip'][i]:5.2f}")
    cr = crossings(res)
    lines.append("")
    lines.append("order crossings with the structural mode:" if cr else "no order crosses the structural mode in this range")
    for name, rpm, f, amp in cr:
        lines.append(f"  {name:14s} crosses {f:6.0f} Hz at {rpm:6.0f} rpm   response {amp:.4f} g")
    return "\n".join(lines)


def save(res, path="campbell.npz"):
    np.savez_compressed(path, **{k: v for k, v in res.items() if k != "order_names"})
    return path
