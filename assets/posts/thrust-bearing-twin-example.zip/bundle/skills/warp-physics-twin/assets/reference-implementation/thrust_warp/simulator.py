"""Batched two-face thrust bearing simulator on NVIDIA Warp.

    sim = Simulator(B=64, cal=Calibration(), device="cuda")
    sim.set_scenario(rpm=..., load=..., pedal=..., ...)      # per-vehicle inputs for this step
    sim.step(dt=1/60, warp=912)                              # one outer step
    sig = sim.signals()                                      # dict of (B,) numpy arrays

The outer step dt is real time; wear, fatigue and thermal use dt * warp (engine time),
exactly as the interactive page does.
"""
from __future__ import annotations
import numpy as np
import warp as wp
from . import kernels as K
from .geometry import NT, NR, radii, masks, A_PAD
from .calibration import Calibration, NCAL, IDX
IDX_MUB_OV = IDX["MUB_OV"]
from .combustion import build_grid

SIGNALS = ["t_eng_h", "T_oil", "rpm", "load", "pedal", "F_ext_kN", "F_film_kN", "F_asp_kN", "F_front_kN", "F_asp_front_kN",
           "h_min_um", "lambda", "h_min_front_um", "lambda_front", "p_film_max_MPa", "cav_fraction",
           "x_mm", "v_mm_s", "vib_rms", "k_film_MN_m", "c_squeeze_kNs_m", "T_visc_Nm", "T_bound_Nm", "P_fric_W",
           "T_face_C", "T_face_max_C", "T_front_C", "mu_mPas", "p_gallery_bar", "p_supply_bar",
           "end_play_mm", "wear_mean_um", "wear_max_um", "wear_front_mean_um", "debris_ppm", "fatigue_D", "spall",
           "dent_width_deg", "ckp_amp", "ckp_jitter_us", "misfire", "cone_mrad", "bend_tilt_um",
           "T_front_max_C", "fill_min", "fill_min_front", "q_supply_ml_s", "q_leak_ml_s", "q_side_ml_s", "corrosion_um3", "oxidation", "soot", "water", "TAN", "fuel",
           "plastic_max_um", "pileup_max_um", "scuffed_cells", "crank_damage_max_um", "impacts", "impact_energy_J",
           "groove_depth_min_um", "groove_cond_min", "q_edge_ml_s", "debris_particles", "debris_embedded", "debris_d_mean_um",
           "mu_sump_mPas", "pump_factor", "end_play_thermal_mm", "warmup_active", "prime_remaining_s", "groove_offset_deg",
           "warp_limited_cells", "acc_inst_g", "f_film_Hz", "f_struct_Hz", "f_squeal_Hz", "chatter_rms_rad_s", "stick_slip_frac", "mu_boundary"]


class Simulator:
    def __init__(self, B: int, cal: Calibration | np.ndarray = None, device: str | None = None,
                 sweeps: int = 30, sweeps_stiff: int = 12, seed: int = 1, requires_grad: bool = False, ndeb: int = 256):
        wp.init()
        self.device = device or wp.get_device()
        self.B, self.sweeps, self.sweeps_stiff, self.seed = B, sweeps, sweeps_stiff, seed
        self.step_i = 0
        rg = requires_grad
        calv = cal.batch(B) if isinstance(cal, Calibration) or cal is None and (cal := Calibration()) else np.asarray(cal, np.float32)
        self.cal = wp.array(calv, dtype=float, device=self.device, requires_grad=rg)
        self.cal_np = calv
        groove, pad_s = masks()
        self.groove = wp.array(groove, dtype=int, device=self.device)
        self.pad_s = wp.array(pad_s, dtype=float, device=self.device)
        self.rj = wp.array(radii(), dtype=float, device=self.device)
        self.npad = float((groove == 0).sum() * NR)
        # combustion tables
        c0 = Calibration.from_vector(calv[0])
        rpms, loads, F, T, PM = build_grid(c0)
        self.rpm_axis = wp.array(rpms, dtype=float, device=self.device)
        self.load_axis = wp.array(loads, dtype=float, device=self.device)
        self.gf = wp.array(F, dtype=float, device=self.device)
        self.gas_torque_np, self.gas_force_np, self.pmax_np, self.rpms_np, self.loads_np = T, F, PM, rpms, loads
        z = lambda *s, **kw: wp.zeros(s, dtype=float, device=self.device, requires_grad=rg and kw.get("grad", False))
        # grids
        self.h = z(B, 2, NT, NR); self.p = z(B, 2, NT, NR); self.p_tmp = z(B, 2, NT, NR); self.p2 = z(B, 2, NT, NR)
        self.pasp = z(B, 2, NT, NR); self.sigC = z(B, 2, NT, NR); self.phiP = z(B, 2, NT, NR)
        self.wear = z(B, 2, NT, NR, grad=True)
        self.rin = wp.ones((B, 2, NT, NR), dtype=float, device=self.device)
        self.Tcell = wp.full((B, 2, NT, NR), 120.0, dtype=float, device=self.device); self.Tcell2 = z(B, 2, NT, NR)
        self.muCell = z(B, 2, NT, NR); self.dent_map = z(B, NT, NR); self.dentD = z(B, NT, NR)
        self.qin = z(B, 2, 6); self.qout = z(B, 2, 6); self.fill = wp.ones((B, 2, 6), dtype=float, device=self.device); self.psup_pad = z(B, 2, 6)
        self.qside = z(B, 2); self.fill_min = z(B, 2); self.qsupply = z(B, 2); self.qleak = z(B); self.corr = z(B)
        self.oil = z(B, 5); self.mub = z(B, 2); self.TmaxF = z(B)
        # deformation, damage, grooves, debris, cold start (v3)
        self.plas = z(B, 2, NT, NR); self.pile = z(B, 2, NT, NR); self.scuff = z(B, 2, NT, NR); self.crank_dmg = z(B, NT, NR)
        self.paSum = z(B, 2); self.impE = z(B); self.impN = z(B); self.impTot = z(B); self.plasMax = z(B); self.pileMax = z(B); self.scuffN = z(B); self.crankMax = z(B)
        self.grooveD = wp.full((B, 6), 60e-6, dtype=float, device=self.device); self.grooveCond = wp.ones((B, 6), dtype=float, device=self.device); self.edgeLeak = z(B, 6)
        self.NDEB = ndeb; self.d_th = z(B, ndeb); self.d_r = z(B, ndeb); self.d_z = z(B, ndeb); self.d_d = z(B, ndeb)
        self.d_alive = wp.zeros((B, ndeb), dtype=int, device=self.device); self.d_emb = wp.zeros((B, ndeb), dtype=int, device=self.device)
        self.debGen = z(B); self.debN = z(B); self.debEmb = z(B); self.debD = z(B); self.pumpF = wp.ones(B, dtype=float, device=self.device); self.ep0 = z(B)
        self.prime = z(B); self.primeT = z(B); self.grooveOff = z(B)
        self.warp_lim = z(B); self.y = z(B); self.vy = z(B); self.psi = z(B); self.dpsi = z(B); self.acc_inst = z(B); self.chatter = z(B); self.slipfrac = z(B); self.mub_dyn = z(B)
        self.cold = np.zeros(B, bool); self.cold_t = np.zeros(B); self.Toil = np.full(B, 110.0); self.tamb = np.full(B, 20.0)
        # per vehicle / per face
        for n in ["W", "Fc", "Tv", "Tb", "hmin", "lam", "pmax", "cav", "W2", "Fc2", "hmin2", "lam2", "pmax2", "cav2", "k", "cone",
                  "wear_mean", "wear_max", "wsum", "wmax"]:
            pass
        for n in ["W", "Fc", "Tv", "Tb", "hmin", "lam", "pmax", "cav", "W2", "Fc2", "hmin2", "lam2", "pmax2", "cav2", "k", "cone", "wear_mean", "wear_max", "wsum", "wmax"]:
            setattr(self, n, z(B, 2))
        for n in ["x", "v", "angle", "om", "mu", "muEff", "muF", "aer", "pgal", "psup", "sig0", "dentW", "bendX", "bendY",
                  "cyc_phase", "c", "Fext", "acc_rms", "Ffront", "dV", "Vworn", "ppm", "ep", "tEng", "Tface", "Tmax", "TfaceF",
                  "fatD", "spall", "Pfric", "ckp_amp", "ckp_jit", "muBase"]:
            setattr(self, n, z(B))
        self.Tface.fill_(120.0); self.TfaceF.fill_(120.0); self.ep.fill_(float(calv[0, 0])); self.ep0.fill_(float(calv[0, 0]))
        self.oil.assign(np.tile(np.array([0, 0, 0, calv[0, IDX["TAN0"]], 0], np.float32), (B, 1)))
        self.mub.fill_(float(calv[0, IDX_MUB_OV])); self.psup_pad.fill_(0.0); self.grooveD.fill_(float(calv[0, IDX['GROOVE_D']]))
        self.misfire = wp.zeros((B, 8), dtype=int, device=self.device)
        # scenario inputs
        self.rpm = z(B); self.load = z(B); self.pedal = z(B); self.toil = z(B); self.ra = z(B); self.sev = z(B)
        self.tilt = z(B); self.runout = z(B); self.clutch = z(B)
        self.mode = wp.zeros(B, dtype=int, device=self.device)
        self.fm = z(B, K.NFM)
        self.set_scenario()
        self.warmup()

    # ------------------------------------------------------------------
    def set_scenario(self, rpm=1200.0, load=40.0, pedal=1.0, toil=110.0, ra_um=0.8, sev=0.0, tilt_um=0.0, runout_um=2.0,
                     clutch_kN=4.0, mode=0, fm=None):
        """Every argument is a scalar or a (B,) array. sev in 0..1. fm is (B, 10) severities in 0..1 for
        [aeration, debris, dilution, release-bearing preload, misalignment, misfire, fatigue, washer spin, low oil supply, dry restart]."""
        B = self.B
        def put(arr, val, dtype=np.float32):
            arr.assign(np.broadcast_to(np.asarray(val, dtype), (B,)).copy())
        put(self.rpm, rpm); put(self.load, load); put(self.pedal, pedal); put(self.toil, toil); put(self.ra, ra_um)
        put(self.sev, sev); put(self.tilt, np.asarray(tilt_um, np.float32) * 1e-6); put(self.runout, np.asarray(runout_um, np.float32) * 1e-6)
        put(self.clutch, clutch_kN); put(self.mode, mode, np.int32)
        if fm is not None:
            self.fm.assign(np.broadcast_to(np.asarray(fm, np.float32), (B, K.NFM)).copy())

    def set_calibration(self, calv: np.ndarray):
        self.cal.assign(np.asarray(calv, np.float32)); self.cal_np = np.asarray(calv, np.float32)

    def warmup(self, steps: int = 30, dt: float = 1.0 / 60.0):
        """Settle the axial dynamics and the pressure field without wearing anything (warp = 0)."""
        for _ in range(steps):
            self.step(dt, warp=0.0)
        self.step_i = 0; self.impN.zero_(); self.impE.zero_()

    def reset_wear(self):
        self.wear.zero_(); self.rin.fill_(1.0); self.wear_mean.zero_(); self.wear_max.zero_(); self.Vworn.zero_()
        self.fatD.zero_(); self.spall.zero_(); self.tEng.zero_(); self.corr.zero_()

    def oil_change(self):
        o = self.oil.numpy(); o[:] = 0; o[:, 3] = self.cal_np[:, IDX["TAN0"]]; self.oil.assign(o)

    def set_dent_map(self, hmap: np.ndarray):
        """hmap (B, NT, NR) or (NT, NR) in metres, positive = recess, negative = raised rim; rear face."""
        hm = np.asarray(hmap, np.float32)
        if hm.ndim == 2:
            hm = np.broadcast_to(hm, (self.B, NT, NR))
        self.dent_map.assign(np.ascontiguousarray(hm))

    # ------------------------------------------------------------------
    def _solve(self, hscale, p, W, Fc, hmin, lam, pmax, cav, sweeps):
        d = self.device
        wp.launch(K.k_build_h, dim=(self.B, 2, NT, NR), device=d, inputs=[
            self.cal, self.groove, self.pad_s, self.rj, self.x, hscale, self.tilt, self.runout, self.angle,
            self.bendX, self.bendY, self.cone, self.sev, self.dentW, self.spall, self.wear, self.rin, self.sig0, self.dent_map, self.plas, self.pile, self.crank_dmg, self.grooveD, self.ep0, self.grooveOff],
            outputs=[self.h, self.sigC, self.phiP, self.dentD])
        a, bb = p, self.p_tmp
        for s in range(sweeps):
            wp.launch(K.k_jacobi, dim=(self.B, 2, NT, NR), device=d, inputs=[
                self.cal, self.groove, self.rj, self.h, self.phiP, self.muCell, self.om, self.psup, self.psup_pad, self.dentW, a, bb, 1.0, self.grooveOff])
            a, bb = bb, a
        if a is not p:
            wp.copy(p, a)
        W.zero_(); Fc.zero_(); self.Tv.zero_(); pmax.zero_(); cav.zero_(); hmin.fill_(1.0); lam.fill_(1e9); self.paSum.zero_()
        wp.launch(K.k_contact, dim=(self.B, 2, NT, NR), device=d, inputs=[
            self.cal, self.groove, self.rj, self.h, self.sigC, p, self.muCell, self.om],
            outputs=[self.pasp, W, Fc, self.Tv, hmin, lam, pmax, cav, self.paSum, self.grooveOff])

    def cold_start(self, tamb=-10.0, vehicles=None):
        """Start a cranking + warm-up sequence at ambient temperature for all (or selected) vehicles."""
        idx = np.arange(self.B) if vehicles is None else np.asarray(vehicles)
        self.cold[idx] = True; self.cold_t[idx] = 0.0; self.tamb[idx] = tamb; self.Toil[idx] = tamb
        t = self.toil.numpy(); t[idx] = tamb; self.toil.assign(t)
        tc = self.Tcell.numpy(); tc[idx] = tamb; self.Tcell.assign(tc); tf = self.Tface.numpy(); tf[idx] = tamb; self.Tface.assign(tf); tff = self.TfaceF.numpy(); tff[idx] = tamb; self.TfaceF.assign(tff)
        x = self.x.numpy(); x[idx] = 0; self.x.assign(x); v = self.v.numpy(); v[idx] = 0; self.v.assign(v)

    def _warmup_host(self, dt, warp):
        """Sump temperature state for vehicles in a cold-start sequence: cranking, then fast idle while friction and engine heat warm the oil."""
        if not self.cold.any():
            return
        c = self.cal_np; idx = np.where(self.cold)[0]
        rpm = self.rpm.numpy(); load = self.load.numpy(); pf = self.Pfric.numpy()
        crank = self.cold_t[idx] < 1.5
        rpm[idx] = np.where(crank, c[idx, IDX["T_CRANK_RPM"]], np.round(800 + 700 * np.clip((60 - self.Toil[idx]) / 80, 0, 1)))
        load[idx] = np.where(crank, 5.0, np.maximum(load[idx], 8.0))
        qin = c[idx, IDX["K_ENG_HEAT"]] * 40 * (rpm[idx] / 1000) * (0.3 + 0.7 * load[idx] / 100) + 0.5 * pf[idx]
        self.Toil[idx] += (qin - c[idx, IDX["HA_AMB"]] * (self.Toil[idx] - self.tamb[idx])) / c[idx, IDX["C_OIL"]] * dt * warp
        self.Toil[idx] = np.clip(self.Toil[idx], self.tamb[idx], 135)
        self.cold_t[idx] += dt
        t = self.toil.numpy(); t[idx] = self.Toil[idx]; self.toil.assign(t); self.rpm.assign(rpm); self.load.assign(load)
        done = idx[(self.Toil[idx] > 95) & (rpm[idx] <= 800)]
        self.cold[done] = False

    def hot_restart(self, vehicles=None):
        """Dry / slow-prime restart: gallery pressure ramps from zero over 1.5 s (+6 s at full 'dry' severity), longer for thick oil."""
        idx = np.arange(self.B) if vehicles is None else np.asarray(vehicles)
        fm = self.fm.numpy(); sv = fm[idx, K.FM_DRY]
        mu = np.array([self._mu_host(b) for b in idx]); T = np.minimum(20.0, (1.5 + 6.0 * sv) * np.maximum(1.0, np.sqrt(mu / 0.01)))
        pt = self.primeT.numpy(); pr = self.prime.numpy(); pt[idx] = T; pr[idx] = T; self.primeT.assign(pt); self.prime.assign(pr)
        tf = self.Tface.numpy(); tf[idx] = np.maximum(tf[idx], self.toil.numpy()[idx] + 25); self.Tface.assign(tf)

    def margins(self):
        """Design margins as fractions: (limit - value)/limit for stay-below, value/limit - 1 for stay-above."""
        s = self.signals(); c = self.cal_np
        pa_max = self.pasp.numpy()[:, 0].max(axis=(1, 2)) / 1e6
        m = {
            "lambda_rear": s["lambda"] / 3.0 - 1, "lambda_front": s["lambda_front"] / 3.0 - 1,
            "film_pressure": (c[:, IDX["SF_FAT"]] / 1e6 - s["p_film_max_MPa"]) / (c[:, IDX["SF_FAT"]] / 1e6),
            "asperity_pressure": (c[:, IDX["PA_MAX"]] / 1e6 - pa_max) / (c[:, IDX["PA_MAX"]] / 1e6),
            "temperature": (180.0 - s["T_face_max_C"]) / 180.0, "end_play": (0.30 - s["end_play_mm"]) / 0.30,
            "gallery_pressure": s["p_gallery_bar"] / 1.0 - 1, "pad_fill": s["fill_min"] / 0.8 - 1,
            "fatigue": 1 - s["fatigue_D"], "wear_vs_overlay": (c[:, IDX["OVERLAY"]] * 1e6 - s["wear_max_um"]) / (c[:, IDX["OVERLAY"]] * 1e6),
            "axial_travel": (s["end_play_thermal_mm"] / 2 - np.abs(s["x_mm"])) / (s["end_play_thermal_mm"] / 2),
        }
        return {k: v.astype(np.float32) for k, v in m.items()}

    def reset_deformation(self):
        for a in (self.plas, self.pile, self.scuff, self.crank_dmg, self.impN, self.impTot, self.debGen, self.plasMax, self.pileMax, self.scuffN, self.crankMax):
            a.zero_()
        self.d_alive.zero_(); self.rin.fill_(1.0); self.grooveD.fill_(float(self.cal_np[0, IDX["GROOVE_D"]])); self.grooveCond.fill_(1.0); self.edgeLeak.zero_()

    def step(self, dt: float = 1.0 / 60.0, warp: float = 912.0, nsub: int | None = None, solve_film: bool = True):
        """solve_film=False reuses the previous pressure, stiffness and damping and integrates only the
        axial / structural / tangential dynamics: the film changes slowly compared with a 250 Hz mode,
        so a sweep can sample vibration at kHz rates for a fraction of the cost."""
        d, B = self.device, self.B
        dte = dt * warp
        if not solve_film:
            ns = nsub if nsub is not None else max(1, int(round(dt / 2.5e-4)))
            wp.launch(K.k_axial, dim=B, device=d, inputs=[
                self.cal, self.fm, self.mode, self.rpm, self.load, self.pedal, self.clutch, self.W, self.Fc, self.k, self.c,
                self.wear_max, self.ep0, self.x, self.v, self.angle, self.om, self.y, self.vy, self.psi, self.dpsi, dt, ns],
                outputs=[self.Fext, self.acc_rms, self.Ffront, self.impE, self.impN, self.acc_inst, self.chatter, self.slipfrac, self.mub_dyn])
            self.step_i += 1
            return
        self._warmup_host(dt, warp)
        wp.launch(K.k_prep, dim=B, device=d, inputs=[
            self.cal, self.fm, self.rpm, self.load, self.toil, self.ra, self.sev, self.x, self.angle, self.Tface, self.TfaceF,
            self.wear_mean, self.spall, self.oil, self.gf, self.rpm_axis, self.load_axis, self.misfire, self.step_i, self.seed, dt],
            outputs=[self.mu, self.muEff, self.muBase, self.aer, self.pgal, self.psup, self.sig0, self.dentW, self.cone,
                     self.bendX, self.bendY, self.om, self.cyc_phase, self.pumpF, self.ep0, self.prime, self.primeT, self.grooveOff])
        wp.launch(K.k_mu, dim=(B, 2, NT, NR), device=d, inputs=[self.cal, self.muBase, self.toil, self.Tcell], outputs=[self.muCell])
        # pad supply from last step's flow budget (one-step lag); first step: full supply
        if self.step_i == 0:
            self.fill.fill_(1.0)
        wp.launch(K.k_grooves, dim=(B, 6), device=d, inputs=[self.cal, self.groove, self.pile, self.plas, self.wear, self.muEff, self.psup], outputs=[self.grooveD, self.grooveCond, self.edgeLeak])
        wp.launch(K.k_pads, dim=(B, 2), device=d, inputs=[self.cal, self.psup, self.qin, self.qout, self.qleak, self.dentW, self.grooveCond, self.edgeLeak],
                  outputs=[self.fill, self.psup_pad, self.fill_min, self.qsupply])
        # real solve first, then the stiffness solve at 1.03 h0 perturbed from the fresh solution
        self._solve(1.0, self.p, self.W, self.Fc, self.hmin, self.lam, self.pmax, self.cav, self.sweeps)
        wp.copy(self.p2, self.p)
        self._solve(1.03, self.p2, self.W2, self.Fc2, self.hmin2, self.lam2, self.pmax2, self.cav2, self.sweeps_stiff)
        self.qin.zero_(); self.qout.zero_(); self.qside.zero_(); self.qleak.zero_()
        wp.launch(K.k_flow, dim=(B, 2, NT, NR), device=d, inputs=[
            self.cal, self.groove, self.rj, self.h, self.p, self.phiP, self.muCell, self.om, self.psup, self.dentD],
            outputs=[self.qin, self.qout, self.qside, self.qleak, self.grooveOff])
        wp.launch(K.k_stiffness, dim=B, device=d, inputs=[self.W, self.Fc, self.W2, self.Fc2, self.cal, self.x, self.muEff, self.hmin],
                  outputs=[self.k, self.c])
        if dt > 0:
            ns = nsub or max(1, int(round(dt / 2.5e-4)))
            wp.launch(K.k_axial, dim=B, device=d, inputs=[
                self.cal, self.fm, self.mode, self.rpm, self.load, self.pedal, self.clutch, self.W, self.Fc, self.k, self.c,
                self.wear_max, self.ep0, self.x, self.v, self.angle, self.om, self.y, self.vy, self.psi, self.dpsi, dt, ns],
                outputs=[self.Fext, self.acc_rms, self.Ffront, self.impE, self.impN, self.acc_inst, self.chatter, self.slipfrac, self.mub_dyn])
        if dte > 0:
            wp.launch(K.k_thermal_cell, dim=(B, 2, NT, NR), device=d, inputs=[
                self.cal, self.groove, self.rj, self.h, self.pasp, self.muCell, self.om, self.toil, self.mub, self.Tcell, self.Tcell2, dte])
            wp.copy(self.Tcell, self.Tcell2)
            wp.launch(K.k_oil, dim=B, device=d, inputs=[self.cal, self.fm, self.toil, self.load, self.Tface, dte], outputs=[self.oil])
            self.wsum.zero_(); self.wmax.zero_(); self.dV.zero_(); self.warp_lim.zero_()
            wp.launch(K.k_wear, dim=(B, 2, NT, NR), device=d, inputs=[
                self.cal, self.fm, self.groove, self.rj, self.pasp, self.p, self.om, self.pmax, self.wear_max, self.Tcell, self.oil, dte, self.h, self.sigC, self.angle],
                outputs=[self.wear, self.rin, self.wsum, self.wmax, self.dV, self.corr, self.plas, self.pile, self.scuff, self.crank_dmg, self.warp_lim])
            wp.launch(K.k_impact, dim=(B, NT, NR), device=d, inputs=[self.cal, self.rj, self.pasp, self.paSum, self.impE, self.wear_max], outputs=[self.plas])
            self.debN.zero_(); self.debEmb.zero_(); self.debD.zero_()
            wp.launch(K.k_debris, dim=(B, self.NDEB), device=d, inputs=[
                self.cal, self.groove, self.rj, self.h, self.p, self.pasp, self.om, self.muEff, self.angle, self.debGen, dte, dt, self.seed, self.step_i,
                self.d_th, self.d_r, self.d_z, self.d_d, self.d_alive, self.d_emb],
                outputs=[self.wear, self.plas, self.pile, self.crank_dmg, self.debN, self.debEmb, self.debD])
            wp.launch(K.k_finish, dim=B, device=d, inputs=[
                self.cal, self.fm, self.toil, self.runout, self.wsum, self.wmax, self.npad, self.dV, self.W, self.Fc, self.Tv, self.om,
                self.pmax, self.Tcell, self.groove, dte, self.mub, self.x, self.v, self.acc_rms, self.angle],
                outputs=[self.wear_mean, self.wear_max, self.Vworn, self.ppm, self.ep, self.tEng, self.Tface, self.Tmax, self.TfaceF, self.TmaxF,
                         self.fatD, self.spall, self.Tb, self.Pfric, self.ckp_amp, self.ckp_jit, self.ep0, self.debGen, self.impE, self.impTot,
                         self.plas, self.pile, self.scuff, self.crank_dmg, self.plasMax, self.pileMax, self.scuffN, self.crankMax])
        self.step_i += 1

    # ------------------------------------------------------------------
    def signals(self) -> dict:
        g = lambda a: a.numpy()
        W, Fc, hmin, lam, Tv, Tb, k, pmax, cav = g(self.W), g(self.Fc), g(self.hmin), g(self.lam), g(self.Tv), g(self.Tb), g(self.k), g(self.pmax), g(self.cav)
        wm, wx = g(self.wear_mean), g(self.wear_max); oil = g(self.oil)
        return {
            "t_eng_h": g(self.tEng), "T_oil": g(self.toil), "rpm": g(self.rpm), "load": g(self.load), "pedal": g(self.pedal),
            "F_ext_kN": g(self.Fext) / 1e3, "F_film_kN": W[:, 0] / 1e3, "F_asp_kN": Fc[:, 0] / 1e3,
            "F_front_kN": g(self.Ffront) / 1e3, "F_asp_front_kN": Fc[:, 1] / 1e3,
            "h_min_um": hmin[:, 0] * 1e6, "lambda": lam[:, 0], "h_min_front_um": hmin[:, 1] * 1e6, "lambda_front": lam[:, 1],
            "p_film_max_MPa": pmax[:, 0] / 1e6, "cav_fraction": cav[:, 0],
            "x_mm": g(self.x) * 1e3, "v_mm_s": g(self.v) * 1e3, "vib_rms": g(self.acc_rms),
            "k_film_MN_m": k[:, 0] / 1e6, "c_squeeze_kNs_m": g(self.c) / 1e3,
            "T_visc_Nm": Tv[:, 0] + Tv[:, 1], "T_bound_Nm": Tb[:, 0] + Tb[:, 1], "P_fric_W": g(self.Pfric),
            "T_face_C": g(self.Tface), "T_face_max_C": g(self.Tmax), "T_front_C": g(self.TfaceF), "mu_mPas": g(self.mu) * 1e3,
            "p_gallery_bar": g(self.pgal) / 1e5, "p_supply_bar": g(self.psup) / 1e5,
            "end_play_mm": g(self.ep) * 1e3, "wear_mean_um": wm[:, 0], "wear_max_um": wx[:, 0], "wear_front_mean_um": wm[:, 1],
            "debris_ppm": g(self.ppm), "fatigue_D": g(self.fatD), "spall": g(self.spall), "dent_width_deg": g(self.dentW),
            "ckp_amp": g(self.ckp_amp), "ckp_jitter_us": g(self.ckp_jit), "misfire": g(self.misfire).sum(1).astype(np.float32),
            "cone_mrad": g(self.cone)[:, 0] * 1e3, "bend_tilt_um": np.hypot(g(self.bendX), g(self.bendY)) * 1e6,
            "T_front_max_C": g(self.TmaxF), "fill_min": g(self.fill_min)[:, 0], "fill_min_front": g(self.fill_min)[:, 1],
            "q_supply_ml_s": g(self.qsupply)[:, 0] * 1e6, "q_leak_ml_s": g(self.qleak) * 1e6, "q_side_ml_s": g(self.qside)[:, 0] * 1e6,
            "corrosion_um3": g(self.corr) * 1e18, "oxidation": oil[:, 0], "soot": oil[:, 1], "water": oil[:, 2], "TAN": oil[:, 3], "fuel": oil[:, 4],
            "plastic_max_um": g(self.plasMax) * 1e6, "pileup_max_um": g(self.pileMax) * 1e6, "scuffed_cells": g(self.scuffN), "crank_damage_max_um": g(self.crankMax) * 1e6,
            "impacts": g(self.impN), "impact_energy_J": g(self.impTot), "groove_depth_min_um": g(self.grooveD).min(1) * 1e6, "groove_cond_min": g(self.grooveCond).min(1),
            "q_edge_ml_s": g(self.edgeLeak).sum(1) * 1e6, "debris_particles": g(self.debN), "debris_embedded": g(self.debEmb),
            "debris_d_mean_um": np.where(g(self.debN) > 0, g(self.debD) / np.maximum(1, g(self.debN)), 0) * 1e6,
            "mu_sump_mPas": np.array([self._mu_host(b) for b in range(self.B)], np.float32) * 1e3, "pump_factor": g(self.pumpF), "end_play_thermal_mm": g(self.ep0) * 1e3,
            "warmup_active": self.cold.astype(np.float32), "prime_remaining_s": g(self.prime), "groove_offset_deg": g(self.grooveOff),
            "warp_limited_cells": g(self.warp_lim), "acc_inst_g": g(self.acc_inst), "f_film_Hz": self.mode_frequencies()["film"], "f_struct_Hz": self.mode_frequencies()["struct"],
            "f_squeal_Hz": self.mode_frequencies()["tab"], "chatter_rms_rad_s": g(self.chatter), "stick_slip_frac": g(self.slipfrac), "mu_boundary": g(self.mub_dyn),
        }

    def mode_frequencies(self):
        """Undamped natural frequencies of the three axial / tangential modes, and the film mode's damping ratio.
        film:   crank mass on the two oil films, k from the perturbation solve, c from squeeze damping
        struct: flexplate / converter (or clutch pack) mass on its modal spring to the flange
        tab:    washer inertia on its anti-rotation tab (the squeal mode)"""
        c = self.cal_np
        k = self.k.numpy().sum(1); m = c[:, IDX["M_CR"]]
        cc = self.c.numpy()
        with np.errstate(invalid="ignore", divide="ignore"):
            f_film = np.sqrt(np.maximum(k, 0) / m) / (2 * np.pi)
            zeta = np.where(k > 0, cc / (2 * np.sqrt(np.maximum(k, 1e-9) * m)), np.inf)
        return {"film": f_film.astype(np.float32), "film_zeta": zeta.astype(np.float32),
                "struct": (np.sqrt(c[:, IDX["K_STRUCT"]] / c[:, IDX["M_FLEX"]]) / (2 * np.pi)).astype(np.float32),
                "tab": (np.sqrt(c[:, IDX["K_TAB"]] / c[:, IDX["J_WASH"]]) / (2 * np.pi)).astype(np.float32)}

    def _mu_host(self, b):
        c = self.cal_np[b]; T = float(self.toil.numpy()[b]) if False else float(self.Toil[b]) if self.cold[b] else float(self.toil.numpy()[b])
        import math
        f = lambda v: math.log10(math.log10(v + 0.7)); t1, t2 = math.log10(313.15), math.log10(373.15)
        Bw = (f(c[IDX["NU40"]]) - f(c[IDX["NU100"]])) / (t2 - t1); Aw = f(c[IDX["NU40"]]) + Bw * t1
        nu = max(1.5, 10 ** (10 ** (Aw - Bw * math.log10(max(200, T + 273.15)))) - 0.7)
        return nu * 1e-6 * c[IDX["RHO_OIL"]] * (1 - 0.00065 * (T - 15))

    def deformation_maps(self):
        return {"plastic": self.plas.numpy()[:, 0], "pileup": self.pile.numpy()[:, 0], "scuff": self.scuff.numpy()[:, 0], "crank": self.crank_dmg.numpy()}

    def debris(self):
        return {"theta": self.d_th.numpy(), "r": self.d_r.numpy(), "d": self.d_d.numpy(), "alive": self.d_alive.numpy(), "embedded": self.d_emb.numpy()}

    def set_grade(self, name):
        GR = {"0W-20": (44, 8.5), "5W-30": (64, 10.8), "10W-40": (96, 14.5), "15W-40": (108, 14.8), "20W-50": (170, 19)}
        n40, n100 = GR[name]; c = self.cal_np.copy(); c[:, IDX["NU40"]] = n40; c[:, IDX["NU100"]] = n100; self.set_calibration(c)

    def signal_matrix(self) -> np.ndarray:
        s = self.signals()
        return np.stack([s[n] for n in SIGNALS], axis=1).astype(np.float32)

    def pressure(self, face: int = 0) -> np.ndarray:
        return self.p.numpy()[:, face]

    def temperature(self, face: int = 0) -> np.ndarray:
        return self.Tcell.numpy()[:, face]

    def film(self, face: int = 0) -> np.ndarray:
        return self.h.numpy()[:, face]

    def wear_map(self, face: int = 0) -> np.ndarray:
        return self.wear.numpy()[:, face]

    def pad_fill(self, face: int = 0) -> np.ndarray:
        return self.fill.numpy()[:, face]

    def gas_torque(self, rpm: float, load: float, misfire_slot: int | None = None) -> np.ndarray:
        """720-degree torque signature (N m) for the whole engine at a table node."""
        ir = int(np.argmin(np.abs(self.rpms_np - rpm))); il = int(np.argmin(np.abs(self.loads_np - load)))
        out = np.zeros(720)
        for k in range(8):
            t = self.gas_torque_np[ir, il, 1 if misfire_slot == k else 0]
            out += np.roll(t, 90 * k)
        return out
