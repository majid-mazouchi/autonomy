# thrust_warp — batched, GPU-ready thrust bearing / crank walk simulator

The physics of the interactive page (v5) ported to NVIDIA Warp so that hundreds of
vehicles run in parallel and the whole calibration table can be varied per vehicle.

Version 3.3 adds the RCA-readiness layer: `sensors.py` (production channel set with noise,
quantization, broadcast rates, dropouts, drift and lag), `study.py` (discriminability of the failure
modes through the production sensors, plus Saltelli/Sobol sensitivity), `intervene.py` (do-operator
with matched build spread and seed, dose-response curves), and a stability limiter on the wear step
that makes long time-warp steps safe (`warp_limited_cells` reports when the warp is too coarse).

Version 3.2 adds vibration: a structural axial mode (flexplate / converter or clutch pack mass on a
modal spring to the crank flange) through which the external axial force reaches the thrust face, a
washer tangential mode on its anti-rotation tab with a velocity-weakening friction law (stick-slip
chatter and squeal in boundary contact), `Simulator.mode_frequencies()`, `step(solve_film=False)` for
kHz vibration sampling, and `thrust_warp.campbell.sweep()` which runs one rpm per batch slot and
returns the order-tracked response, the mode lines and the order crossings for a Campbell diagram.

Version 3.1 closes parity with page v16: washer spin (per-vehicle groove offset through every kernel, six-fold supply alignment, back-face rubbing), dry / slow-prime hot restart (`hot_restart()`), low-oil-supply failure mode, and `margins()` returning the eleven design margins per vehicle. Failure-mode vector is now length 10.

Version 3 brings the package level with page v16: plastic flow with pile-up rims, brinelling
from landings, scuffing with roughening, crank face scoring in the crank frame, groove depth loss
with depth^3 delivery and break-out edge leaks, tracked third-body particles (spawn, transport,
filter, embed, scratch), crank imperfections (waviness, conicity, fillet ridge, combined
roughness), chamfer and taper fraction as film terms, Walther oil grades with cold start and
warm-up, pump inlet cavitation, and thermal end play. `Simulator.cold_start(tamb)`,
`set_grade('0W-20')`, `reset_deformation()`, `deformation_maps()`, `debris()` are the new entry
points; verify.py has 31 checks.

Version 2 adds the micro-level chain: flow-resolved starvation with the dent as a leak
channel, measured or synthetic dent height maps with raised rims, per-cell temperature
and viscosity on both faces, overlay corrosion coupled to oil chemistry, oil ageing
states, and an ensemble-Kalman digital-twin interface.

Same model: 120 x 8 polar Reynolds solve on both thrust faces (Jacobi sweeps with
cavitation clamp and pressure cap), Patir-Cheng pressure flow factor, Greenwood-Williamson
asperity contact with plastic running-in, per-column thermal balance on the rear face
(lumped on the front), thermo-elastic coning, combustion bending from a Wiebe cylinder
model, 25 kg axial dynamics with 4 kHz substeps, Archard wear, cavitation erosion,
overlay fatigue, oil pressure and viscosity, CKP amplitude and jitter. Failure modes:
dent, aeration, debris, fuel dilution, release-bearing preload, misalignment, misfire,
fatigue spall, tilt, runout, initial end play, washer spin, low oil supply, dry hot restart.

## Layout
    thrust_warp/calibration.py   60-parameter dataclass; reads the page's Calibration JSON export
    thrust_warp/geometry.py      grid, radii, groove masks
    thrust_warp/combustion.py    Wiebe cylinder pressure tables on an (rpm, load) grid
    thrust_warp/drive_cycles.py  urban / highway / launch / tow schedules
    thrust_warp/kernels.py       the eight Warp kernels
    thrust_warp/simulator.py     Simulator(B, cal): set_scenario(), step(dt, warp), signals()
    thrust_warp/fleet.py         Monte Carlo fleet: survival, B10, detection lead time
    thrust_warp/dataset.py       labelled time-series + pressure fields for KNO/FNO/PINN work
    thrust_warp/calibrate.py     batched finite-difference Gauss-Newton fit to end-play data
    thrust_warp/dent_shapes.py   dent_with_rim, score_line, pitting, edge_burr height maps
    thrust_warp/sensors.py       production sensor bus: noise, quantization, rates, dropouts, drift, lag
    thrust_warp/study.py         discriminability study and Sobol sensitivity
    thrust_warp/intervene.py     interventions, matched counterfactuals, dose-response
    thrust_warp/campbell.py      speed sweep, order tracking, Campbell diagram data, order/mode crossings
    thrust_warp/twin.py          EnsembleTwin: EnKF estimation of dent severity, wear multiplier, end play, fuel
    verify.py                    checks steady numbers against the page's solver
    run_all.sh / run_all.bat     install, verify, small dataset, small fleet, small fit

## Quick start
    pip install -r requirements.txt
    python verify.py
    python -c "from thrust_warp import *; s=Simulator(64); s.set_scenario(rpm=1200, pedal=1); s.step(1/60, 912); print(s.signals()['lambda'])"

Use `device="cuda"` (default when available). On CPU a step costs about 5 ms per vehicle;
on a GPU the batch dimension is close to free up to a few thousand vehicles.

## Micro-level physics (v2)
Flow: per cell q = (omega r h / 2 - phi_p h^3/(12 mu) dp/(r dtheta)) dr; each pad's inlet demand
is compared with groove delivery Q_GROOVE_K * p_sup plus CARRY times the previous pad's outlet,
minus the dent leak Q = DENT_LEAK_K d^3 w /(12 mu L) p_sup where the dent crosses a groove.
Fill fraction < 1 lowers that groove's supply pressure as fill^STARVE_EXP. Signals: fill_min,
q_supply, q_leak, q_side; `sim.pad_fill()` gives all six pads.

Dent shapes: `sim.set_dent_map(h)` accepts any (NT, NR) height map in metres, positive recess,
negative raised material. A rim touches first, wears in, then leaves a leak path.

Thermal: every cell on both faces has its own temperature (shear + asperity heating, convection,
conduction in theta and r) and viscosity, so trailing edges and the wake of a dent run hot.

Corrosion: rate = K_CORR exp(-Ea/R (1/T - 1/T_ref)) (1 + A_TAN TAN + A_WATER water + A_FUEL fuel),
times (1 + SYN_CORR) on cells in asperity contact, applied to exposed overlay; corrosion_um3
accumulates the volume. Oil states (oxidation, soot, water, TAN, fuel) evolve with temperature,
load and the aeration / dilution modes; `sim.oil_change()` resets them.

Twin: `EnsembleTwin` runs N members with sampled hidden parameters, predicts the observed
signals, and applies the EnKF update each telemetry sample. `twin.demo()` recovers a
synthetic 0.45 dent from CKP jitter, oil pressure and face temperature.

## Units and conventions
SI throughout, except wear which is stored in micrometres (float32 resolution). Face 0 is
the rear face (loaded by the clutch), face 1 the front. `warp` multiplies dt for wear,
fatigue and thermal only, exactly as the page's time-warp slider. Severities are 0..1.

## Calibration notes
`calibrate.fit` builds a batch of 1 + 2N vehicles (nominal plus +/- perturbations of each
free parameter in log space), so one rollout gives the Jacobian of the end-play misfit.
The column norms of J are the identifiability report: a zero column means the data cannot
see that parameter (for example KW_BK before the overlay wears through). `wp.Tape`
adjoints are not used because the sweeps and wear updates are in-place; a ping-pong
version for exact gradients is the natural next step.

## v3 physics in one place
Plastic: d(delta)/dt = C_PLAST (pa/Y - 1)+, rims PILEUP * delta / 4 on neighbours; brinelling: K_IMP * 1/2 m v^2 / Y
distributed by asperity pressure when v > V_IMP; scuffing when T_cell > T_SCUFF and lambda < 1.2: K_SCUFF per metre,
roughness *= (1 + ROUGH_SCUFF ds), crank scored at HARD_RATIO; crank scoring from exposed bronze and debris; grooves:
depth = GROOVE_D - rims in the groove + half the wall flow, delivery ∝ depth^3, edge leak ∝ d_land^3 on a worn outer
land; particles: DEB_FRAC of removed volume at DEB_D_MEAN (lognormal), transported by u(z), filtered at FILTER_RATE,
embed at EMBED_RATE when d > h (recess 0.35 d, stands proud 0.3 d) else scratch K_3B d; Walther viscosity from NU40/NU100
per cell, pump factor min(1, MU_PUMP_LIM / mu_sump), warm-up dT/dt = (engine heat + friction - HA_AMB (T - T_amb)) / C_OIL,
EP0(T) = EP0 + K_EP_T (T - 20).

## Known simplifications
Front face temperature is lumped. Combustion tables use nearest (rpm, load) nodes. The
misfire draw uses Warp's per-vehicle RNG, so runs are reproducible for a given seed.
Coefficients are the page's order-of-magnitude values; replace them with fleet data.
