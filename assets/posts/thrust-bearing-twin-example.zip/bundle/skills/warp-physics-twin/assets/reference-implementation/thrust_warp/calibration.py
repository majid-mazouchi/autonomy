"""Calibration set: the same 60 parameters as the interactive page (v5), in one dataclass.

Load / save the JSON exported by the page's Calibration window, and pack into a
(B, NCAL) float32 array so every vehicle in a batch can carry its own values.
"""
from __future__ import annotations
import json, math
from dataclasses import dataclass, fields, asdict
import numpy as np

SQ2 = math.sqrt(2.0)


@dataclass
class Calibration:
    # Geometry
    EP0: float = 0.10e-3          # m, initial crank end play
    TAPER: float = 25e-6          # m, taper-land depth at the leading edge
    DENT_D: float = 45e-6         # m, dent depth at 100 % severity
    SPALL_D: float = 30e-6        # m, fatigue spall depth
    OVERLAY: float = 25e-6        # m, overlay thickness
    # Dynamics
    M_CR: float = 25.0            # kg, axial mass
    M_BLOCK_RATIO: float = 0.35   # crank -> block transfer for the accelerometer
    F_BIAS_MAN: float = 300.0     # N, rearward bias with the pedal up (manual)
    F_BIAS_AUTO: float = 150.0    # N, converter preload
    BEND_K: float = 5e-6          # m, bending tilt per unit (60 kN) gas force
    # Contact
    EK: float = 40e9 * 0.0067     # Pa, E'K for Greenwood-Williamson
    PA_MAX: float = 80e6          # Pa, asperity pressure cap
    P_CAP: float = 60e6           # Pa, film pressure cap (elastic limit)
    SIG_RA: float = 1.25 * SQ2    # sigma per unit Ra
    PC_ON: float = 1.0            # Patir-Cheng on/off
    K_PL: float = 2e-3            # 1/m, plastic flattening rate
    RUNIN_MIN: float = 0.35       # lowest roughness fraction
    # Wear
    KW_OV: float = 4e-16          # 1/Pa, Archard on overlay
    KW_BK: float = 1e-15          # 1/Pa, Archard on backing
    K_CAV: float = 2e-13          # m/rad, cavitation erosion
    M_OIL: float = 5.5            # kg, oil charge
    # Friction
    MUB_OV: float = 0.12
    MUB_BK: float = 0.20
    # Oil
    MU100: float = 0.0095         # Pa s at 100 C
    MU_SLOPE: float = 0.03        # 1/K
    P_RELIEF: float = 4.5e5       # Pa
    G0: float = 7e-10             # m3/(s Pa)
    MU_REF: float = 0.0095
    Q_PER_RPM: float = 1.667e-7   # m3/s per rpm
    SUP_FRAC: float = 0.75
    # Thermal
    C_TH: float = 45.0            # J/K
    HA: float = 25.0              # W/K
    F_TH: float = 0.6
    K_CIRC: float = 0.4           # W/K between adjacent columns
    CONE_K: float = 2e-5          # rad/K
    # Fatigue
    SF_FAT: float = 12e6
    B_FAT: float = 4.0
    N_REF: float = 1e7
    # Sensor
    CKP_GAP: float = 1.0e-3
    CKP_G0: float = 1.5e-3
    CKP_X0: float = 0.5e-3
    JIT_AMP: float = 40.0
    JIT_VEL: float = 2e5
    # Engine (Wiebe)
    BORE_D: float = 103.25e-3
    STROKE: float = 92e-3
    ROD_L: float = 155e-3
    CR: float = 10.7
    Q_CYL: float = 2600.0
    P_MAN_MIN: float = 0.35e5
    WIEBE_A: float = 5.0
    WIEBE_M: float = 2.0
    BURN_DUR: float = 45.0
    SPARK_ADV: float = 22.0
    GAMMA: float = 1.32
    MISF_SLOT: float = 2.0
    # Flow / starvation
    Q_GROOVE_K: float = 8.0e-12   # m3/s per Pa of groove supply pressure delivered to each groove
    CARRY: float = 0.6            # fraction of a pad's outlet flow carried into the next pad
    DENT_LEAK_K: float = 0.4      # dent leak conductance scale (times d^3 w / 12 mu L)
    STARVE_EXP: float = 1.0       # supply pressure falls as fill^STARVE_EXP
    # Corrosion / tribochemistry (overlay)
    K_CORR: float = 0.002         # um/h base corrosion rate at T_REF on exposed overlay
    EA_CORR: float = 60e3         # J/mol activation energy
    T_REF_CORR: float = 120.0     # C
    A_TAN: float = 0.8            # rate multiplier per mgKOH/g of TAN
    A_WATER: float = 15.0         # per volume fraction of water
    A_FUEL: float = 3.0           # per volume fraction of fuel
    SYN_CORR: float = 3.0         # corrosion-wear synergy on cells in contact
    # Oil ageing
    K_OX: float = 2.0e-4          # oxidation units per hour at 100 C
    EA_OX: float = 80e3           # J/mol
    TAN_PER_OX: float = 2.0       # mgKOH/g per oxidation unit
    VISC_PER_OX: float = 0.6      # viscosity multiplier slope per oxidation unit
    SOOT_RATE: float = 5.0e-5     # volume fraction per hour at 100 % load
    VISC_PER_SOOT: float = 8.0
    WATER_IN: float = 0.0         # water ingress volume fraction per hour (short trips)
    WATER_OUT: float = 0.05       # water boil-off fraction per hour above 90 C
    TAN0: float = 0.5
    # Washer design (grid geometry itself is a Simulator argument; these are film-height terms)
    TAPER_FRAC: float = 0.6       # fraction of the pad occupied by the taper land
    CHAMFER_MM: float = 0.6       # inner-edge chamfer, mm (no film on the chamfer)
    GROOVE_D: float = 60e-6       # m, groove depth as machined
    EDGE_LEAK_K: float = 0.5      # break-out leak conductance scale on a worn outer land
    # Crank imperfections
    WAVE_AMP: float = 0.0         # m, crank face lobing amplitude
    WAVE_ORDER: float = 3.0       # lobes
    CONE_CR: float = 0.0          # m, flange conicity across the face
    FILLET_INT: float = 0.0       # m, fillet-to-chamfer interference ridge
    RA_CRANK: float = 0.4         # um, crank face roughness (combined with washer Ra)
    # Deformation and damage
    Y_OV: float = 60e6            # Pa, overlay yield
    Y_BK: float = 220e6           # Pa, backing yield
    C_PLAST: float = 1e-8         # m/s plastic flow rate per unit (pa/Y - 1)
    PILEUP: float = 0.4           # share of displaced volume piled up on neighbours
    V_IMP: float = 0.004          # m/s landing velocity above which brinelling occurs
    K_IMP: float = 1.0            # share of impact energy absorbed as indentation
    T_SCUFF: float = 200.0        # C, scuffing temperature when lambda < 1.2
    K_SCUFF: float = 3e-12        # m/m scuffing removal per metre slid
    ROUGH_SCUFF: float = 0.004    # 1/m roughening rate of a scuffed cell
    HARD_RATIO: float = 0.08      # crank damage share relative to the washer
    # Third-body particles
    DEB_FRAC: float = 0.02        # share of removed volume that becomes tracked particles
    DEB_D_MEAN: float = 12e-6     # m, median particle size
    FILTER_RATE: float = 0.5      # 1/h removal by the filter
    EMBED_RATE: float = 2.0       # 1/h embedding rate of an oversize particle in a starved cell
    K_3B: float = 2e-4            # scratch depth per pass as a fraction of particle size
    # Oil grade (Walther / ASTM D341) and cold start
    NU40: float = 64.0            # cSt at 40 C (5W-30)
    NU100: float = 10.8           # cSt at 100 C
    RHO_OIL: float = 850.0        # kg/m3 at 15 C
    MU_PUMP_LIM: float = 0.8      # Pa s above which the pump inlet cavitates
    C_OIL: float = 9000.0         # J/K oil charge plus wetted metal
    K_ENG_HEAT: float = 25.0      # W per rpm-fraction and load-fraction, scaled x40
    HA_AMB: float = 18.0          # W/K oil to ambient
    K_EP_T: float = 0.2e-6        # m/K end-play growth with block temperature
    T_CRANK_RPM: float = 250.0    # cranking speed
    # Structural axial mode carrying load through the thrust face (flexplate / converter or clutch pack)
    M_FLEX: float = 8.0           # kg, effective mass of the flexplate-converter or clutch assembly
    K_STRUCT: float = 2.0e7       # N/m, modal stiffness between that mass and the crank flange
    Z_STRUCT: float = 0.03        # modal damping ratio of the structural mode
    # Washer tangential (anti-rotation tab) mode: stick-slip chatter / squeal in boundary contact
    J_WASH: float = 1.2e-5        # kg m2, washer polar inertia
    K_TAB: float = 2.0e3          # N m/rad, anti-rotation tab torsional stiffness
    Z_TAB: float = 0.02           # damping ratio of the tab mode
    MU_S: float = 0.16            # static boundary friction
    MU_K: float = 0.09            # kinetic boundary friction
    V_STRIB: float = 0.8          # m/s, Stribeck scale of the falling (mixed-regime) friction branch

    # ---- helpers -------------------------------------------------------
    @classmethod
    def names(cls) -> list[str]:
        return [f.name for f in fields(cls)]

    @classmethod
    def index(cls, name: str) -> int:
        return cls.names().index(name)

    def to_vector(self) -> np.ndarray:
        return np.array([getattr(self, n) for n in self.names()], dtype=np.float32)

    @classmethod
    def from_vector(cls, v) -> "Calibration":
        return cls(**{n: float(x) for n, x in zip(cls.names(), v)})

    def save(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump({"model": "thrust_warp", "parameters": [
                {"name": n, "value": getattr(self, n)} for n in self.names()]}, f, indent=2)

    @classmethod
    def load(cls, path: str) -> "Calibration":
        """Reads either this module's JSON or the page's Calibration-window export."""
        with open(path) as f:
            j = json.load(f)
        c = cls()
        items = j["parameters"] if isinstance(j, dict) and "parameters" in j else (
            j if isinstance(j, list) else [{"name": k, "value": v} for k, v in j.items()])
        for it in items:
            if it["name"] in cls.names():
                setattr(c, it["name"], float(it["value"]))
        return c

    def batch(self, B: int) -> np.ndarray:
        """(B, NCAL) with the same values in every row; edit rows for per-vehicle spread."""
        return np.tile(self.to_vector()[None, :], (B, 1))


NCAL = len(Calibration.names())
IDX = {n: i for i, n in enumerate(Calibration.names())}
