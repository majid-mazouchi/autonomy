# Kernel patterns (shapes to copy)

## Calibration array
    @dataclass class Calibration: EP0: float = 0.10e-3; ...      # one field per coefficient
    IDX = {name: i}; I_EP0 = wp.constant(IDX["EP0"])              # index constants for kernels
    cal = wp.array(cal_dataclass.batch(B), dtype=float)          # (B, NCAL); edit rows for spread

## Per-vehicle prep (dim=B)
Viscosity with ageing and dilution, oil pressure from pump/leakage/relief, coning from face
temperature, per-cycle random events from a phase accumulator, table lookups (rpm, load)
by nearest node, combustion bending as a vector sum over cylinders.

## Field build (dim=(B,F,NT,NR))
    h = h0(x, face) + taper(pad_s) + sign*(tilt + runout + bending) + cone*(r - r_m) + dent + spall + map + wear
    sigC = sig0 * rin;  phiP = 1 - 0.9 exp(-0.56 h / sigC)

## Jacobi sweep (dim=(B,F,NT,NR)) with ping-pong buffers
    if groove: p_out = psup_pad[groove_of(i)]; return
    coefficients cE, cW (theta), cN, cS (radial, with r +/- dr/2), source (om/2)(hE - hW)/(2 dth)
    p_out = clamp(p_in + relax*(v - p_in), 0, P_CAP)

## Integrate (dim=(B,F,NT,NR)) with atomics
    atomic_add(W, p dA); atomic_add(Fc, pa dA); atomic_add(Tv, mu om r / h r^2 dA)
    atomic_min(hmin), atomic_min(lam), atomic_max(pmax), atomic_add(cav, dA/A_pad where p == 0)

## Flow budget (dim=(B,F,NT,NR)) then pads (dim=(B,F))
    q_theta = (om r h/2 - phi h^3/(12 mu) dp/(r dth)) dr; atomic_add qin at pad inlet, qout at outlet
    q_side at outer ring; dent leak K d^3 w/(12 mu L) psup on groove columns crossed by the dent
    fill = min(1, (Q_GROOVE_K psup + CARRY qout[prev] - leak) / qin); psup_pad = psup fill^n

## Axial dynamics (dim=B, inner loop over substeps)
    external force from mode/pedal/load + 1x/4x ripples + failure-mode terms
    v = (v + ds/m F_net) / (1 + ds c/m + ds^2 k/m); x += ds v; limits from EP0/2 and wear on each face
    accumulate acc^2 for the accelerometer RMS

## Thermal per cell (dim=(B,F,NT,NR))
    q = mu om^2 r^2 / h dA + mub pa om r dA
    Tss = (hA Toil + f q + k (T_ip + T_im + T_jp + T_jm)) / (hA + k_sum); T += (Tss - T)(1 - exp(-dte/tau))

## Wear per cell (dim=(B,F,NT,NR))
    Archard kw pa om r dte (+ debris); cavitation erosion on p == 0 cells with a pressurised neighbour;
    running-in rin *= exp(-K_PL (pa/PA_MAX)^2 om r dte); corrosion Arrhenius x chemistry x synergy on exposed overlay;
    wear_um = min(cap, wear_um + dw*1e6); atomic sums for mean/max/volume

## Finish (dim=B)
    end play = EP0 + mean wear both faces; debris ppm from worn volume; fatigue Basquin-Miner -> spall;
    CKP amplitude and jitter; face mean/max temperatures from the cell field
