# Uses of the batched simulator

## Dataset (dataset.py)
`random_scenarios(B, rng)` assigns 0-2 failure modes per vehicle with severities 0.2-1.0
and returns the scenario kwargs plus a `(B, n_modes)` label matrix. `generate()` runs each
drive cycle, optionally pre-ages vehicles on random duty, records `signal_matrix()` per
step and pressure fields every k steps, and saves an npz with signal, mode and cycle
names. Default warp is small (200) so the cycle is a time series; use `pre_age_h` for
worn states.

## Fleet (fleet.py)
`sample_fleet()` perturbs EP0 per vehicle, roughness, oil temperature, clutch force and
assigns defects by share. `run_fleet()` samples the duty cycle at random instants (the
warp step is much longer than a schedule step), records first symptom (sustained lambda
below a threshold or debris above ppm) and time to the end-play limit, and returns
survival, B10, median life and detection lead time.

## Calibration (calibrate.py)
Batch of 1 + 2N vehicles (nominal plus log-space perturbations of each free parameter)
gives the Jacobian of the end-play misfit in one rollout; damped Gauss-Newton with a
trust radius; the column norms of J are the identifiability report (a zero column means
the data cannot see that parameter). Prefer this over `wp.Tape` until the kernels are
ping-pong throughout.

## Twin (twin.py)
`EnsembleTwin(N, hidden, observed)`: N members carry sampled hidden parameters (dent
severity, wear multiplier, initial end play, fuel fraction); each telemetry sample runs
one predict step, then the EnKF update with perturbed observations and mild inflation;
parameters are clipped to bounds and re-applied to the calibration array and scenario.
`demo()` recovers a synthetic dent from CKP jitter, oil pressure and face temperature.
Extend `hidden` by adding a bound and an `_apply` branch; extend `observed` with any
signal name.
