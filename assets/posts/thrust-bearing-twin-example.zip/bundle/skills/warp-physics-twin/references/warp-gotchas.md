# Warp gotchas (v1.5 to 1.16, CPU and CUDA)

Typing
- Every kernel argument is typed: `wp.array(dtype=float)`, `wp.array2d/3d/4d(dtype=float)`, `wp.array(dtype=int)`, scalars `float` / `int`.
- No implicit int/float mixing: `float(i)`, `int(x)`; literals inside kernels take the type of the expression (`0.5 * x` fine, `x / 2` with int `x` is integer division).
- Declare a variable once with a definite type; `tx = float(0.0)` before accumulating in a loop. Reassigning with a different type fails to compile.
- Module-level constants: `C_NT = wp.constant(120)`; Python ints from a dict are not visible inside kernels unless wrapped this way. Index constants for the calibration columns are the cleanest way to read `cal[b, I_KW]`.
- `wp.func` helpers must be typed too and return one value.

Control flow
- `if/elif/else`, `for i in range(n)`, `while`, early `return` are fine. No list, dict, tuple, string or exception inside kernels.
- Loop bounds may be runtime ints; nested loops of a few thousand iterations per thread (axial substeps) are fine.

Memory and launches
- `wp.launch(kernel, dim=(B, F, NT, NR), inputs=[...], outputs=[...])`; `b, f, i, j = wp.tid()` inside.
- Atomics: `wp.atomic_add(arr, b, f, v)`, `wp.atomic_max`, `wp.atomic_min` (fill the target with 1e9 first for min).
- Zero accumulators every step (`arr.zero_()`, `arr.fill_(v)`); `wp.copy(dst, src)` for ping-pong; `arr.assign(numpy)` to upload; `arr.numpy()` to download (synchronises).
- In-place read+write of one array in a kernel is fine for forward simulation but wrong under `wp.Tape`; write to a second buffer if adjoints are needed.
- Random: `st = wp.rand_init(seed, b * 100003 + step)`; `wp.randf(st)`; deterministic per (seed, vehicle, step).

Numerics
- Jacobi sweeps: 30 for the main solve, 12 for the stiffness solve with a warm start from the main pressure copy; relax 1.0 (Jacobi over-relaxation diverges).
- Clamp `p` to `[0, P_CAP]` each sweep (cavitation and elastic limit).
- Implicit conduction: `T = (hA*Toil + q + K*(T_ip + T_im)) / (hA + 2K)`; the explicit form with K/hA > 1 blows up in one step.
- Store wear in micrometres (float32 keeps 1e-3 µm steps); store lengths in metres.
- Startup: 30 steps at warp 0 before any wear or data collection.
- CPU speed: about 5 ms per vehicle per step at 120x8x2 cells with ~45 sweeps; kernels compile once per process (10-40 s the first time, cached afterwards).

Packaging
- `pip install warp-lang` (PyPI); the wheel bundles CUDA runtime pieces, CPU works without a driver.
- `wp.init()` prints device info to stderr; filter it in scripts that compare outputs.
- Keep numpy on the host for schedules, tables and statistics; keep kernels free of anything but arithmetic.
