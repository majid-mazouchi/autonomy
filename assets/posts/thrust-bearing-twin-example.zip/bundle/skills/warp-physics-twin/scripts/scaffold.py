#!/usr/bin/env python3
"""Scaffold a batched Warp physics package with the standard kernel order and a verify script.
Usage: scaffold.py <package_name> [--nt 120] [--nr 8] [--out DIR]
The generated physics is a single-face thrust film placeholder that runs on CPU; replace the
marked sections with the real model, keep the structure."""
import argparse, os, textwrap
ap = argparse.ArgumentParser(); ap.add_argument("name"); ap.add_argument("--nt", type=int, default=120); ap.add_argument("--nr", type=int, default=8); ap.add_argument("--out", default=".")
a = ap.parse_args(); root = os.path.join(a.out, a.name); pkg = os.path.join(root, a.name); os.makedirs(pkg, exist_ok=True)
W = lambda rel, txt: open(os.path.join(root, rel), "w").write(textwrap.dedent(txt).lstrip())

W(f"{a.name}/calibration.py", '''
    """Calibration dataclass; every coefficient here, per-vehicle via batch()."""
    from dataclasses import dataclass, fields
    import numpy as np, json

    @dataclass
    class Calibration:
        EP0: float = 0.10e-3        # m initial clearance
        TAPER: float = 25e-6        # m taper depth
        MU100: float = 0.0095       # Pa s
        MU_SLOPE: float = 0.03      # 1/K
        SIG_RA: float = 1.7678      # sigma per Ra
        EK: float = 2.68e8          # Pa, E'K
        PA_MAX: float = 80e6
        P_CAP: float = 60e6
        KW: float = 4e-16           # 1/Pa Archard
        M_CR: float = 25.0          # kg
        PSUP: float = 1.7e5         # Pa groove supply

        @classmethod
        def names(cls): return [f.name for f in fields(cls)]
        def to_vector(self): return np.array([getattr(self, n) for n in self.names()], np.float32)
        def batch(self, B): return np.tile(self.to_vector()[None, :], (B, 1))
        def save(self, path): json.dump({"parameters": [{"name": n, "value": getattr(self, n)} for n in self.names()]}, open(path, "w"), indent=2)
        @classmethod
        def load(cls, path):
            c = cls(); [setattr(c, it["name"], float(it["value"])) for it in json.load(open(path))["parameters"] if it["name"] in cls.names()]; return c

    IDX = {n: i for i, n in enumerate(Calibration.names())}
    NCAL = len(IDX)
''')

W(f"{a.name}/geometry.py", f'''
    import math, numpy as np
    NT, NR = {a.nt}, {a.nr}
    RI, RO = 33.5e-3, 50e-3
    RM, B = 0.5 * (RI + RO), RO - RI
    DTH, DR = 2 * math.pi / NT, B / NR
    def radii(): return (RI + (np.arange(NR) + 0.5) * DR).astype(np.float32)
    def masks():
        deg = (np.arange(NT) + 0.5) * 360.0 / NT; local = deg % 60.0
        groove = ((local < 7) | (local > 53)).astype(np.int32)
        return groove, np.where(groove == 1, 0.0, (local - 7.0) / 46.0).astype(np.float32)
''')

W(f"{a.name}/kernels.py", '''
    """Standard kernel order: prep -> build_h -> jacobi (ping-pong) -> contact/integrate -> stiffness -> axial -> wear -> finish.
    Replace the physics inside each kernel; keep the shapes and the atomics."""
    import math, warp as wp
    from .geometry import NT, NR, RM, DTH, DR, RO, B as BW
    from .calibration import IDX
    C_NT, C_NR = wp.constant(NT), wp.constant(NR)
    C_DTH, C_DR, C_RO, C_RM, C_BW = wp.constant(float(DTH)), wp.constant(float(DR)), wp.constant(float(RO)), wp.constant(float(RM)), wp.constant(float(BW))
    PI = wp.constant(math.pi)
    _c = lambda n: wp.constant(IDX[n])
    I_EP0, I_TAPER, I_MU100, I_MU_SLOPE, I_SIG_RA, I_EK, I_PA_MAX, I_P_CAP, I_KW, I_M_CR, I_PSUP = [_c(n) for n in
        ["EP0", "TAPER", "MU100", "MU_SLOPE", "SIG_RA", "EK", "PA_MAX", "P_CAP", "KW", "M_CR", "PSUP"]]

    @wp.kernel
    def k_prep(cal: wp.array2d(dtype=float), rpm: wp.array(dtype=float), toil: wp.array(dtype=float), ra_um: wp.array(dtype=float),
               om: wp.array(dtype=float), mu: wp.array(dtype=float), sig0: wp.array(dtype=float), psup: wp.array(dtype=float)):
        b = wp.tid()
        om[b] = rpm[b] * 2.0 * PI / 60.0
        mu[b] = cal[b, I_MU100] * wp.exp(cal[b, I_MU_SLOPE] * (100.0 - toil[b]))      # TODO: local temperature, ageing
        sig0[b] = ra_um[b] * 1.0e-6 * cal[b, I_SIG_RA]
        psup[b] = cal[b, I_PSUP]                                                     # TODO: oil pressure model

    @wp.kernel
    def k_build_h(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), pad_s: wp.array(dtype=float), rj: wp.array(dtype=float),
                  x: wp.array(dtype=float), hscale: float, wear_um: wp.array3d(dtype=float), h: wp.array3d(dtype=float)):
        b, i, j = wp.tid()
        h0 = wp.max(0.3e-6, cal[b, I_EP0] * 0.5 - x[b]) * hscale
        if groove[i] == 1:
            tap = 60.0e-6
        else:
            tap = cal[b, I_TAPER] * wp.max(0.0, 1.0 - pad_s[i] / 0.6)
        h[b, i, j] = wp.max(0.3e-6, h0 + tap + wear_um[b, i, j] * 1.0e-6)           # TODO: tilt, runout, dent, coning

    @wp.kernel
    def k_jacobi(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), rj: wp.array(dtype=float), h: wp.array3d(dtype=float),
                 mu: wp.array(dtype=float), om: wp.array(dtype=float), psup: wp.array(dtype=float),
                 p_in: wp.array3d(dtype=float), p_out: wp.array3d(dtype=float)):
        b, i, j = wp.tid()
        ip = (i + 1) % C_NT
        im = (i + C_NT - 1) % C_NT
        if groove[i] == 1:
            p_out[b, i, j] = psup[b]
            return
        inv = 1.0 / (12.0 * mu[b])
        r = rj[j]
        hc = h[b, i, j]
        hE = h[b, ip, j]
        hW = h[b, im, j]
        he = 0.5 * (hc + hE)
        hw = 0.5 * (hc + hW)
        cE = he * he * he * inv / (r * r * C_DTH * C_DTH)
        cW = hw * hw * hw * inv / (r * r * C_DTH * C_DTH)
        if j < C_NR - 1:
            hn = 0.5 * (hc + h[b, i, j + 1])
            pN = p_in[b, i, j + 1]
        else:
            hn = hc
            pN = 0.0
        cN = (r + 0.5 * C_DR) * hn * hn * hn * inv / (r * C_DR * C_DR)
        if j > 0:
            hs = 0.5 * (hc + h[b, i, j - 1])
            pS = p_in[b, i, j - 1]
        else:
            hs = hc
            pS = psup[b] * 0.5
        cS = (r - 0.5 * C_DR) * hs * hs * hs * inv / (r * C_DR * C_DR)
        src = (om[b] * 0.5) * (hE - hW) / (2.0 * C_DTH)
        v = (cE * p_in[b, ip, j] + cW * p_in[b, im, j] + cN * pN + cS * pS - src) / (cE + cW + cN + cS)
        p_out[b, i, j] = wp.min(cal[b, I_P_CAP], wp.max(0.0, v))

    @wp.kernel
    def k_contact(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), rj: wp.array(dtype=float), h: wp.array3d(dtype=float),
                  sig0: wp.array(dtype=float), p: wp.array3d(dtype=float), pasp: wp.array3d(dtype=float),
                  W: wp.array(dtype=float), Fc: wp.array(dtype=float), hmin: wp.array(dtype=float), lam: wp.array(dtype=float)):
        b, i, j = wp.tid()
        dA = rj[j] * C_DR * C_DTH
        hv = h[b, i, j]
        wp.atomic_add(W, b, p[b, i, j] * dA)
        pa = float(0.0)
        if groove[i] == 0:
            l = hv / sig0[b]
            wp.atomic_min(hmin, b, hv)
            wp.atomic_min(lam, b, l)
            if l < 4.0:
                pa = wp.min(cal[b, I_PA_MAX], cal[b, I_EK] * 4.4086e-5 * wp.pow(4.0 - l, 6.804))
        pasp[b, i, j] = pa
        wp.atomic_add(Fc, b, pa * dA)

    @wp.kernel
    def k_stiffness(W: wp.array(dtype=float), Fc: wp.array(dtype=float), W2: wp.array(dtype=float), Fc2: wp.array(dtype=float),
                    cal: wp.array2d(dtype=float), x: wp.array(dtype=float), mu: wp.array(dtype=float), hmin: wp.array(dtype=float),
                    k: wp.array(dtype=float), c: wp.array(dtype=float)):
        b = wp.tid()
        h0 = wp.max(0.3e-6, cal[b, I_EP0] * 0.5 - x[b])
        k[b] = wp.clamp((W[b] + Fc[b] - W2[b] - Fc2[b]) / (0.03 * h0), 0.0, 1.0e10)
        hm = wp.max(hmin[b], 2.0e-6)
        A = PI * (C_RO * C_RO - (C_RO - C_BW) * (C_RO - C_BW)) * 0.77
        c[b] = wp.clamp(3.0 * mu[b] * A * C_BW * C_BW / (hm * hm * hm), 2.0e4, 5.0e7)   # squeeze-film damping

    @wp.kernel
    def k_axial(cal: wp.array2d(dtype=float), Fext: wp.array(dtype=float), W: wp.array(dtype=float), Fc: wp.array(dtype=float),
                k: wp.array(dtype=float), cd: wp.array(dtype=float), x: wp.array(dtype=float), v: wp.array(dtype=float), dt: float, nsub: int):
        b = wp.tid()
        ds = dt / float(nsub)
        m = cal[b, I_M_CR]
        c = cd[b]
        xf = x[b]
        xx = x[b]
        vv = v[b]
        lim = cal[b, I_EP0] * 0.5 - 0.3e-6
        for s in range(nsub):
            Fnet = Fext[b] - (W[b] + Fc[b] + k[b] * (xx - xf))
            vv = (vv + ds / m * Fnet) / (1.0 + ds * c / m + ds * ds * k[b] / m)
            xx += ds * vv
            if xx > lim:
                xx = lim
                if vv > 0.0:
                    vv = 0.0
            if xx < -lim:
                xx = -lim
                if vv < 0.0:
                    vv = 0.0
        x[b] = xx
        v[b] = vv

    @wp.kernel
    def k_wear(cal: wp.array2d(dtype=float), groove: wp.array(dtype=int), rj: wp.array(dtype=float), pasp: wp.array3d(dtype=float),
               om: wp.array(dtype=float), dte: float, wear_um: wp.array3d(dtype=float), wsum: wp.array(dtype=float), wmax: wp.array(dtype=float)):
        b, i, j = wp.tid()
        dw = cal[b, I_KW] * pasp[b, i, j] * om[b] * rj[j] * dte
        wn = wp.min(1200.0, wear_um[b, i, j] + dw * 1.0e6)
        wear_um[b, i, j] = wn
        if groove[i] == 0:
            wp.atomic_add(wsum, b, wn)
            wp.atomic_max(wmax, b, wn)

    @wp.kernel
    def k_finish(cal: wp.array2d(dtype=float), wsum: wp.array(dtype=float), npad: float, dte: float,
                 wear_mean: wp.array(dtype=float), ep: wp.array(dtype=float), tEng: wp.array(dtype=float)):
        b = wp.tid()
        wear_mean[b] = wsum[b] / npad
        ep[b] = cal[b, I_EP0] + wear_mean[b] * 1.0e-6
        tEng[b] += dte / 3600.0
''')

W(f"{a.name}/simulator.py", f'''
    import numpy as np, warp as wp
    from . import kernels as K
    from .geometry import NT, NR, radii, masks
    from .calibration import Calibration

    SIGNALS = ["t_eng_h", "rpm", "F_ext_kN", "F_film_kN", "F_asp_kN", "h_min_um", "lambda", "x_mm", "end_play_mm", "wear_mean_um", "wear_max_um"]

    class Simulator:
        def __init__(self, B, cal=None, device=None, sweeps=30, sweeps_stiff=12):
            wp.init(); self.device = device or wp.get_device(); self.B = B; self.sweeps, self.sweeps_stiff = sweeps, sweeps_stiff
            calv = (cal or Calibration()).batch(B) if not isinstance(cal, np.ndarray) else cal
            self.cal = wp.array(calv.astype(np.float32), dtype=float, device=self.device); self.cal_np = calv
            groove, pad_s = masks(); self.groove = wp.array(groove, dtype=int, device=self.device); self.pad_s = wp.array(pad_s, dtype=float, device=self.device)
            self.rj = wp.array(radii(), dtype=float, device=self.device); self.npad = float((groove == 0).sum() * NR)
            z = lambda *s: wp.zeros(s, dtype=float, device=self.device)
            self.h, self.p, self.p_tmp, self.p2, self.pasp, self.wear = z(B, NT, NR), z(B, NT, NR), z(B, NT, NR), z(B, NT, NR), z(B, NT, NR), z(B, NT, NR)
            for n in ["om", "mu", "sig0", "psup", "W", "Fc", "hmin", "lam", "W2", "Fc2", "hmin2", "lam2", "k", "c", "x", "v", "wsum", "wmax", "wear_mean", "ep", "tEng", "rpm", "toil", "ra", "Fext"]:
                setattr(self, n, z(B))
            self.set_scenario(); self.warmup()

        def set_scenario(self, rpm=1200.0, toil=110.0, ra_um=0.8, F_ext_N=4000.0):
            for arr, val in [(self.rpm, rpm), (self.toil, toil), (self.ra, ra_um), (self.Fext, F_ext_N)]:
                arr.assign(np.broadcast_to(np.asarray(val, np.float32), (self.B,)).copy())

        def _solve(self, hscale, p, W, Fc, hmin, lam, sweeps):
            d = self.device
            wp.launch(K.k_build_h, dim=(self.B, NT, NR), device=d, inputs=[self.cal, self.groove, self.pad_s, self.rj, self.x, hscale, self.wear], outputs=[self.h])
            a, b = p, self.p_tmp
            for _ in range(sweeps):
                wp.launch(K.k_jacobi, dim=(self.B, NT, NR), device=d, inputs=[self.cal, self.groove, self.rj, self.h, self.mu, self.om, self.psup, a, b]); a, b = b, a
            if a is not p: wp.copy(p, a)
            W.zero_(); Fc.zero_(); hmin.fill_(1.0); lam.fill_(1e9)
            wp.launch(K.k_contact, dim=(self.B, NT, NR), device=d, inputs=[self.cal, self.groove, self.rj, self.h, self.sig0, p], outputs=[self.pasp, W, Fc, hmin, lam])

        def step(self, dt=1 / 60, warp=0.0):
            d, B = self.device, self.B; dte = dt * warp
            wp.launch(K.k_prep, dim=B, device=d, inputs=[self.cal, self.rpm, self.toil, self.ra], outputs=[self.om, self.mu, self.sig0, self.psup])
            self._solve(1.0, self.p, self.W, self.Fc, self.hmin, self.lam, self.sweeps)
            wp.copy(self.p2, self.p); self._solve(1.03, self.p2, self.W2, self.Fc2, self.hmin2, self.lam2, self.sweeps_stiff)   # stiffness: perturb from the fresh solution
            wp.launch(K.k_stiffness, dim=B, device=d, inputs=[self.W, self.Fc, self.W2, self.Fc2, self.cal, self.x, self.mu, self.hmin], outputs=[self.k, self.c])
            if dt > 0:
                wp.launch(K.k_axial, dim=B, device=d, inputs=[self.cal, self.Fext, self.W, self.Fc, self.k, self.c, self.x, self.v, dt, max(1, int(round(dt / 2.5e-4)))])
            if dte > 0:
                self.wsum.zero_(); self.wmax.zero_()
                wp.launch(K.k_wear, dim=(B, NT, NR), device=d, inputs=[self.cal, self.groove, self.rj, self.pasp, self.om, dte], outputs=[self.wear, self.wsum, self.wmax])
                wp.launch(K.k_finish, dim=B, device=d, inputs=[self.cal, self.wsum, self.npad, dte], outputs=[self.wear_mean, self.ep, self.tEng])

        def warmup(self, steps=60):
            for _ in range(steps): self.step(1 / 60, 0.0)

        def signals(self):
            g = lambda a: a.numpy()
            return {{"t_eng_h": g(self.tEng), "rpm": g(self.rpm), "F_ext_kN": g(self.Fext) / 1e3, "F_film_kN": g(self.W) / 1e3, "F_asp_kN": g(self.Fc) / 1e3,
                    "h_min_um": g(self.hmin) * 1e6, "lambda": g(self.lam), "x_mm": g(self.x) * 1e3, "end_play_mm": g(self.ep) * 1e3,
                    "wear_mean_um": g(self.wear_mean), "wear_max_um": g(self.wmax)}}

        def signal_matrix(self):
            s = self.signals(); return np.stack([s[n] for n in SIGNALS], 1).astype(np.float32)
''')
W(f"{a.name}/__init__.py", f"from .calibration import Calibration, IDX, NCAL\nfrom .simulator import Simulator, SIGNALS\n")
W("verify.py", f'''
    """Reproduce the source model's steady numbers here; edit the expected ranges to the reference."""
    import sys, numpy as np; sys.path.insert(0, ".")
    from {a.name} import Simulator, Calibration
    def check(name, val, lo, hi):
        ok = lo <= val <= hi; print(f"  {{'PASS' if ok else 'FAIL'}}  {{name:22s}} {{val:9.3f}}   expected {{lo}} .. {{hi}}"); return ok
    sim = Simulator(B=2); sim.set_scenario(rpm=1200, toil=110, F_ext_N=4000)
    for _ in range(60): sim.step(1 / 60, 0.0)
    s = sim.signals(); ok = True
    ok &= check("lambda", s["lambda"][0], 1.5, 6.0)
    ok &= check("film load kN", s["F_film_kN"][0] + s["F_asp_kN"][0], 3.0, 5.0)
    for _ in range(300): sim.step(1 / 60, 3000.0)
    s2 = sim.signals(); ok &= check("wear after 4 h um", s2["wear_mean_um"][0], 0.0, 50.0)
    print("ALL PASS" if ok else "SOME CHECKS FAILED"); sys.exit(0 if ok else 1)
''')
W("run_all.sh", "#!/usr/bin/env bash\nset -e; cd \"$(dirname \"$0\")\"\npython3 -m pip install -q warp-lang numpy 2>/dev/null || python3 -m pip install -q --break-system-packages warp-lang numpy\npython3 verify.py\n")
W("README.md", f"# {a.name}\n\nScaffolded batched Warp physics package. Replace the TODO physics in `{a.name}/kernels.py`, keep the kernel order, keep `verify.py` green.\n")
print("scaffolded", root)
