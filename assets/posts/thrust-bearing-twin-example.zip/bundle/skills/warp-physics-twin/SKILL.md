---
name: warp-physics-twin
description: Port a hand-written physics model (bearing, film, contact, thermal, wear, combustion, oil chemistry) to a batched NVIDIA Warp simulator, then use it for dataset generation, fleet Monte Carlo, calibration and an ensemble-Kalman digital twin. Use this whenever the user mentions Warp, PhysicsNeMo ground truth, "simulate a fleet", "generate training data", "calibrate against measurements", "digital twin", "monitor", or wants a JavaScript/Python physics model to run in batch on a GPU, even if they do not say "Warp".
---

# Warp physics twin

Pattern: one batch dimension `b` = vehicle / scenario / ensemble member; one kernel
per physical step; every coefficient in a `(B, NCAL)` calibration array so vehicles can
differ; a `verify.py` that reproduces the source model's steady numbers before any
fleet, dataset or twin work. `assets/reference-implementation/` (v3.3, level with page v19: deformation, debris,
groove loss, crank imperfections, Walther oil grades and cold start, washer spin, margins, structural mode, stick-slip chatter, campbell.sweep, sensors, discriminability and Sobol studies, interventions) is the complete
thrust-bearing package (two faces, flow-resolved starvation, per-cell thermal,
corrosion, oil ageing, Wiebe combustion, fleet, dataset, calibration, EnKF twin) and
is the thing to copy from.

## Workflow

1. **Map the model.** List states by shape: per-cell `(B,F,NT,NR)`, per-column
   `(B,F,NT)`, per-pad `(B,F,6)`, per-vehicle `(B,)`. List inputs per step (rpm,
   load, pedal, oil temperature) and static scenario inputs (roughness, defect
   severity, failure-mode severities `(B,NFM)`).
2. **Scaffold** with `scripts/scaffold.py <name> --nt 120 --nr 8` to get
   calibration dataclass, geometry, kernel file with the standard eight kernels,
   Simulator class, verify and run_all. Then replace the placeholder physics.
3. **Write kernels in the fixed order**: prep (per vehicle: viscosity, oil
   pressure, coning, random events, table lookups) → build_h → mu per cell →
   pad budgets → N Jacobi sweeps (ping-pong buffers) → contact/integrate
   (atomics) → flow → stiffness (second solve at 1.03 h0) → axial substeps →
   thermal → oil ageing → wear → finish (signals). Read
   `references/kernel-patterns.md` for the code shapes and
   `references/warp-gotchas.md` before writing a line.
4. **Verify** against the source model: same operating point, same numbers
   within a few percent (λ, h_min, film load, gallery pressure, torque mean),
   plus behavioural checks (defect wears faster, starvation appears at hot idle,
   corrosion grows with TAN). Keep `verify.py` green through every change.
5. **Warm up** before wearing: 30 steps at `warp = 0` so the film and the axial
   position settle; otherwise the startup impact scores the face.
6. **Then build the uses** (`references/uses.md`): dataset with labels and
   pressure fields, fleet with random duty sampling, batched finite-difference
   calibration with an identifiability report, EnKF twin.
7. **Tune the reduced or fast constants last** (Q_GROOVE_K, K_CORR, oil-ageing
   rates, fleet constants) and say plainly in the README that they are
   order-of-magnitude until replaced by data.

## Symbolic first
Derive each kernel's law with the sympy harness in the physics-sim-page skill
(`scripts/symbolic_derive.py`) and paste the derived expression into the kernel with the
assumption list as a comment. The harness sections map one-to-one onto kernels: 1-2 →
k_jacobi / k_flow, 3-4 → k_stiffness, 5 → k_contact, 6 → k_thermal_cell, 7 → walther_mu,
8 → k_wear / k_impact / k_debris / k_grooves, 9 → k_prep (thermal end play).

## Before anyone reasons about causes with it
1. Sensor layer first: wrap the signals in the channel set the target actually broadcasts, with
   noise, quantization, rate, dropout, drift and lag. Studies on clean signals over-credit features.
2. Discriminability study: can the observable projection separate the failure modes at all? A mode
   that collapses into another here cannot be root-caused downstream, however good the agent.
3. Time-warp stability: any accumulated-damage loop integrated with a large warped step will
   over-integrate itself. Limit the per-step increment to a fraction of the state it consumes
   (wear <= 0.1 h) and report the number of clipped cells; a silent explosion looks like physics.
4. Settle after every operating-point change before applying warp, or hours of the transient are
   aged into the surface.
5. Interventions must be matched: same build spread, same schedule, same seed in both arms.

## Non-negotiables

- CPU must run: `wp.init()` picks `cpu` when no CUDA; keep batch sizes in
  `run_all` toy-sized (B ≤ 16, hours ≤ 60) so the pipeline is checkable anywhere.
- Store wear in micrometres in float32; store nothing that needs 1e-9 relative
  resolution in float32 metres.
- Jacobi ping-pong, not Gauss-Seidel in place: parallel-safe and keeps the door
  open for `wp.Tape`. Do not claim tape gradients while any kernel reads and
  writes the same array; use batched finite differences for calibration.
- Conduction in the implicit denominator; per-cycle random draws from a phase
  accumulator; duty cycles sampled randomly when the warp step exceeds the
  schedule step.
- Signals as a named list in one place; `signal_matrix()` stacks them for
  datasets; the same names the interactive page uses.

## Deliverables

Package folder with README (layout, units, calibration notes, known
simplifications), `requirements.txt` (`warp-lang>=1.5`, `numpy`), `verify.py`,
`run_all.sh` and `run_all.bat`, and a zip. Present the zip plus README,
kernels.py, simulator.py and verify.py.
