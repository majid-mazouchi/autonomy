# simkit — skills and harnesses for building 3D physics simulations and Warp twins

Two skills (Claude / Copilot `SKILL.md` format) and two Copilot agents, extracted from the
thrust-bearing / crank-walk build (page v1-v5, Warp package v1-v2).

    skills/physics-sim-page/      interactive Three.js + physics pages in the house style
      SKILL.md                    workflow, testing checklist, numerical rules
      references/                 architecture contract, physics checklist, house style
      scripts/js_check.py         node --check on the page's script block
      scripts/physics_harness.js  run the page's physics in Node (DOM/THREE stubs), profile, compare
      scripts/test_page.py        Playwright + SwiftShader: errors, actions, downloads, screenshots
      scripts/patch.py            asserting Patcher + CAL refactor helper
      scripts/symbolic_derive.py  sympy derivations: film profile, Reynolds stencil, damping, GW fit, implicit thermal, Walther, rate laws, units
      scripts/causal_graph_build.py  builds the causal block-diagram page from node/edge/loop lists
      references/symbolic-physics.md, film-gap-microview.md, deformation-damage.md, rendering-pitfalls.md, causal-graph.md
      assets/thrust-bearing-crank-walk-v16.html, thrust-bearing-causal-graph.html  reference builds
      assets/page-skeleton.html   runnable template with P / S / CAL_DEF / SIG / FM_DEF, tabs, chart
      assets/example-*.json       scenario and actions files for the harnesses
    skills/warp-physics-twin/     batched NVIDIA Warp port, dataset, fleet, calibration, EnKF twin
      SKILL.md                    workflow, non-negotiables, deliverables
      references/                 warp gotchas, kernel patterns, uses (dataset / fleet / calibrate / twin)
      scripts/scaffold.py         generates a runnable single-face package with the standard kernel order
      assets/reference-implementation/   the full thrust_warp v2 package
    agents/sim-architect.agent.md, agents/sim-tester.agent.md

Install for Claude: save each `.skill` file (or the folder) into your skills.
Install for VS Code Copilot: copy `skills/*` into `.github/skills/` and `agents/*` into `.github/agents/`.

Harness quick use
    python skills/physics-sim-page/scripts/js_check.py page.html
    node skills/physics-sim-page/scripts/physics_harness.js /tmp/_page_script.js scenario.json 300
    python skills/physics-sim-page/scripts/test_page.py page.html --actions actions.json
    python skills/warp-physics-twin/scripts/scaffold.py mymodel && cd mymodel && python verify.py
