# Diagnosis Copilot Kit

Turn the nine-part **Diagnosis Series** into a working skill set for **GitHub Copilot in VS Code**.
It gives your Copilot four "harnesses":

1. **Doctrine** — always-on custom instructions, so every chat reasons the disciplined way.
2. **Skills** — `/slash` prompt files, one per diagnostic move.
3. **Agents** — a *Diagnostician* and a *Fleet Analyst* custom agent that orchestrate the loop with human gates.
4. **Tools** — a small local MCP server so the numbers (confidence intervals, chi-square, Mantel–Haenszel,
   partial correlation, CUSUM, Weibull/B10, BIC) are **computed, never guessed**.

The design follows the series' own principle: *agents propose, deterministic tools verify, humans gate.*

## What's inside
```
.github/
  copilot-instructions.md                 # doctrine — auto-applied to every chat
  instructions/                           # path-specific rules (applyTo globs)
    dtc-and-freezeframe.instructions.md
    ecu-c-source.instructions.md
    fleet-data.instructions.md
  prompts/                                # /slash skills
    rca-intake.prompt.md      rca-frame.prompt.md       rca-impostor.prompt.md
    rca-sufficiency.prompt.md rca-report.prompt.md
    fleet-demix.prompt.md     fleet-cohort.prompt.md    fleet-rigor.prompt.md
    fleet-surveillance.prompt.md          fleet-remediate.prompt.md
    capa-8d.prompt.md         design-experiment.prompt.md
  agents/                                 # custom agents (a.k.a. chat modes)
    diagnostician.agent.md                fleet-analyst.agent.md
mcp/
  diagnosis_stats_server.py               # local MCP server — deterministic stats
  requirements.txt   mcp.json.example   README.md
```

## Install — give the harnesses to your Copilot

### 1) Drop `.github/` into your diagnosis workspace
Copy this kit's `.github/` folder into the **root of the repo** where you do diagnosis work
(merge into an existing `.github/` if you have one). VS Code Copilot auto-detects:

| File | What VS Code does |
|------|-------------------|
| `copilot-instructions.md`            | applied to **every** chat request in the workspace |
| `instructions/*.instructions.md`     | applied automatically when you touch files matching its `applyTo` glob |
| `prompts/*.prompt.md`                | available as slash commands: `/rca-intake`, `/fleet-rigor`, … |
| `agents/*.agent.md`                  | appear in the chat **mode picker** as *Diagnostician* / *Fleet Analyst* |

Turn the features on (Settings → search the key):
`chat.promptFiles` = **true**, and make sure prompt/instruction/agent file locations include `.github`
(the defaults do). On older VS Code, custom agents lived in `.github/chatmodes/*.chatmode.md` — if the
mode picker doesn't show them, copy the two agent files there and rename `.agent.md` → `.chatmode.md`.

### 2) Add the stats MCP server (recommended — this is the "referee")
```
cd mcp
python -m venv .venv && . .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```
Then create `.vscode/mcp.json` in your workspace from `mcp/mcp.json.example` (edit the path), or run
**MCP: Add Server…** from the Command Palette. Reload, open the **Tools** picker in chat, and enable the
`diagnosis-stats` tool set. Now the agents call real functions for every number.

### 3) Pick the model
Open a *Diagnostician* chat and set the model picker to **Claude Opus 4.8** (or your best available). The
agent files request it, but the picker is the source of truth.

### 4) Try it
- Open an evidence file (a DTC dump, a telemetry CSV, an ECU `.c`).
- Run the skills in order: `/rca-intake` → `/rca-frame` → `/rca-impostor` → `/rca-sufficiency` → `/rca-report`.
- Or switch to the **Diagnostician** agent and say *"Diagnose this."* — it walks the whole loop and stops at
  the human gates (before it concludes, before it proposes a fix).

## How the skills map to the series
| Skill / agent | Series post |
|---------------|-------------|
| doctrine, `/rca-intake` `/rca-frame` `/rca-impostor` `/rca-report` | 1 · RCA Under Uncertain Evidence |
| `/rca-sufficiency` | 2 · When Is the Evidence Enough? |
| multi-fault / sensor checks in doctrine | 3 · Harder Cases |
| `/fleet-demix` `/fleet-cohort` `/fleet-remediate`, Fleet Analyst | 4 · Fleet-Scale RCA |
| `/fleet-rigor` `/fleet-surveillance` + MCP stats tools | 5 · Fleet RCA, Made Rigorous |
| `/design-experiment` | 6 · Proving Cause with Experiments |
| on-board notes in `ecu-c-source` instructions | 7 · Diagnosis on the Vehicle |
| `fleet-data` instructions, MCP `telemetry`/joins | 8 · The Data Plumbing |
| `/capa-8d` | 9 · From Root Cause to No Cause |

## Safety notes
- Keep telemetry / DTC-catalog / warranty access **inside the MCP server**, never pasted into prompts.
- The doctrine forbids the model from inventing statistics — it must call the stats tools or say it can't.
- Every agent keeps a human gate before any irreversible step (concluding, proposing a fix, scoping a campaign).

## Companion toolkits (plug in the techniques)
The diagnosis-copilot-kit is the **orchestration / method** layer. These existing kits are the
**technique toolboxes** the skills reach for — drop any of them into your workspace and the agents can call
their scripts (via the `runCommands` tool) or you can expose them as extra MCP tools alongside `diagnosis-stats`:

| Companion kit | Powers which skill / step |
|---------------|---------------------------|
| **residual-analysis-kit**       | the *referee* — residuals that confirm a mechanism (`/rca-impostor` referee, FDI) |
| **change-detection-kit**        | onset change-points + early warning (`/fleet-surveillance`, the onset curve) |
| **dependence-measures-kit**     | the *impostor* check — correlation / partial dependence (`/rca-impostor`) |
| **multivariate-monitoring-kit** | which signals move together; fleet anomaly (`/fleet-demix`, sensor checks) |
| **spectral-analysis-kit**       | frequency-signature fingerprinting (signature step in `/rca-frame`) |
| **probabilistic-methods-kit**   | Bayesian fusion & uncertainty (the *fuse by weight* step, `/rca-report`) |

Tip: keep these as sibling folders and let the Diagnostician / Fleet Analyst agents call their scripts; the
`diagnosis-stats` MCP server covers the lightweight stats, the companion kits cover the heavier signal analysis.

## Sample evidence (dry-run the skills)
Grab **diagnosis-sample-evidence** (a separate bundle) to exercise every skill end to end: a single-vehicle case
(DTC + freeze-frame, the firmware bug, a charge-session log, complaints, service history) and a 240-car fleet
table with two embedded causes, a Simpson's-paradox confound, a weekly rate series for CUSUM, and connector
failure times for Weibull/B10. Its README has a skill-by-skill dry-run script and the hidden ground truth.
