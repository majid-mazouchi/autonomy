# diagnosis-stats — local MCP server

Deterministic statistics for the diagnosis agents, so numbers are **computed, not guessed**.

## Tools
- `ci_proportion(successes, n, conf)` — Wilson + normal-approx confidence interval for a rate.
- `chi2_2x2(a, b, c, d)` — chi-square test + p-value for a 2×2 cohort split.
- `mantel_haenszel(strata)` — stratified odds ratio (Simpson-proof combination of subgroups).
- `partial_correlation(x, y, z)` — correlation of x,y controlling for z (kills impostor correlations).
- `cusum(rates, baseline, slack, threshold)` — early-warning monitor; returns the statistic and alarm index.
- `weibull_b10(times, n_censored)` — fits a Weibull (median-rank regression) and returns beta, eta, B10 life.
- `bic_select(values, k_max)` — picks the number of sub-populations by BIC (de-mixing).

## Setup
```
python -m venv .venv && . .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python diagnosis_stats_server.py                  # runs on stdio
```

## Wire into VS Code
Copy `mcp.json.example` to `.vscode/mcp.json` in your workspace (fix the path), or run
**MCP: Add Server… → stdio** from the Command Palette. Reload, then enable the `diagnosis-stats`
tools in the chat **Tools** picker. The agents will call them automatically.
