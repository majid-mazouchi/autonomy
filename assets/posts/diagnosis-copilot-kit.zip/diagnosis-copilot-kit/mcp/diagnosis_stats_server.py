"""diagnosis-stats: a small MCP server of deterministic statistics for fault diagnosis.

Run on stdio:  python diagnosis_stats_server.py
Exposes tools the Copilot diagnosis agents call so numbers are computed, not guessed.
"""
from __future__ import annotations
import math
from typing import List

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("diagnosis-stats")


@mcp.tool()
def ci_proportion(successes: int, n: int, conf: float = 0.95) -> dict:
    """95%-style confidence interval for a proportion (rate). Returns point estimate plus
    the Wilson interval (preferred, good for small n) and the normal-approximation interval."""
    if n <= 0:
        return {"error": "n must be > 0"}
    z = _z(conf)
    p = successes / n
    # normal approximation
    se = math.sqrt(max(p * (1 - p), 0) / n)
    lo_n, hi_n = p - z * se, p + z * se
    # Wilson
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    half = (z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))) / denom
    return {
        "p": round(p, 6),
        "wilson": [round(max(0, center - half), 6), round(min(1, center + half), 6)],
        "normal": [round(max(0, lo_n), 6), round(min(1, hi_n), 6)],
        "conf": conf, "n": n, "successes": successes,
    }


@mcp.tool()
def chi2_2x2(a: int, b: int, c: int, d: int) -> dict:
    """Chi-square test for a 2x2 table [[a, b], [c, d]] (e.g. affected/healthy x group).
    Returns the chi-square statistic and a p-value (df=1)."""
    n = a + b + c + d
    if min(a + b, c + d, a + c, b + d) == 0:
        return {"error": "a zero margin makes the test undefined"}
    chi2 = n * (a * d - b * c) ** 2 / ((a + b) * (c + d) * (a + c) * (b + d))
    p = math.erfc(math.sqrt(chi2 / 2.0))  # survival function of chi-square with df=1
    return {"chi2": round(chi2, 4), "p_value": p, "n": n,
            "rate_group1": round(a / (a + b), 6), "rate_group2": round(c / (c + d), 6)}


@mcp.tool()
def mantel_haenszel(strata: List[List[int]]) -> dict:
    """Mantel-Haenszel stratified odds ratio. Each stratum is [a, b, c, d] for a 2x2 table.
    Combines subgroups without Simpson's paradox."""
    num = den = 0.0
    for s in strata:
        a, b, c, d = s
        n = a + b + c + d
        if n == 0:
            continue
        num += a * d / n
        den += b * c / n
    if den == 0:
        return {"error": "denominator is zero"}
    return {"OR_MH": round(num / den, 4), "strata": len(strata)}


@mcp.tool()
def partial_correlation(x: List[float], y: List[float], z: List[List[float]]) -> dict:
    """Partial correlation between x and y, controlling for one or more variables z
    (z = list of columns). Use to test whether a correlation survives conditioning (impostor check)."""
    import numpy as np
    x = np.asarray(x, float); y = np.asarray(y, float)
    Z = np.column_stack([np.ones_like(x)] + [np.asarray(c, float) for c in z])
    def resid(v):
        beta, *_ = np.linalg.lstsq(Z, v, rcond=None)
        return v - Z @ beta
    rx, ry = resid(x), resid(y)
    denom = math.sqrt(float(rx @ rx) * float(ry @ ry))
    if denom == 0:
        return {"error": "zero residual variance"}
    r = float(rx @ ry) / denom
    return {"partial_r": round(r, 4),
            "marginal_r": round(float(np.corrcoef(x, y)[0, 1]), 4)}


@mcp.tool()
def cusum(rates: List[float], baseline: float, slack: float = 0.0, threshold: float = 0.0) -> dict:
    """One-sided CUSUM for early warning on an emerging rate. Accumulates excess over baseline;
    alarms when the cumulative sum crosses threshold. Returns the S series and the first alarm index."""
    S = 0.0
    series, alarm = [], None
    for i, r in enumerate(rates):
        S = max(0.0, S + (r - baseline - slack))
        series.append(round(S, 6))
        if alarm is None and threshold > 0 and S > threshold:
            alarm = i
    return {"S": series, "alarm_index": alarm,
            "alarmed": alarm is not None}


@mcp.tool()
def weibull_b10(times: List[float], n_censored: int = 0) -> dict:
    """Fit a Weibull distribution to failure times by median-rank regression and report the shape
    (beta: <1 infant mortality, >1 wear-out), scale (eta), and B10 life (age at which 10% fail).
    n_censored = number of still-running units (approximate adjustment)."""
    import numpy as np
    t = np.sort(np.asarray([x for x in times if x > 0], float))
    m = len(t)
    if m < 2:
        return {"error": "need at least 2 failure times"}
    N = m + max(0, int(n_censored))
    i = np.arange(1, m + 1)
    F = (i - 0.3) / (N + 0.4)               # median rank
    x = np.log(t)
    yv = np.log(-np.log(1.0 - F))
    beta, intercept = np.polyfit(x, yv, 1)
    eta = math.exp(-intercept / beta)
    b10 = eta * (-math.log(0.9)) ** (1.0 / beta)
    shape_kind = "infant-mortality" if beta < 0.95 else ("wear-out" if beta > 1.05 else "roughly-random")
    return {"beta": round(float(beta), 3), "eta": round(float(eta), 3),
            "B10": round(float(b10), 3), "shape": shape_kind, "n_failures": m, "n_censored": int(n_censored)}


@mcp.tool()
def bic_select(values: List[float], k_max: int = 5) -> dict:
    """Pick the number of sub-populations (clusters) in a 1-D signature by BIC (lower is better).
    Use to de-mix a fleet honestly instead of splitting by eye. Returns BIC per k and the best k."""
    import numpy as np
    try:
        from sklearn.mixture import GaussianMixture
    except Exception:
        return {"error": "scikit-learn not installed; pip install scikit-learn"}
    X = np.asarray(values, float).reshape(-1, 1)
    k_max = max(1, min(int(k_max), len(X) - 1)) if len(X) > 2 else 1
    bics = {}
    for k in range(1, k_max + 1):
        gm = GaussianMixture(n_components=k, covariance_type="full", random_state=0).fit(X)
        bics[k] = round(float(gm.bic(X)), 2)
    best = min(bics, key=bics.get)
    return {"bic_by_k": bics, "best_k": best}


def _z(conf: float) -> float:
    # inverse normal CDF for the two-sided z; common values without scipy
    table = {0.90: 1.6449, 0.95: 1.9600, 0.975: 2.2414, 0.99: 2.5758}
    return table.get(round(conf, 3), 1.9600)


if __name__ == "__main__":
    mcp.run()
