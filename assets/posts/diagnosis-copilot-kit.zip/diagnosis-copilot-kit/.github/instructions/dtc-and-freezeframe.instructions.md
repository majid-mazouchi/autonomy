---
applyTo: "**/*.dtc,**/*dtc*,**/*freeze*,**/*.json"
---
# DTC & freeze-frame inputs
- Trust the **status bits, freeze-frame, and set-conditions** (high). Treat the human-readable **code
  description** as a search term only (low) — it is often generic catalog boilerplate.
- The freeze-frame is the gold: temperature, SOC, current, charge mode, balancing state, firmware version at
  the moment the code set. Read those facts together before interpreting.
- A DTC is the ECU's *hypothesis*, scoped to what it can sense — never the cause by itself.
- For a fleet, the same code across many cars is probably a **mixture** of causes; do not assume one cause.
