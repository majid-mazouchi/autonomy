---
applyTo: "**/*.csv,**/*.parquet,**/*telemetry*,**/*warranty*,**/*fleet*"
---
# Fleet / tabular data
- Reduce to **one row per vehicle** before reasoning across vehicles; do not let a chatty logger outvote the fleet.
- Never act on a raw fleet-wide rate. **Stratify** by plant, firmware, build week, supplier lot, climate, usage;
  trust a difference only if it survives conditioning (beware **Simpson's paradox**).
- The batch is biased: warranty/service data over-represents severe, reporting cars and can miss cars that failed
  hard and went silent (**selection & survivorship bias**). Absence of signal is not absence of fault.
- For any rate comparison, significance test, stratified estimate, CUSUM, clustering, or survival fit, call the
  `diagnosis-stats` MCP tools — do not estimate by eye.
