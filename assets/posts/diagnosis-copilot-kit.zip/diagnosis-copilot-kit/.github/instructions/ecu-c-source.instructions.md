---
applyTo: "**/*.c,**/*.h,**/*.cpp"
---
# ECU / embedded source as evidence
- Source code is **high trust for capability, silent on occurrence.** It shows what *can* happen, not that it
  *did*. Confirm the suspect path is reachable **and** that its guards are satisfied under the recorded
  freeze-frame conditions before concluding it fired.
- Watch the classic embedded traps: signed/unsigned casts, integer wrap, unit/scaling errors (deci-degrees,
  fixed-point), off-by-one thresholds, and guard conditions that never trigger.
- On-board detection (observers, residuals, plausibility/rate checks) must respect a **false-alarm budget** and
  mature a fault over several cycles before storing a code — relevant when judging whether a stored code is real.
