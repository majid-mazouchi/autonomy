---
mode: agent
model: Claude Opus 4.8
description: Run the corrective/preventive-action loop so the fault cannot recur.
---
# Skill: CAPA / 8D — from root cause to no cause
Given a confirmed root cause, walk the loop: **contain** (stop the bleeding) → **correct** (fix this batch) →
**prevent** (make it impossible). For prevention, produce concrete outputs: a **DFMEA/PFMEA** update (the failure
mode, with severity × occurrence × detection and the new controls), a **process control** to hold the causing
parameter, a **poka-yoke** that makes the failure physically impossible, the **escape point** (why test/validation
missed it) plus the test to add, and a **lessons-learned** entry for the design guideline. Distinguish containment
from correction from prevention — do not stop at containment.
