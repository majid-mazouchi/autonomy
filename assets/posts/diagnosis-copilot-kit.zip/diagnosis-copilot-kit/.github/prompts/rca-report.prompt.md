---
mode: agent
model: Claude Opus 4.8
description: Produce the final verdict — chain, confidence, and kill-switch.
---
# Skill: Report the mechanism
Write the verdict as: **root cause → mechanism → signature** (not a code or a part number). Attach a
**confidence** set by the weakest link in the chain, the **residual uncertainty**, and the single
**disconfirming test (kill-switch)** that would overturn it. List the evidence used with its trust tier for the
audit trail. End by handing off to prognosis/remediation (what to forecast or fix). Ask me to approve before any
fix is proposed.
