---
mode: agent
model: Claude Opus 4.8
description: Split a fleet throwing one code into homogeneous sub-populations (de-mix the mixture).
---
# Skill: De-mix the population
For a fleet with one common code: reduce each affected car to a short **signature** (when/how it fails — cold,
hot, high current, severity, frequency), then cluster the signatures. Use the `diagnosis-stats` tool
`bic_select` to choose the number of clusters honestly (do not split by eye); keep a noise/singleton tail and
allow soft membership. Output the candidate sub-populations with size and a one-line signature each, and a note
on whether the clusters are tight enough to be real. Then recommend running the single-vehicle method per cluster.
Fleet data: ${input:data:Reference the per-vehicle table}
