---
mode: agent
model: Claude Opus 4.8
description: Decide whether the evidence is enough to conclude — confirmed, inconclusive, or incoherent.
---
# Skill: The sufficiency gate
Given the surviving hypotheses and the evidence, run the gate:
1. **Discrimination** — do the available measurements actually separate the survivors? Name the discriminating
   measurement if not (observational equivalence).
2. **Margin** — is the posterior lead large enough, carried by high-trust independent evidence? (set the bar by
   the cost of being wrong, stated up front).
3. **Coverage** — any orphan anomaly the leader cannot explain? (often a second fault).
4. **Robustness** — does the verdict survive removing its single most influential clue?
Then return exactly one state: **CONFIRMED**, **INCONCLUSIVE** (+ the exact next measurement to collect, ranked
by value of information), or **INCOHERENT** (+ which source to re-audit or which hypothesis to add).
