---
mode: agent
model: Claude Opus 4.8
description: Choose a proportionate remediation scope and verify the fix.
---
# Skill: Remediation scope & verification
For each confirmed cause, recommend a campaign: **OTA / targeted recall / monitor-only**, scoped to the
affected-population rule. Lay out prevented-loss (forecast failures × cost) vs. campaign cost; let the forecast
slope set urgency; apply the **safety override** (a safety hazard is a mandatory recall regardless of economics).
Then define the **verification**: which treated-cohort prevalence curve must bend down, and by when, to confirm
the fix worked — and what a non-bending curve would mean (re-open). Ask me to approve before committing a campaign.
