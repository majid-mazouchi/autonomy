---
mode: agent
model: Claude Opus 4.8
description: Grade a pile of diagnosis evidence by provenance and trust before using any of it.
---
# Skill: Evidence intake & grading
Take the evidence I provide (DTC + freeze-frame, ECU source, telemetry, customer/dealer reports, service
history, anything attached) and produce a **provenance grading table** with columns:
`source | what it can establish | what it cannot | trust (high/med/low)`.

Rules:
- Split the DTC into two rows: machine fields (high) and text description (low).
- Mark source code as high-for-capability, silent-on-occurrence.
- Mark testimony low (propose & date only); mark history medium (watch for confounds/red herrings).
Then list the **open questions** and what evidence would resolve each. Do **not** propose a cause yet.
Evidence to grade: ${input:evidence:Paste or reference the evidence}
