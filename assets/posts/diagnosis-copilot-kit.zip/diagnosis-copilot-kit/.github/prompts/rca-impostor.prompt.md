---
mode: agent
model: Claude Opus 4.8
description: Break the most convincing correlation with a partial-correlation / confounding check.
---
# Skill: Kill the impostor
The most convincing feature is the prime suspect for being a co-effect of the true cause. For the candidate I
name (or the strongest correlation in the data), run the partial-correlation test: condition on the suspected
upstream cause (or stratify by the cohort variable) and check whether the association survives.
Use the `diagnosis-stats` tool `partial_correlation` (and `mantel_haenszel` for stratified rates) — do not
estimate by eye. Report: marginal association, conditional association, and verdict (impostor dropped / survives).
Candidate / data: ${input:candidate:Which correlation to test, and the data}
