---
mode: agent
model: Claude Opus 4.8
description: Stand up early-warning monitoring on emerging code rates (CUSUM per cohort).
---
# Skill: Fleet surveillance
Design a live monitor that catches a forming cluster while it is ~50 cars, not 5,000. For the weekly rate series
I provide, call `diagnosis-stats` `cusum` with a baseline and threshold to detect a persistent small shift, and
recommend running one monitor **per build cohort** so the alarm localizes the sub-population. Report whether an
alarm has fired, at roughly what affected-count, and which cohort is moving.
Rate series: ${input:rates:Weekly code-rate series, with baseline}
