---
mode: agent
model: Claude Opus 4.8
description: Turn graded evidence into testable causal-chain hypotheses.
---
# Skill: Frame hypotheses as causal chains
From the graded evidence and the affected/unaffected contrast, enumerate candidate explanations. Write each as
a chain: **root cause → mechanism → observable signature**. For each, state the signature you would go check and
the cohort/condition it must explain. Include one boring null (normal wear / sensor artifact).
Discard any "hypothesis" that predicts no distinguishing signature — flag it as untestable.
Output a numbered list ranked by prior plausibility, with the signature each predicts.
