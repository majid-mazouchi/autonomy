---
mode: agent
model: Claude Opus 4.8
description: Make a fleet finding statistically honest — CIs, significance, MH, multiple-comparisons, power.
---
# Skill: Rigor check
For the cohort split or rate comparison I give you, compute (via `diagnosis-stats`, never by eye):
- `ci_proportion` for each group's rate (report the intervals; do they overlap?);
- `chi2` for the 2×2 split (statistic + p-value, with sample sizes);
- `mantel_haenszel` if a confounder is present.
Then flag the **multiple-comparisons** risk if several attributes were scanned (Bonferroni / FDR threshold) and
note any **power** problem (a stratum too small to detect a real effect). Verdict: real and actionable / real but
underpowered / not significant.
Inputs: ${input:counts:Group counts, e.g. affected/total per group}
