---
mode: agent
model: Claude Opus 4.8
description: Prove cause with an experiment — a staged rollout, difference-in-differences, or IV.
---
# Skill: Design an experiment to prove cause
Observation suggests; intervention proves. For the suspected fix, design the strongest feasible experiment:
- **Randomized staged rollout** — randomly assign which cars get the fix first (canary → 10% → 50% → 100%);
  compare treatment vs control with a confidence interval; define guardrail metrics and a stopping rule.
- If randomization isn't possible, **difference-in-differences** vs the not-yet-updated cohort (state the
  parallel-trends assumption), or an **instrumental variable** when assignment is as-good-as-random.
Also draw the small **causal graph** (DAG): name the confounders to adjust for and any collider to avoid.
Output the design, the metric, the sample size/power, and what result would (and would not) prove causation.
Hypothesis / fix: ${input:fix:The fix and the metric to move}
