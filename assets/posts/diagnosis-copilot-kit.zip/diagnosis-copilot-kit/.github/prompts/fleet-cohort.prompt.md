---
mode: agent
model: Claude Opus 4.8
description: Find the cohort boundary that names a cause — and check it isn't a confounder.
---
# Skill: Cohort boundary
Within a cluster, find the build attribute (firmware, plant, build week, supplier lot, climate) that best
separates affected from healthy cars. Use `diagnosis-stats` `chi2` and `ci_proportion` to confirm the split is
real, and `mantel_haenszel` to combine strata without Simpson's paradox. Output the affected-population rule
(over VINs) and the confidence that the boundary is causal, not confounded. Beware multiple-comparisons if you
scanned many attributes — flag it and apply correction.
