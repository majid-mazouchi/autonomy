#!/usr/bin/env python3
"""
hitl_server.py — a Model Context Protocol server that puts a human in the loop.

It exposes the gating logic of this pack as protocol-level tools so any MCP-capable agent can:
  - classify a proposed action by reversibility x blast radius (classify_blast_radius),
  - request human approval before a side-effectful action via MCP elicitation (request_approval),
  - append the decision to a tamper-evident-ish audit log (record_decision).

Design principle: FAIL CLOSED. If no human channel is reachable (the client does not support
elicitation, or the user declines/cancels), request_approval returns "rejected" — never "approved".

Run (stdio):   python3 hitl_server.py
Verify syntax: python -m py_compile hitl_server.py
Requires:      mcp>=1.10 , pydantic>=2   (see requirements.txt)
"""
from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone

from pydantic import BaseModel, Field

from mcp.server.fastmcp import Context, FastMCP

try:  # elicitation result types (match on these)
    from mcp.server.elicitation import (
        AcceptedElicitation,
        DeclinedElicitation,
        CancelledElicitation,
    )
    _HAVE_ELICIT = True
except Exception:  # pragma: no cover - older SDKs
    _HAVE_ELICIT = False

try:
    from mcp.types import ToolAnnotations
except Exception:  # pragma: no cover
    ToolAnnotations = None  # type: ignore

mcp = FastMCP("hitl-gate")

GATE_LOG = os.environ.get("HITL_GATE_LOG", os.path.join(os.getcwd(), ".gate-log", "decisions.jsonl"))


# --------------------------------------------------------------------------
# Blast-radius classification (pure logic; mirrors the gate-by-blast-radius skill)
# --------------------------------------------------------------------------

_MATRIX = {
    # (reversibility, scope) -> recommended gate
    ("reversible", "self"): "auto",
    ("reversible", "single"): "auto",
    ("reversible", "group"): "notify",
    ("reversible", "fleet"): "approve",
    ("hard", "self"): "auto",
    ("hard", "single"): "approve",
    ("hard", "group"): "approve",
    ("hard", "fleet"): "approve+two-person",
    ("irreversible", "self"): "approve",
    ("irreversible", "single"): "approve",
    ("irreversible", "group"): "approve+two-person",
    ("irreversible", "fleet"): "approve+two-person+wait",
}
_REV = {"reversible", "hard", "irreversible"}
_SCOPE = {"self", "single", "group", "fleet"}


def _anno(**kw):
    if ToolAnnotations is not None:
        try:
            return ToolAnnotations(**kw)
        except Exception:
            return kw
    return kw


@mcp.tool(
    annotations=_anno(title="Classify blast radius", readOnlyHint=True, destructiveHint=False,
                      idempotentHint=True, openWorldHint=False),
)
def classify_blast_radius(action: str, reversibility: str = "irreversible", scope: str = "fleet") -> str:
    """Recommend a gate for an action from its reversibility and blast radius.

    reversibility: one of 'reversible', 'hard' (hard-to-reverse), 'irreversible'.
    scope: one of 'self', 'single' (one external record), 'group', 'fleet' (fleet/global).
    Returns the recommended gate tier and a short rationale. Read-only; performs no side effect.
    """
    r = reversibility.strip().lower()
    s = scope.strip().lower()
    if r not in _REV:
        return f"error: reversibility must be one of {sorted(_REV)} (got {reversibility!r})."
    if s not in _SCOPE:
        return f"error: scope must be one of {sorted(_SCOPE)} (got {scope!r})."
    gate = _MATRIX[(r, s)]
    needs_human = gate != "auto"
    return json.dumps({
        "action": action,
        "reversibility": r,
        "scope": s,
        "recommended_gate": gate,
        "needs_human_approval": needs_human,
        "rationale": f"{r} effect with {s} blast radius -> {gate}.",
    }, indent=2)


# --------------------------------------------------------------------------
# Human approval via elicitation (fail-closed)
# --------------------------------------------------------------------------

class ApprovalDecision(BaseModel):
    """Structured human decision. Schema uses primitive fields only (MCP elicitation requirement)."""
    decision: str = Field(description="One of: approve, edit, reject, rework")
    edited_arguments: str = Field(default="", description="If decision=edit, corrected arguments as JSON")
    reason: str = Field(default="", description="Short rationale (required for reject/rework)")


def _decision_record(action_id, summary, blast_radius, provenance, decision, edited, reason, reviewer):
    return {
        "action_id": action_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "summary": summary,
        "blast_radius": blast_radius,
        "provenance": provenance,
        "decision": decision,
        "edited_arguments": edited,
        "reason": reason,
        "reviewer": reviewer,
    }


def _append_log(record: dict) -> None:
    os.makedirs(os.path.dirname(GATE_LOG), exist_ok=True)
    with open(GATE_LOG, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(record) + "\n")


@mcp.tool(
    annotations=_anno(title="Request human approval", readOnlyHint=True, destructiveHint=False,
                      idempotentHint=False, openWorldHint=True),
)
async def request_approval(
    action_id: str,
    summary: str,
    blast_radius: str = "high",
    provenance: str = "",
    ctx: Context = None,  # type: ignore[assignment]
) -> str:
    """Pause and ask a human to approve a proposed side-effectful action before it runs.

    Shows the reviewer the action summary, its blast radius, and provenance (why it was proposed),
    and collects approve / edit / reject / rework via MCP elicitation. The decision is logged.

    FAILS CLOSED: if the client cannot reach a human (elicitation unsupported), or the user declines
    or cancels, the returned decision is 'rejected' and the action MUST NOT proceed.
    """
    prompt = (
        f"APPROVAL REQUESTED\n"
        f"Action: {summary}\n"
        f"Blast radius: {blast_radius}\n"
        f"Provenance: {provenance or '(none supplied)'}\n\n"
        f"Choose: approve / edit / reject / rework."
    )

    decision, edited, reason = "rejected", "", "no human approval channel available; failed closed"
    reviewer = "unknown"

    if ctx is not None and _HAVE_ELICIT:
        try:
            result = await ctx.elicit(message=prompt, schema=ApprovalDecision)
            if isinstance(result, AcceptedElicitation):
                data = result.data
                decision = (data.decision or "").strip().lower() or "rejected"
                edited = data.edited_arguments or ""
                reason = data.reason or ""
                reviewer = "human"
                if decision not in {"approve", "edit", "reject", "rework"}:
                    decision, reason = "rejected", f"unrecognized decision {data.decision!r}; failed closed"
            elif isinstance(result, DeclinedElicitation):
                decision, reason = "rejected", "human declined"
                reviewer = "human"
            elif isinstance(result, CancelledElicitation):
                decision, reason = "rejected", "human cancelled"
                reviewer = "human"
        except Exception as e:  # elicitation not supported / transport error -> fail closed
            decision, reason = "rejected", f"elicitation unavailable ({e}); failed closed"

    approved = decision in {"approve", "edit"}
    record = _decision_record(action_id, summary, blast_radius, provenance, decision, edited, reason, reviewer)
    try:
        _append_log(record)
    except Exception:
        pass  # logging must never make the gate fail open

    return json.dumps({
        "action_id": action_id,
        "approved": approved,
        "decision": decision,
        "edited_arguments": edited,
        "reason": reason,
        "reviewer": reviewer,
        "note": "Proceed only if approved is true. Treat any error as not-approved.",
    }, indent=2)


@mcp.tool(
    annotations=_anno(title="Record gate decision", readOnlyHint=False, destructiveHint=False,
                      idempotentHint=False, openWorldHint=False),
)
def record_decision(action_id: str, summary: str, decision: str, blast_radius: str = "",
                    provenance: str = "", reason: str = "", reviewer: str = "human") -> str:
    """Append a gate decision to the audit log (JSONL) without requesting a new approval.

    Use this to log out-of-band approvals (e.g. a two-person sign-off completed elsewhere) so the
    learning loop and complacency metrics have a complete record. Writes one line to HITL_GATE_LOG.
    """
    record = _decision_record(action_id, summary, blast_radius, provenance,
                              decision.strip().lower(), "", reason, reviewer)
    try:
        _append_log(record)
    except Exception as e:
        return f"error: could not write to gate log at {GATE_LOG}: {e}"
    return json.dumps({"logged": True, "path": GATE_LOG, "record": record}, indent=2)


@mcp.resource("hitl://policy")
def gate_policy() -> str:
    """The gating policy this server enforces, as a readable resource."""
    return json.dumps({
        "principle": "fail closed: an unreachable human means not-approved",
        "matrix": {f"{k[0]}|{k[1]}": v for k, v in _MATRIX.items()},
        "responses": ["approve", "edit", "reject", "rework"],
        "log": GATE_LOG,
    }, indent=2)


if __name__ == "__main__":
    mcp.run()
