#!/usr/bin/env python3
"""gate_log_append.py — append a gate-decision record to the audit log (JSONL).

Used by the sessionEnd hook to write a session marker, and callable directly to log
out-of-band decisions. Validates the minimum required fields against the schema's intent.

Usage:
    python3 gate_log_append.py --session-end
    python3 gate_log_append.py --action-id A1 --summary "..." --decision approve --reviewer me
Env:
    HITL_GATE_LOG   path to the JSONL log (default: ./.gate-log/decisions.jsonl)
"""
from __future__ import annotations
import argparse, json, os, sys
from datetime import datetime, timezone

LOG = os.environ.get("HITL_GATE_LOG", os.path.join(os.getcwd(), ".gate-log", "decisions.jsonl"))
DECISIONS = {"approve", "edit", "reject", "rework", "rejected", "session-end"}


def append(record: dict) -> None:
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(record) + "\n")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--session-end", action="store_true", help="write a session-end marker")
    ap.add_argument("--action-id", default="")
    ap.add_argument("--summary", default="")
    ap.add_argument("--decision", default="")
    ap.add_argument("--blast-radius", default="")
    ap.add_argument("--provenance", default="")
    ap.add_argument("--reason", default="")
    ap.add_argument("--reviewer", default="human")
    a = ap.parse_args(argv)

    now = datetime.now(timezone.utc).isoformat()
    if a.session_end:
        append({"action_id": "session", "timestamp": now, "summary": "session ended",
                "decision": "session-end", "reviewer": "system"})
        return 0
    if not a.action_id or not a.decision:
        print("error: --action-id and --decision are required (or use --session-end)", file=sys.stderr)
        return 2
    if a.decision.lower() not in DECISIONS:
        print(f"error: --decision must be one of {sorted(DECISIONS)}", file=sys.stderr)
        return 2
    append({"action_id": a.action_id, "timestamp": now, "summary": a.summary,
            "blast_radius": a.blast_radius, "provenance": a.provenance,
            "decision": a.decision.lower(), "reason": a.reason, "reviewer": a.reviewer})
    print(f"logged to {LOG}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
