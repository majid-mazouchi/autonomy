#!/usr/bin/env python3
"""
gate_coverage_linter.py — flag side-effectful operations that are not behind a human-approval gate.

Benign static analysis (AST only; it never executes the code it scans). For each Python file it
finds calls that change the world (writes, sends, deletes, deploys, spawns, money movement, device
actions) and reports the ones whose enclosing function is not "gated" — i.e. neither decorated with
an approval decorator nor preceded by an approval call earlier in the same function body.

Usage:
    python3 gate_coverage_linter.py [PATH ...]                 # scan files/dirs (default: .)
    python3 gate_coverage_linter.py src/ --json report.json    # also write a JSON report
    python3 gate_coverage_linter.py --policy gate_policy.json   # override default markers/patterns
    python3 gate_coverage_linter.py --hook                      # quiet; exit 1 if violations (for hooks)

Exit code is the number of violations (capped at 250), so it can act as a pre-commit / preToolUse gate.

Heuristics are configurable. This tool reduces missed gates; it is not a proof of coverage.
"""
from __future__ import annotations
import argparse
import ast
import json
import os
import sys
from dataclasses import dataclass, field, asdict
from typing import Any

# ---- Default policy -------------------------------------------------------

DEFAULT_POLICY: dict[str, Any] = {
    # Decorators that mark a function as gated.
    "gate_decorators": [
        "requires_approval", "needs_approval", "require_approval", "human_approval",
        "gated", "approval_required", "human_in_the_loop", "hitl",
    ],
    # Function/attribute names that, when CALLED inside a function, count as an in-body gate.
    "gate_calls": [
        "request_approval", "require_approval", "elicit", "confirm", "ask_approval",
        "human_input", "await_approval", "interrupt",
    ],
    # Attribute-call patterns that are side-effectful, e.g. requests.post, shutil.rmtree.
    # Matched on the dotted attribute path ending.
    "sideeffect_attrs": [
        "requests.post", "requests.put", "requests.patch", "requests.delete",
        "session.post", "session.put", "session.patch", "session.delete",
        "os.remove", "os.unlink", "os.rmdir", "os.removedirs", "os.rename",
        "shutil.rmtree", "shutil.move",
        "subprocess.run", "subprocess.call", "subprocess.Popen", "subprocess.check_call",
        "boto3.delete_object", "client.delete_object", "client.put_object",
    ],
    # Bare/last-segment method or function names that are side-effectful.
    "sideeffect_names": [
        "commit", "delete", "send", "send_message", "sendmail", "publish", "deploy",
        "push", "push_ota", "flash", "flash_firmware", "execute", "executemany",
        "transfer", "charge", "refund", "withdraw", "grant", "revoke", "terminate",
        "start_campaign", "clear_dtc", "write_calibration", "remove", "drop",
    ],
    # If open(...) is called with a write/append/exclusive mode, treat as side-effectful.
    "flag_open_write": True,
}

WRITE_MODES = {"w", "a", "x", "wb", "ab", "xb", "w+", "a+", "r+", "rb+", "wt", "at"}


@dataclass
class Finding:
    file: str
    line: int
    col: int
    call: str
    enclosing_function: str
    reason: str


@dataclass
class Report:
    files_scanned: int = 0
    findings: list[Finding] = field(default_factory=list)


# ---- AST analysis ---------------------------------------------------------

def dotted_name(node: ast.AST) -> str:
    """Best-effort dotted path for a call target, e.g. requests.post -> 'requests.post'."""
    if isinstance(node, ast.Attribute):
        base = dotted_name(node.value)
        return f"{base}.{node.attr}" if base else node.attr
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Call):
        return dotted_name(node.func)
    return ""


def last_segment(dotted: str) -> str:
    return dotted.rsplit(".", 1)[-1] if dotted else ""


def decorator_names(fn: ast.AST) -> set[str]:
    names: set[str] = set()
    for d in getattr(fn, "decorator_list", []):
        if isinstance(d, ast.Call):
            names.add(last_segment(dotted_name(d.func)))
        else:
            names.add(last_segment(dotted_name(d)))
    return names


def open_is_write(call: ast.Call) -> bool:
    if not call.args and not call.keywords:
        return False
    # positional mode is the 2nd arg
    if len(call.args) >= 2 and isinstance(call.args[1], ast.Constant) and isinstance(call.args[1].value, str):
        return call.args[1].value in WRITE_MODES
    for kw in call.keywords:
        if kw.arg == "mode" and isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, str):
            return kw.value.value in WRITE_MODES
    return False


class FunctionScanner(ast.NodeVisitor):
    """Scans a single function body: is it gated, and which side-effect calls does it contain?"""

    def __init__(self, policy: dict[str, Any]):
        self.policy = policy
        self.gate_call_lines: list[int] = []
        self.sideeffects: list[tuple[ast.Call, str]] = []

    def visit_Call(self, node: ast.Call) -> None:
        dotted = dotted_name(node.func)
        seg = last_segment(dotted)
        if seg in self.policy["gate_calls"] or dotted in self.policy["gate_calls"]:
            self.gate_call_lines.append(node.lineno)
        reason = self._sideeffect_reason(node, dotted, seg)
        if reason:
            self.sideeffects.append((node, reason))
        self.generic_visit(node)

    def _sideeffect_reason(self, node: ast.Call, dotted: str, seg: str) -> str:
        for pat in self.policy["sideeffect_attrs"]:
            if dotted == pat or dotted.endswith("." + pat):
                return f"side-effectful call '{pat}'"
        if seg in self.policy["sideeffect_names"]:
            return f"side-effectful call '{seg}(...)'"
        if self.policy.get("flag_open_write") and seg == "open" and open_is_write(node):
            return "file opened for writing"
        return ""


def iter_functions(tree: ast.AST):
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            yield node


def analyze_source(src: str, filename: str, policy: dict[str, Any]) -> list[Finding]:
    findings: list[Finding] = []
    try:
        tree = ast.parse(src, filename=filename)
    except SyntaxError as e:
        findings.append(Finding(filename, e.lineno or 0, e.offset or 0, "<parse error>", "", str(e)))
        return findings
    gate_decos = set(policy["gate_decorators"])
    for fn in iter_functions(tree):
        scanner = FunctionScanner(policy)
        for stmt in fn.body:
            scanner.visit(stmt)
        gated_by_decorator = bool(decorator_names(fn) & gate_decos)
        for call, reason in scanner.sideeffects:
            if gated_by_decorator:
                continue
            # in-body gate must appear before the side effect
            if any(gl <= call.lineno for gl in scanner.gate_call_lines):
                continue
            findings.append(Finding(
                file=filename, line=call.lineno, col=call.col_offset,
                call=dotted_name(call.func) or "<call>",
                enclosing_function=fn.name, reason=reason + " is not behind an approval gate",
            ))
    return findings


# ---- Driver ---------------------------------------------------------------

def iter_py_files(paths: list[str]):
    for p in paths:
        if os.path.isfile(p) and p.endswith(".py"):
            yield p
        elif os.path.isdir(p):
            for root, dirs, files in os.walk(p):
                dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", ".venv", "venv", "node_modules"}]
                for f in files:
                    if f.endswith(".py"):
                        yield os.path.join(root, f)


def load_policy(path: str | None) -> dict[str, Any]:
    policy = json.loads(json.dumps(DEFAULT_POLICY))  # deep copy
    if path:
        with open(path, "r", encoding="utf-8") as fh:
            override = json.load(fh)
        for k, v in override.items():
            policy[k] = v
    return policy


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Flag side-effectful calls that are not behind a human-approval gate.")
    ap.add_argument("paths", nargs="*", default=["."], help="files or directories to scan (default: .)")
    ap.add_argument("--json", dest="json_out", help="write a JSON report to this path")
    ap.add_argument("--policy", help="JSON file overriding the default markers/patterns")
    ap.add_argument("--hook", action="store_true", help="quiet mode for hooks; print only a summary")
    args = ap.parse_args(argv)

    policy = load_policy(args.policy)
    report = Report()
    for fpath in iter_py_files(args.paths or ["."]):
        report.files_scanned += 1
        try:
            with open(fpath, "r", encoding="utf-8") as fh:
                src = fh.read()
        except (OSError, UnicodeDecodeError):
            continue
        report.findings.extend(analyze_source(src, fpath, policy))

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as fh:
            json.dump({"files_scanned": report.files_scanned,
                       "violations": len(report.findings),
                       "findings": [asdict(f) for f in report.findings]}, fh, indent=2)

    n = len(report.findings)
    if args.hook:
        print(f"[gate-coverage] {n} ungated side-effect(s) across {report.files_scanned} file(s).")
    else:
        if not report.findings:
            print(f"gate-coverage: OK — no ungated side effects in {report.files_scanned} file(s).")
        else:
            print(f"gate-coverage: {n} ungated side-effect(s) in {report.files_scanned} file(s):\n")
            for f in report.findings:
                print(f"  {f.file}:{f.line}:{f.col}  in {f.enclosing_function}()  ->  {f.call}")
                print(f"      {f.reason}")
            print("\nFix: wrap each in an approval gate (e.g. @requires_approval, or request_approval(...) "
                  "before the call). See the framework-gate-primitives skill.")
    return min(n, 250)


if __name__ == "__main__":
    sys.exit(main())
