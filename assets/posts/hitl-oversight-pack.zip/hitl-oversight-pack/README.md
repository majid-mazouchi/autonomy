# HITL & Oversight Pack (for VS Code Copilot)

A plugin pack that adds **human-in-the-loop gating** to agentic systems: it finds the actions that change the world, decides which ones need a human, places the gate at the right chokepoint, and enforces a **fail-closed** rule — if a human can't be reached, the action does not run.

It installs as a single Copilot **plugin** (`plugin.json`) that bundles agents, skills, hooks, and an MCP server. It maps onto a three-layer progressive-disclosure setup: agents at the top, skills pulled in on demand, harnesses (linter + MCP server + hooks) as the executable layer.

## What's inside

Agents (`agents/`, `.agent.md` — select from the agents dropdown)
- **gate-architect** — scans a design or repo, classifies side-effectful actions by reversibility x blast radius, and proposes where gates belong and how to wire them.
- **vhm-gate-agent** — the same method specialized for Vehicle Health Management (fleet diagnostics, prognostics, OTA, calibration, service campaigns).

Skills (`skills/<name>/SKILL.md` — progressive-loading, shown in the `/skills` menu)
- **gate-by-blast-radius** — the reversibility x blast-radius decision tree and matrix, and what counts as a side effect.
- **framework-gate-primitives** — the concrete gate primitive for LangGraph, AutoGen, CrewAI, OpenAI Agents SDK, Semantic Kernel, Pydantic AI, MCP, and A2A, with wiring snippets.

Harnesses
- **scripts/gate_coverage_linter.py** — AST static analysis that flags side-effectful calls not behind an approval gate. Exit code = violation count, so it works as a pre-commit / `preToolUse` hook and as a tool the agents call. Configurable via `--policy policy.json`.
- **mcp/hitl_server.py** — an MCP server (`hitl-gate`) exposing `classify_blast_radius`, `request_approval` (via MCP elicitation, fail-closed), and `record_decision`, plus a `hitl://policy` resource.
- **hooks/hooks.json** — a `preToolUse` coverage check and a `sessionEnd` log marker.
- **scripts/gate_log_append.py** + **schema/gate_decision.schema.json** — the append-only JSONL decision log and its schema, feeding audit, complacency metrics, and the learning loop.

## Install

1. Copy `hitl-oversight-pack/` into your workspace (or your plugins location). VS Code auto-detects the `plugin.json` and surfaces the agents, skills, hooks, and MCP server alongside your own.
2. Install the server deps: `pip install -r mcp/requirements.txt`.
3. Reload the window. Pick **Gate Architect** (or **VHM Gate Agent**) from the agents dropdown; the skills appear under `/skills`; the `hitl-gate` MCP server appears in the MCP server list.

Run the linter standalone:
```
python3 scripts/gate_coverage_linter.py src/ --json gate-report.json
```

## The one rule that matters

**Fail closed.** Every gate — the linter's exit code, the MCP server's `request_approval`, the agents' guidance — treats an unreachable or silent human as *not approved*. A stalled action is recoverable; an erroneous irreversible fleet-wide action may not be.

## Verify before you rely on it

- **Framework/protocol APIs move fast.** The snippets in `framework-gate-primitives` were checked against current docs but should be re-verified against the versions you use.
- **MCP elicitation client support varies.** Some clients don't implement `elicitation/create`; the server handles that by failing closed. Test with your client (e.g. MCP Inspector).
- **Hook field names and the plugin root token** (`${CHAT_PLUGIN_ROOT}`) depend on your VS Code version's hook/plugin contract — confirm against the current "Agent plugins" / "Hooks" docs and adjust `hooks/hooks.json` and `.mcp.json` if needed.
- The linter is a heuristic that reduces missed gates; it is not a proof of coverage.

The gating logic and the framework table are drawn from the companion monograph on human-in-the-loop in agentic AI (sections on gate placement, the framework/protocol survey, and the decision walker).
