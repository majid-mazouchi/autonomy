---
name: gate-by-blast-radius
description: Decide whether an agent action needs a human gate, and which kind, by classifying it on two axes — reversibility and blast radius. Use when reviewing an agent design or a tool/function for human-in-the-loop oversight, when asked "should this be gated?", or when placing approval checkpoints in an agentic workflow.
---

# Gate by blast radius

The core question for any agent action is not "is it risky?" but **"if this goes wrong, how bad and how recoverable is it?"** Two axes answer that:

- **Reversibility** — can the effect be undone cheaply? (reversible / hard-to-reverse / irreversible)
- **Blast radius** — how far does the effect reach? (self / single external record / group / fleet-or-global)

The gate strength is a function of both. Reversible and narrow → let it run. Irreversible and wide → require human approval, possibly two-person.

## The decision tree

Apply in order; stop at the first match.

1. **Is the action read-only / no external side effect?** (a query, a draft, an in-memory computation)
   → No gate. Let it run and log.
2. **Is it reversible AND narrow** (affects only this run's scratch state or a single easily-restored record)?
   → No gate, or async notify-only. Optionally sample for audit.
3. **Is it reversible but wide**, OR **hard-to-reverse but narrow**?
   → Gate with **approval** on a confidence trigger: auto-run when the agent's calibrated confidence is high and the input is in-distribution; escalate to a human otherwise. Always log.
4. **Is it irreversible**, OR **wide-and-hard-to-reverse**?
   → **Always require human approval** before execution, with full provenance shown. Offer approve / edit / reject / rework.
5. **Is it irreversible AND fleet-or-global** (mass effect, safety-relevant, regulated)?
   → **Two-person rule** (independent second approver) and a mandatory waiting/confirmation step. This is the EU AI Act "two-person" tier for the highest-impact actions.

## The matrix

| | Self / scratch | Single record | Group | Fleet / global |
|---|---|---|---|---|
| **Reversible** | auto | auto / notify | notify / approve | approve |
| **Hard-to-reverse** | auto / notify | approve | approve | approve + two-person |
| **Irreversible** | approve | approve | approve + two-person | approve + two-person + wait |

## What counts as a side effect (look for these)

Writes and deletes (file, DB, object store), network sends (email, message, webhook, API POST/PUT/PATCH/DELETE), money movement (charges, transfers, refunds), spawning processes or sub-agents, configuration or permission changes, publishing or deploying, and any physical-world or device action (flashing firmware, OTA push, actuator command). When in doubt, treat an action whose name contains send / delete / deploy / push / flash / commit / execute / transfer / publish / grant as side-effectful until proven otherwise.

## Hard rules

- **Fail closed.** If the human approval channel is unreachable, the answer is *not approved* — never auto-proceed on an action that required a gate.
- **Gate the effect, not the chatter.** Put the gate at the line that actually changes the world (the tool call / commit), not on the reasoning around it.
- **One gate per side-effectful action**, sited at the narrowest chokepoint that still dominates the effect. Don't gate every intermediate step — that produces alert fatigue and rubber-stamping.
- **Show provenance at the gate.** A reviewer who can't see why the action was proposed will rubber-stamp it. Include the trigger, the inputs, and the predicted effect.

## How to apply

When reviewing code or a design: enumerate the side-effectful actions, place each in the matrix (state the reversibility and blast radius you assumed), and emit the recommended gate. Then check whether that gate actually exists in the implementation. The companion `framework-gate-primitives` skill shows how to wire the chosen gate in each agent framework; the `gate_coverage_linter.py` harness flags side-effectful calls that have no gate.
