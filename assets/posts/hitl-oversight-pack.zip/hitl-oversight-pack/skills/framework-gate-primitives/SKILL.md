---
name: framework-gate-primitives
description: Implement a human approval gate in a specific agent framework or interoperability protocol. Use when a gating plan has been decided (see the gate-by-blast-radius skill) and you need the concrete primitive and wiring for LangGraph, AutoGen, CrewAI, the OpenAI Agents SDK, Semantic Kernel, Pydantic AI, MCP, or A2A.
---

# Framework gate primitives

Once you know an action needs a gate, the implementation is framework-specific but the shape is always the same: classify the action (usually the tool), pause before the side-effectful ones, persist enough state to resume, and offer the human approve / edit / reject / rework. Below are the current primitives. Frameworks move fast — confirm against the latest docs before relying on a signature.

A universal rule that overrides any framework detail: **fail closed.** If the pause cannot reach a human (no UI attached, elicitation unsupported, timeout), the action must not execute.

## LangGraph
Primitive: `interrupt()` inside a node plus a checkpointer; resume with `Command(resume=...)`. Granularity: node and tool. State is persisted by `thread_id`, so a run can wait indefinitely and resume later (use `InMemorySaver` for dev, `SqliteSaver`/`PostgresSaver` for production). LangChain also ships `HumanInTheLoopMiddleware` with a per-tool `interrupt_on` policy that allows approve / edit / reject / respond.
```python
from langgraph.types import interrupt, Command
def commit_node(state):
    decision = interrupt({"action": "deploy", "args": state["args"]})  # pauses; persisted by thread_id
    if decision.get("approve"):
        return do_commit(state["args"])
    return {"status": "rejected"}
```

## AutoGen (AgentChat)
Primitive: a `UserProxyAgent` participating in the team, or `human_input_mode` (NEVER / TERMINATE / ALWAYS) on a `ConversableAgent`. Granularity: conversation turn. The human is a first-class participant in the group chat; supply a custom `input_func` to route the prompt to your UI.
```python
from autogen_agentchat.agents import UserProxyAgent
user = UserProxyAgent("approver", input_func=my_async_ui_prompt)  # team pauses on its turn
```

## CrewAI
Primitive: `human_input=True` on a task — the agent prompts for input before delivering its final answer. Granularity: task. In a hierarchical process the manager agent validates results before proceeding, which is itself a gate.
```python
from crewai import Task
deploy = Task(description="Push OTA update", expected_output="confirmation", agent=ota_agent, human_input=True)
```

## OpenAI Agents SDK
Primitive: `@function_tool(needs_approval=True)` — the run records an interruption instead of executing; inspect `result.interruptions`, approve with `state.approve(...)`, resume by re-running with the serialized state. Granularity: tool, and the approval surface is run-wide (it works across handoffs and nested `agent.as_tool()` calls). Serialize `RunState` to wait hours for a human.
```python
from agents import Agent, Runner, function_tool
@function_tool(needs_approval=True)
async def cancel_order(order_id: int) -> str: ...
res = await Runner.run(agent, "cancel 123")
if res.interruptions:
    st = res.to_state()
    for i in res.interruptions: st.approve(i)   # or st.reject(i)
    res = await Runner.run(agent, st)
```

## Semantic Kernel
Primitive: `IFunctionInvocationFilter` — intercepts before and after each `KernelFunction` invocation, so you can prompt for approval, override the result, or short-circuit. Granularity: function / tool. (Maintain a registry of which tool names require approval and let the filter auto-pass read-only ones.)

## Pydantic AI
Primitive: a tool with `requires_approval=True` and an agent `output_type` that includes `DeferredToolRequests`. The run returns `DeferredToolRequests` (with `.approvals`); you resolve them with `DeferredToolResults` (ToolApproved / ToolDenied) on the next run. Granularity: tool; supports durable execution so approvals can be resolved across runs.
```python
from pydantic_ai import Agent, DeferredToolRequests, DeferredToolResults
agent = Agent("openai:gpt-4o", output_type=[str, DeferredToolRequests])
@agent.tool(requires_approval=True)
async def delete_file(ctx, path: str) -> str: ...
```

## MCP (protocol boundary — between you and a server you may not own)
Primitive: **elicitation** — a server pauses mid-tool-call and requests structured input from the user via the client (`ctx.elicit(message=..., schema=Model)`, returning Accepted / Declined / Cancelled). Also **sampling** (`sampling/createMessage`), where the spec says there should be a human able to review, edit, or deny. The gate lives at the host/client, one place for every server the host talks to. Schemas must use primitive fields only. Not every client supports elicitation — handle "method not found" by failing closed. (This pack ships such a server: `mcp/hitl_server.py`.)

## A2A (protocol boundary — between agents you may not own)
Primitive: the task lifecycle state **input-required**. A remote agent that needs human approval transitions the task to `input-required`; the client resumes by sending a follow-up on the same task ID. Granularity: cross-agent task; durable and multi-turn across independently deployed agents. (A `USER_CONSENT_REQUIRED` state for explicit pre-action approval is a research proposal, not yet in the baseline spec.)

## Choosing where the gate sits
- Inside one system you own → use the framework primitive at the **tool** (LangGraph, OpenAI SDK, Pydantic AI, Semantic Kernel) or the **task/turn** (CrewAI, AutoGen).
- Across a trust boundary to agents/servers you don't own → gate at the **protocol** (MCP elicitation, A2A input-required). This is where an ungated handoff is most dangerous, so prefer protocol-level gating there.
