/* Interactive explorers for the multivariate-monitoring monograph. Vanilla JS. */
(function () {
  "use strict";
  var INK = "#221d17", MUTE = "#7a6f5e", RUST = "#b0492f",
      TEAL = "#1f6f6a", OCHRE = "#c4922b", LINE = "#d9cfb8";

  function fit(c){var d=window.devicePixelRatio||1,w=c.clientWidth||600,h=c.clientHeight||240;
    c.width=w*d;c.height=h*d;var x=c.getContext("2d");x.setTransform(d,0,0,d,0,0);return {ctx:x,w:w,h:h};}
  function rng(seed){var s=seed>>>0;return function(){s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
  function gauss(n,seed){var r=rng(seed),o=new Float64Array(n),i;
    for(i=0;i<n;i++){var u=Math.max(1e-9,r()),v=r();o[i]=Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);}return o;}

  // ======================================================================
  // A. PCA monitoring with fault injection (uses a baked model)
  // ======================================================================
  (function pca(){
    var M = window.PCA_MODEL; if(!M) return;
    var cv=document.getElementById("ex-pca-canvas"); if(!cv) return;
    var bar=document.getElementById("ex-pca-contrib");
    var selS=document.getElementById("ex-pca-sensor"), selT=document.getElementById("ex-pca-type");
    var mag=document.getElementById("ex-pca-mag"), cap=document.getElementById("ex-pca-cap");
    M.names.forEach(function(nm,i){var o=document.createElement("option");o.value=i;o.textContent=nm;selS.appendChild(o);});
    selS.value = 2; // T_cell3 by default

    function standardize(row){var z=new Float64Array(M.m),j;for(j=0;j<M.m;j++)z[j]=(row[j]-M.mean[j])/M.std[j];return z;}
    function scores(z){var t=new Float64Array(M.k),a,j;for(a=0;a<M.k;a++){var s=0;for(j=0;j<M.m;j++)s+=z[j]*M.P[j][a];t[a]=s;}return t;}
    function recon(t){var zh=new Float64Array(M.m),j,a;for(j=0;j<M.m;j++){var s=0;for(a=0;a<M.k;a++)s+=M.P[j][a]*t[a];zh[j]=s;}return zh;}
    function stats(row){var z=standardize(row),t=scores(z),zh=recon(t),j;
      var T2=0;for(j=0;j<M.k;j++)T2+=t[j]*t[j]/M.eig[j];
      var Q=0,contrib=new Float64Array(M.m);for(j=0;j<M.m;j++){var e=z[j]-zh[j];contrib[j]=e*e;Q+=e*e;}
      return {T2:T2,Q:Q,contrib:contrib};}

    function build(){
      var fsen=parseInt(selS.value,10), kind=selT.value, amt=parseFloat(mag.value)/100;
      var nb=M.base.length, half=nb;            // healthy then faulted copy
      var rows=[], i;
      for(i=0;i<nb;i++) rows.push(M.base[i].slice());
      for(i=0;i<nb;i++){
        var r=M.base[i].slice(), ramp=amt*(i/(nb-1));
        if(kind==="drift"){ r[fsen]+=ramp*6*M.std[fsen]; }
        else { for(var j=0;j<M.m;j++) r[j]*=(1+ramp*1.6); } // common excursion -> T2
        rows.push(r);
      }
      return {rows:rows, split:half, fsen:fsen, kind:kind};
    }

    function draw(){
      var b=build(), T2=[], Q=[], worst=-1, worstQ=-1, worstT2=-1, worstStat=-1, i;
      for(i=0;i<b.rows.length;i++){var s=stats(b.rows[i]);T2.push(s.T2);Q.push(s.Q);
        if(i>=b.split){var key=b.kind==="drift"?s.Q/M.q_limit:s.T2/M.t2_limit;
          if(key>worstStat){worstStat=key;worst=i;}}}
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=30;ctx.clearRect(0,0,w,h);
      var rT2=T2.map(function(v){return v/M.t2_limit;}), rQ=Q.map(function(v){return v/M.q_limit;});
      var top=Math.max(2.2, Math.max.apply(null,rT2.concat(rQ))*1.1);
      function X(i){return pad+i/(b.rows.length-1)*(w-2*pad);}
      function Y(v){return h-pad-Math.min(v,top)/top*(h-2*pad);}
      ctx.fillStyle="rgba(176,73,47,0.06)";ctx.fillRect(X(b.split),pad,w-pad-X(b.split),h-2*pad);
      ctx.strokeStyle=LINE;ctx.beginPath();ctx.moveTo(pad,h-pad);ctx.lineTo(w-pad,h-pad);ctx.moveTo(pad,pad);ctx.lineTo(pad,h-pad);ctx.stroke();
      ctx.strokeStyle=INK;ctx.setLineDash([4,3]);ctx.beginPath();ctx.moveTo(pad,Y(1));ctx.lineTo(w-pad,Y(1));ctx.stroke();ctx.setLineDash([]);
      function plot(arr,col){ctx.strokeStyle=col;ctx.lineWidth=1.4;ctx.beginPath();
        for(i=0;i<arr.length;i++){if(i===0)ctx.moveTo(X(i),Y(arr[i]));else ctx.lineTo(X(i),Y(arr[i]));}ctx.stroke();}
      plot(rT2,TEAL);plot(rQ,RUST);
      ctx.font="11px monospace";ctx.fillStyle=TEAL;ctx.fillText("T\u00b2",pad+4,pad+12);
      ctx.fillStyle=RUST;ctx.fillText("Q (SPE)",pad+34,pad+12);
      ctx.fillStyle=MUTE;ctx.fillText("limit",w-pad-30,Y(1)-4);ctx.fillText("fault \u2192",X(b.split)+4,h-pad-6);
      // contribution bar for worst sample
      var s=stats(b.rows[worst<0?b.rows.length-1:worst]);
      var g=fit(bar),c2=g.ctx,w2=g.w,h2=g.h,p2=26;c2.clearRect(0,0,w2,h2);
      var cm=Math.max.apply(null,s.contrib)||1, bw=(w2-2*p2)/M.m*0.7, gap=(w2-2*p2)/M.m;
      var topi=0;for(i=1;i<M.m;i++)if(s.contrib[i]>s.contrib[topi])topi=i;
      for(i=0;i<M.m;i++){var bx=p2+i*gap+gap*0.15, bh=s.contrib[i]/cm*(h2-2*p2);
        c2.fillStyle=(i===topi)?RUST:TEAL;c2.fillRect(bx,h2-p2-bh,bw,bh);
        c2.fillStyle=MUTE;c2.font="9px monospace";c2.save();c2.translate(bx+bw/2,h2-p2+10);c2.rotate(-0.5);
        c2.textAlign="right";c2.fillText(M.names[i],0,0);c2.restore();}
      c2.fillStyle=INK;c2.font="11px monospace";c2.fillText("Q contribution (worst fault sample)",p2,14);
      var which=b.kind==="drift"?"Q":"T\u00b2";
      var crossed=(b.kind==="drift"? rQ[worst]>1 : rT2[worst]>1);
      cap.textContent = crossed
        ? which+" crosses its limit in the fault region; the contribution bar points at "+M.names[topi]+"."
        : "Turn up the drift until "+which+" crosses its limit, then read which sensor the contribution bar blames.";
    }
    [selS,selT,mag].forEach(function(e){e.addEventListener("input",draw);});
    window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // B. Mahalanobis vs Euclidean (2D)
  // ======================================================================
  (function maha(){
    var cv=document.getElementById("ex-maha-canvas"); if(!cv) return;
    var euEl=document.getElementById("ex-maha-eu"), mdEl=document.getElementById("ex-maha-md"),
        sRho=document.getElementById("ex-maha-rho"), sX=document.getElementById("ex-maha-x"),
        sY=document.getElementById("ex-maha-y"), cap=document.getElementById("ex-maha-cap");
    var N=260, gx=gauss(N,2), gy=gauss(N,8);
    var LIM=Math.sqrt(9.21);  // chi-square(2) 99%

    function draw(){
      var rho=parseFloat(sRho.value)/100, px=parseFloat(sX.value)/10, py=parseFloat(sY.value)/10;
      // cloud from correlation rho via Cholesky of [[1,rho],[rho,1]]
      var a=1, b=rho, c=Math.sqrt(Math.max(1e-6,1-rho*rho));
      var xs=new Float64Array(N), ys=new Float64Array(N), i;
      for(i=0;i<N;i++){xs[i]=gx[i];ys[i]=rho*gx[i]+c*gy[i];}
      // Sinv for [[1,rho],[rho,1]]
      var det=1-rho*rho, si00=1/det, si01=-rho/det, si11=1/det;
      var md=Math.sqrt(px*(si00*px+si01*py)+py*(si01*px+si11*py));
      var eu=Math.sqrt(px*px+py*py);
      euEl.textContent=eu.toFixed(1); mdEl.textContent=md.toFixed(1);
      mdEl.style.color = md>LIM?RUST:TEAL;
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=24,sc=(Math.min(w,h)-2*pad)/9; // +-4.5 range
      ctx.clearRect(0,0,w,h);
      var cx=w/2, cy=h/2;
      function PX(x){return cx+x*sc;} function PY(y){return cy-y*sc;}
      ctx.strokeStyle=LINE;ctx.beginPath();ctx.moveTo(pad,cy);ctx.lineTo(w-pad,cy);ctx.moveTo(cx,pad);ctx.lineTo(cx,h-pad);ctx.stroke();
      // covariance ellipses (1,2,3 sd) eigen of [[1,rho],[rho,1]]: vals 1+|rho|,1-|rho| at +-45deg
      var ar=rho>=0?Math.PI/4:-Math.PI/4, l1=Math.sqrt(1+Math.abs(rho)), l2=Math.sqrt(1-Math.abs(rho));
      for(var k=1;k<=3;k++){ctx.strokeStyle=OCHRE;ctx.globalAlpha=0.55-0.13*k;ctx.lineWidth=1.2;ctx.beginPath();
        for(var th=0;th<=Math.PI*2+0.01;th+=0.1){var ex=k*l1*Math.cos(th),ey=k*l2*Math.sin(th);
          var rx=ex*Math.cos(ar)-ey*Math.sin(ar), ry=ex*Math.sin(ar)+ey*Math.cos(ar);
          if(th===0)ctx.moveTo(PX(rx),PY(ry));else ctx.lineTo(PX(rx),PY(ry));}ctx.stroke();}
      ctx.globalAlpha=1;
      ctx.fillStyle="rgba(31,111,106,0.5)";for(i=0;i<N;i++){ctx.beginPath();ctx.arc(PX(xs[i]),PY(ys[i]),2.2,0,6.28);ctx.fill();}
      // test point + euclidean line
      ctx.strokeStyle=MUTE;ctx.setLineDash([3,3]);ctx.beginPath();ctx.moveTo(PX(0),PY(0));ctx.lineTo(PX(px),PY(py));ctx.stroke();ctx.setLineDash([]);
      ctx.fillStyle=md>LIM?RUST:TEAL;ctx.beginPath();ctx.arc(PX(px),PY(py),6,0,6.28);ctx.fill();
      ctx.strokeStyle="#fff";ctx.lineWidth=1.5;ctx.stroke();
      cap.textContent = md>LIM
        ? "Mahalanobis "+md.toFixed(1)+" exceeds the 99% limit ("+LIM.toFixed(1)+"): an outlier given the correlation, even though Euclidean is only "+eu.toFixed(1)+"."
        : "Inside the healthy cloud. Push the point off the diagonal ridge and Mahalanobis climbs far faster than Euclidean.";
    }
    [sRho,sX,sY].forEach(function(e){e.addEventListener("input",draw);});
    window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // C. Sequential detection: per-sample limit vs EWMA
  // ======================================================================
  (function seq(){
    var cv=document.getElementById("ex-seq-canvas"); if(!cv) return;
    var sShift=document.getElementById("ex-seq-shift"), sLam=document.getElementById("ex-seq-lam"),
        read=document.getElementById("ex-seq-read"), cap=document.getElementById("ex-seq-cap");
    var N=320, onset=160, g=gauss(N,77);
    function draw(){
      var shift=parseFloat(sShift.value)/100*1.5, lam=parseFloat(sLam.value)/100;
      lam=Math.max(0.03,lam);
      var x=new Float64Array(N), i;
      for(i=0;i<N;i++) x[i]=g[i]+(i>=onset?shift:0);
      var L=3.0, ewLim=L*Math.sqrt(lam/(2-lam));
      var ew=new Float64Array(N), p=0, rawHit=-1, ewHit=-1;
      for(i=0;i<N;i++){p=lam*x[i]+(1-lam)*p;ew[i]=p;
        if(i>=onset&&rawHit<0&&x[i]>L)rawHit=i;
        if(i>=onset&&ewHit<0&&ew[i]>ewLim)ewHit=i;}
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=30;ctx.clearRect(0,0,w,h);
      var lo=-3, hi=Math.max(4, shift+3.5);
      function X(i){return pad+i/(N-1)*(w-2*pad);}
      function Y(v){return h-pad-(v-lo)/(hi-lo)*(h-2*pad);}
      ctx.fillStyle="rgba(176,73,47,0.06)";ctx.fillRect(X(onset),pad,w-pad-X(onset),h-2*pad);
      ctx.strokeStyle=LINE;ctx.beginPath();ctx.moveTo(pad,Y(0));ctx.lineTo(w-pad,Y(0));ctx.stroke();
      ctx.fillStyle="rgba(122,111,94,0.5)";for(i=0;i<N;i++){ctx.beginPath();ctx.arc(X(i),Y(x[i]),1.6,0,6.28);ctx.fill();}
      ctx.strokeStyle=OCHRE;ctx.setLineDash([5,3]);ctx.beginPath();ctx.moveTo(pad,Y(L));ctx.lineTo(w-pad,Y(L));ctx.stroke();
      ctx.strokeStyle=TEAL;ctx.beginPath();ctx.moveTo(pad,Y(ewLim));ctx.lineTo(w-pad,Y(ewLim));ctx.stroke();ctx.setLineDash([]);
      ctx.strokeStyle=TEAL;ctx.lineWidth=1.8;ctx.beginPath();
      for(i=0;i<N;i++){if(i===0)ctx.moveTo(X(i),Y(ew[i]));else ctx.lineTo(X(i),Y(ew[i]));}ctx.stroke();
      function mark(idx,col){if(idx<0)return;ctx.strokeStyle=col;ctx.lineWidth=1.4;ctx.setLineDash([4,3]);
        ctx.beginPath();ctx.moveTo(X(idx),pad);ctx.lineTo(X(idx),h-pad);ctx.stroke();ctx.setLineDash([]);}
      mark(rawHit,OCHRE);mark(ewHit,TEAL);
      ctx.font="11px monospace";ctx.fillStyle=OCHRE;ctx.fillText("per-sample limit",pad+4,Y(L)-4);
      ctx.fillStyle=TEAL;ctx.fillText("EWMA + limit",pad+4,Y(ewLim)+14);
      ctx.fillStyle=MUTE;ctx.fillText("shift \u2192",X(onset)+4,h-pad-4);
      var rd=rawHit<0?"never":(rawHit-onset)+" samples", ed=ewHit<0?"never":(ewHit-onset)+" samples";
      read.innerHTML="detection delay &nbsp; per-sample <b>"+rd+"</b> &nbsp;|&nbsp; EWMA <b style='color:"+TEAL+"'>"+ed+"</b>";
      cap.textContent = (ewHit>=0 && (rawHit<0||ewHit<rawHit))
        ? "For this small shift the EWMA accumulates evidence and alarms first; the per-sample chart only trips on the odd noisy spike."
        : "Raise the shift and the per-sample chart catches up; EWMA's edge is largest for small, slow drifts.";
    }
    [sShift,sLam].forEach(function(e){e.addEventListener("input",draw);});
    window.addEventListener("resize",draw); draw();
  })();

  // ======================================================================
  // D. Operating modes: a global model false-alarms on a healthy mode change
  // ======================================================================
  (function modes(){
    var cv=document.getElementById("ex-mode-canvas"); if(!cv) return;
    var sSep=document.getElementById("ex-mode-sep"), sMode=document.getElementById("ex-mode-aware"),
        read=document.getElementById("ex-mode-read"), cap=document.getElementById("ex-mode-cap");
    var n=160, ax=gauss(n,21), ay=gauss(n,22), bx=gauss(n,23), by=gauss(n,24);
    var LIM=9.21;
    function md(px,py,mx,my,sxx,syy,sxy){
      var dx=px-mx, dy=py-my, det=sxx*syy-sxy*sxy;
      var i00=syy/det,i01=-sxy/det,i11=sxx/det;
      return dx*(i00*dx+i01*dy)+dy*(i01*dx+i11*dy);
    }
    function draw(){
      var sep=parseFloat(sSep.value)/100*6, aware=sMode.value==="aware", i;
      var Ax=[],Ay=[],Bx=[],By=[];
      for(i=0;i<n;i++){Ax.push(-sep/2+0.7*ax[i]);Ay.push(-sep/4+0.7*ay[i]);
        Bx.push(sep/2+0.7*bx[i]);By.push(sep/4+0.7*by[i]);}
      function mc(X,Y){var mx=0,my=0;for(i=0;i<n;i++){mx+=X[i];my+=Y[i];}mx/=n;my/=n;
        var sxx=0,syy=0,sxy=0;for(i=0;i<n;i++){var dx=X[i]-mx,dy=Y[i]-my;sxx+=dx*dx;syy+=dy*dy;sxy+=dx*dy;}
        return {mx:mx,my:my,sxx:sxx/(n-1),syy:syy/(n-1),sxy:sxy/(n-1)};}
      var mA=mc(Ax,Ay), mB=mc(Bx,By), flagged=0;
      for(i=0;i<n;i++){var dA=md(Bx[i],By[i],mA.mx,mA.my,mA.sxx,mA.syy,mA.sxy);
        var dB=md(Bx[i],By[i],mB.mx,mB.my,mB.sxx,mB.syy,mB.sxy);
        if((aware?Math.min(dA,dB):dA)>LIM)flagged++;}
      var rate=flagged/n*100;
      var f=fit(cv),ctx=f.ctx,w=f.w,h=f.h,pad=14;ctx.clearRect(0,0,w,h);
      var all=Ax.concat(Bx), ally=Ay.concat(By);
      var xmin=Math.min.apply(null,all)-1,xmax=Math.max.apply(null,all)+1;
      var ymin=Math.min.apply(null,ally)-1,ymax=Math.max.apply(null,ally)+1;
      function PX(x){return pad+(x-xmin)/(xmax-xmin)*(w-2*pad);}
      function PY(y){return h-pad-(y-ymin)/(ymax-ymin)*(h-2*pad);}
      ctx.fillStyle="rgba(31,111,106,0.5)";for(i=0;i<n;i++){ctx.beginPath();ctx.arc(PX(Ax[i]),PY(Ay[i]),2,0,6.28);ctx.fill();}
      for(i=0;i<n;i++){var dA=md(Bx[i],By[i],mA.mx,mA.my,mA.sxx,mA.syy,mA.sxy);
        var dB=md(Bx[i],By[i],mB.mx,mB.my,mB.sxx,mB.syy,mB.sxy);
        ctx.fillStyle=((aware?Math.min(dA,dB):dA)>LIM)?"rgba(176,73,47,0.75)":"rgba(196,146,43,0.7)";
        ctx.beginPath();ctx.arc(PX(Bx[i]),PY(By[i]),2,0,6.28);ctx.fill();}
      ctx.font="11px monospace";ctx.fillStyle=TEAL;ctx.fillText("mode A (trained)",pad+2,14);
      ctx.fillStyle=OCHRE;ctx.fillText("mode B (healthy)",pad+2,28);
      read.innerHTML="false alarms on healthy mode B: <b style='color:"+(rate>15?RUST:TEAL)+"'>"+rate.toFixed(0)+"%</b> ("+(aware?"mode-aware":"global model")+")";
      cap.textContent = aware
        ? "Mode-aware scoring judges each sample against its own regime, so a healthy mode change is not an alarm."
        : "A single global model treats mode B as anomalous as soon as the modes separate, drowning real faults in false alarms.";
    }
    [sSep,sMode].forEach(function(e){e.addEventListener("input",draw);});
    window.addEventListener("resize",draw); draw();
  })();
})();
