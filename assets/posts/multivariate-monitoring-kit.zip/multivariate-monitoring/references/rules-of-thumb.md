# Rules of thumb

1. Scale before you decompose. Unit-variance every sensor first, or PCA, PLS, CCA and Mahalanobis all just track whichever channel has the biggest numbers.
2. Fit on healthy, score on everything. The model and its control limits come from a clean reference period; new data is only ever scored, never refit into the baseline.
3. Use T² and Q as a pair, never alone. T² catches in-pattern excursions, Q catches new patterns. Most real faults trip Q first.
4. Reach for a label when you have one. PLS-DA and LDA beat PCA and Mahalanobis at separating a known fault, because they optimize for the distinction instead of for variance.
5. Localize, then confirm. Contribution and VIP plots point at suspect sensors but smear blame across correlated channels; treat them as leads, not verdicts.
6. Mind the sample-to-variable ratio. Covariance-based methods need many more samples than variables; otherwise regularize, shrink, or reduce dimension first.
7. Validate out of sample. In-sample limits and accuracies are optimistic; hold out clean data, cross-validate latent-variable counts, and permutation-test PLS-DA separation.
8. Detrend slow operating drift. A baseline that wanders across operating modes inflates every statistic; model per mode or remove the trend before monitoring.

## Pick by scenario

| Scenario | Pick | Why |
| --- | --- | --- |
| Continuous fleet monitoring, many correlated sensors, no labels | PCA T² + Q | the standard always-on pair |
| Alarm fired, which sensor is responsible | Q / T² contributions | decompose the statistic onto variables |
| Point looks normal per channel but feels wrong | Mahalanobis distance | it scores the joint correlation |
| Overlapping vibration or current sources at one sensor | ICA | unmix independent generators |
| Relate a command block to a response block | CCA | correlation between two variable sets |
| Labeled healthy vs degraded runs, fault is subtle | PLS-DA | supervised, aims at the label |
| Known, labeled fault modes, classify new runs | LDA / QDA | Gaussian class models |
| Few labeled samples per class | LDA | shared covariance is stable on small data |
| Plenty of labels, classes differ in shape | QDA | per-class covariance fits curved boundaries |
