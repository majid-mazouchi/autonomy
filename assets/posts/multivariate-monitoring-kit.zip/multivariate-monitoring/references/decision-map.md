# Decision map

Start from the question you have, not the method you know.

| If you are asking | Reach for |
| --- | --- |
| Is any new sample still inside the normal multi-sensor pattern? | PCA T² + Q |
| Which sensor broke the pattern? | Q / T² contribution plot |
| Is this point an outlier given the joint correlation? | Mahalanobis distance |
| A fault shows up only as a mixed signal | ICA |
| How does a command block relate to a response block? | CCA |
| I have a quality or fault label to separate against | PLS-DA |
| Which sensors carry the fault signature (with a label)? | PLS VIP scores |
| Fault classes are known and labeled; classify new runs | LDA / QDA |

## Escalation order

1. Scale every sensor to unit variance and set aside a clean healthy reference period.
2. Fit `PCAMonitor` on healthy data; score new samples with T-squared and Q against their limits.
3. On an alarm, read `q_contributions` (or T-squared contributions) to localize the suspect channel.
4. Cross-check with `mahalanobis`, which shares none of PCA's rank choices.
5. If a fault arrives mixed, unmix with `ica_sources`; to relate command and response blocks, use `cca_fit`.
6. Once history is labeled, switch to `pls_da` for subtle faults and `lda_qda` to classify known modes.
