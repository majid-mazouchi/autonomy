# Subspace monitoring, the workhorse

_Build one model of healthy behaviour, then ask of every new sample: is it still inside the normal pattern, and if not, which sensor broke it. This is what runs continuously on a fleet._

## PCA with Hotelling's T² and the SPE / Q statistic

**Essence.** The classic process-monitoring pair. T² watches variation inside the model subspace; Q watches the residual subspace. Contribution plots then name the offending variable.

**In plain words.** Principal component analysis learns the few directions along which a healthy multi-sensor system actually varies. Two numbers then summarize any new sample. Hotelling's T² measures how far it sits inside that learned subspace, so it catches unusual but in-pattern operation. The squared prediction error, called SPE or Q, measures how far it falls outside the subspace, so it catches a brand-new pattern the model never saw, such as two sensors that used to track each other drifting apart. When either crosses its control limit, a contribution plot breaks the statistic back down onto the raw sensors and points at the culprit.

**Diagnostic example.** A converter has a dozen correlated temperatures, currents, and voltages. PCA on a month of healthy data keeps three components. A developing solder crack slowly decouples one thermistor from the rest: T² stays calm because each reading is individually normal, but Q climbs past its limit because the joint correlation is broken. The Q contribution plot puts almost all the blame on that one thermistor channel.

**Engine call.** `PCAMonitor().fit(X_healthy); then mon.t2(X), mon.q(X), mon.q_contributions(x)`

```python
import numpy as np
from scipy import stats

class PCAMonitor:
    def fit(self, X, var=0.9, alpha=0.99):
        self.mu = X.mean(0); self.sd = X.std(0, ddof=1); self.sd[self.sd==0]=1
        Z = (X - self.mu) / self.sd
        n, m = Z.shape
        _, s, Vt = np.linalg.svd(Z, full_matrices=False)
        eig = s**2 / (n - 1)
        k = int(np.searchsorted(np.cumsum(eig)/eig.sum(), var) + 1)
        self.P, self.eig, self.res = Vt[:k].T, eig[:k], eig[k:]
        self.k = k
        self.t2_lim = k*(n-1)*(n+1)/(n*(n-k))*stats.f.ppf(alpha, k, n-k)
        t1,t2,t3 = self.res.sum(), (self.res**2).sum(), (self.res**3).sum()
        h0 = 1 - 2*t1*t3/(3*t2**2); ca = stats.norm.ppf(alpha)
        self.q_lim = t1*(ca*np.sqrt(2*t2*h0**2)/t1 + 1 + t2*h0*(h0-1)/t1**2)**(1/h0)
        return self
    def _z(self, X): return (np.atleast_2d(X) - self.mu) / self.sd
    def t2(self, X): T = self._z(X) @ self.P; return (T**2 / self.eig).sum(1)
    def q(self, X):
        Z = self._z(X); E = Z - Z @ self.P @ self.P.T; return (E**2).sum(1)
    def q_contrib(self, x):
        z = self._z(x); e = z - z @ self.P @ self.P.T; return (e[0]**2)

mon = PCAMonitor().fit(X_healthy)
flag = (mon.t2(X_new) > mon.t2_lim) | (mon.q(X_new) > mon.q_lim)
culprit = np.argmax(mon.q_contrib(X_new[flag][-1]))  # which sensor
```

**Practical note.** Always scale to unit variance first, or the largest-range sensor dominates the components. Choose the rank from a scree plot or cumulative variance, not reflexively at 95%. Recompute limits on a held-out healthy set, since in-sample limits are optimistic. Watch T² and Q together: T² alone misses new patterns, Q alone misses extreme but in-pattern excursions. Contribution plots indicate, they do not prove, since a fault smears across correlated sensors.

**Reference.** Jackson & Mudholkar (1979), Technometrics 21; Wise & Gallagher (1996), J. Process Control 6; Qin (2003), J. Chemometrics 17.

## Mahalanobis distance

**Essence.** A covariance-aware outlier metric: the multivariate generalization of the z-score. It rescales by the healthy covariance, so it flags points that violate the joint correlation even when each axis looks normal.

**In plain words.** A plain z-score asks how many standard deviations a value sits from the mean, one variable at a time. That misses faults that keep every single sensor in its normal range while breaking the relationship between them. Mahalanobis distance fixes this by dividing out the full covariance of the healthy data. Geometrically it stretches and rotates space so the healthy cloud becomes a sphere; distance is then measured in that whitened space. A point sitting off the main correlation axis is far in Mahalanobis terms even if it is close in ordinary Euclidean terms. Under a Gaussian assumption the squared distance follows a chi-square law, which gives a clean control limit.

**Diagnostic example.** Two coolant sensors normally rise and fall together. After a fault one reads high while the other reads low, both still within their individual operating bands. Euclidean distance from the mean barely moves; Mahalanobis distance jumps well past its chi-square limit because the pair has left the diagonal ridge of normal joint behaviour.

**Engine call.** `mahalanobis(X_ref, x)`

```python
import numpy as np
from scipy import stats

def mahalanobis(X_ref, x):
    mu = X_ref.mean(0)
    S = np.cov(X_ref, rowvar=False)
    Sinv = np.linalg.pinv(S)
    d = np.atleast_2d(x) - mu
    dist = np.sqrt(np.einsum("ij,jk,ik->i", d, Sinv, d))
    limit = np.sqrt(stats.chi2.ppf(0.99, df=X_ref.shape[1]))
    return dist, limit

dist, limit = mahalanobis(X_healthy, X_new)
alarms = dist > limit
```

**Practical note.** The covariance must be estimated on genuinely healthy, representative data, and you need roughly ten or more samples per variable or the inverse is unstable; regularize, shrink, or use a robust covariance (MCD) for heavy tails and outliers in the reference set. The chi-square limit assumes approximate multivariate normality, so verify it or set the threshold empirically from a clean validation set.

**Reference.** Mahalanobis (1936), Proc. Natl. Inst. Sci. India 2; Rousseeuw & Van Zomeren (1990), JASA 85 (robust covariance).

## Independent component analysis (ICA)

**Essence.** Separates statistically independent sources from their mixtures. The right tool when a fault arrives mixed together with other signals at a shared sensor.

**In plain words.** PCA finds uncorrelated, orthogonal directions ranked by variance. ICA instead finds directions that are statistically independent, which need not be orthogonal, by pushing the recovered signals as far from Gaussian as possible. The payoff is source separation: when one sensor records a sum of several physical processes, ICA can pull them apart into their underlying generators. In monitoring it is used both to unmix overlapping fault signatures and as a feature step before the same T² and Q machinery, since a fault often lives in one independent component rather than one raw channel.

**Diagnostic example.** A single accelerometer on a gearbox hears two tones at once: a healthy meshing vibration and a faint bearing defect tone. They overlap in the raw spectrum. ICA across a few accelerometers separates the two independent sources, and the bearing component, once isolated, shows the rising amplitude that the mixed signal hid.

**Engine call.** `ica_sources(X, n_components)`

```python
import numpy as np
from sklearn.decomposition import FastICA

ica = FastICA(n_components=3, whiten="unit-variance",
              max_iter=1000, random_state=0).fit(X_obs)
sources = ica.transform(X_obs)   # recovered independent signals
mixing  = ica.mixing_            # how sources combine into sensors
# monitor the most fault-sensitive source as its own signal
track = sources[:, 0]
```

**Practical note.** ICA needs non-Gaussian sources; it cannot separate Gaussian mixtures, and it fixes neither the order nor the sign or scale of the recovered sources, so label them by inspection or by correlation to known references. Whiten first (FastICA does this internally), and never feed it more components than sensors. It is sensitive to strong noise, so denoise or band-limit before unmixing.

**Reference.** Hyvarinen & Oja (2000), Neural Networks 13 (FastICA); Lee et al. (2004), J. Process Control 14 (ICA monitoring).
