# Supervised, with a fault label in hand

_When historical data is labeled by quality outcome or fault class, supervised projections beat unsupervised ones: they aim the model at the distinction you actually care about._

## PLS and discriminant PLS (PLS-DA)

**Essence.** The supervised counterpart to PCA. It builds latent directions that covary with a quality or fault label, so it separates classes the unsupervised subspace may blur.

**In plain words.** PCA chooses directions by variance alone, indifferent to any label. Partial least squares instead chooses latent directions that maximize covariance between the inputs and a target. With a continuous target it is a regression; with a class label coded as an indicator it becomes discriminant PLS, a classifier. Because it leans toward the label, PLS often needs fewer components than PCA to expose a fault, and its VIP score, variable importance in projection, ranks how much each sensor contributes, which doubles as fault localization.

**Diagnostic example.** You have runs labeled healthy or degraded. The degradation is spread thinly across several sensors, so it hides below the dominant load variation that PCA's first components capture. PLS-DA finds the latent direction that tracks the label and cleanly separates the two groups, and its VIP scores flag the three sensors carrying the fault signature.

**Engine call.** `pls_da(X, y, n_components)`

```python
import numpy as np
from sklearn.cross_decomposition import PLSRegression

Y = (y == 1).astype(float)[:, None]                 # fault = 1
pls = PLSRegression(n_components=2, scale=True).fit(X, Y)
T = pls.x_scores_                                   # latent scores
pred = (pls.predict(X)[:, 0] > 0.5).astype(int)
# VIP score per variable (importance in the projection)
W, Q = pls.x_weights_, pls.y_loadings_
ss = (T**2).sum(0) * (Q**2).sum(0); p = X.shape[1]
vip = np.sqrt(p * ((ss * (W/np.linalg.norm(W,axis=0))**2).sum(1)) / ss.sum())
```

**Practical note.** Pick the number of latent variables by cross-validation, not by eye, and beware that PLS-DA on a label will manufacture apparent separation even from noise if components are overfit, so always validate on held-out runs and, with imbalanced classes, on a permutation test. VIP above one is the usual relevance cutoff but is a heuristic. Scale the inputs.

**Reference.** Wold, Sjostrom & Eriksson (2001), Chemom. Intell. Lab. Syst. 58; Barker & Rayens (2003), J. Chemometrics 17 (PLS-DA).

## Linear and quadratic discriminant analysis (LDA / QDA)

**Essence.** Probabilistic classifiers for known, labeled fault classes. LDA assumes one shared covariance and draws straight boundaries; QDA fits a covariance per class and draws curved ones.

**In plain words.** When the fault modes are known and you have labeled examples of each, discriminant analysis models every class as a Gaussian and assigns a new sample to the most probable one. LDA ties all classes to a single shared covariance, which yields linear decision boundaries and very few parameters, so it is stable on small data. QDA gives each class its own covariance, which yields quadratic boundaries that fit classes of different shape or spread, at the cost of estimating far more parameters and a real risk of overfitting when classes are small. LDA also doubles as a supervised dimensionality reduction that maximizes between-class separation.

**Diagnostic example.** A pump has three labeled states: healthy, cavitation, and bearing wear. Their feature clouds have different shapes, cavitation being far more spread out. LDA's shared-covariance boundary clips part of the cavitation class; QDA's per-class covariance wraps each cloud correctly and recovers the misclassified runs, because here the extra parameters are justified by enough labeled data.

**Engine call.** `lda_qda(X, y, kind='lda'|'qda')`

```python
from sklearn.discriminant_analysis import (
    LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis)

lda = LinearDiscriminantAnalysis().fit(X, y)
qda = QuadraticDiscriminantAnalysis().fit(X, y)
print("LDA acc", lda.score(X, y), " QDA acc", qda.score(X, y))
# LDA as supervised projection that maximizes class separation
X_lda = LinearDiscriminantAnalysis(n_components=2).fit_transform(X, y)
```

**Practical note.** LDA's shared-covariance assumption is also its strength: it is stable when classes are small or unequal. Switch to QDA only when you have enough labeled samples per class to estimate a separate covariance each, otherwise QDA overfits. Both assume Gaussian classes; strongly non-Gaussian or multi-modal classes need a different classifier. Always report cross-validated, not resubstitution, accuracy.

**Reference.** Fisher (1936), Annals of Eugenics 7; Hastie, Tibshirani & Friedman (2009), Elements of Statistical Learning, ch. 4.
