# Relating two blocks of variables

_Sometimes the question is not whether one cloud is normal, but how one set of variables relates to another: commands to responses, inputs to outputs._

## Canonical correlation analysis (CCA)

**Essence.** Finds the linear combination of one variable block that correlates most strongly with a combination of another. Natural for relating an actuator or command block to a response block.

**In plain words.** Given two groups of variables measured on the same samples, CCA looks for one weighted mixture from each group such that the two mixtures correlate as highly as possible, then a second orthogonal pair, and so on. Each pair is a canonical mode, and its canonical correlation says how tightly that input combination is tied to that output combination. It generalizes ordinary correlation from two scalars to two vectors, and it answers a question single correlations cannot: which combined drive mode explains which combined response mode.

**Diagnostic example.** On the command side you have throttle, gear, and steering; on the response side, three accelerations. CCA reveals that one weighted blend of commands explains almost all of one blend of responses, with canonical correlation near one. A new operating regime where that canonical correlation collapses signals that the command-to-response coupling has changed, often an early sign of an actuator or linkage fault.

**Engine call.** `cca_fit(X_block, Y_block)`

```python
import numpy as np
from sklearn.cross_decomposition import CCA

cca = CCA(n_components=2, scale=True).fit(X_cmd, Y_resp)
U, V = cca.transform(X_cmd, Y_resp)        # canonical variates
corrs = [np.corrcoef(U[:, i], V[:, i])[0, 1] for i in range(2)]
# a drop in the leading canonical correlation flags decoupling
print("canonical correlations:", np.round(corrs, 2))
```

**Practical note.** Canonical correlations are optimistically high when either block has many variables relative to the sample count, so regularize (regularized or sparse CCA) or reduce dimension first, and validate the correlations on held-out data. Scale both blocks. Interpret the weight vectors with care, since correlated variables within a block share and trade weight.

**Reference.** Hotelling (1936), Biometrika 28; Hardoon, Szedmak & Shawe-Taylor (2004), Neural Computation 16.
