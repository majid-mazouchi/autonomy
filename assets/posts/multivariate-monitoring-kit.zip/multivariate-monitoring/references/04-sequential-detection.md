# Sequential detection

A control limit judges one sample in isolation. A developing fault is a
sequence, and a small persistent shift can sit under the limit for a long time.
Accumulate evidence across samples instead.

## EWMA and CUSUM
`ewma(stat, lam, L, center, sd)` smooths a statistic stream so a small sustained
shift compounds into a clear alarm. `cusum(stat, k, h, center, sd)` adds up small
deviations until they cross a bound. Both detect small drifts far sooner than a
raw limit, and are slower on large sudden jumps.

```python
from multivariate_monitoring import PCAMonitor, ewma
mon = PCAMonitor().fit(X_healthy)
qref = mon.q(X_healthy)                       # phase-I reference
ew = ewma(mon.q(stream), lam=0.1, L=3.0,
          center=qref.mean(), sd=qref.std())  # limits from healthy phase
alarms = ew["ewma"] > ew["limit"]
```

## Practical
Set the reference from a clean healthy phase, never from the stream being
watched. Tune the memory to the drift you fear: small lambda for slow faults.
Judge alarms by run length, and report in-control and post-shift average run
length when you set a limit. The Tennessee Eastman Process is the canonical
public benchmark for these schemes.

## Reference
Page (1954), Biometrika 41; Roberts (1959), Technometrics 1; Downs & Vogel
(1993), Comput. Chem. Eng. 17.
