# Worked case study: battery-pack sensor array

A synthetic but structured cell-group cooling fault that slowly decouples one
temperature sensor, taken through the monitoring stack on a 300-sample
record of 8 channels. All numbers are produced by the engine.

## Step 1 - fit the healthy model
PCA on the clean reference keeps 2 components (95% of variance).
Control limits: T-squared 9.3, Q 1.50. New data is only scored, never refit.

## Step 2 - detect
Healthy Q false-alarm rate 0% (expected at the 99% limit). During the fault,
Q breaches on 73% of samples while T-squared stays calm: the readings are each
individually plausible but their joint correlation has broken. T-squared-quiet, Q-loud is the
signature of a new pattern, not a larger version of an old one.

## Step 3 - localize
The Q contribution plot on the worst sample puts 82% of the residual
on a single channel, T_cell3, the decoupled sensor. Neighbours pick up a little
blame because they correlate with it; contributions are leads, not proof.

## Step 4 - cross-check and classify
Mahalanobis distance reads 22 vs a limit of 4.5, confirming the
fault without PCA's rank assumptions. With the fault labeled, PLS-DA separates at
88% with top VIP T_cell3, and LDA classifies at 88%.

## Verdict
Unsupervised PCA caught a fault no single-channel limit would flag, Q localized it,
Mahalanobis confirmed it independently, and the supervised tools separated and re-identified
the culprit once labeled. The reflex order: scale, fit on healthy, watch T-squared and Q,
read contributions to localize, then confirm and classify.
