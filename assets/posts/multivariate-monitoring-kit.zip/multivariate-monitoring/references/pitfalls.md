# Pitfalls and assumptions

Read before presenting any single statistic as a verdict.

## PCA with Hotelling's T² and the SPE / Q statistic

Always scale to unit variance first, or the largest-range sensor dominates the components. Choose the rank from a scree plot or cumulative variance, not reflexively at 95%. Recompute limits on a held-out healthy set, since in-sample limits are optimistic. Watch T² and Q together: T² alone misses new patterns, Q alone misses extreme but in-pattern excursions. Contribution plots indicate, they do not prove, since a fault smears across correlated sensors.

## Mahalanobis distance

The covariance must be estimated on genuinely healthy, representative data, and you need roughly ten or more samples per variable or the inverse is unstable; regularize, shrink, or use a robust covariance (MCD) for heavy tails and outliers in the reference set. The chi-square limit assumes approximate multivariate normality, so verify it or set the threshold empirically from a clean validation set.

## Independent component analysis (ICA)

ICA needs non-Gaussian sources; it cannot separate Gaussian mixtures, and it fixes neither the order nor the sign or scale of the recovered sources, so label them by inspection or by correlation to known references. Whiten first (FastICA does this internally), and never feed it more components than sensors. It is sensitive to strong noise, so denoise or band-limit before unmixing.

## Canonical correlation analysis (CCA)

Canonical correlations are optimistically high when either block has many variables relative to the sample count, so regularize (regularized or sparse CCA) or reduce dimension first, and validate the correlations on held-out data. Scale both blocks. Interpret the weight vectors with care, since correlated variables within a block share and trade weight.

## PLS and discriminant PLS (PLS-DA)

Pick the number of latent variables by cross-validation, not by eye, and beware that PLS-DA on a label will manufacture apparent separation even from noise if components are overfit, so always validate on held-out runs and, with imbalanced classes, on a permutation test. VIP above one is the usual relevance cutoff but is a heuristic. Scale the inputs.

## Linear and quadratic discriminant analysis (LDA / QDA)

LDA's shared-covariance assumption is also its strength: it is stable when classes are small or unequal. Switch to QDA only when you have enough labeled samples per class to estimate a separate covariance each, otherwise QDA overfits. Both assume Gaussian classes; strongly non-Gaussian or multi-modal classes need a different classifier. Always report cross-validated, not resubstitution, accuracy.
