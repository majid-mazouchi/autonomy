# Extensions: learned monitors, diagnosis, prognosis

## When the healthy manifold curves
Linear PCA measures distance to a flat plane. For a curved healthy region, use a
learned one-class detector. `learned_monitor(X_healthy, X_new, method)` wraps
isolation forest or one-class SVM; `kpca_spe` is kernel-PCA reconstruction error.

```python
from multivariate_monitoring import learned_monitor
score = learned_monitor(X_healthy, X_new, method="iforest")["score"]
```

Use these only when linear PCA visibly fails. They need more data and tuning and
give no clean contribution plot.

## Diagnosis: reconstruction-based contributions
Plain contributions smear blame onto correlated neighbours. `rbc_q(monitor, x)`
asks how much Q would drop if each variable alone were corrected, isolating the
true culprit.

```python
from multivariate_monitoring import rbc_q
culprit = rbc_q(mon, x_fault).argmax()
```

## Running through a sensor dropout
`reconstruct_missing(monitor, x, missing_idx)` fills a failed sensor from the rest
via the healthy correlation structure, so monitoring continues.

## Prognosis
A monotone-trending statistic (EWMA of Q) is a health index. Fit a trend and
extrapolate to the failure threshold for a remaining-useful-life estimate, then
hand off to a dedicated prognostics model with uncertainty bands. Verify the
statistic trends with damage on run-to-failure data first, and report an interval.

## Reference
Scholkopf et al. (2001), Neural Computation 13; Liu, Ting & Zhou (2008), ICDM;
Alcala & Qin (2009), Automatica 45; Nelson, Taylor & MacGregor (1996), Chemom.
Intell. Lab. Syst. 35; Lee et al. (2014), Mech. Syst. Signal Process. 42.
