# Operating modes and autocorrelation

The two assumptions most quietly violated on a real fleet: one operating regime,
and independent samples.

## Mode-aware monitoring
A single global model false-alarms the moment the system enters a healthy but
different regime. `MultiModeMonitor` clusters the healthy data into modes, fits a
PCAMonitor per mode, and scores each sample against its own mode.

```python
from multivariate_monitoring import MultiModeMonitor
mm = MultiModeMonitor(n_modes=3, var_explained=0.9).fit(X_healthy)
alarms = mm.q(X_new) > mm.q_limit(X_new)
```

Detect the mode from trusted operating variables (load, speed, setpoint), not the
monitored sensors. Keep a dwell time to avoid thrashing at transitions. Recursive
or moving-window PCA handles slow drift, but cap the adaptation rate so it cannot
learn a fault as normal.

## Dynamic PCA
Autocorrelated samples make the monitoring statistic autocorrelated, so alarms
cluster and the i.i.d.-based limit is wrong. `time_lag_embed(X, lags)` stacks each
sample with its recent past before PCA, restoring independence.

```python
from multivariate_monitoring import time_lag_embed, PCAMonitor
Xd = time_lag_embed(X, lags=2)
mon = PCAMonitor(var_explained=0.95).fit(Xd)
```

Choose lags from the residual autocorrelation (usually one or two); guard the
sample-to-variable ratio; set limits empirically when in doubt.

## Reference
Hwang & Han (1999), Control Eng. Practice 7; Ku, Storer & Georgakis (1995),
Chemom. Intell. Lab. Syst. 30.
