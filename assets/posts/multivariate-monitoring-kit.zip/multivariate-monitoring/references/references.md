# References

- Jackson & Mudholkar (1979), Technometrics 21; Wise & Gallagher (1996), J. Process Control 6; Qin (2003), J. Chemometrics 17.
- Mahalanobis (1936), Proc. Natl. Inst. Sci. India 2; Rousseeuw & Van Zomeren (1990), JASA 85 (robust covariance).
- Hyvarinen & Oja (2000), Neural Networks 13 (FastICA); Lee et al. (2004), J. Process Control 14 (ICA monitoring).
- Hotelling (1936), Biometrika 28; Hardoon, Szedmak & Shawe-Taylor (2004), Neural Computation 16.
- Wold, Sjostrom & Eriksson (2001), Chemom. Intell. Lab. Syst. 58; Barker & Rayens (2003), J. Chemometrics 17 (PLS-DA).
- Fisher (1936), Annals of Eugenics 7; Hastie, Tibshirani & Friedman (2009), Elements of Statistical Learning, ch. 4.