# The six at a glance

| Method | Needs labels | Nonlinearity | Output | Limit | Cost |
| --- | --- | --- | --- | --- | --- |
| PCA T2/Q | no | linear (kernel for curved) | two statistics + contributions | F-dist, Jackson-Mudholkar | low |
| Mahalanobis | no | covariance only | distance | chi-square | low |
| ICA | no | non-Gaussian sources | independent components | monitor a component | medium |
| CCA | no (two blocks) | linear | canonical correlations | permutation / F | low |
| PLS-DA | yes | mostly linear | latent scores + VIP | cross-validated | medium |
| LDA/QDA | yes | LDA linear, QDA curved | class + posterior | Gaussian posterior | low |

## Which statistic catches which fault
| Fault | Signature | Caught by |
| --- | --- | --- |
| Sensor bias | one channel offset | Q + contribution; Mahalanobis |
| Slow drift | small persistent climb | EWMA / CUSUM of Q |
| Stuck-at / flatline | variance collapse | Q + contribution |
| Gain change | amplitude scales | T2 if in-pattern, Q if it breaks correlation |
| Two-sensor decoupling | joint pattern broken | Q + contribution; Mahalanobis |
| Multivariate mean shift | operating point moves | T2 |
| New healthy mode | whole cloud relocates | mode-aware monitoring |
