---
name: multivariate-monitoring
description: >-
  Choose and apply the right multivariate method for system health management:
  PCA with Hotelling T-squared and the SPE/Q statistic plus contribution plots,
  PLS discriminant analysis, canonical correlation analysis, independent
  component analysis, Mahalanobis distance, and linear or quadratic discriminant
  analysis. Use when the task is to decide whether a multi-sensor sample is still
  in the healthy pattern, localize which channel broke it, relate a command block
  to a response block, separate mixed sources, or classify known fault modes, and
  to generate correct Python.
---

# Multivariate monitoring

A progressive-disclosure skill for watching many sensors at once and producing
verified Python. Read this file first, then open only the reference you need.

Overview
This skill organizes the multivariate monitoring workhorses by the question they
answer. Is a new multi-sensor sample still in the healthy pattern, and which
channel broke it. How does one block of variables relate to another. Given
labeled history, how do you separate or classify the fault. A tested engine
implements every method with numpy, scipy, and scikit-learn only.

When to use this skill
Use it whenever a diagnostics task spans many sensors: continuous fleet
monitoring, localizing an alarm to a channel, relating commands to responses,
unmixing overlapping fault signatures, or classifying known fault modes from
labeled data.

How to route a request
First decide what the user has and is asking, then open the matching reference.
1. Unlabeled monitoring, is it still normal and which channel: references/01-subspace-monitoring.md
2. Relate a command block to a response block: references/02-relating-blocks.md
3. Labeled history, separate or classify a fault: references/03-supervised-classification.md
Always consult references/decision-map.md to confirm the choice and
references/pitfalls.md before trusting a number.

Reference docs
- `references/01-subspace-monitoring.md` covers subspace monitoring, the workhorse.
- `references/02-relating-blocks.md` covers relating two blocks of variables.
- `references/03-supervised-classification.md` covers supervised, with a fault label in hand.
- `references/04-sequential-detection.md` adds EWMA and CUSUM run-length monitoring of the statistics.
- `references/05-non-stationary-and-dynamic.md` covers mode-aware monitoring and dynamic PCA for autocorrelated streams.
- `references/06-extensions-and-prognosis.md` covers learned one-class monitors, reconstruction-based diagnosis, sensor-dropout recovery, and the bridge to remaining-useful-life.
- `references/07-at-a-glance.md` is the comparison table and the fault-to-method matrix.
- `references/decision-map.md` maps every question to its method and the escalation order.
- `references/rules-of-thumb.md` gives general heuristics and a scenario table.
- `references/case-study.md` runs the whole stack on one fault, a worked example.
- `references/pitfalls.md` lists the assumptions and failure modes.
- `references/references.md` is the bibliography.

Engine
scripts/multivariate_monitoring.py is the single source of truth. Import the
named class or function from each reference. Run it directly for a self-test:

    python scripts/multivariate_monitoring.py

Core functionalities
Fit a PCA monitor on healthy data and score new samples with Hotelling T-squared
and the SPE/Q statistic, with control limits and per-variable contributions to
localize a fault. Score covariance-aware outliers with Mahalanobis distance.
Separate mixed sources with ICA. Relate two variable blocks with CCA. With a
label, separate subtle faults with PLS-DA and its VIP scores, and classify known
modes with LDA or QDA. For the time dimension, run EWMA or CUSUM on a statistic;
for multi-regime fleets, MultiModeMonitor; for autocorrelated streams,
time_lag_embed (dynamic PCA); for curved manifolds, learned_monitor and kpca_spe;
for diagnosis, rbc_q; and reconstruct_missing to run through a sensor dropout.

Inputs
A samples-by-sensors matrix and a healthy reference period for monitoring; two
aligned blocks for CCA; a label vector for the supervised methods.

Outputs
Statistics against control limits, per-variable contributions or VIP scores,
canonical correlations, recovered sources, or class predictions.

Conventions for generated answers
Scale to unit variance and fit limits on healthy data only. Report T-squared and
Q as a pair. Treat contributions and VIP as leads, not proof. Prefer labeled
methods when a label exists, and validate out of sample. State the assumption
that would change the conclusion next to any reported value.

Assets
assets/multivariate-monitoring.html is the full illustrated monograph, with a
figure, worked example, two interactive explorers, and an end-to-end case study.
