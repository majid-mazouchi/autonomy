# Multivariate monitoring kit

A VS Code Copilot skill for multivariate system health monitoring, in the
progressive-disclosure layout. Read `SKILL.md` first; it routes to the rest.

## Layout
- `SKILL.md` routing and overview.
- `references/01-subspace-monitoring.md` covers subspace monitoring, the workhorse.
- `references/02-relating-blocks.md` covers relating two blocks of variables.
- `references/03-supervised-classification.md` covers supervised, with a fault label in hand.
- `references/decision-map.md`, `references/rules-of-thumb.md`, `references/pitfalls.md`, `references/case-study.md`, `references/references.md`.
- `scripts/multivariate_monitoring.py` the tested engine (numpy, scipy, scikit-learn only). Run it for a self-test:

      python scripts/multivariate_monitoring.py

- `copilot/` a monitoring-analyst chat mode, a `/monitor` prompt, and path-scoped instructions.
- `assets/multivariate-monitoring.html` the full illustrated monograph.
