---
mode: agent
description: 'Set up multivariate monitoring or classification for a health-management question, using the verified engine.'
tools: ['codebase', 'search', 'runCommands']
---

# /monitor

Pick and apply the right multivariate method for a system health management
question, then return runnable code from the project engine.

Inputs the user may give: the sensor matrix and a healthy reference period,
whether a fault or quality label exists, and the question (still normal? which
channel? which fault?). If any is missing, ask once, then proceed with a stated
assumption.

Steps:
1. Restate the question in one line and note whether labels are available.
2. Open `references/decision-map.md` and name the recommended method(s).
3. Open the relevant group reference for interpretation and caveats.
4. Produce the exact call into `scripts/multivariate_monitoring.py`, wired to the
   user's variable names, including scaling and limit checks.
5. State the result against its limit and the single assumption that would flip
   the conclusion. Cross-check against `references/pitfalls.md`.

The task to solve: ${input:question:Describe the sensors, any labels, and what you want to know}
