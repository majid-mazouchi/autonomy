---
applyTo: '**/*.py'
---

# Multivariate monitoring conventions

When writing code that monitors many sensors for diagnostics, follow these rules.

Use the project engine. Call the classes and functions in
`scripts/multivariate_monitoring.py` (`PCAMonitor`, `mahalanobis`, `ica_sources`,
`cca_fit`, `pls_da`, `lda_qda`) instead of re-implementing them.

Scale first, fit on healthy. Standardize every sensor to unit variance, fit the
model and its control limits on a clean reference period, and only ever score
new data.

Watch the pair. Report T-squared and Q together; note that T-squared catches
in-pattern excursions and Q catches new patterns, and that most faults trip Q.

Localize, then confirm. Use `q_contributions` to point at a channel, then
cross-check with `mahalanobis`, and comment that contributions smear across
correlated sensors.

Reach for labels when present. Prefer `pls_da` and `lda_qda` over unsupervised
methods when a quality or fault label exists, and validate out of sample rather
than on resubstitution.

Label assumptions in the code. Note scaling, the healthy-reference window, the
covariance sample-to-variable ratio, and any Gaussian assumption next to the call.
