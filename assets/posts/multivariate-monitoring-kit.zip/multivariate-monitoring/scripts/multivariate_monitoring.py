"""
Multivariate monitoring engine for system health management.

Purpose
One tested module behind the monograph and the Copilot kit. Implements the
process-monitoring workhorses: PCA with Hotelling T-squared and the SPE/Q
statistic plus contribution plots, PLS discriminant analysis, canonical
correlation analysis, independent component analysis, Mahalanobis distance,
and linear and quadratic discriminant analysis.

Dependencies
numpy, scipy, scikit-learn only.
"""
import numpy as np
from scipy import stats
from sklearn.cross_decomposition import PLSRegression, CCA
from sklearn.decomposition import FastICA
from sklearn.discriminant_analysis import (LinearDiscriminantAnalysis,
                                           QuadraticDiscriminantAnalysis)


# ===========================================================================
# PCA monitoring: Hotelling T-squared (in-model) + SPE/Q (residual) + limits
# ===========================================================================
class PCAMonitor:
    """
    Purpose
    Fit a PCA model on healthy data, then score new samples with two
    complementary statistics. T-squared measures distance inside the model
    subspace (unusual but in-pattern variation). Q, the squared prediction
    error, measures distance off the subspace (a new pattern the model never
    saw). Contributions decompose either statistic back onto raw variables to
    localize the offending sensor.

    Inputs
    n_components fixes the retained rank, or leave it None and var_explained
    chooses the smallest rank passing that cumulative variance. alpha is the
    confidence for the control limits.

    Outputs
    Fitted model exposing scores, t2, q, and the contribution methods, plus
    t2_limit_ and q_limit_ control limits.
    """

    def __init__(self, n_components=None, var_explained=0.90, alpha=0.99):
        self.n_components = n_components
        self.var_explained = var_explained
        self.alpha = alpha

    def fit(self, X):
        X = np.asarray(X, float)
        self.mean_ = X.mean(0)
        self.std_ = X.std(0, ddof=1)
        self.std_[self.std_ == 0] = 1.0
        Z = (X - self.mean_) / self.std_
        n, m = Z.shape
        U, s, Vt = np.linalg.svd(Z, full_matrices=False)
        eig = s ** 2 / (n - 1)
        if self.n_components is None:
            ratio = np.cumsum(eig) / eig.sum()
            k = int(np.searchsorted(ratio, self.var_explained) + 1)
            k = max(1, min(k, m - 1))
        else:
            k = self.n_components
        self.k_ = k
        self.P_ = Vt[:k].T          # loadings, m x k
        self.eig_ = eig[:k]
        self.eig_resid_ = eig[k:]
        # Hotelling T-squared limit via the F distribution
        self.t2_limit_ = (k * (n - 1) * (n + 1) / (n * (n - k)) *
                          stats.f.ppf(self.alpha, k, n - k))
        # Q (SPE) limit via the Jackson-Mudholkar approximation
        t1 = self.eig_resid_.sum()
        t2 = (self.eig_resid_ ** 2).sum()
        t3 = (self.eig_resid_ ** 3).sum()
        if t1 > 0 and t2 > 0:
            h0 = 1 - 2 * t1 * t3 / (3 * t2 ** 2)
            ca = stats.norm.ppf(self.alpha)
            self.q_limit_ = t1 * (ca * np.sqrt(2 * t2 * h0 ** 2) / t1 +
                                  1 + t2 * h0 * (h0 - 1) / t1 ** 2) ** (1 / h0)
        else:
            self.q_limit_ = 0.0
        return self

    def _z(self, X):
        return (np.atleast_2d(np.asarray(X, float)) - self.mean_) / self.std_

    def scores(self, X):
        return self._z(X) @ self.P_

    def t2(self, X):
        T = self.scores(X)
        return np.sum(T ** 2 / self.eig_, axis=1)

    def residuals(self, X):
        Z = self._z(X)
        return Z - Z @ self.P_ @ self.P_.T

    def q(self, X):
        E = self.residuals(X)
        return np.sum(E ** 2, axis=1)

    def t2_contributions(self, x):
        """Per-variable contribution to a sample's T-squared."""
        z = self._z(x)[0]
        t = z @ self.P_
        return z * (self.P_ @ (t / self.eig_))

    def q_contributions(self, x):
        """Per-variable contribution to a sample's Q (squared residual)."""
        return self.residuals(x)[0] ** 2


# ===========================================================================
# PLS discriminant analysis (supervised: regress against a fault label)
# ===========================================================================
def pls_da(X, y, n_components=2):
    """
    Purpose
    Supervised projection when a quality or fault label exists. PLS finds
    latent directions that covary with the label, not merely with the inputs,
    so it separates classes the unsupervised PCA subspace may blur.

    Inputs
    X is samples by features, y is a binary or class label, n_components is the
    number of latent variables.

    Outputs
    Dict with the fitted model, the latent scores, predicted labels, and VIP
    scores ranking each variable's contribution.
    """
    X = np.asarray(X, float)
    y = np.asarray(y)
    classes = np.unique(y)
    Y = (y[:, None] == classes[None, :]).astype(float) if len(classes) > 2 \
        else (y == classes[-1]).astype(float)[:, None]
    model = PLSRegression(n_components=n_components, scale=True).fit(X, Y)
    T = model.x_scores_
    W = model.x_weights_
    Q = model.y_loadings_
    ss = np.sum(T ** 2, axis=0) * np.sum(Q ** 2, axis=0)
    p = X.shape[1]
    vip = np.sqrt(p * np.sum(ss * (W / np.linalg.norm(W, axis=0)) ** 2, axis=1) / ss.sum())
    pred = classes[np.argmax(model.predict(X), axis=1)] if len(classes) > 2 \
        else np.where(model.predict(X)[:, 0] > 0.5, classes[-1], classes[0])
    return dict(model=model, scores=T, vip=vip, pred=pred, classes=classes)


# ===========================================================================
# Canonical correlation analysis (relate two variable blocks)
# ===========================================================================
def cca_fit(X, Y, n_components=2):
    """
    Purpose
    Find pairs of linear combinations, one from each block, that are maximally
    correlated. Natural for relating an actuator or command block to a response
    block: it reveals which combined input mode drives which combined output.

    Inputs
    X and Y are two sample-aligned blocks of variables.

    Outputs
    Dict with the canonical correlations and the two sets of scores.
    """
    X = np.asarray(X, float)
    Y = np.asarray(Y, float)
    n_components = min(n_components, X.shape[1], Y.shape[1])
    cca = CCA(n_components=n_components, scale=True).fit(X, Y)
    U, V = cca.transform(X, Y)
    corrs = np.array([np.corrcoef(U[:, i], V[:, i])[0, 1]
                      for i in range(n_components)])
    return dict(model=cca, corrs=corrs, u=U, v=V)


# ===========================================================================
# Independent component analysis (separate mixed sources)
# ===========================================================================
def ica_sources(X, n_components=None, seed=0):
    """
    Purpose
    Recover statistically independent source signals from observed mixtures.
    Useful when a fault shows up only as a mixed signal, for example several
    vibration sources summed at one accelerometer.

    Inputs
    X is samples by sensors, n_components is the number of sources to recover.

    Outputs
    Dict with the recovered sources and the estimated mixing matrix.
    """
    X = np.asarray(X, float)
    n_components = n_components or X.shape[1]
    ica = FastICA(n_components=n_components, random_state=seed,
                  max_iter=1000, whiten="unit-variance").fit(X)
    return dict(model=ica, sources=ica.transform(X), mixing=ica.mixing_)


# ===========================================================================
# Mahalanobis distance (covariance-aware outlier metric)
# ===========================================================================
def mahalanobis(X_ref, x, ridge=1e-9):
    """
    Purpose
    The covariance-aware generalization of the z-score. It rescales by the
    healthy covariance so a point that looks ordinary on each axis but violates
    the joint correlation is still flagged.

    Inputs
    X_ref is the healthy reference set, x is one sample or a batch.

    Outputs
    Mahalanobis distance per sample and the chi-square control limit (df equals
    the number of variables, alpha 0.99).
    """
    X_ref = np.asarray(X_ref, float)
    mu = X_ref.mean(0)
    S = np.cov(X_ref, rowvar=False)
    Sinv = np.linalg.pinv(S + ridge * np.eye(S.shape[0]))
    x = np.atleast_2d(np.asarray(x, float))
    d = x - mu
    dist = np.sqrt(np.einsum("ij,jk,ik->i", d, Sinv, d))
    limit = np.sqrt(stats.chi2.ppf(0.99, df=X_ref.shape[1]))
    return dict(distance=dist, limit=limit)


# ===========================================================================
# Linear and quadratic discriminant analysis (known fault classes)
# ===========================================================================
def lda_qda(X, y, kind="lda"):
    """
    Purpose
    Supervised classification when the fault classes are known and labeled.
    LDA assumes a shared covariance and yields linear boundaries; QDA fits a
    covariance per class and yields curved boundaries, at the cost of more
    parameters.

    Inputs
    X is samples by features, y is the class label, kind is lda or qda.

    Outputs
    Dict with the fitted classifier, predicted labels, and the resubstitution
    accuracy.
    """
    X = np.asarray(X, float)
    y = np.asarray(y)
    clf = (LinearDiscriminantAnalysis() if kind == "lda"
           else QuadraticDiscriminantAnalysis()).fit(X, y)
    pred = clf.predict(X)
    return dict(model=clf, pred=pred, accuracy=float((pred == y).mean()))


# ===========================================================================
# sequential detection: turn a per-sample statistic into a run-length monitor
# ===========================================================================
def ewma(stat, lam=0.2, L=3.0, center=None, sd=None):
    """
    Purpose
    Exponentially weighted moving average of a monitoring statistic, which
    accumulates evidence across samples and so catches small persistent shifts
    a per-sample limit walks straight past.

    Inputs
    stat is a 1-D stream (for example mon.q(stream)). lam is the memory (small
    means long memory), L is the limit width in sigma. center and sd fix the
    in-control reference from a healthy phase; if omitted they are estimated
    from stat (only valid when stat is itself in-control).

    Outputs
    Dict with the smoothed series, its steady-state control limit, and center.
    """
    s = np.asarray(stat, float)
    mu = s.mean() if center is None else center
    sg = (s.std() if sd is None else sd) + 1e-12
    z = np.empty_like(s)
    prev = mu
    for i, v in enumerate(s):
        prev = lam * v + (1 - lam) * prev
        z[i] = prev
    lim = mu + L * sg * np.sqrt(lam / (2 - lam))
    return dict(ewma=z, limit=lim, center=mu)


def cusum(stat, k=0.5, h=5.0, center=None, sd=None):
    """
    Purpose
    One-sided cumulative-sum control of a statistic, tuned to detect an upward
    shift of about 2k standard deviations as fast as possible.

    Inputs
    stat is a 1-D stream, k the allowance (half the target shift), h the limit.
    center and sd fix the in-control reference from a healthy phase.

    Outputs
    Dict with the running CUSUM and its limit.
    """
    s = np.asarray(stat, float)
    mu = s.mean() if center is None else center
    sg = (s.std() if sd is None else sd) + 1e-12
    z = (s - mu) / sg
    cp = np.zeros_like(z)
    c = 0.0
    for i, v in enumerate(z):
        c = max(0.0, c + v - k)
        cp[i] = c
    return dict(cusum=cp, limit=h)


# ===========================================================================
# mode-aware monitoring for non-stationary, multi-regime fleets
# ===========================================================================
class MultiModeMonitor:
    """
    Purpose
    A single global PCA model false-alarms whenever the system changes
    operating mode, since each mode has its own mean and covariance. This fits
    one PCAMonitor per discovered mode and scores each sample against its own
    mode, so a healthy mode change no longer trips the alarm.

    Inputs
    n_modes is how many operating regimes to cluster the healthy data into;
    remaining keyword arguments pass through to PCAMonitor.

    Outputs
    Fitted monitor exposing q and per-sample q_limit.
    """

    def __init__(self, n_modes=2, **kw):
        self.n_modes = n_modes
        self.kw = kw

    def fit(self, X):
        from sklearn.cluster import KMeans
        X = np.asarray(X, float)
        self.km_ = KMeans(self.n_modes, n_init=10, random_state=0).fit(X)
        self.models_ = [PCAMonitor(**self.kw).fit(X[self.km_.labels_ == c])
                        for c in range(self.n_modes)]
        return self

    def q(self, X):
        X = np.atleast_2d(np.asarray(X, float))
        lab = self.km_.predict(X)
        return np.array([self.models_[c].q(row)[0] for row, c in zip(X, lab)])

    def q_limit(self, X):
        lab = self.km_.predict(np.atleast_2d(np.asarray(X, float)))
        return np.array([self.models_[c].q_limit_ for c in lab])


# ===========================================================================
# dynamic monitoring: time-lag embedding for autocorrelated streams
# ===========================================================================
def time_lag_embed(X, lags=1):
    """
    Purpose
    Static PCA assumes independent samples; sensor streams are autocorrelated,
    which leaves the residual serially correlated and the limits wrong.
    Stacking each row with its recent past (dynamic PCA) lets the model absorb
    the temporal dynamics and whiten the residual.

    Inputs
    X is samples by sensors, lags is how many past steps to append.

    Outputs
    The embedded matrix, with lags fewer rows and (lags+1) times the columns.
    """
    X = np.atleast_2d(np.asarray(X, float))
    n = len(X)
    return np.hstack([X[lags - l:n - l] for l in range(lags + 1)])


# ===========================================================================
# diagnosis: reconstruction-based contributions, and missing-sensor recovery
# ===========================================================================
def rbc_q(monitor, x):
    """
    Purpose
    Plain Q contributions smear blame onto sensors merely correlated with the
    faulty one. Reconstruction-based contribution asks, for each variable, how
    much the Q statistic would drop if that variable were corrected, which
    isolates the true culprit far more cleanly.

    Inputs
    monitor is a fitted PCAMonitor, x is one sample.

    Outputs
    Per-variable reconstruction-based contribution to Q.
    """
    z = monitor._z(x)[0]
    C = np.eye(monitor.P_.shape[0]) - monitor.P_ @ monitor.P_.T
    den = np.diag(C)
    return (C @ z) ** 2 / np.where(den > 1e-12, den, 1.0)


def reconstruct_missing(monitor, x, missing_idx):
    """
    Purpose
    Estimate the value of one or more failed or dropped sensors from the rest,
    using the healthy PCA correlation structure. The same model that detects
    faults can fill a gap, which keeps a fleet monitor running through a sensor
    dropout.

    Inputs
    monitor is a fitted PCAMonitor, x the sample (missing entries ignored),
    missing_idx the indices to reconstruct.

    Outputs
    A copy of x with the missing entries replaced by their PCA estimate.
    """
    x = np.asarray(x, float).copy()
    z = (x - monitor.mean_) / monitor.std_
    known = [i for i in range(len(x)) if i not in missing_idx]
    t, *_ = np.linalg.lstsq(monitor.P_[known], z[known], rcond=None)
    zfull = monitor.P_ @ t
    for i in missing_idx:
        x[i] = zfull[i] * monitor.std_[i] + monitor.mean_[i]
    return x


# ===========================================================================
# learned relatives of the Q statistic (nonlinear / curved healthy manifolds)
# ===========================================================================
def learned_monitor(X_healthy, X_new, method="iforest", seed=0):
    """
    Purpose
    When the healthy region is curved, linear PCA's Q statistic measures
    distance to a flat plane and misfires. Learned one-class detectors model
    the curved support directly. These are the modern descendants of Q.

    Inputs
    X_healthy fits the model, X_new is scored. method is iforest or ocsvm.

    Outputs
    Dict with an anomaly score per new sample (higher is more anomalous).
    """
    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler().fit(X_healthy)
    Xh, Xn = sc.transform(X_healthy), sc.transform(np.atleast_2d(X_new))
    if method == "iforest":
        from sklearn.ensemble import IsolationForest
        m = IsolationForest(random_state=seed).fit(Xh)
        return dict(score=-m.score_samples(Xn), model=m, scaler=sc)
    from sklearn.svm import OneClassSVM
    m = OneClassSVM(nu=0.05, gamma="scale").fit(Xh)
    return dict(score=-m.decision_function(Xn), model=m, scaler=sc)


def kpca_spe(X_healthy, X_new, n_components=2, gamma=None):
    """
    Purpose
    Kernel PCA reconstruction error: the Q statistic computed in a nonlinear
    feature space, so the healthy manifold may curve.

    Inputs
    X_healthy fits, X_new is scored, n_components and gamma set the kernel PCA.

    Outputs
    Reconstruction error per new sample.
    """
    from sklearn.decomposition import KernelPCA
    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler().fit(X_healthy)
    Xh, Xn = sc.transform(X_healthy), sc.transform(np.atleast_2d(X_new))
    k = KernelPCA(n_components=n_components, kernel="rbf", gamma=gamma,
                  fit_inverse_transform=True).fit(Xh)
    rec = k.inverse_transform(k.transform(Xn))
    return np.sum((Xn - rec) ** 2, axis=1)


def _demo():
    rng = np.random.default_rng(0)
    # healthy correlated process, then a fault that breaks the correlation
    n, m = 300, 6
    L = rng.normal(0, 1, (n, 2))
    A = rng.normal(0, 1, (2, m))
    Xok = L @ A + 0.25 * rng.normal(0, 1, (n, m))
    mon = PCAMonitor(var_explained=0.9).fit(Xok)
    fault = Xok[:50].copy()
    fault[:, 3] += np.linspace(0, 6, 50)      # sensor 4 drifts
    print("PCA  k=%d  T2lim=%.1f  Qlim=%.1f" % (mon.k_, mon.t2_limit_, mon.q_limit_))
    print("     healthy Q exceed rate %.2f, fault Q exceed rate %.2f"
          % ((mon.q(Xok) > mon.q_limit_).mean(), (mon.q(fault) > mon.q_limit_).mean()))
    print("     top Q contributor on last fault sample: var",
          int(np.argmax(mon.q_contributions(fault[-1]))))
    y = np.r_[np.zeros(150), np.ones(150)].astype(int)
    Xc = Xok.copy(); Xc[150:, 0] += 2.5
    pls = pls_da(Xc, y); print("PLS-DA acc %.2f  top VIP var %d"
                               % ((pls["pred"] == y).mean(), int(np.argmax(pls["vip"]))))
    cc = cca_fit(Xok[:, :3], Xok[:, 3:]); print("CCA  canonical corrs", np.round(cc["corrs"], 2))
    ic = ica_sources(Xok[:, :3]); print("ICA  sources", ic["sources"].shape)
    mh = mahalanobis(Xok, fault[-1]); print("Maha dist %.1f  limit %.1f"
                                            % (mh["distance"][0], mh["limit"]))
    ld = lda_qda(Xc, y, "lda"); qd = lda_qda(Xc, y, "qda")
    print("LDA acc %.2f  QDA acc %.2f" % (ld["accuracy"], qd["accuracy"]))
    # advanced primitives
    qstream = mon.q(np.vstack([Xok, fault]))
    ew = ewma(qstream); cu = cusum(qstream)
    print("EWMA limit %.2f, CUSUM limit %.1f" % (ew["limit"], cu["limit"]))
    mm = MultiModeMonitor(n_modes=2, var_explained=0.9).fit(Xok)
    print("MultiMode q on 1 sample %.2f" % mm.q(Xok[0])[0])
    print("dynamic embed shape", time_lag_embed(Xok, 2).shape)
    print("RBC top var", int(np.argmax(rbc_q(mon, fault[-1]))))
    rec = reconstruct_missing(mon, Xok[0], [3])
    print("missing recon abs err %.2f" % abs(rec[3] - Xok[0, 3]))
    lm = learned_monitor(Xok, fault[-1:], "iforest")
    print("iforest score %.2f" % lm["score"][0])
    print("kpca spe %.2f" % kpca_spe(Xok, fault[-1:])[0])


if __name__ == "__main__":
    _demo()
