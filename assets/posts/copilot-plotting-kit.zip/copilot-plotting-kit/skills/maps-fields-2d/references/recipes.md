# Maps & Fields — Guidance

## Contour levels

- Efficiency: dense filled levels for the field; LABELED lines only at the
  business-relevant set (90/94/96/97%). The 97% island location is usually
  the message.
- Flux/loss: ~10–14 unlabeled fill levels + labeled lines every 2nd-3rd.
- NaN-mask everything outside the envelope (the synth demos show how);
  plotting into infeasible regions reads as a data error.

## Color normalization

- Efficiency maps: linear normalization clipped to [0.80, 0.985] —
  full [0,1] wastes the colormap on regions nobody operates in.
- Dwell density: LogNorm by default (dwell spans decades); say "(log)" in
  the colorbar label.
- Diverging CMAP_DIV only for deltas between two maps (cal A vs cal B),
  centered at zero.

## Envelope construction

Constant torque to base speed, constant power above:
t_env = min(T_max, P_max·60/(2π·n)). For measured envelopes, plot the
measured points and the fitted line both; calibration reviews ask.

## MTPA / MTPV overlays

- MTPA in the current plane: trajectory of (id, iq) minimizing current for
  each torque; on the torque-speed map it appears as the corner approach
  path. Label trajectories directly at the line end (house rule), not in
  the legend.
- When overlaying a measured drive cycle, decimate to ≤2k points and use
  alpha 0.5 ink scatter; size by dwell when dwell weights exist.

## 3D camera guidance (policy-permitted surfaces)

- Default view elev=24, azim=-118 puts the saturation droop of ψd toward
  the viewer for negative-id maps; adjust so the steepest gradient region
  is not self-occluded.
- Light edge lines (paper color, lw 0.15) read as a measurement grid —
  keep them; they signal native grid resolution honestly.
- The 2D contour twin is not optional. Reviewers measure on the twin.
