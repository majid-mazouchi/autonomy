"""efficiency_map.py — Torque-speed efficiency maps with trajectories."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, CMAP_SEQ, SIZES  # noqa: E402


def plot_efficiency_map(speed, torque, eff, envelope=None, trajectories=None,
                        op_points=None, title="", size="doc_full",
                        levels=(0.80, 0.86, 0.90, 0.93, 0.95, 0.96, 0.97)):
    """
    speed [rpm] 1D, torque [Nm] 1D, eff 2D [len(torque), len(speed)] in 0..1.
    envelope: (speed_env, torque_env) capability line.
    trajectories: dict {label: (speed_arr, torque_arr)} e.g. MTPA, drive cycle.
    op_points: (speed_pts, torque_pts[, dwell_weights]).
    """
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    cf = ax.contourf(speed, torque, eff, levels=np.linspace(min(min(levels), 0.70), 0.985, 26),
                     cmap=CMAP_SEQ)
    cs = ax.contour(speed, torque, eff, levels=levels,
                    colors=COLORS["ink_soft"], linewidths=0.7)
    ax.clabel(cs, fmt=lambda v: f"{v:.0%}", fontsize=8, inline=True)
    if envelope is not None:
        ax.plot(*envelope, color=COLORS["ink"], lw=2.0, label="Envelope")
    for (label, (s, tq)), c in zip((trajectories or {}).items(),
                                   [COLORS["crimson"], COLORS["orange"],
                                    COLORS["violet"]]):
        ax.plot(s, tq, color=c, lw=1.9)
        ax.text(s[-1], tq[-1], f" {label}", color=c, fontsize=9,
                fontweight="semibold", va="center")
    if op_points is not None:
        s, tq, *w = op_points
        sizes = 14 if not w else 8 + 60 * np.asarray(w[0]) / max(w[0])
        ax.scatter(s, tq, s=sizes, color=COLORS["ink"], alpha=0.55, lw=0,
                   label="Operating points", zorder=5)
    fig.colorbar(cf, ax=ax, label="Efficiency [-]", pad=0.01,
                 format=lambda v, _: f"{v:.0%}")
    ax.set_xlabel("Speed [rpm]"); ax.set_ylabel("Torque [Nm]")
    ax.set_title(title or "Efficiency map")
    if envelope is not None or op_points is not None:
        ax.legend(loc="upper right", fontsize=8.5)
    ax.grid(False)
    return fig, ax


def synth_pmsm_map(n_s=120, n_t=100, s_max=12000, t_max=320, s_base=5200):
    """
    Synthetic but physically-shaped PMSM efficiency map for demos:
    copper loss ~ T^2 (with field-weakening penalty above base speed),
    iron loss ~ w^1.6, windage ~ w^3, fixed inverter loss. Produces a
    realistic ~96-97% island at mid speed / mid-high torque.
    """
    s = np.linspace(100, s_max, n_s)
    tq = np.linspace(2, t_max, n_t)
    S, T = np.meshgrid(s, tq)
    w = S * 2 * np.pi / 60
    w_b = s_base * 2 * np.pi / 60
    fw = 1 + 1.6 * np.clip((w - w_b) / w_b, 0, None) ** 2
    p_mech = w * T
    p_cu = 0.040 * T**2 * fw
    p_fe = 0.090 * w**1.6
    p_wind = 3e-6 * w**3
    p_fix = 250.0
    eff = p_mech / (p_mech + p_cu + p_fe + p_wind + p_fix)
    # envelope: constant torque then constant power
    s_env = np.linspace(100, s_max, 200)
    t_env = np.minimum(t_max, t_max * s_base / np.maximum(s_env, s_base))
    eff = np.where(T <= np.interp(S, s_env, t_env), eff, np.nan)
    return s, tq, eff, (s_env, t_env)


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    s, tq, eff, env = synth_pmsm_map()
    rl_s = np.linspace(400, 9500, 80)
    road_load = {"Road load": (rl_s, 18 + 1.6e-6 * rl_s**2)}
    ops = (rng.uniform(800, 9000, 90), rng.uniform(10, 180, 90),
           rng.gamma(2, 1, 90))
    fig, _ = plot_efficiency_map(s, tq, eff, envelope=env, trajectories=road_load,
                                 op_points=ops,
                                 title="Demo — PMSM efficiency map with cycle points")
    print("Wrote", save_fig(fig, "/tmp/map_eff", "quick"))
