"""flux_maps.py — Flux map surfaces (policy-compliant 3D) and contour twins."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, CMAP_SEQ, SIZES  # noqa: E402


def plot_flux_surface(id_a, iq_a, psi, name="ψd", title="", size="doc_tall",
                      elev=24, azim=-118):
    """
    3D surface with contour floor — the policy-permitted 3D form.
    id_a, iq_a: 1D current axes [A]; psi: 2D [len(iq), len(id)] [Wb/Vs].
    Ship the contour twin (plot_flux_contour) alongside, always.
    """
    ID, IQ = np.meshgrid(id_a, iq_a)
    fig = plt.figure(figsize=SIZES[size], constrained_layout=True)
    ax = fig.add_subplot(projection="3d")
    ax.plot_surface(ID, IQ, psi, cmap=CMAP_SEQ, rstride=1, cstride=1,
                    lw=0.15, edgecolor=COLORS["paper"], antialiased=True,
                    alpha=0.96)
    zfloor = np.nanmin(psi) - 0.12 * (np.nanmax(psi) - np.nanmin(psi))
    ax.contour(ID, IQ, psi, levels=10, zdir="z", offset=zfloor,
               cmap=CMAP_SEQ, linewidths=1)
    ax.set_zlim(zfloor, np.nanmax(psi))
    ax.view_init(elev=elev, azim=azim)
    ax.set_xlabel("i_d [A]"); ax.set_ylabel("i_q [A]")
    ax.set_zlabel(f"{name} [Vs]")
    ax.set_title(title or f"{name} flux map")
    ax.xaxis.pane.set_facecolor(COLORS["cream"])
    ax.yaxis.pane.set_facecolor(COLORS["cream"])
    ax.zaxis.pane.set_facecolor(COLORS["paper"])
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.pane.set_edgecolor(COLORS["grid"])
    ax.grid(False)
    return fig, ax


def plot_flux_contour(id_a, iq_a, psi, name="ψd", title="", size="doc_half",
                      n_levels=12):
    """Mandatory 2D twin of the surface — same data, same colormap."""
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    cf = ax.contourf(id_a, iq_a, psi, levels=n_levels, cmap=CMAP_SEQ)
    cs = ax.contour(id_a, iq_a, psi, levels=n_levels,
                    colors=COLORS["ink_soft"], linewidths=0.6)
    ax.clabel(cs, fontsize=7.5, inline=True, fmt="%.3f")
    fig.colorbar(cf, ax=ax, label=f"{name} [Vs]", pad=0.02)
    ax.set_xlabel("i_d [A]"); ax.set_ylabel("i_q [A]")
    ax.set_title(title or f"{name} — contour twin")
    ax.grid(False)
    return fig, ax


def synth_flux_map(n=60, i_max=400, psi_pm=0.085, ld0=2.9e-4, lq0=6.1e-4):
    """Synthetic IPM ψd map with saturation + cross-coupling for demos."""
    id_a = np.linspace(-i_max, 0, n)
    iq_a = np.linspace(0, i_max, n)
    ID, IQ = np.meshgrid(id_a, iq_a)
    sat_d = 1 / (1 + (np.abs(ID) / 320) ** 2.2)
    cross = 1 / (1 + (IQ / 480) ** 2)
    psi_d = psi_pm + ld0 * ID * sat_d * (0.75 + 0.25 * cross)
    return id_a, iq_a, psi_d


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    id_a, iq_a, psi_d = synth_flux_map()
    fig, _ = plot_flux_surface(id_a, iq_a, psi_d,
                               title="Demo — ψd(i_d, i_q) with saturation")
    print("Wrote", save_fig(fig, "/tmp/map_flux3d", "quick"))
    fig, _ = plot_flux_contour(id_a, iq_a, psi_d)
    print("Wrote", save_fig(fig, "/tmp/map_flux2d", "quick"))
