"""dwell_density.py — Operating-point dwell density over the torque-speed plane."""
import sys
from pathlib import Path

import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, CMAP_SEQ, SIZES  # noqa: E402


def plot_dwell_hexbin(speed, torque, envelope=None, title="",
                      size="doc_full", gridsize=46, log=True,
                      highlight_gap=None):
    """
    speed, torque: per-sample operating points (fleet or cycle data).
    envelope: (s_env, t_env) capability line — shows coverage vs capability.
    highlight_gap: (s0,s1,t0,t1) box marking an untested region.
    """
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    hb = ax.hexbin(speed, torque, gridsize=gridsize, cmap=CMAP_SEQ,
                   norm=mcolors.LogNorm() if log else None,
                   mincnt=1, linewidths=0.2, edgecolors=COLORS["paper"])
    if envelope is not None:
        ax.plot(*envelope, color=COLORS["ink"], lw=2.0, label="Envelope")
        ax.legend(loc="upper right", fontsize=8.5)
    if highlight_gap:
        s0, s1, t0, t1 = highlight_gap
        ax.add_patch(plt.Rectangle((s0, t0), s1 - s0, t1 - t0, fill=False,
                                   ec=COLORS["fail"], lw=1.6, ls="--"))
        ax.text(s0, t1, " coverage gap", color=COLORS["fail"], fontsize=9,
                fontweight="semibold", va="bottom")
    fig.colorbar(hb, ax=ax, label="Dwell [samples]" + (" (log)" if log else ""),
                 pad=0.01)
    ax.set_xlabel("Speed [rpm]"); ax.set_ylabel("Torque [Nm]")
    ax.set_title(title or "Operating-point dwell density")
    ax.grid(False)
    return fig, ax


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    n = 80_000
    speed = np.abs(rng.normal(3200, 1600, n)) + rng.uniform(0, 2500, n)
    torque = np.abs(rng.normal(60, 45, n)) * (1 - speed / 26000)
    s_env = np.linspace(100, 12000, 200)
    t_env = np.minimum(320, 320 * 5200 / np.maximum(s_env, 5200))
    fig, _ = plot_dwell_hexbin(speed, torque, envelope=(s_env, t_env),
                               highlight_gap=(8500, 11500, 90, 170),
                               title="Demo — fleet dwell vs capability (80k samples)")
    print("Wrote", save_fig(fig, "/tmp/map_dwell", "quick"))
