---
name: maps-fields-2d
description: 2D field and map visuals for machine and powertrain data — torque-speed efficiency maps with MTPA/MTPV trajectories and operating points, flux map surfaces (3D with mandatory contour twin), and operating-point dwell density (hexbin). Use whenever plotting efficiency maps, flux maps psi_d/psi_q, loss maps, torque-speed envelopes, calibration surfaces, operating-point coverage, or any quantity over a 2D grid, and whenever 3D plotting is requested (this skill carries the 3D policy).
---

# Maps & 2D Fields

Quantities over 2D domains — the native visuals of machine calibration and VHM operating analysis. Assumes `plot-style-guide` applied.

## Layer 2: Recipe index

| Need | Script entry point |
|---|---|
| Efficiency map + envelope + MTPA + op. points | `efficiency_map.py::plot_efficiency_map` |
| Flux map 3D surface with contour floor | `flux_maps.py::plot_flux_surface` |
| Flux map 2D contour twin | `flux_maps.py::plot_flux_contour` |
| Operating-point dwell density (hexbin) | `dwell_density.py::plot_dwell_hexbin` |

Core conventions:
1. Efficiency maps: filled contours in `CMAP_SEQ`, labeled iso-efficiency lines at 90/94/96/97%, torque envelope as solid ink line, trajectories (MTPA, drive cycle) as overlaid curves with direct labels. Operating points as scatter sized by dwell time when available.
2. 3D POLICY (binding for the whole kit): static 3D is banned in deliverables except where the surface IS the object (flux maps, loss surfaces, calibration maps). Permitted 3D uses `plot_surface` with a projected contour on the floor plane, viewing angle chosen to avoid self-occlusion of the relevant region, and MUST ship with a 2D contour twin from the same data. Interactive 3D (plotly Surface/Scatter3d) is exploration-only — never exec decks. No 3D bar charts, no 3D pie, ever.
3. Dwell density: hexbin (not scatter) above ~5k points, log color scale when dwell spans decades, torque envelope overlaid so coverage gaps are visible against capability.
4. Axes follow machine convention: speed [rpm or rad/s] on x, torque [Nm] on y; flux maps: id on x, iq on y, quadrant labeled.
5. Grid data must be plotted on its native grid — no smoothing/interpolation that invents calibration points; if display interpolation is used, the caption says so.

## Layer 3: Resources

- `scripts/efficiency_map.py`, `scripts/flux_maps.py`, `scripts/dwell_density.py` — runnable synthetic demos (PMSM-flavored).
- `references/recipes.md` — contour level choices, colormap normalization, envelope construction, MTPA/MTPV overlay math notes, 3D camera guidance.
