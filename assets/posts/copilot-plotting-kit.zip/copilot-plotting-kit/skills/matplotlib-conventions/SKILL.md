---
name: matplotlib-conventions
description: House idioms for building static figures with matplotlib — figure templates, subplot layouts, annotation patterns, and anti-chartjunk rules. Use this skill whenever writing matplotlib code for any chart, plot, subplot grid, or static figure, including when the user just says "plot this" or "make a chart" without naming matplotlib.
---

# Matplotlib Conventions

House idioms for static figures. Assumes `plot-style-guide` is loaded and `apply_style()` has been called.

## Layer 2: Core conventions

1. Always use the object-oriented API (`fig, ax = plt.subplots(...)`); never pyplot state machine calls (`plt.plot`, `plt.title`) in deliverable code.
2. Pick figure size from `style_setup.SIZES` presets — never guess dimensions.
3. Subplot grids: use `plt.subplots(nrows, ncols, sharex=...)` with `constrained_layout=True`. For aligned multi-signal stacks, `sharex=True` is mandatory.
4. Titles state the takeaway, not the topic: "Bearing fault energy doubles above 4 kRPM", not "FFT of vibration signal".
5. Annotate the one number that matters with `annotate_key_point()` from `scripts/fig_templates.py` rather than expecting readers to read it off the axes.
6. Use direct line labeling (text at line end) instead of a legend when there are ≤4 series and space allows — `label_lines_directly()` helper.
7. Anti-chartjunk: no 3D, no drop shadows, no dual y-axes unless the two quantities are causally linked (then color-match each axis to its series).

## Layer 3: Resources

- `scripts/fig_templates.py` — canonical constructors: `single()`, `stacked()`, `grid()`, `comparison_bars()`, plus `annotate_key_point()` and `label_lines_directly()`. Start from these, never from a blank figure.
- `references/conventions.md` — extended rules: tick formatting (engineering notation, time axes), error band patterns, twin-axis policy, log-scale rules, layout debugging. Read when handling a case not covered above.
