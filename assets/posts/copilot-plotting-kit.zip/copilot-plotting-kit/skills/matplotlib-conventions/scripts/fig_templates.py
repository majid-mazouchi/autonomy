"""
fig_templates.py — Canonical figure constructors and annotation helpers.
Build every matplotlib figure from these; never start from a blank canvas.

Requires: style_setup.apply_style() called first.
"""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, PALETTE, SIZES  # noqa: E402


# ----------------------------------------------------------------------------
# Constructors
# ----------------------------------------------------------------------------
def single(size="doc_full"):
    """One axes, preset size."""
    return plt.subplots(figsize=SIZES[size], constrained_layout=True)


def stacked(n, size="doc_tall", height_ratios=None):
    """Vertically stacked, time-aligned axes (multi-signal telemetry)."""
    fig, axes = plt.subplots(
        n, 1, figsize=SIZES[size], sharex=True, constrained_layout=True,
        gridspec_kw={"height_ratios": height_ratios or [1] * n})
    for ax in axes[:-1]:
        ax.tick_params(labelbottom=False)
    return fig, axes


def grid(nrows, ncols, size="doc_tall", sharex=False, sharey=False):
    """Small-multiples grid."""
    return plt.subplots(nrows, ncols, figsize=SIZES[size],
                        sharex=sharex, sharey=sharey, constrained_layout=True)


def comparison_bars(labels, values, baseline_idx=None, size="doc_half",
                    highlight_idx=None, ylabel=""):
    """
    Horizontal comparison bars. Optional baseline reference line and a single
    highlighted bar (everything else neutral grey).
    """
    fig, ax = single(size)
    n = len(labels)
    colors = [COLORS["neutral"]] * n
    if highlight_idx is not None:
        colors[highlight_idx] = COLORS["blue"]
    else:
        colors = PALETTE[:n]
    ax.barh(range(n), values, color=colors, height=0.62)
    ax.set_yticks(range(n), labels)
    ax.invert_yaxis()
    ax.set_xlabel(ylabel)
    if baseline_idx is not None:
        ax.axvline(values[baseline_idx], color=COLORS["ink_soft"],
                   ls="--", lw=1, zorder=0)
    for i, v in enumerate(values):
        ax.text(v, i, f" {v:g}", va="center", ha="left",
                fontsize=9.5, color=COLORS["ink"])
    ax.grid(axis="y", visible=False)
    return fig, ax


# ----------------------------------------------------------------------------
# Annotation helpers
# ----------------------------------------------------------------------------
def annotate_key_point(ax, x, y, text, dx=30, dy=25):
    """Callout for THE number that matters. One or two per figure, max."""
    ax.annotate(
        text, xy=(x, y), xytext=(dx, dy), textcoords="offset points",
        fontsize=9.5, color=COLORS["ink"], fontweight="semibold",
        arrowprops=dict(arrowstyle="-", color=COLORS["ink_soft"], lw=0.9),
        bbox=dict(boxstyle="round,pad=0.35", fc=COLORS["paper"],
                  ec=COLORS["spine"], lw=0.8))


def label_lines_directly(ax, pad_frac=0.01):
    """Replace a legend with labels at each line's right end (<=4 series)."""
    xmax = ax.get_xlim()[1]
    pad = (xmax - ax.get_xlim()[0]) * pad_frac
    for line in ax.get_lines():
        label = line.get_label()
        if label.startswith("_"):
            continue
        x, y = line.get_xdata(), line.get_ydata()
        if len(x) == 0:
            continue
        ax.text(x[-1] + pad, y[-1], label, color=line.get_color(),
                fontsize=9.5, va="center", fontweight="semibold")
    leg = ax.get_legend()
    if leg:
        leg.remove()


def shade_band(ax, lo, hi, color_key="warn", label=None, axis="y"):
    """Horizontal or vertical reference band (spec limits, alarm zones)."""
    fn = ax.axhspan if axis == "y" else ax.axvspan
    fn(lo, hi, color=COLORS[color_key], alpha=0.14, lw=0, label=label, zorder=0)


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    # Demo: stacked telemetry + comparison bars
    t = np.linspace(0, 10, 800)
    fig, axes = stacked(3)
    axes[0].plot(t, 3000 + 500 * np.sin(0.8 * t)); axes[0].set_ylabel("Speed [rpm]")
    axes[1].plot(t, 40 + 5 * np.cos(0.8 * t), color=PALETTE[1]); axes[1].set_ylabel("Iq [A]")
    axes[2].plot(t, 65 + 0.8 * t, color=PALETTE[3]); axes[2].set_ylabel("Temp [degC]")
    shade_band(axes[2], 70, 75, "warn"); shade_band(axes[2], 75, 80, "fail")
    axes[2].set_xlabel("Time [s]")
    axes[0].set_title("Demo — aligned telemetry stack")
    print("Wrote", save_fig(fig, "/tmp/templates_demo", "quick"))
