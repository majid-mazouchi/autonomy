# Matplotlib Conventions — Extended Rules

## Tick formatting

- Engineering quantities: `EngFormatter` from `matplotlib.ticker`
  (e.g. 12 k, 3.4 M) for frequency, sample counts, mileage.
- Time axes from datetimes: `ConciseDateFormatter` — never default
  auto-dates, they waste horizontal space.
- Elapsed-time axes: seconds up to 120 s, minutes up to 120 min, then hours.
  State the unit in the label, not in every tick.
- Percentages: `PercentFormatter(xmax=1)` if data is 0–1 fractions.
- Limit ticks to ~5–7 per axis: `ax.xaxis.set_major_locator(MaxNLocator(6))`.

## Uncertainty and error display

- Continuous confidence/uncertainty: `fill_between` band at alpha 0.18,
  same hue as the central line. Label the band in the legend ("90% CI").
- Discrete points: capped error bars `capsize=2.5, elinewidth=1`.
- Never stack more than two overlapping bands on one axes — use small
  multiples instead.

## Twin axes policy

Dual y-axes are allowed only when two quantities are causally linked and
the chart's message is their relationship (e.g. speed and phase current
during a transient). Requirements:
1. Color-match each axis (label + ticks + spine) to its series color.
2. No grid for the secondary axis (`ax2.grid(False)`).
3. Never twin bar charts.

## Log scales

- Spectra: log frequency axis above 2 decades of span; dB magnitude
  (`20*log10`) rather than log-scale linear magnitude.
- Always label as such: "Magnitude [dB re 1 A]".
- Minor gridlines on for log axes (`which="both"`, minor alpha 0.5).

## Layout debugging

- Use `constrained_layout=True` everywhere; if labels still clip, the fix
  is a bigger SIZES preset, not `tight_layout` hacks.
- Long category labels: horizontal bars, never rotated x labels >30°.
- Check exports at 100% zoom in the destination (Word page / slide) before
  declaring done — minimum legible tick size is ~9 pt at final scale.

## File hygiene

- One figure per script function; functions return `(fig, ax)` and never
  call `plt.show()` in deliverable code.
- Deterministic output: seed any jitter/random demo data (`np.random.default_rng(42)`).
- Close figures in batch loops (`plt.close(fig)`) to avoid memory creep.
