"""correlation.py — Hierarchically-ordered correlation heatmaps."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, CMAP_DIV, SIZES  # noqa: E402


def plot_corr_clustered(df, title="", size="doc_tall", annotate_max=12,
                        fade_below=0.2, method="pearson"):
    """
    Correlation heatmap with features ordered by hierarchical clustering.
    The ordering is the insight: correlated blocks become visible.
    """
    from scipy.cluster.hierarchy import leaves_list, linkage
    from scipy.spatial.distance import squareform
    corr = df.corr(method=method).to_numpy()
    cols = list(df.columns)
    dist = 1 - np.abs(corr)
    np.fill_diagonal(dist, 0.0)
    order = leaves_list(linkage(squareform(dist, checks=False), method="average"))
    corr = corr[np.ix_(order, order)]
    cols = [cols[i] for i in order]
    n = len(cols)
    # fade weak cells toward the canvas
    display = corr.copy()
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    im = ax.imshow(display, cmap=CMAP_DIV, vmin=-1, vmax=1)
    weak = np.abs(corr) < fade_below
    ax.imshow(np.where(weak, 1.0, np.nan), cmap="Greys", vmin=0, vmax=4,
              alpha=0.55)  # wash over weak cells
    if n <= annotate_max:
        for i in range(n):
            for j in range(n):
                if not weak[i, j] and i != j:
                    ax.text(j, i, f"{corr[i, j]:.2f}", ha="center",
                            va="center", fontsize=7.5,
                            color=COLORS["ink"] if abs(corr[i, j]) < 0.75
                            else COLORS["paper"])
    fig.colorbar(im, ax=ax, label=f"{method.title()} r [-]", pad=0.01)
    ax.set_xticks(range(n), cols, rotation=40, ha="right", fontsize=8.5)
    ax.set_yticks(range(n), cols, fontsize=8.5)
    ax.set_title(title or "Feature correlation (clustered order)")
    ax.grid(False)
    return fig, ax


if __name__ == "__main__":
    import pandas as pd
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    n = 2000
    base = rng.normal(size=n)
    thermal = rng.normal(size=n)
    df = pd.DataFrame({
        "Iq ripple": base + rng.normal(0, .4, n),
        "6f harmonic": base * 0.9 + rng.normal(0, .5, n),
        "Speed err": base * 0.5 + rng.normal(0, .8, n),
        "Vdc ripple": rng.normal(size=n),
        "Inv temp": thermal + rng.normal(0, .3, n),
        "Stator temp": thermal * 0.85 + rng.normal(0, .4, n),
        "Coolant flow": -thermal * 0.6 + rng.normal(0, .6, n),
        "Mileage": rng.normal(size=n)})
    fig, _ = plot_corr_clustered(df, "Demo — VHM feature correlation")
    print("Wrote", save_fig(fig, "/tmp/ml_corr", "quick"))
