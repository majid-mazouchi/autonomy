"""embeddings.py — Embedding scatter with cluster hulls + silhouette plots."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, PALETTE, SIZES  # noqa: E402


def plot_embedding_clusters(X2, labels, label_names=None, title="",
                            axis_labels=("Dim 1", "Dim 2"), size="doc_full",
                            noise_label=-1):
    """
    X2: (n,2) embedded points. labels: cluster ids; noise_label plotted grey.
    Convex hulls per cluster at low alpha.
    """
    from scipy.spatial import ConvexHull
    X2 = np.asarray(X2); labels = np.asarray(labels)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    uniq = [u for u in np.unique(labels) if u != noise_label]
    if (labels == noise_label).any():
        m = labels == noise_label
        ax.scatter(X2[m, 0], X2[m, 1], s=10, color=COLORS["neutral"],
                   alpha=0.5, lw=0, label=f"Noise (n={m.sum()})")
    for u, c in zip(uniq, PALETTE):
        m = labels == u
        name = (label_names or {}).get(u, f"Cluster {u}")
        ax.scatter(X2[m, 0], X2[m, 1], s=14, color=c, alpha=0.75, lw=0,
                   label=f"{name} (n={m.sum()})")
        if m.sum() >= 3:
            hull = ConvexHull(X2[m])
            pts = X2[m][np.r_[hull.vertices, hull.vertices[0]]]
            ax.fill(pts[:, 0], pts[:, 1], color=c, alpha=0.10, lw=0)
            ax.plot(pts[:, 0], pts[:, 1], color=c, lw=1.0, alpha=0.6)
            cx, cy = X2[m].mean(axis=0)
            ax.text(cx, cy, name, fontsize=9.5, fontweight="semibold",
                    color=c, ha="center")
    ax.set_xlabel(axis_labels[0]); ax.set_ylabel(axis_labels[1])
    ax.set_title(title); ax.legend(fontsize=8.5, loc="best")
    return fig, ax


def plot_silhouette(X, labels, title="", size="doc_half"):
    """Per-cluster silhouette bars, sorted; mean as dashed line."""
    from sklearn.metrics import silhouette_samples, silhouette_score
    X = np.asarray(X); labels = np.asarray(labels)
    sil = silhouette_samples(X, labels)
    mean_s = silhouette_score(X, labels)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    y0 = 0
    for u, c in zip(np.unique(labels), PALETTE):
        vals = np.sort(sil[labels == u])
        ax.fill_betweenx(np.arange(y0, y0 + vals.size), 0, vals,
                         color=c, alpha=0.8, lw=0)
        ax.text(-0.02, y0 + vals.size / 2, str(u), ha="right", va="center",
                fontsize=9, color=COLORS["ink_soft"])
        y0 += vals.size + max(8, int(0.01 * labels.size))
    ax.axvline(mean_s, color=COLORS["ink_soft"], ls="--", lw=1.2,
               label=f"Mean = {mean_s:.2f}")
    ax.axvline(0, color=COLORS["spine"], lw=0.8)
    ax.set_yticks([]); ax.set_xlabel("Silhouette coefficient [-]")
    ax.set_title(title or "Silhouette by cluster")
    ax.legend(fontsize=8.5, loc="lower right")
    ax.grid(axis="y", visible=False)
    return fig, ax


if __name__ == "__main__":
    from sklearn.cluster import KMeans
    from sklearn.datasets import make_blobs
    from sklearn.decomposition import PCA
    from style_setup import apply_style, save_fig
    apply_style()
    X, _ = make_blobs(n_samples=900, centers=4, n_features=8,
                      cluster_std=[1.0, 1.4, 0.8, 2.2], random_state=42)
    km = KMeans(4, n_init=10, random_state=42).fit(X)
    pca = PCA(2).fit(X)
    X2 = pca.transform(X)
    names = {0: "Bearing-like", 1: "Healthy core", 2: "Stator-like", 3: "Mixed"}
    fig, _ = plot_embedding_clusters(
        X2, km.labels_, names, "Demo — fault-mode discovery (PCA + k-means)",
        (f"PC1 ({pca.explained_variance_ratio_[0]:.0%} var)",
         f"PC2 ({pca.explained_variance_ratio_[1]:.0%} var)"))
    print("Wrote", save_fig(fig, "/tmp/ml_embed", "quick"))
    fig, _ = plot_silhouette(X, km.labels_, "Demo — clustering quality")
    print("Wrote", save_fig(fig, "/tmp/ml_silhouette", "quick"))
