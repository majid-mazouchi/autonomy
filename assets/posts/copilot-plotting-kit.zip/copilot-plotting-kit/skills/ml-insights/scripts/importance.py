"""importance.py — Feature importance bars and calibration diagrams."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, SIZES  # noqa: E402


def plot_feature_importance(names, values, spread=None, top_k=5,
                            method="Permutation importance", title="",
                            size="doc_full", unit="[-]"):
    """
    Horizontal sorted bars; top_k in blue, rest neutral; spread as error bars.
    Accepts any precomputed importance (permutation, gain, mean |SHAP|).
    """
    idx = np.argsort(values)
    names = [names[i] for i in idx]
    vals = np.asarray(values, dtype=float)[idx]
    err = None if spread is None else np.asarray(spread, dtype=float)[idx]
    n = len(names)
    colors = [COLORS["blue"] if i >= n - top_k else COLORS["neutral"]
              for i in range(n)]
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.barh(range(n), vals, color=colors, height=0.65,
            xerr=err, error_kw=dict(ecolor=COLORS["ink_soft"], lw=1,
                                    capsize=2.5))
    ax.set_yticks(range(n), names, fontsize=9)
    ax.set_xlabel(f"{method} {unit}")
    ax.set_title(title or f"{method} — top {top_k} highlighted")
    ax.grid(axis="y", visible=False)
    return fig, ax


def plot_calibration(y_true, y_prob, n_bins=10, title="", size="doc_half"):
    """Reliability diagram + predicted-probability strip; ECE in title."""
    y_true = np.asarray(y_true); y_prob = np.asarray(y_prob, dtype=float)
    edges = np.linspace(0, 1, n_bins + 1)
    mids, frac, conf, w = [], [], [], []
    for a, b in zip(edges[:-1], edges[1:]):
        m = (y_prob >= a) & (y_prob < b if b < 1 else y_prob <= b)
        if m.sum() == 0:
            continue
        mids.append((a + b) / 2); frac.append(y_true[m].mean())
        conf.append(y_prob[m].mean()); w.append(m.mean())
    ece = float(np.sum(np.asarray(w) * np.abs(np.asarray(frac) - np.asarray(conf))))
    fig, (ax, axh) = plt.subplots(
        2, 1, figsize=SIZES[size], constrained_layout=True,
        gridspec_kw={"height_ratios": [4, 1]}, sharex=True)
    ax.plot([0, 1], [0, 1], ls=":", color=COLORS["neutral"], lw=1,
            label="Perfect")
    ax.plot(mids, frac, "o-", color=COLORS["blue"], lw=1.7, ms=5,
            label="Model")
    ax.set_ylabel("Observed fault fraction [-]")
    ax.set_title(title or f"Calibration (ECE = {ece:.3f})")
    ax.legend(fontsize=8.5, loc="upper left")
    axh.hist(y_prob, bins=edges, color=COLORS["slate"], alpha=0.6)
    axh.set_xlabel("Predicted probability [-]")
    axh.set_yticks([])
    axh.grid(visible=False)
    return fig, (ax, axh)


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    feats = ["6f harmonic", "Iq ripple", "Stator temp slope", "Speed err",
             "Vdc ripple", "Coolant Δp", "Mileage", "Ambient temp",
             "SOC window", "Charge cycles"]
    vals = np.sort(rng.gamma(2, 0.02, len(feats)))[::-1]
    fig, _ = plot_feature_importance(feats, vals, spread=vals * 0.18,
                                     title="Demo — what drives the stator-fault score")
    print("Wrote", save_fig(fig, "/tmp/ml_importance", "quick"))
    y = (rng.random(5000) < 0.3).astype(int)
    p = np.clip(0.3 + 0.5 * (y - 0.3) + rng.normal(0, 0.22, y.size), 0.01, 0.99)
    fig, _ = plot_calibration(y, p, title=None)
    print("Wrote", save_fig(fig, "/tmp/ml_calibration", "quick"))
