---
name: ml-insights
description: Visuals for ML model understanding — embedding scatter (PCA/UMAP) with cluster hulls, silhouette plots, hierarchically-clustered correlation heatmaps, feature importance, and probability calibration curves. Use whenever visualizing clustering results, dimensionality reduction, feature relationships, model explainability, fault-mode discovery, or fleet segmentation, including when the user says "cluster the data" or "which features matter".
---

# ML Insights

Model-understanding visuals for fault classifiers, anomaly detectors, and fleet segmentation. Assumes `plot-style-guide` applied.

## Layer 2: Recipe index

| Need | Script entry point |
|---|---|
| 2D embedding scatter + convex cluster hulls | `embeddings.py::plot_embedding_clusters` |
| Silhouette plot per cluster | `embeddings.py::plot_silhouette` |
| Correlation heatmap, hierarchically ordered | `correlation.py::plot_corr_clustered` |
| Feature importance (bar, with spread) | `importance.py::plot_feature_importance` |
| Calibration / reliability diagram | `importance.py::plot_calibration`

Core conventions:
1. Embeddings: state the method and explained variance (PCA) or parameters (UMAP n_neighbors/min_dist) in the axis labels or caption — an unlabeled embedding is unfalsifiable. Cluster hulls at alpha 0.10 with the categorical palette; noise/unassigned points in neutral grey.
2. Embedding axes carry no physical units — say "PC1 (38% var)" style labels; never let readers ascribe meaning to distances across UMAP plots from different runs.
3. Silhouette plot is the honesty companion to any clustering claim — per-cluster bars sorted, mean silhouette as a dashed line, thin/negative clusters visibly flagged.
4. Correlation heatmaps: order features by hierarchical clustering (the order IS the insight), diverging CMAP_DIV centered at 0, |r| < 0.2 cells faded; annotate values only when the matrix is ≤ 12×12.
5. Feature importance: horizontal bars sorted, spread (std across folds/permutations) as thin error bars, top-k highlighted in blue with the rest neutral; method named in the title (permutation, gain, |SHAP|). The script accepts precomputed SHAP values — it does not compute them.
6. Calibration: reliability curve with the diagonal, histogram of predicted probabilities as a quiet lower strip, ECE in the title.

## Layer 3: Resources

- `scripts/embeddings.py`, `scripts/correlation.py`, `scripts/importance.py` — runnable demos (sklearn only; UMAP/SHAP optional inputs).
- `references/recipes.md` — method choice (PCA vs UMAP vs t-SNE), hull vs ellipse, DBSCAN noise display, correlation pitfalls, calibration binning.
