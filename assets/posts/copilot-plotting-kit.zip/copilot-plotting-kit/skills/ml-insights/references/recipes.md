# ML Insights — Guidance

## Embedding method choice

| Goal | Method | Notes |
|---|---|---|
| Linear structure, fast, interpretable axes | PCA | report explained variance per axis |
| Nonlinear cluster separation for presentation | UMAP | fix random_state; report n_neighbors, min_dist |
| Avoid | t-SNE for anything quantitative | distances/density not meaningful |

- Standardize features before PCA/UMAP (per-feature z-score); say so.
- Never compare point positions across two separately-fitted embeddings.

## Hulls vs ellipses

- Convex hulls (default): honest about actual extent; sensitive to outliers
  — for heavy-tailed clusters use the hull of the central 95% instead.
- 2σ covariance ellipses: cleaner for Gaussian-ish clusters, imply a model.
- DBSCAN/HDBSCAN noise: always neutral grey, counted in the legend; hiding
  noise points overstates clustering quality.

## Correlation pitfalls

- Pearson on heavy-tailed features lies — use Spearman (`method="spearman"`)
  for monotonic-but-nonlinear relations and name it in the colorbar.
- Mask the diagonal mentally; the fade-below-|0.2| wash keeps the block
  structure readable.
- Correlated-feature blocks justify dropping features before importance
  analysis; otherwise importance splits across the block arbitrarily.

## Importance methods

- Permutation importance on a held-out set is the default honest choice.
- Tree gain importances inflate high-cardinality features — caption it if
  used.
- SHAP: compute upstream, pass mean |SHAP| per feature into
  plot_feature_importance with method="mean |SHAP|". For beeswarm-style
  per-sample views use shap's own plotting; restyle to tokens afterward.

## Calibration

- 10 equal-width bins default; ≥30 samples per shown bin or merge.
- ECE in the title makes the figure self-grading; for fault probabilities
  feeding maintenance decisions, calibration matters more than AUC.
