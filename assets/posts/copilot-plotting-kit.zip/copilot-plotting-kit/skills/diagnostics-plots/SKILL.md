---
name: diagnostics-plots
description: Domain plot recipes for vehicle diagnostics and fault detection — FFT spectra, spectrograms, order maps, residual plots with thresholds, fault-signature heatmaps, and classifier evaluation (confusion matrices, ROC/PR). Use whenever plotting vibration/current/NVH spectra, fault detection results, DTC analysis, anomaly scores, residuals, or any ML fault-classifier performance, even if the user only says "visualize the diagnostic results".
---

# Diagnostics Plots

Recipes for fault detection and isolation visuals. Assumes `plot-style-guide` applied; semantic colors are binding: ok=#2E8B57, warn=#D9A21B, fail=#C03546.

## Layer 2: Recipe index

| Need | Script entry point |
|---|---|
| FFT spectrum with harmonic markers | `spectral.py::plot_spectrum` |
| Spectrogram (time-frequency) | `spectral.py::plot_spectrogram` |
| Order spectrum vs speed (order map) | `spectral.py::plot_order_map` |
| Residual + adaptive threshold + alarm flags | `spectral.py::plot_residual_threshold` |
| Confusion matrix (counts + recall %) | `classifier_eval.py::plot_confusion` |
| ROC / PR curves with operating point | `classifier_eval.py::plot_roc_pr` |
| Fault signature heatmap (fault x symptom) | `fault_heatmap.py::plot_signature_matrix` |
| DTC occurrence heatmap (fleet x time) | `fault_heatmap.py::plot_dtc_occurrence` |

Core conventions:
1. Spectra: dB magnitude, log frequency above 2 decades; mark expected fault frequencies (orders, sidebands) with labeled vertical stems, not legend entries.
2. Residual plots always show three layers: residual trace (blue), threshold (dashed crimson), alarm markers (crimson dots on exceedances). Shade the fault-injected interval if known (warn band).
3. Confusion matrices: row-normalized recall in each cell alongside raw count; sequential colormap; diagonal readable at a glance.
4. ROC alone is misleading under class imbalance (faults are rare) — always pair with the PR curve and mark the chosen operating point on both.
5. Spectrograms use `CMAP_SEQ` on the light canvas; annotate the event of interest with an ink box, not an arrowhead clutter.

## Layer 3: Resources

- `scripts/spectral.py`, `scripts/classifier_eval.py`, `scripts/fault_heatmap.py` — runnable, each has a `__main__` demo with synthetic data.
- `references/recipes.md` — parameter guidance (window/overlap choices, dB references, order analysis math, threshold display patterns) and worked interpretation notes. Read before non-default spectral settings.
