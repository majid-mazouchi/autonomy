# Diagnostics Plot Recipes — Parameter Guidance

## Welch spectrum settings

| Goal | nperseg | window | overlap |
|---|---|---|---|
| Smooth PSD, broad features | fs/2 (≈0.5 s segments) | hann | 50% |
| Resolve close harmonics/sidebands | 4–8 s of samples | hann | 75% |
| Short records (< 2 s) | len(x)//4 | hann | 50% |

- Frequency resolution Δf = fs / nperseg. To separate sidebands spaced by
  slip frequency f_s, need Δf ≤ f_s / 3.
- dB reference: state it in the label — "PSD [dB re 1 A²/Hz]" for current,
  "dB re 1 g²/Hz" for accel. Comparisons across plots require same ref.

## Spectrogram settings

- nperseg trades time vs frequency resolution; for transient events
  (driftmode exit, trip events) prefer 256–512 at 10 kHz, overlap 75–87.5%.
- Clip the color range to [p99 − 60 dB, p99] — full range hides structure.
- `rasterized=True` keeps SVG exports small (the mesh becomes a bitmap,
  text stays vector).

## Order analysis

- Order = frequency / shaft-rotational-frequency. Resample to constant
  samples-per-revolution (using an encoder/resolver position channel)
  before FFT to get sharp order lines under varying speed.
- Typical e-motor markers: pole-pass order = pole-pairs × 1x, PWM
  sidebands around f_sw, gear-mesh orders = tooth counts. Mark only the
  orders relevant to the hypothesis under test (≤ 5 stems per plot).

## Residual / threshold display

- Adaptive thresholds (e.g. CUSUM, EWMA bounds) are arrays — plot them as
  the dashed crimson line; never collapse them to a scalar in the figure.
- Detection-delay annotation: first alarm time minus fault-injection time
  is usually THE number — surface it in the callout and the title.
- For multiple residuals, use a stacked layout (matplotlib-conventions
  `stacked()`), one residual per axes, shared time axis, shared fault-window
  shading.

## Classifier evaluation

- Confusion matrix normalization: row (recall) for "which faults do we
  miss"; column (precision) for "what do alarms mean". Default to row;
  state the choice in the title.
- Under prevalence < 10%, report AP and the PR curve prominently; an
  ROC-AUC of 0.95 can coexist with useless precision.
- Mark the deployed operating threshold on both curves — reviewers always
  ask "where do we run".

## Interpretation notes worth writing into captions

- A clean 2x line in current spectra often indicates resolver eccentricity
  / offset, not a mechanical fault — check position-error residual first.
- Sidebands at ±f_r (rotational) around PWM carriers track mechanical
  modulation; growth rate matters more than absolute level.
