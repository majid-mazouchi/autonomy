"""
spectral.py — Spectra, spectrograms, order maps, and residual/threshold plots
for diagnostics work.
"""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy import signal

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, CMAP_SEQ, SIZES  # noqa: E402


def plot_spectrum(x, fs, fault_freqs=None, title="", db_ref=1.0,
                  size="doc_full", nperseg=None):
    """
    Welch spectrum in dB with labeled fault-frequency stems.
    fault_freqs: dict {label: freq_hz}
    """
    f, pxx = signal.welch(x, fs, nperseg=nperseg or min(len(x), 4096))
    mag_db = 10 * np.log10(pxx / db_ref**2 + 1e-20)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.plot(f[1:], mag_db[1:], color=COLORS["blue"], lw=1.2)
    if f[-1] / max(f[1], 1e-9) > 100:
        ax.set_xscale("log")
    ymin = ax.get_ylim()[0]
    for label, ff in (fault_freqs or {}).items():
        ax.axvline(ff, color=COLORS["fail"], lw=0.9, ls=":", zorder=1)
        ax.text(ff, ymin + 2, f" {label}", rotation=90, va="bottom",
                fontsize=8.5, color=COLORS["fail"])
    ax.set_xlabel("Frequency [Hz]")
    ax.set_ylabel("PSD [dB]")
    ax.set_title(title)
    return fig, ax


def plot_spectrogram(x, fs, title="", size="doc_full", event_box=None,
                     nperseg=1024, overlap=0.75, fmax=None):
    """
    Time-frequency map on the light canvas. event_box: (t0, t1, f0, f1)
    rectangle annotating the event of interest.
    """
    f, t, sxx = signal.spectrogram(x, fs, nperseg=nperseg,
                                   noverlap=int(nperseg * overlap))
    sxx_db = 10 * np.log10(sxx + 1e-20)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    vmax = np.percentile(sxx_db, 99)
    pcm = ax.pcolormesh(t, f, sxx_db, cmap=CMAP_SEQ, vmin=vmax - 60,
                        vmax=vmax, shading="gouraud", rasterized=True)
    if fmax:
        ax.set_ylim(0, fmax)
    if event_box:
        t0, t1, f0, f1 = event_box
        ax.add_patch(plt.Rectangle((t0, f0), t1 - t0, f1 - f0, fill=False,
                                   ec=COLORS["ink"], lw=1.4))
    fig.colorbar(pcm, ax=ax, label="PSD [dB]", pad=0.01)
    ax.set_xlabel("Time [s]"); ax.set_ylabel("Frequency [Hz]")
    ax.set_title(title); ax.grid(False)
    return fig, ax


def plot_order_map(orders, speeds_rpm, amplitude, title="",
                   mark_orders=None, size="doc_full"):
    """
    Order map: amplitude over (speed, order) grid — e.g. from a run-up.
    amplitude: 2D array [len(speeds), len(orders)].
    mark_orders: list of order numbers to flag (e.g. pole-pass, 6th, 12th).
    """
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    pcm = ax.pcolormesh(orders, speeds_rpm, amplitude, cmap=CMAP_SEQ,
                        shading="auto", rasterized=True)
    for o in (mark_orders or []):
        ax.axvline(o, color=COLORS["fail"], ls=":", lw=1)
        ax.text(o, speeds_rpm[-1], f" {o}x", color=COLORS["fail"],
                fontsize=8.5, va="top")
    fig.colorbar(pcm, ax=ax, label="Amplitude [-]", pad=0.01)
    ax.set_xlabel("Order [x shaft speed]"); ax.set_ylabel("Speed [rpm]")
    ax.set_title(title); ax.grid(False)
    return fig, ax


def plot_residual_threshold(t, residual, threshold, fault_window=None,
                            title="", size="doc_full", ylabel="Residual [-]"):
    """
    Residual trace + (possibly adaptive) threshold + alarm flags.
    threshold: scalar or array like t.
    fault_window: (t0, t1) known fault-injected interval -> warn shading.
    """
    thr = np.broadcast_to(np.asarray(threshold, dtype=float), np.shape(t))
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    if fault_window:
        ax.axvspan(*fault_window, color=COLORS["warn"], alpha=0.14, lw=0,
                   label="Fault injected", zorder=0)
    ax.plot(t, residual, color=COLORS["blue"], lw=1.1, label="Residual")
    ax.plot(t, thr, color=COLORS["fail"], ls="--", lw=1.3, label="Threshold")
    alarms = np.asarray(residual) > thr
    if alarms.any():
        ax.plot(np.asarray(t)[alarms], np.asarray(residual)[alarms], ".",
                color=COLORS["fail"], ms=4, label="Alarm")
        t_first = np.asarray(t)[alarms][0]
        ax.annotate(f"First alarm\nt = {t_first:.2f} s",
                    xy=(t_first, float(thr[alarms.argmax()])),
                    xytext=(15, 30), textcoords="offset points", fontsize=9,
                    fontweight="semibold", color=COLORS["ink"],
                    arrowprops=dict(arrowstyle="-", color=COLORS["ink_soft"]))
    ax.set_xlabel("Time [s]"); ax.set_ylabel(ylabel)
    ax.set_title(title); ax.legend(loc="upper left")
    return fig, ax


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    fs, T = 10_000, 8.0
    t = np.arange(0, T, 1 / fs)
    x = (0.4 * np.sin(2 * np.pi * 120 * t)
         + 0.12 * np.sin(2 * np.pi * 720 * t) * (t > 4)   # emerging 6th harmonic
         + rng.normal(0, 0.05, t.size))
    fig, _ = plot_spectrum(x, fs, fault_freqs={"6th harm.": 720},
                           title="Demo — stator current spectrum")
    print("Wrote", save_fig(fig, "/tmp/diag_spectrum", "quick"))
    fig, _ = plot_spectrogram(x, fs, fmax=1500, event_box=(4, 8, 650, 800),
                              title="Demo — fault emergence at t=4 s")
    print("Wrote", save_fig(fig, "/tmp/diag_specgram", "quick"))
    res = np.abs(signal.hilbert(x - np.sin(2 * np.pi * 120 * t) * 0.4))
    fig, _ = plot_residual_threshold(t[::50], res[::50], 0.18,
                                     fault_window=(4, 8),
                                     title="Demo — residual with threshold")
    print("Wrote", save_fig(fig, "/tmp/diag_residual", "quick"))
