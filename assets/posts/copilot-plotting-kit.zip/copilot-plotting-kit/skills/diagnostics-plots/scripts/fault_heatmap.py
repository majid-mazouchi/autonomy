"""
fault_heatmap.py — Fault-signature matrices and DTC occurrence heatmaps.
"""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, CMAP_SEQ, SIZES  # noqa: E402


def plot_signature_matrix(matrix, faults, symptoms, title="",
                          size="doc_tall", ternary=True):
    """
    Fault x symptom signature matrix (FDI structure).
    ternary=True: values in {-1, 0, +1} -> down / none / up glyphs.
    Otherwise continuous sensitivity in [0, 1].
    """
    M = np.asarray(matrix, dtype=float)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    if ternary:
        ax.imshow(np.zeros_like(M), cmap="Greys", vmin=0, vmax=1, alpha=0)
        glyph = {1: ("▲", COLORS["fail"]), -1: ("▼", COLORS["blue"]),
                 0: ("·", COLORS["neutral"])}
        for i in range(M.shape[0]):
            for j in range(M.shape[1]):
                g, c = glyph[int(np.sign(M[i, j]))]
                ax.text(j, i, g, ha="center", va="center",
                        fontsize=13, color=c)
    else:
        im = ax.imshow(M, cmap=CMAP_SEQ, vmin=0, vmax=1)
        fig.colorbar(im, ax=ax, label="Sensitivity [-]", pad=0.01)
    ax.set_xticks(range(len(symptoms)), symptoms, rotation=35, ha="right")
    ax.set_yticks(range(len(faults)), faults)
    ax.set_xlabel("Symptom / residual"); ax.set_ylabel("Fault mode")
    ax.set_title(title or "Fault signature matrix")
    ax.set_xticks(np.arange(-0.5, len(symptoms)), minor=True)
    ax.set_yticks(np.arange(-0.5, len(faults)), minor=True)
    ax.grid(which="minor", color=COLORS["grid"], lw=0.7)
    ax.grid(which="major", visible=False)
    ax.tick_params(which="minor", length=0)
    return fig, ax


def plot_dtc_occurrence(counts, dtc_labels, period_labels, title="",
                        size="doc_tall", annotate_max=True):
    """
    DTC occurrence heatmap: rows=DTCs, cols=time periods (or vehicle groups).
    counts: 2D array of occurrence counts.
    """
    C = np.asarray(counts, dtype=float)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    im = ax.imshow(C, cmap=CMAP_SEQ, aspect="auto")
    fig.colorbar(im, ax=ax, label="Occurrences", pad=0.01)
    ax.set_xticks(range(len(period_labels)), period_labels,
                  rotation=30, ha="right")
    ax.set_yticks(range(len(dtc_labels)), dtc_labels)
    ax.set_title(title or "DTC occurrence")
    ax.grid(False)
    if annotate_max and C.size:
        i, j = np.unravel_index(np.argmax(C), C.shape)
        ax.add_patch(plt.Rectangle((j - 0.5, i - 0.5), 1, 1, fill=False,
                                   ec=COLORS["fail"], lw=1.6))
        ax.annotate(f"Peak: {int(C[i, j])}", xy=(j, i), xytext=(12, -18),
                    textcoords="offset points", fontsize=9,
                    fontweight="semibold", color=COLORS["fail"])
    return fig, ax


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    faults = ["Bearing wear", "Stator ITSC", "Resolver offset", "DC-link cap"]
    symptoms = ["r1: Iq ripple", "r2: 6f harm.", "r3: speed err",
                "r4: Vdc ripple", "r5: temp drift"]
    sig = np.array([[1, 1, 0, 0, 1], [1, 1, -1, 0, 1],
                    [0, 0, 1, 0, 0], [0, -1, 0, 1, 0]])
    fig, _ = plot_signature_matrix(sig, faults, symptoms,
                                   "Demo — FDI signature structure")
    print("Wrote", save_fig(fig, "/tmp/diag_signature", "quick"))
    C = rng.poisson(3, (6, 10)); C[2, 6] = 31
    fig, _ = plot_dtc_occurrence(C, [f"P0A{k}F" for k in range(6)],
                                 [f"W{k+1}" for k in range(10)],
                                 "Demo — DTC occurrence by week")
    print("Wrote", save_fig(fig, "/tmp/diag_dtc", "quick"))
