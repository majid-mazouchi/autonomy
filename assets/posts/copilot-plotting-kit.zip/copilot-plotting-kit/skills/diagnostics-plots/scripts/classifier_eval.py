"""
classifier_eval.py — Fault-classifier evaluation visuals:
confusion matrix (counts + recall), ROC + PR pair with operating point.
"""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, CMAP_SEQ, SIZES  # noqa: E402


def plot_confusion(cm, class_names, title="", size="square"):
    """
    cm: square array of raw counts (rows=true, cols=predicted).
    Cells show count + row-normalized recall %.
    """
    cm = np.asarray(cm, dtype=float)
    recall = cm / cm.sum(axis=1, keepdims=True).clip(min=1)
    n = len(class_names)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.imshow(recall, cmap=CMAP_SEQ, vmin=0, vmax=1)
    for i in range(n):
        for j in range(n):
            light = recall[i, j] > 0.55
            ax.text(j, i, f"{int(cm[i, j])}\n{recall[i, j]:.0%}",
                    ha="center", va="center", fontsize=9.5,
                    fontweight="semibold" if i == j else "normal",
                    color=COLORS["paper"] if light else COLORS["ink"])
    ax.set_xticks(range(n), class_names, rotation=30, ha="right")
    ax.set_yticks(range(n), class_names)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True")
    ax.set_title(title or "Confusion matrix (count, row recall)")
    ax.grid(False)
    return fig, ax


def plot_roc_pr(y_true, y_score, op_threshold=None, title_prefix="",
                size="doc_full"):
    """
    ROC + PR side by side (mandatory pair under class imbalance).
    Marks the operating point if op_threshold given.
    """
    from sklearn.metrics import (auc, average_precision_score,
                                 precision_recall_curve, roc_curve)
    fpr, tpr, thr_roc = roc_curve(y_true, y_score)
    prec, rec, thr_pr = precision_recall_curve(y_true, y_score)
    roc_auc = auc(fpr, tpr)
    ap = average_precision_score(y_true, y_score)
    pos_rate = np.mean(y_true)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=SIZES[size],
                                   constrained_layout=True)
    ax1.plot(fpr, tpr, color=COLORS["blue"], label=f"AUC = {roc_auc:.3f}")
    ax1.plot([0, 1], [0, 1], ls=":", color=COLORS["neutral"], lw=1)
    ax1.set_xlabel("False positive rate"); ax1.set_ylabel("True positive rate")
    ax1.set_title(f"{title_prefix} ROC".strip())

    ax2.plot(rec, prec, color=COLORS["teal"], label=f"AP = {ap:.3f}")
    ax2.axhline(pos_rate, ls=":", color=COLORS["neutral"], lw=1,
                label=f"Prevalence = {pos_rate:.1%}")
    ax2.set_xlabel("Recall"); ax2.set_ylabel("Precision")
    ax2.set_title(f"{title_prefix} Precision-Recall".strip())

    if op_threshold is not None:
        i = np.argmin(np.abs(thr_roc - op_threshold))
        ax1.plot(fpr[i], tpr[i], "o", color=COLORS["fail"], ms=7,
                 label=f"Op. point (thr={op_threshold:g})")
        j = np.argmin(np.abs(thr_pr - op_threshold))
        ax2.plot(rec[j], prec[j], "o", color=COLORS["fail"], ms=7)
    for ax in (ax1, ax2):
        ax.set_xlim(-0.02, 1.02); ax.set_ylim(-0.02, 1.05)
        ax.legend(loc="lower right" if ax is ax1 else "lower left")
    return fig, (ax1, ax2)


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    names = ["Healthy", "Bearing", "Stator", "Resolver"]
    cm = np.array([[940, 18, 8, 4], [22, 161, 9, 3],
                   [11, 7, 142, 5], [6, 2, 4, 88]])
    fig, _ = plot_confusion(cm, names, "Demo — fault classifier")
    print("Wrote", save_fig(fig, "/tmp/diag_confusion", "quick"))
    y = (rng.random(4000) < 0.06).astype(int)
    s = np.clip(rng.normal(0.25 + 0.5 * y, 0.18), 0, 1)
    fig, _ = plot_roc_pr(y, s, op_threshold=0.5, title_prefix="Demo —")
    print("Wrote", save_fig(fig, "/tmp/diag_roc_pr", "quick"))
