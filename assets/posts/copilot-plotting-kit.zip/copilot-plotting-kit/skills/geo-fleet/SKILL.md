---
name: geo-fleet
description: Geographic fleet visuals — DTC/fault density by state or region (choropleth) and dealer/incident point maps (scattergeo), in the paper_light plotly theme. Use whenever fleet data has a geographic dimension: regional DTC rates, recall scope by geography, charging-infrastructure correlation, climate-dependent failure analysis, or whenever the user mentions maps of vehicles, regions, or states.
---

# Geo Fleet

Geographic views of fleet health. Plotly-based (interactive, HTML monographs); follows plotly-interactive embedding rules including the static-twin obligation for formal deliverables.

## Layer 2: Core rules

1. Regional rates, not raw counts: normalize DTC/fault counts by vehicles-in-operation per region before mapping — a raw-count choropleth is a population map. Show n in the hover.
2. Choropleth for region-level rates (`fleet_geo.py::plot_state_choropleth`); scattergeo for point events sized by count (`plot_incident_points`). Never both encodings for the same variable on one map.
3. Sequential cream→blue scale for rates; diverging crimson←cream→blue only for deltas vs fleet mean. Grey (#E7EBEF) for regions below a minimum-n threshold — and say the threshold in the caption.
4. Climate/usage hypotheses (cold-weather faults, fast-charge density) need the covariate shown — side-by-side maps or a rate-vs-covariate scatter companion, not an eyeballed claim.
5. Static twin for documents: ranked horizontal bar of the top/bottom regions carries the same decision content as the map and prints better.

## Layer 3: Resources

- `scripts/fleet_geo.py` — choropleth + point map builders with hover templates and the paper_light geo styling.
