"""fleet_geo.py — Fleet choropleths and incident point maps (plotly)."""
import sys
from pathlib import Path

import numpy as np
import plotly.graph_objects as go

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plotly-interactive" / "scripts"))
from plotly_theme import COLORS, apply_plotly_theme, to_embed_html  # noqa: E402

PAPER_SEQ = [[0.0, "#FBF7F0"], [0.35, "#BFD3EE"], [0.65, "#5C8BD6"],
             [0.85, "#1F5FBF"], [1.0, "#0E2F66"]]


def _geo_layout(fig, title, scope="usa"):
    fig.update_layout(
        title=title, height=460,
        geo=dict(scope=scope, bgcolor=COLORS["cream"],
                 lakecolor=COLORS["paper"], landcolor="#F2EDE3",
                 subunitcolor=COLORS["spine"], showlakes=True),
        margin=dict(l=10, r=10, t=56, b=10))
    return fig


def plot_state_choropleth(states, rate, n_vehicles=None, title="",
                          unit="DTCs / 1k veh / yr", min_n=200):
    """
    states: 2-letter codes. rate: normalized rate per state.
    n_vehicles: vehicles in operation (regions below min_n greyed out).
    """
    apply_plotly_theme()
    rate = np.asarray(rate, dtype=float)
    n = None if n_vehicles is None else np.asarray(n_vehicles)
    z = rate.copy()
    custom = np.stack([rate, n if n is not None else np.full_like(rate, -1)],
                      axis=-1)
    if n is not None:
        z = np.where(n < min_n, np.nan, z)
    fig = go.Figure(go.Choropleth(
        locations=states, locationmode="USA-states", z=z,
        colorscale=PAPER_SEQ, marker_line_color=COLORS["spine"],
        marker_line_width=0.8,
        colorbar=dict(title=unit, thickness=14),
        customdata=custom,
        hovertemplate="%{location}: %{customdata[0]:.1f} " + unit +
                      "<br>n = %{customdata[1]:,.0f} veh<extra></extra>"))
    return _geo_layout(fig, title or "Fleet DTC rate by state")


def plot_incident_points(lat, lon, count, labels=None, title="",
                         unit="events"):
    """Point events sized by count (dealers, incident clusters)."""
    apply_plotly_theme()
    count = np.asarray(count, dtype=float)
    sizes = 6 + 26 * np.sqrt(count / count.max())
    fig = go.Figure(go.Scattergeo(
        lat=lat, lon=lon, mode="markers",
        marker=dict(size=sizes, color=COLORS["blue"], opacity=0.65,
                    line=dict(color=COLORS["paper"], width=0.8)),
        text=labels,
        hovertemplate="%{text}: %{customdata:,.0f} " + unit + "<extra></extra>",
        customdata=count))
    return _geo_layout(fig, title or "Incidents by location")


if __name__ == "__main__":
    rng = np.random.default_rng(42)
    states = ["MI","OH","IL","TX","CA","FL","NY","PA","WA","CO","MN","WI",
              "IN","TN","GA","NC","AZ","NV","OR","MA"]
    cold = {"MI","MN","WI","NY","MA","CO","IL","OH","PA","IN","WA","OR"}
    rate = np.array([8.5 + 4.2*(s in cold) + rng.normal(0,1.0) for s in states])
    nveh = rng.integers(300, 40000, len(states)); nveh[3] = 150  # TX under min-n
    fig = plot_state_choropleth(states, rate, nveh,
        "Demo — cold-climate DTC rate pattern", min_n=200)
    open("/tmp/geo_choropleth.html","w").write(
        "<html><body style='background:#FBF7F0'>" + to_embed_html(fig)
        + "</body></html>")
    print("Wrote /tmp/geo_choropleth.html")
