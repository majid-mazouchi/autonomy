# Flows & Relations — Guidance

## Waterfall

- Order: gains largest-first, then costs largest-first, then total. For
  bridges between two known states (2025 → 2026 cost), keep causal order
  instead and use start_label.
- Subtotals when >6 steps: insert an anchor bar ("Gross benefit") midway.
- Y axis starts at 0 unless bridging two large states — then state the
  axis break in the caption.
- Exec caption template: "Net +$6.8M/yr; recall avoidance is 68% of gross
  benefit. Assumes 320k connected vehicles; platform cost amortized over 3 yr."

## Sankey

- Group flows < 2% of total into "Other" BEFORE building; >25 links reads
  as noodles.
- Stage coloring: one palette color per vertical stage, links inherit the
  source at 30% alpha.
- Conservation check before plotting: in != out per intermediate node is
  either intentional (stock change — say so) or a data bug.
- Static twin for Word/PDF: render the same data as a two-stage stacked
  bar pair with labeled segments — do not screenshot the Sankey.

## Layered DAG

- Layering: longest path from roots; the renderer raises on cycles —
  resolve them in the model (a feedback edge is a different diagram:
  use svg-figures control-loop pattern).
- ≤ 12 nodes; otherwise cluster nodes by subsystem first.
- Edge weight (e.g. occurrence count, RPN contribution) → linewidth;
  state the encoding in the caption.
- Color semantics follow the kit: blue=root causes, teal=symptoms/
  intermediate, crimson=effects/decisions.

## Parallel coordinates

- 4–7 axes; beyond that, pre-select with feature importance.
- Axis order: put correlated axes adjacent (less crossing); or causal
  order if one exists (conditions → usage → outcome).
- Always min-max per axis with real-unit endpoints labeled — a unitless
  parallel plot is unreadable.
- Highlight one class only; two classes max with blue vs orange.
