---
name: flows-relations
description: Flow and relationship visuals — waterfall charts for ROI/cost decomposition, Sankey diagrams for claim/repair/data flows, layered DAGs for causal and FMEA dependency structure, and parallel coordinates for multi-dimensional conditions. Use whenever showing how a total decomposes, how volume flows between stages, what depends on what, or how multi-dimensional settings differ — including pitch ROI stories, warranty flow, DTC-to-root-cause paths, and fault propagation.
---

# Flows & Relations

How totals decompose, volumes flow, and things depend on each other. Assumes `plot-style-guide` applied. Waterfalls and DAGs are matplotlib (static); Sankey is plotly (interactive with a static-twin obligation per plotly-interactive rules).

## Layer 2: Recipe index

| Need | Script entry point |
|---|---|
| Waterfall (ROI / cost decomposition) | `waterfall.py::plot_waterfall` |
| Sankey flow (plotly) | `sankey_flow.py::build_sankey` |
| Layered DAG (causal / FMEA dependency) | `dag_graph.py::plot_layered_dag` |
| Parallel coordinates | `parallel_coords.py::plot_parallel` |

Core conventions:
1. Waterfalls: increases in ok-green, decreases in crimson, subtotal/total bars in ink-grey with semibold value labels; connector lines hairline; start and end bars anchored to zero. This is the canonical exec ROI exhibit — run exec-figure-polish on it by default.
2. Sankey: nodes colored by stage using the categorical palette at 80%, links at 30% alpha of their source node color; node labels carry the absolute volume; flows below ~2% of total grouped into "Other" before plotting.
3. DAGs: layered left→right by causal depth (layer = longest path from a root); nodes are svg-figures-style boxes; edge thickness may encode strength; cycles are an input error — detect and report, don't draw.
4. Parallel coordinates: each variable min-max normalized to its own axis with real-unit tick labels at top/bottom; one class highlighted in color, the rest neutral at low alpha; axes ordered to minimize crossings of the highlighted class (or by domain logic).
5. All four carry totals/units in labels — flow widths and bar heights without units are decoration, not evidence.

## Layer 3: Resources

- `scripts/waterfall.py`, `scripts/sankey_flow.py`, `scripts/dag_graph.py`, `scripts/parallel_coords.py` — runnable demos.
- `references/recipes.md` — waterfall ordering rules, Sankey grouping thresholds, DAG layout details, axis-ordering heuristics, exec caption templates.
