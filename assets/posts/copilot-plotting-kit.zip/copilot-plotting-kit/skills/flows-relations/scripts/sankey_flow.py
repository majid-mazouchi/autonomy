"""sankey_flow.py — Plotly Sankey in the paper_light template."""
import sys
from pathlib import Path

import plotly.graph_objects as go

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plotly-interactive" / "scripts"))
from plotly_theme import COLORS, PALETTE, apply_plotly_theme, to_embed_html  # noqa: E402


def _rgba(hexc, a):
    h = hexc.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r},{g},{b},{a})"


def build_sankey(node_labels, node_stage, links, title="", unit=""):
    """
    node_labels: list of names. node_stage: stage index per node (colors).
    links: list of (src_idx, dst_idx, value).
    """
    apply_plotly_theme()
    node_colors = [_rgba(PALETTE[s % len(PALETTE)], 0.85) for s in node_stage]
    link_colors = [_rgba(PALETTE[node_stage[s] % len(PALETTE)], 0.30)
                   for s, _, _ in links]
    totals = {}
    for s, d, v in links:
        totals[s] = totals.get(s, 0) + v
        totals[d] = totals.get(d, 0) + 0  # ensure key
    fig = go.Figure(go.Sankey(
        arrangement="snap",
        node=dict(label=[f"{l}" for l in node_labels],
                  color=node_colors, pad=18, thickness=16,
                  line=dict(color=COLORS["spine"], width=0.5)),
        link=dict(source=[s for s, _, _ in links],
                  target=[d for _, d, _ in links],
                  value=[v for _, _, v in links],
                  color=link_colors,
                  hovertemplate="%{source.label} → %{target.label}: "
                                "%{value:,.0f} " + unit + "<extra></extra>")))
    fig.update_layout(title=title, height=440, margin=dict(l=12, r=12, t=56, b=16))
    return fig


if __name__ == "__main__":
    labels = ["Field DTCs", "Telemetry triage", "Dealer diagnosis",
              "Software fix (OTA)", "Component repair", "No fault found",
              "Recall scope"]
    stage = [0, 1, 1, 2, 2, 2, 2]
    links = [(0, 1, 8200), (0, 2, 3100),
             (1, 3, 5200), (1, 4, 1900), (1, 5, 700), (1, 6, 400),
             (2, 4, 1800), (2, 5, 900), (2, 6, 400)]
    fig = build_sankey(labels, stage, links,
                       "Demo — DTC resolution flow (vehicles/yr)", "veh")
    open("/tmp/flow_sankey.html", "w").write(
        "<html><body style='background:#FBF7F0'>"
        + to_embed_html(fig) + "</body></html>")
    print("Wrote /tmp/flow_sankey.html")
