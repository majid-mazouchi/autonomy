"""dag_graph.py — Layered DAG rendering for causal / FMEA dependency graphs."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, SIZES  # noqa: E402

TINT = {"blue": "#E4ECF8", "teal": "#E0F0F0", "orange": "#FAEADF",
        "crimson": "#F6E2E4", "violet": "#ECE7F7", "slate": "#E7EBEF"}


def _layers(nodes, edges):
    """Layer = longest path from any root. Raises on cycles."""
    preds = {n: set() for n in nodes}
    for a, b, *_ in edges:
        preds[b].add(a)
    layer, frontier = {}, [n for n in nodes if not preds[n]]
    if not frontier:
        raise ValueError("Graph has no roots — cycle detected")
    for n in frontier:
        layer[n] = 0
    remaining = set(nodes) - set(frontier)
    guard = 0
    while remaining:
        progressed = False
        for n in list(remaining):
            if preds[n] <= layer.keys():
                layer[n] = 1 + max(layer[p] for p in preds[n])
                remaining.discard(n); progressed = True
        guard += 1
        if not progressed or guard > len(nodes) + 1:
            raise ValueError(f"Cycle detected involving: {sorted(remaining)}")
    return layer


def plot_layered_dag(nodes, edges, node_colors=None, title="",
                     size="doc_tall", edge_weight_key=None):
    """
    nodes: list of names (or (name, subtitle) tuples).
    edges: list of (src, dst) or (src, dst, weight).
    node_colors: dict name->accent ('blue','teal','orange','crimson',
    'violet','slate').
    """
    names = [n[0] if isinstance(n, tuple) else n for n in nodes]
    subs = {n[0]: n[1] for n in nodes if isinstance(n, tuple)}
    lay = _layers(names, edges)
    n_layers = max(lay.values()) + 1
    cols = {}
    for L in range(n_layers):
        members = [n for n in names if lay[n] == L]
        for i, n in enumerate(members):
            cols[n] = (L, i, len(members))

    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.set_xlim(-0.6, n_layers - 0.4); ax.axis("off")
    pos = {}
    for n, (L, i, k) in cols.items():
        y = (i + 0.5) / k
        pos[n] = (L, y)
    ymax = 1.0
    ax.set_ylim(-0.05, ymax + 0.05)
    # edges first
    weights = [e[2] for e in edges if len(e) > 2]
    wmax = max(weights) if weights else 1
    for e in edges:
        a, b = e[0], e[1]
        w = e[2] if len(e) > 2 else None
        lw = 0.8 + 2.2 * (w / wmax) if w is not None else 1.1
        (x0, y0), (x1, y1) = pos[a], pos[b]
        xm = (x0 + x1) / 2
        bez_x = np.linspace(0, 1, 40)
        xs = (1 - bez_x)**2 * x0 + 2 * (1 - bez_x) * bez_x * xm + bez_x**2 * x1
        ys = (1 - bez_x)**2 * y0 + 2 * (1 - bez_x) * bez_x * y0 + bez_x**2 * y1
        ax.plot(xs + 0.18, ys, color=COLORS["ink_soft"], lw=lw, alpha=0.65,
                solid_capstyle="round", zorder=1)
        ax.annotate("", xy=(x1 - 0.19, y1), xytext=(x1 - 0.24, ys[-2]),
                    arrowprops=dict(arrowstyle="-|>", lw=0,
                                    color=COLORS["ink_soft"], alpha=0.8))
    # nodes
    for n, (x, y) in pos.items():
        acc = (node_colors or {}).get(n, "blue")
        ax.add_patch(plt.Rectangle((x - 0.18, y - 0.055), 0.36, 0.11,
                                   transform=ax.transData, zorder=3,
                                   fc=TINT[acc], ec=COLORS[acc], lw=1.4,
                                   joinstyle="round"))
        ax.text(x, y + (0.012 if n in subs else 0), n, ha="center",
                va="center", fontsize=9, fontweight="semibold",
                color=COLORS["ink"], zorder=4)
        if n in subs:
            ax.text(x, y - 0.028, subs[n], ha="center", va="center",
                    fontsize=7.5, color=COLORS["ink_soft"], zorder=4)
    ax.set_title(title or "Dependency graph", fontsize=13,
                 fontweight="semibold", color=COLORS["ink"])
    return fig, ax


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    nodes = [("Bearing wear", "root cause"), ("Rotor imbalance", "root cause"),
             ("Vibration ↑", "symptom"), ("Iq ripple ↑", "symptom"),
             ("Temp rise", "symptom"), ("NVH complaint", "effect"),
             ("Derate event", "effect"), ("DTC P0A78", "effect")]
    edges = [("Bearing wear", "Vibration ↑", 3), ("Bearing wear", "Temp rise", 2),
             ("Rotor imbalance", "Vibration ↑", 2),
             ("Rotor imbalance", "Iq ripple ↑", 1),
             ("Vibration ↑", "NVH complaint", 3),
             ("Iq ripple ↑", "DTC P0A78", 2),
             ("Temp rise", "Derate event", 3),
             ("Temp rise", "DTC P0A78", 1)]
    colors = {n[0]: c for n, c in zip(nodes, ["blue", "blue", "teal", "teal",
                                              "teal", "crimson", "crimson",
                                              "crimson"])}
    fig, _ = plot_layered_dag(nodes, edges, colors,
                              "Demo — fault propagation (FMEA view)")
    print("Wrote", save_fig(fig, "/tmp/flow_dag", "quick"))
