"""waterfall.py — Waterfall charts for ROI and cost decomposition."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, SIZES  # noqa: E402


def plot_waterfall(labels, deltas, start=0.0, start_label=None,
                   total_label="Total", title="", size="doc_full",
                   unit="$M", fmt="{:+,.1f}"):
    """
    labels/deltas: contribution steps (signed). Adds a start bar (if
    start_label) and a closing total bar automatically.
    """
    deltas = list(map(float, deltas))
    bars = []
    if start_label:
        bars.append((start_label, start, "anchor"))
    run = start
    for lbl, d in zip(labels, deltas):
        bars.append((lbl, d, "delta")); run += d
    bars.append((total_label, run, "anchor"))

    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    cum = start if start_label else 0.0
    prev_top = None
    for i, (lbl, v, kind) in enumerate(bars):
        if kind == "anchor":
            bottom, height = 0, v
            color = COLORS["slate"]
            top = v
            label_val = f"{v:,.1f}"
            weight = "semibold"
        else:
            bottom = cum if v >= 0 else cum + v
            height = abs(v)
            color = COLORS["ok"] if v >= 0 else COLORS["fail"]
            top = cum + max(v, 0)
            cum += v
            label_val = fmt.format(v)
            weight = "normal"
        ax.bar(i, height, bottom=bottom, color=color, width=0.62,
               edgecolor=COLORS["paper"], lw=0.5)
        ax.text(i, bottom + height + 0.02 * abs(run or 1), label_val,
                ha="center", va="bottom", fontsize=9, fontweight=weight,
                color=COLORS["ink"])
        if prev_top is not None:
            ax.plot([i - 1 + 0.31, i - 0.31], [prev_top, prev_top],
                    color=COLORS["spine"], lw=0.8)
        prev_top = top if kind == "delta" else v
        if kind == "anchor" and i == 0:
            cum = v
    ax.set_xticks(range(len(bars)), [b[0] for b in bars], fontsize=9,
                  rotation=18, ha="right")
    ax.set_ylabel(f"Value [{unit}]")
    ax.set_title(title)
    ax.grid(axis="x", visible=False)
    return fig, ax


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    fig, _ = plot_waterfall(
        ["Avoided recalls", "Warranty triage", "Unplanned downtime",
         "Platform cost", "Data/cloud opex"],
        [4.6, 2.1, 1.9, -1.2, -0.6],
        start=0, start_label=None,
        total_label="Net annual",
        title="Demo — VHM program ROI decomposition",
        unit="$M/yr")
    print("Wrote", save_fig(fig, "/tmp/flow_waterfall", "quick"))
