"""parallel_coords.py — Parallel coordinates with class highlighting."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, SIZES  # noqa: E402


def plot_parallel(df, cols, class_col, highlight, title="", size="doc_full",
                  units=None, max_context=400):
    """
    df: DataFrame. cols: ordered numeric columns to show as axes.
    class_col: column holding the class; rows == highlight drawn in blue,
    rest in neutral grey (subsampled to max_context).
    units: optional dict col->unit for axis footer labels.
    """
    units = units or {}
    X = df[cols].to_numpy(dtype=float)
    lo, hi = X.min(axis=0), X.max(axis=0)
    Xn = (X - lo) / np.where(hi - lo == 0, 1, hi - lo)
    is_hl = (df[class_col] == highlight).to_numpy()
    rng = np.random.default_rng(0)
    ctx_idx = np.where(~is_hl)[0]
    if ctx_idx.size > max_context:
        ctx_idx = rng.choice(ctx_idx, max_context, replace=False)

    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    xs = np.arange(len(cols))
    for i in ctx_idx:
        ax.plot(xs, Xn[i], color=COLORS["neutral"], lw=0.6, alpha=0.25,
                zorder=1)
    for i in np.where(is_hl)[0]:
        ax.plot(xs, Xn[i], color=COLORS["blue"], lw=1.1, alpha=0.55, zorder=3)
    for j, c in enumerate(cols):
        ax.axvline(j, color=COLORS["spine"], lw=1, zorder=2)
        u = f" [{units[c]}]" if c in units else ""
        ax.text(j, 1.03, f"{hi[j]:.3g}", ha="center", fontsize=8,
                color=COLORS["ink_soft"])
        ax.text(j, -0.05, f"{lo[j]:.3g}", ha="center", va="top", fontsize=8,
                color=COLORS["ink_soft"])
        ax.text(j, -0.13, c + u, ha="center", va="top", fontsize=9,
                color=COLORS["ink"], fontweight="semibold")
    ax.plot([], [], color=COLORS["blue"], lw=1.5,
            label=f"{class_col} = {highlight} (n={is_hl.sum()})")
    ax.plot([], [], color=COLORS["neutral"], lw=1,
            label=f"Other (n={(~is_hl).sum()}, shown {ctx_idx.size})")
    ax.legend(loc="upper right", fontsize=8.5)
    ax.set_xlim(-0.3, len(cols) - 0.7); ax.set_ylim(-0.02, 1.1)
    ax.axis("off")
    ax.set_title(title, fontsize=13, fontweight="semibold",
                 color=COLORS["ink"], pad=24)
    return fig, ax


if __name__ == "__main__":
    import pandas as pd
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    n = 1200
    cls = rng.random(n) < 0.08
    df = pd.DataFrame({
        "Ambient": rng.normal(18, 9, n) + 6 * cls,
        "Load factor": np.clip(rng.normal(0.45, 0.15, n) + 0.22 * cls, 0, 1),
        "SOC swing": np.clip(rng.normal(0.5, 0.18, n) + 0.15 * cls, 0, 1),
        "Fast charges/wk": rng.poisson(2 + 4 * cls),
        "Mileage": rng.normal(40, 18, n) + 25 * cls,
        "Failed": np.where(cls, "yes", "no")})
    fig, _ = plot_parallel(df, ["Ambient", "Load factor", "SOC swing",
                                "Fast charges/wk", "Mileage"],
                           "Failed", "yes",
                           title="Demo — conditions of failed units vs fleet",
                           units={"Ambient": "degC", "Mileage": "kkm"})
    print("Wrote", save_fig(fig, "/tmp/flow_parallel", "quick"))
