# Exec Figure Pre-Flight Checklist

Run top to bottom; every "no" is a required fix.

## Message
- [ ] Can you state the chart's claim in one sentence with one number?
- [ ] Is that sentence the title (or the slide headline directly above)?
- [ ] Does the visual evidence for the claim carry the most visual weight?
- [ ] Would removing any series/element leave the claim intact? (then remove)

## Emphasis recipe
- Message series: house blue #1F5FBF (or semantic color if the message IS
  the status), linewidth 2.2.
- Context series: neutral #9AA0AC, linewidth 1.0, alpha 0.8, no legend
  entries beyond a single "Other programs (n=12)".
- The key number: `annotate_key_point()` box; max 2 callouts per figure.
- Threshold/target lines: dashed, labeled at the line, not in the legend.

## Title transformations (before → after)
- "RUL prediction results" → "Bearings flagged 310 h before failure —
  enough for scheduled service"
- "DTC occurrence heatmap" → "One supplier batch drives 73% of P0A1F
  events"
- "Cost analysis" → "Telemetry screening cuts recall scope by 41% ($8.2M)"

## Numbers
- [ ] 2–3 significant figures everywhere visible.
- [ ] Business translation present (h → days of shop capacity; faults →
      vehicles; rates → $/yr) at least once.
- [ ] Comparisons are like-for-like (same window, same fleet) or the
      difference is footnoted.

## Credibility line (small print under figure)
Template: "Data: <fleet/test population>, <date window>; <n> units.
Assumes <key assumption>. Source: <pipeline/report id>."

## Slide vs document differences
| Aspect | Slide | Document |
|---|---|---|
| Title | In slide headline, chart title omitted | In chart title |
| Fonts | +2 pt across the board | Standard scale |
| Detail | One chart per slide; backup slides for detail | Detail panel allowed below the headline chart |
| Format | PNG @200 dpi, 16:9 presets | SVG, doc presets |

## Squint test
Export at thumbnail (~300 px wide), look for 2 seconds: the highlighted
element and the headline number must be what you remember. If the grid,
legend, or context data wins, repeat the emphasis recipe.

## Final
- [ ] Caption/credibility line present
- [ ] Exported via save_fig() with correct target
- [ ] Checked at 100% zoom in the actual destination (slide/page)
