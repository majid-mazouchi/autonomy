---
name: exec-figure-polish
description: Final-pass rules for executive-facing figures in pitches, leadership reviews, and proposal documents — one message per chart, title-as-takeaway, annotation callouts, decluttering, and business-number surfacing. ALWAYS apply this skill when a figure is destined for executives, a pitch deck, a leadership review, a proposal, or an ROI story, and as a final review pass after diagnostics/prognostics/telemetry charts are drafted for such audiences.
---

# Exec Figure Polish

Transforms a technically-correct chart into a decision-grade exhibit. This is a review/transform pass applied AFTER a chart is drafted with the other skills.

## Layer 2: The seven rules

1. One message per chart. If the figure supports two claims, it becomes two figures. Identify the single sentence the chart must prove before touching styling.
2. Title is the takeaway, stated as that sentence with the number in it: "Recall scope cut 41% with telemetry-based screening" — never "Analysis results".
3. The key number gets a callout (annotation box pointing at the evidence); everything else gets quieter: context series to neutral grey, gridlines stay subtle, legend removed if direct labels fit.
4. Translate units to business meaning where possible: hours → vehicles affected → dollars; keep the engineering unit in a secondary label/caption.
5. Declutter pass: delete anything not serving the message — secondary axes, minor ticks, redundant series, decimal places beyond 2–3 sig figs.
6. Source + assumption line in small print under the figure (data window, fleet size, key assumption) — credibility armor for the Q&A.
7. The squint test: at thumbnail size, the highlighted element must still be the first thing seen. If not, increase contrast between message and context.

## Layer 3: Resources

- `references/checklist.md` — full pre-flight checklist, before/after examples of titles and callouts, color de-emphasis recipe, and slide-vs-document differences. Run the checklist explicitly before delivering any exec figure.
