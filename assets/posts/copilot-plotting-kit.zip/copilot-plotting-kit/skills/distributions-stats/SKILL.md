---
name: distributions-stats
description: Distribution and statistical-process-control visuals — histogram+KDE with percentile markers, ECDF comparisons, violin/box panels, ridgeline drift plots, Q-Q normality checks, and EWMA/CUSUM control charts. Use whenever comparing populations or groups, checking residual normality, showing fleet statistics, monitoring drift over builds/weeks, or whenever the user mentions distributions, histograms, spread, percentiles, or control charts.
---

# Distributions & SPC

Population and drift visuals. Assumes `plot-style-guide` applied.

## Layer 2: Recipe index

| Need | Script entry point |
|---|---|
| Histogram + KDE + P10/P50/P90 markers | `dist_plots.py::plot_hist_kde` |
| ECDF comparison across groups | `dist_plots.py::plot_ecdf` |
| Violin panel per group, sorted by median | `dist_plots.py::plot_violin_panel` |
| Ridgeline — distribution drift over versions/weeks | `dist_plots.py::plot_ridgeline` |
| Q-Q plot (residual normality) | `dist_plots.py::plot_qq` |
| EWMA control chart with violations | `control_charts.py::plot_ewma` |
| CUSUM chart (upper/lower) with threshold | `control_charts.py::plot_cusum` |

Core conventions:
1. "Did the fix shift the population?" → ECDF, not overlapping histograms; two histograms on one axes are only allowed as step outlines, never filled.
2. Violin panels: sort groups by median, fleet median as a dashed reference line across the panel; annotate n per group under each violin.
3. Ridgeline rows are ordered by the drift axis (oldest at bottom); shared x scale; 40–60% overlap; label rows at the left margin, no legend.
4. Q-Q plots accompany any figure whose threshold assumes Gaussian residuals — reference line fitted to the central quartiles, tail departures annotated.
5. Control charts: center line + UCL/LCL in ink_soft; violations as crimson markers; rule used (e.g. EWMA λ=0.2, L=3) stated in the title or caption. CUSUM shows both one-sided sums with the decision interval h.

## Layer 3: Resources

- `scripts/dist_plots.py`, `scripts/control_charts.py` — runnable demos in `__main__`.
- `references/recipes.md` — bin/bandwidth choices, ECDF vs hist decision table, EWMA/CUSUM parameter guidance, drift-reporting caption templates.
