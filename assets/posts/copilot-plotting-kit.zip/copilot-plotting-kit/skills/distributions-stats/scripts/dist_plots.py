"""dist_plots.py — Distribution visuals: hist+KDE, ECDF, violins, ridgeline, Q-Q."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, PALETTE, SIZES  # noqa: E402


def plot_hist_kde(x, title="", xlabel="Value [-]", size="doc_full",
                  percentiles=(10, 50, 90), bins="fd"):
    x = np.asarray(x, dtype=float)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.hist(x, bins=bins, density=True, color=COLORS["blue"], alpha=0.35,
            edgecolor=COLORS["paper"], lw=0.5)
    kde = stats.gaussian_kde(x)
    xs = np.linspace(x.min(), x.max(), 400)
    ax.plot(xs, kde(xs), color=COLORS["blue"], lw=1.9, label="KDE")
    ymax = ax.get_ylim()[1]
    for p in percentiles:
        v = np.percentile(x, p)
        ax.axvline(v, color=COLORS["ink_soft"], ls=":", lw=1)
        ax.text(v, ymax * 0.97, f"P{p}\n{v:.3g}", ha="center", va="top",
                fontsize=8.5, color=COLORS["ink_soft"])
    ax.set_xlabel(xlabel); ax.set_ylabel("Density [-]")
    ax.set_title(title)
    return fig, ax


def plot_ecdf(groups, title="", xlabel="Value [-]", size="doc_full",
              mark_percentile=None):
    """groups: dict {label: array}. The shift-readable comparison."""
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    for (label, x), c in zip(groups.items(), PALETTE):
        xs = np.sort(np.asarray(x, dtype=float))
        ax.step(xs, np.arange(1, xs.size + 1) / xs.size, where="post",
                color=c, lw=1.7, label=f"{label} (n={xs.size})")
    if mark_percentile is not None:
        ax.axhline(mark_percentile / 100, color=COLORS["ink_soft"],
                   ls=":", lw=1)
        ax.text(ax.get_xlim()[0], mark_percentile / 100, f" P{mark_percentile}",
                fontsize=8.5, va="bottom", color=COLORS["ink_soft"])
    ax.set_xlabel(xlabel); ax.set_ylabel("Cumulative fraction [-]")
    ax.set_ylim(0, 1.02); ax.set_title(title); ax.legend(loc="lower right")
    return fig, ax


def plot_violin_panel(groups, title="", ylabel="Value [-]", size="doc_full",
                      sort=True):
    """groups: dict {label: array}; sorted by median, fleet median dashed."""
    items = list(groups.items())
    if sort:
        items.sort(key=lambda kv: np.median(kv[1]))
    labels = [k for k, _ in items]
    data = [np.asarray(v, dtype=float) for _, v in items]
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    vp = ax.violinplot(data, showmedians=True, widths=0.8)
    for body in vp["bodies"]:
        body.set_facecolor(COLORS["blue"]); body.set_alpha(0.35)
        body.set_edgecolor(COLORS["blue"])
    for part in ("cmedians", "cbars", "cmins", "cmaxes"):
        vp[part].set_color(COLORS["ink_soft"]); vp[part].set_linewidth(1)
    allmed = np.median(np.concatenate(data))
    ax.axhline(allmed, color=COLORS["ink_soft"], ls="--", lw=1.1,
               label=f"Overall median = {allmed:.3g}")
    ax.set_xticks(range(1, len(labels) + 1),
                  [f"{l}\n(n={d.size})" for l, d in zip(labels, data)],
                  fontsize=9)
    ax.set_ylabel(ylabel); ax.set_title(title); ax.legend(loc="upper left")
    return fig, ax


def plot_ridgeline(ordered_groups, title="", xlabel="Value [-]",
                   size="doc_tall", overlap=0.5):
    """ordered_groups: list of (label, array), oldest first (drawn at bottom)."""
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    allx = np.concatenate([np.asarray(v) for _, v in ordered_groups])
    xs = np.linspace(allx.min(), allx.max(), 400)
    step = 1.0 - overlap
    for i, (label, x) in enumerate(ordered_groups):
        kde = stats.gaussian_kde(np.asarray(x, dtype=float))
        y = kde(xs); y = y / y.max() * 0.9
        base = i * step
        ax.fill_between(xs, base, base + y, color=COLORS["blue"],
                        alpha=0.30, lw=0, zorder=len(ordered_groups) - i)
        ax.plot(xs, base + y, color=COLORS["blue"], lw=1.1,
                zorder=len(ordered_groups) - i)
        ax.text(xs[0], base + 0.04, f"{label} ", ha="right", va="bottom",
                fontsize=9, color=COLORS["ink_soft"])
    ax.set_yticks([]); ax.set_xlabel(xlabel); ax.set_title(title)
    ax.grid(axis="y", visible=False)
    return fig, ax


def plot_qq(x, title="", size="doc_half", dist="norm"):
    """Q-Q against a theoretical distribution; line fit on central quartiles."""
    x = np.asarray(x, dtype=float)
    (osm, osr), (slope, intercept, r) = stats.probplot(x, dist=dist)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.plot(osm, osr, "o", ms=3.5, color=COLORS["blue"], alpha=0.7)
    ax.plot(osm, slope * osm + intercept, color=COLORS["ink_soft"], ls="--",
            lw=1.2, label=f"fit (r={r:.3f})")
    ax.set_xlabel("Theoretical quantiles [-]")
    ax.set_ylabel("Sample quantiles [-]")
    ax.set_title(title or "Q-Q plot"); ax.legend(fontsize=8.5)
    return fig, ax


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    fig, _ = plot_hist_kde(rng.gamma(4, 12, 3000),
                           "Demo — repair time distribution",
                           "Repair time [h]")
    print("Wrote", save_fig(fig, "/tmp/dist_hist", "quick"))
    g = {"Before fix": rng.normal(2.4, 0.6, 800),
         "After fix": rng.normal(1.8, 0.45, 900)}
    fig, _ = plot_ecdf(g, "Demo — population shift", "Iq ripple [A]",
                       mark_percentile=90)
    print("Wrote", save_fig(fig, "/tmp/dist_ecdf", "quick"))
    fig, _ = plot_qq(rng.standard_t(5, 1500), "Demo — heavy-tailed residuals")
    print("Wrote", save_fig(fig, "/tmp/dist_qq", "quick"))
