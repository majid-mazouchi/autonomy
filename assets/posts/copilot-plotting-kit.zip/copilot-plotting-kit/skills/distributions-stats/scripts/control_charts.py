"""control_charts.py — EWMA and CUSUM control charts with violation flags."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, SIZES  # noqa: E402


def ewma(x, lam):
    z = np.empty_like(x, dtype=float)
    z[0] = x[0]
    for i in range(1, x.size):
        z[i] = lam * x[i] + (1 - lam) * z[i - 1]
    return z


def plot_ewma(t, x, mu0=None, sigma0=None, lam=0.2, L=3.0, title="",
              size="doc_full", ylabel="Statistic [-]", baseline_n=50):
    """EWMA chart; baseline mean/sigma estimated from first baseline_n if not given."""
    x = np.asarray(x, dtype=float); t = np.asarray(t)
    mu0 = np.mean(x[:baseline_n]) if mu0 is None else mu0
    sigma0 = np.std(x[:baseline_n], ddof=1) if sigma0 is None else sigma0
    z = ewma(x, lam)
    i = np.arange(1, x.size + 1)
    se = sigma0 * np.sqrt(lam / (2 - lam) * (1 - (1 - lam) ** (2 * i)))
    ucl, lcl = mu0 + L * se, mu0 - L * se
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.plot(t, x, ".", ms=2.5, color=COLORS["neutral"], label="Samples")
    ax.plot(t, z, color=COLORS["blue"], lw=1.8, label=f"EWMA (λ={lam})")
    ax.plot(t, ucl, color=COLORS["ink_soft"], ls="--", lw=1, label=f"±{L}σ limits")
    ax.plot(t, lcl, color=COLORS["ink_soft"], ls="--", lw=1)
    ax.axhline(mu0, color=COLORS["ink_soft"], ls=":", lw=0.9)
    viol = (z > ucl) | (z < lcl)
    if viol.any():
        ax.plot(t[viol], z[viol], "o", ms=5, color=COLORS["fail"],
                label="Violation")
        tf = t[viol][0]
        ax.annotate(f"First signal\nt = {tf:g}", xy=(tf, z[viol][0]),
                    xytext=(15, 25), textcoords="offset points",
                    fontsize=9, fontweight="semibold", color=COLORS["ink"],
                    arrowprops=dict(arrowstyle="-", color=COLORS["ink_soft"]))
    ax.set_xlabel("Sample / time"); ax.set_ylabel(ylabel)
    ax.set_title(title or f"EWMA control chart (λ={lam}, L={L})")
    ax.legend(loc="upper left", fontsize=8.5)
    return fig, ax


def plot_cusum(t, x, mu0=None, k=0.5, h=5.0, title="", size="doc_full",
               ylabel="CUSUM [σ]", baseline_n=50):
    """Tabular CUSUM (standardized); k and h in sigma units."""
    x = np.asarray(x, dtype=float); t = np.asarray(t)
    mu0 = np.mean(x[:baseline_n]) if mu0 is None else mu0
    s = np.std(x[:baseline_n], ddof=1)
    u = (x - mu0) / s
    cp = np.zeros_like(u); cm = np.zeros_like(u)
    for i in range(1, u.size):
        cp[i] = max(0, cp[i - 1] + u[i] - k)
        cm[i] = max(0, cm[i - 1] - u[i] - k)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.plot(t, cp, color=COLORS["blue"], lw=1.6, label="C+ (upward)")
    ax.plot(t, -cm, color=COLORS["teal"], lw=1.6, label="C− (downward)")
    ax.axhline(h, color=COLORS["fail"], ls="--", lw=1.2, label=f"h = ±{h}σ")
    ax.axhline(-h, color=COLORS["fail"], ls="--", lw=1.2)
    viol = (cp > h) | (cm > h)
    if viol.any():
        tf = t[viol][0]
        ax.axvline(tf, color=COLORS["fail"], ls=":", lw=1)
        ax.text(tf, h, f" signal t = {tf:g}", fontsize=8.5,
                color=COLORS["fail"], va="bottom")
    ax.set_xlabel("Sample / time"); ax.set_ylabel(ylabel)
    ax.set_title(title or f"CUSUM (k={k}σ, h={h}σ)")
    ax.legend(loc="upper left", fontsize=8.5)
    return fig, ax


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    n = 300; t = np.arange(n)
    x = rng.normal(10, 1, n); x[180:] += 0.9   # small sustained shift
    fig, _ = plot_ewma(t, x, title="Demo — EWMA detects 0.9σ shift at n=180",
                       ylabel="Feature mean [A]")
    print("Wrote", save_fig(fig, "/tmp/spc_ewma", "quick"))
    fig, _ = plot_cusum(t, x, title="Demo — CUSUM on the same shift")
    print("Wrote", save_fig(fig, "/tmp/spc_cusum", "quick"))
