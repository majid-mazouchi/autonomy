# Distributions & SPC — Guidance

## Hist vs ECDF vs violin decision table

| Question | Use |
|---|---|
| What does one population look like? | hist + KDE |
| Did the population shift / which is stochastically larger? | ECDF |
| How do many groups compare at once? | violin panel (sorted) |
| How does the distribution drift over an ordered axis? | ridgeline |
| Are residuals Gaussian (threshold validity)? | Q-Q |

## Bins and bandwidth

- Default bins "fd" (Freedman–Diaconis); for heavy-tailed data clip the
  axis at P0.5–P99.5 and say so in the caption.
- KDE bandwidth: scipy's Scott default is fine ≥500 samples; below that
  prefer the histogram alone.
- Never compare two filled histograms — step outlines or ECDF.

## EWMA / CUSUM parameter guidance

| Target shift | EWMA λ | EWMA L | CUSUM k | CUSUM h |
|---|---|---|---|---|
| Small (0.5–1σ), slow drift | 0.1–0.2 | 2.8–3.0 | 0.25–0.5 | 4–5 |
| Moderate (1–2σ) | 0.2–0.4 | 3.0 | 0.5 | 4–5 |
| Large, abrupt | use Shewhart/EWMA λ≥0.4 | 3.0 | 1.0 | 3–4 |

- Baseline window must be verified in-control; show it (lighter shading)
  if there's any doubt.
- Report ARL trade-off in the caption when tuning matters:
  "λ=0.2, L=2.86 → in-control ARL ≈ 370".

## Caption templates

- Shift: "P90 Iq ripple moved from 3.1 A to 2.4 A after SW 21.4 (n=800/900);
  full-distribution shift visible across all percentiles."
- Drift: "Distribution narrows over releases; tail above 4 A eliminated
  in 21.3+."
- SPC: "EWMA (λ=0.2) signals at n=193, 13 samples after the 0.9σ shift."
