"""
styled_tables.py — DataFrame -> house-styled HTML tables, status cells,
heat-shaded columns, and KPI cards for monograph headers.
"""
import numpy as np
import pandas as pd

COLORS = {
    "cream": "#FBF7F0", "paper": "#FFFDF8", "ink": "#1F2430",
    "ink_soft": "#4A5160", "grid": "#E4DDD0",
    "ok": "#2E8B57", "warn": "#D9A21B", "fail": "#C03546",
}
TINT = {"ok": "#E6F2EB", "warn": "#FAF2DC", "fail": "#F6E2E4"}

BASE_CSS = f"""
<style>
table.paper {{
  border-collapse: collapse; font-family: 'Helvetica Neue', Arial, sans-serif;
  font-size: 0.92rem; color: {COLORS['ink']}; background: {COLORS['paper']};
  width: 100%;
}}
table.paper th {{
  text-align: left; font-weight: 600; padding: 8px 12px;
  background: {COLORS['cream']}; color: {COLORS['ink']};
  border-bottom: 2px solid {COLORS['grid']};
}}
table.paper td {{
  padding: 7px 12px; border-bottom: 1px solid {COLORS['grid']};
}}
table.paper td.num, table.paper th.num {{
  text-align: right; font-variant-numeric: tabular-nums;
}}
table.paper td.status {{ border-left: 3px solid; font-weight: 600; }}
table.paper caption {{
  caption-side: bottom; text-align: left; font-size: 0.82rem;
  font-style: italic; color: {COLORS['ink_soft']}; padding-top: 6px;
}}
.kpi-row {{ display: flex; gap: 14px; flex-wrap: wrap; margin: 1rem 0; }}
.kpi {{
  flex: 1 1 150px; background: {COLORS['paper']};
  border: 1px solid {COLORS['grid']}; border-radius: 10px;
  padding: 12px 16px; font-family: 'Helvetica Neue', Arial, sans-serif;
}}
.kpi .v {{ font-size: 1.6rem; font-weight: 650; color: {COLORS['ink']}; }}
.kpi .l {{ font-size: 0.8rem; color: {COLORS['ink_soft']};
  text-transform: uppercase; letter-spacing: 0.05em; }}
.kpi .d {{ font-size: 0.85rem; font-weight: 600; }}
</style>
"""


def status_cell(value, status):
    """Render a pass/warn/fail cell. status in {'ok','warn','fail'}."""
    return (f'<td class="status" style="border-left-color:{COLORS[status]};'
            f'background:{TINT[status]};color:{COLORS[status]}">{value}</td>')


def _heat_color(frac):
    """cream -> blue interpolation for heat-shaded cells."""
    c0, c1 = (251, 247, 240), (31, 95, 191)
    r, g, b = (round(a + (b_ - a) * frac) for a, b_ in zip(c0, c1))
    return f"rgb({r},{g},{b})"


def heat_column(series):
    """Return list of (formatted_value_html_td) with heat shading."""
    s = pd.to_numeric(series, errors="coerce")
    lo, hi = np.nanmin(s), np.nanmax(s)
    rng = (hi - lo) or 1.0
    cells = []
    for v in s:
        if np.isnan(v):
            cells.append('<td class="num">—</td>'); continue
        f = (v - lo) / rng
        fg = "#FFFDF8" if f > 0.55 else COLORS["ink"]
        cells.append(f'<td class="num" style="background:{_heat_color(f)};'
                     f'color:{fg}">{v:,.3g}</td>')
    return cells


def df_to_html_table(df, numeric_cols=None, status_col=None,
                     status_map=None, heat_col=None, caption=None,
                     float_fmt="{:,.2f}", include_css=True):
    """
    DataFrame -> styled HTML table string.
      numeric_cols: right-aligned, formatted with float_fmt
      status_col + status_map: column whose cells render via status_cell;
        status_map: dict value->'ok'/'warn'/'fail' or callable(value)->status
      heat_col: one numeric column to heat-shade
    """
    numeric_cols = set(numeric_cols or
                       df.select_dtypes("number").columns)
    heat_cells = dict(zip(df.index, heat_column(df[heat_col]))) if heat_col else {}

    head = "".join(
        f'<th class="num">{c}</th>' if c in numeric_cols else f"<th>{c}</th>"
        for c in df.columns)
    rows = []
    for idx, row in df.iterrows():
        tds = []
        for c in df.columns:
            v = row[c]
            if c == heat_col:
                tds.append(heat_cells[idx])
            elif c == status_col:
                st = status_map(v) if callable(status_map) else status_map.get(v, "ok")
                tds.append(status_cell(v, st))
            elif c in numeric_cols and pd.notna(v):
                tds.append(f'<td class="num">{float_fmt.format(v)}</td>')
            else:
                tds.append(f"<td>{'—' if pd.isna(v) else v}</td>")
        rows.append("<tr>" + "".join(tds) + "</tr>")
    cap = f"<caption>{caption}</caption>" if caption else ""
    table = (f'<table class="paper">{cap}<thead><tr>{head}</tr></thead>'
             f'<tbody>{"".join(rows)}</tbody></table>')
    return (BASE_CSS + table) if include_css else table


def kpi_cards(cards):
    """
    cards: list of dicts {label, value, delta (optional), good (bool, opt)}.
    Returns the KPI strip HTML for a monograph/report header.
    """
    out = ['<div class="kpi-row">']
    for c in cards:
        delta = ""
        if c.get("delta") is not None:
            col = COLORS["ok"] if c.get("good", True) else COLORS["fail"]
            delta = f'<div class="d" style="color:{col}">{c["delta"]}</div>'
        out.append(f'<div class="kpi"><div class="l">{c["label"]}</div>'
                   f'<div class="v">{c["value"]}</div>{delta}</div>')
    out.append("</div>")
    return "".join(out)


if __name__ == "__main__":
    df = pd.DataFrame({
        "Fault mode": ["Bearing wear", "Stator ITSC", "Resolver offset",
                       "DC-link cap"],
        "Detection rate": [0.96, 0.91, 0.99, 0.83],
        "FAR [1/Mh]": [1.2, 3.4, 0.4, 6.8],
        "Median horizon [h]": [310, 120, 540, 45],
        "Status": ["Pass", "Pass", "Pass", "Review"],
    })
    html = BASE_CSS + kpi_cards([
        {"label": "Fleet coverage", "value": "94%", "delta": "+6 pts vs Q1"},
        {"label": "False alarms", "value": "2.1/Mh", "delta": "−38%"},
        {"label": "Avoided downtime", "value": "$1.4M", "delta": "+$0.3M"},
    ]) + df_to_html_table(
        df, status_col="Status",
        status_map=lambda v: "ok" if v == "Pass" else "warn",
        heat_col="Median horizon [h]",
        caption="Table 1 — Detector performance by fault mode (validation fleet).",
        include_css=False)
    open("/tmp/tables_demo.html", "w").write(
        f"<html><body style='background:{COLORS['cream']};padding:2rem'>{html}</body></html>")
    print("Wrote /tmp/tables_demo.html")
