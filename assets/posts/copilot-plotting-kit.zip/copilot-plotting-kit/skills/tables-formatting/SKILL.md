---
name: tables-formatting
description: Produce styled tables for deliverables — pandas DataFrame to house-styled HTML tables, Word table conventions, executive KPI/ROI summary tables, and conditional formatting (pass/fail cells, heat-shaded columns). Use whenever output includes a table of results, comparisons, KPIs, requirements, test matrices, or ROI numbers, including when the user says "summarize in a table" or "make this a table".
---

# Tables Formatting

Tables in the house style for HTML monographs, Word reports, and exec summaries.

## Layer 2: Core rules

1. HTML tables: build with `scripts/styled_tables.py::df_to_html_table` — light paper styling, hairline rules (no vertical lines, no zebra unless >12 rows), right-aligned numerics with fixed decimals, units in the header not the cells.
2. Semantic cell coloring uses the same tokens as charts: ok=#2E8B57 / warn=#D9A21B / fail=#C03546 as left-border + tinted-fill cells (`status_cell` formatter) — never full-saturation backgrounds behind text.
3. Heat-shaded numeric columns: `heat_column()` (cream→blue), only on ONE column per table — the column the reader should rank by.
4. Executive tables are sentence-readable: ≤7 rows, ≤5 columns, one "so what" column (Δ vs target, ROI, decision). Detail goes to an appendix table.
5. Word: tables via the docx path use Light Grid styling equivalents — header row semibold ink on cream tint, 0.5 pt hairline horizontal rules only; never auto-fit-to-window for numeric tables (fixed column widths).
6. Number discipline: thousands separators; 2–3 significant figures in exec tables; align decimal points; explicit "—" for N/A, never blank cells.

## Layer 3: Resources

- `scripts/styled_tables.py` — `df_to_html_table()`, `status_cell()`, `heat_column()`, `kpi_cards()` (KPI strip for monograph headers); demo in `__main__`.
- `references/word-html-tables.md` — Word table recipe (python-docx settings), CSS for monograph tables, KPI card markup, and an exec ROI table template.
