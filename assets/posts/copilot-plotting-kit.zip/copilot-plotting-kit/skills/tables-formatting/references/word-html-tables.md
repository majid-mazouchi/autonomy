# Word and HTML Table Recipes

## Word (python-docx) house settings

```python
from docx.shared import Pt, RGBColor, Cm
from docx.enum.table import WD_TABLE_ALIGNMENT

table = doc.add_table(rows=1, cols=len(headers))
table.alignment = WD_TABLE_ALIGNMENT.CENTER
table.style = "Light Grid Accent 1"   # then strip vertical borders via XML
# Header row: semibold ink (#1F2430) on cream tint (#FBF7F0)
# Body: 10 pt, 0.5 pt hairline bottom borders only
# Fixed widths: table.autofit = False; set cell.width per column
```

- Numeric columns: right-align paragraphs, tabular figures aren't available
  in Word — pad with figure spaces if decimal alignment matters.
- Status cells: left border 2.25 pt in semantic color + tinted shading
  (use w:shd fill E6F2EB / FAF2DC / F6E2E4); text in the semantic color.
- Repeat header row across pages (table property "Repeat Header Rows").

## Exec ROI table template (≤7 rows)

| Lever | Baseline | With VHM | Δ annual | Confidence |
|---|---|---|---|---|
| Unplanned downtime | ... | ... | +$X.XM | High |
| Recall scope | ... | ... | +$X.XM | Medium |
| Warranty triage | ... | ... | +$X.XM | Medium |
| **Total** | | | **+$X.XM** | |

Rules: one bold total row; confidence column forces honesty; footnote the
assumptions, don't bury them in cells.

## Monograph CSS notes

- The BASE_CSS in styled_tables.py is self-contained; in a monograph,
  move it into the page stylesheet once and call helpers with
  `include_css=False`.
- Tables wider than ~7 columns: wrap in
  `<div style="overflow-x:auto">…</div>` for phone reading.
- Zebra striping only beyond 12 rows:
  `tbody tr:nth-child(even){background:#FBF7F0}`.

## Number formatting reference

| Quantity | Format |
|---|---|
| Money (exec) | $1.4M, $230k — 2 sig figs |
| Rates | 2.1/Mh, 96% — 2–3 sig figs |
| Counts | 12,480 — thousands separators |
| Engineering | 3.42 kNm, 118 °C — unit in header when uniform |
| Missing | — (em dash), never blank or 0 |
