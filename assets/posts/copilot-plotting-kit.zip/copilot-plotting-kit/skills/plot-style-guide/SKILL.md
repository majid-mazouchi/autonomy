---
name: plot-style-guide
description: The single source of truth for figure styling across all plotting work — light paper aesthetic (warm cream background, deep ink text, saturated accents), fonts, sizing, and export settings. ALWAYS load this skill before generating any chart, plot, figure, or diagram with matplotlib, plotly, or SVG, even if the user does not mention styling. Every figure produced in this workspace must apply these tokens.
---

# Plot Style Guide

Single source of truth for figure aesthetics. All other plotting skills (matplotlib-conventions, plotly-interactive, diagnostics-plots, prognostics-plots, timeseries-telemetry, svg-figures) inherit from this skill.

## Layer 2: Core rules

1. Light paper aesthetic: warm cream canvas, deep ink text, saturated accent colors. Never dark mode unless explicitly requested.
2. Apply the style by importing `scripts/style_setup.py` and calling `apply_style()` before any plotting. Never hand-set colors inline; use the named tokens.
3. One categorical palette (`PALETTE`), one sequential colormap (`CMAP_SEQ`), one diverging colormap (`CMAP_DIV`). Do not invent ad-hoc colors.
4. Export targets:
   - Word/HTML documents: SVG, figure width 6.5 in (full) or 3.1 in (half column)
   - PowerPoint: PNG at 2x scale (dpi=200), 16:9-friendly sizes
   - Quick previews: PNG dpi=150
5. Typography: sans-serif stack (Helvetica Neue / Arial / DejaVu Sans). Title 13 pt semibold, axis labels 11 pt, ticks 10 pt, annotations 9.5 pt.
6. 3D policy: static 3D is banned in deliverables except surfaces that ARE the object (flux maps, loss/calibration surfaces) — those use `plot_surface` with a contour floor and MUST ship with a 2D contour twin (see maps-fields-2d skill). Interactive 3D is exploration-only. No 3D bars or pies, ever.
7. Always include units in axis labels in square brackets, e.g. "Speed [rpm]", "Current [A]".

## Layer 3: Resources

- `scripts/style_setup.py` — `apply_style()`, color tokens, `save_fig()` export helper. Import this in every plotting script.
- `references/style-tokens.md` — full token table (hex values, usage rules, semantic color assignments for pass/fail/warning), spacing and sizing tables. Read when making styling decisions not covered above.
