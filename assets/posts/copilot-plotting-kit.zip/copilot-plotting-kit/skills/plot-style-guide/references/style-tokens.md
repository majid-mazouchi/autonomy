# Style Tokens — Full Reference

## Canvas and text

| Token | Hex | Use |
|---|---|---|
| cream | #FBF7F0 | Figure background, page background |
| paper | #FFFDF8 | Axes / panel background |
| ink | #1F2430 | Titles, primary text, emphasized annotations |
| ink_soft | #4A5160 | Axis labels, secondary text, captions |
| grid | #E4DDD0 | Gridlines, table rules, legend borders |
| spine | #C9C1B2 | Axis spines, dividers |

## Categorical palette (use in this order)

| # | Token | Hex |
|---|---|---|
| 1 | blue | #1F5FBF |
| 2 | orange | #E2711D |
| 3 | teal | #0F8B8D |
| 4 | crimson | #C03546 |
| 5 | violet | #6B4FBB |
| 6 | olive | #7A8B2F |
| 7 | brown | #8C5E33 |
| 8 | slate | #52677D |

More than 6 categorical series in one chart is a design smell — switch to
small multiples or highlight-one/grey-the-rest (use `neutral` #9AA0AC for
context series).

## Semantic colors (never repurpose)

| Meaning | Token | Hex | Examples |
|---|---|---|---|
| Healthy / pass / within spec | ok | #2E8B57 | Health index bands, pass cells |
| Caution / degraded / approaching threshold | warn | #D9A21B | Warning bands, P-F window |
| Fault / alarm / failure | fail | #C03546 | Alarm thresholds, failure events, FN cells |
| De-emphasized / context | neutral | #9AA0AC | Fleet background traces, prior runs |

Rule: crimson (#C03546) doubles as categorical color #4 and the semantic
"fail" color. In any chart where failure semantics are present, remove
crimson from the categorical rotation to avoid ambiguity.

## Colormaps

- Sequential (`CMAP_SEQ`): cream → deep blue. For magnitudes on a light
  canvas (spectrograms, occurrence heatmaps). Never use viridis/jet — they
  fight the paper aesthetic.
- Diverging (`CMAP_DIV`): crimson ← cream → blue. For signed quantities
  centered at zero (residuals, deltas vs. baseline). Always center at 0.

## Typography scale

| Element | Size | Weight |
|---|---|---|
| Figure title | 13 pt | semibold |
| Axis label | 11 pt | regular |
| Tick label | 10 pt | regular |
| Legend | 9.5 pt | regular |
| Annotation / callout | 9.5 pt | regular (semibold for the key number) |
| Caption (in document) | 9 pt | italic |

## Sizing and export

| Destination | Preset | Format | Notes |
|---|---|---|---|
| Word/HTML full width | doc_full 6.5×3.8 in | SVG | `svg.fonttype=none` keeps text editable |
| Word/HTML half column | doc_half 3.1×2.6 in | SVG | Bump tick size +0.5 pt if crowded |
| PowerPoint full | slide 9.0×4.8 in | PNG 200 dpi | |
| PowerPoint two-up | slide_half 4.4×4.4 in | PNG 200 dpi | |
| Heatmap / matrix | square 4.5×4.5 in | per destination | |

## Hard rules

1. No top/right spines. Grid behind data, never on top.
2. Units in brackets in every axis label: "Torque [Nm]".
3. Legend inside the axes only if it does not occlude data; otherwise
   upper outside, horizontal.
4. Zero-baseline for bar charts, always. Line charts may zoom, but add a
   subtle axis-break note in the caption when they do.
5. SVG for documents, PNG@2x for slides — never JPEG for line art.
