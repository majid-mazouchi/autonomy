"""
style_setup.py — Single source of truth for figure styling.
Light paper aesthetic: warm cream background, deep ink text, saturated accents.

Usage:
    from style_setup import apply_style, PALETTE, COLORS, save_fig
    apply_style()
"""
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

# ----------------------------------------------------------------------------
# Color tokens
# ----------------------------------------------------------------------------
COLORS = {
    # Canvas + text
    "cream":      "#FBF7F0",   # figure background
    "paper":      "#FFFDF8",   # axes background (slightly lighter)
    "ink":        "#1F2430",   # primary text
    "ink_soft":   "#4A5160",   # secondary text, axis labels
    "grid":       "#E4DDD0",   # gridlines
    "spine":      "#C9C1B2",   # axis spines

    # Saturated accents (categorical order)
    "blue":       "#1F5FBF",
    "orange":     "#E2711D",
    "teal":       "#0F8B8D",
    "crimson":    "#C03546",
    "violet":     "#6B4FBB",
    "olive":      "#7A8B2F",
    "brown":      "#8C5E33",
    "slate":      "#52677D",

    # Semantic
    "ok":         "#2E8B57",   # healthy / pass
    "warn":       "#D9A21B",   # caution / degraded
    "fail":       "#C03546",   # fault / alarm
    "neutral":    "#9AA0AC",   # de-emphasized series, context data
}

PALETTE = [COLORS[k] for k in
           ("blue", "orange", "teal", "crimson", "violet", "olive", "brown", "slate")]

# Sequential colormap: cream -> deep blue (for heatmaps on light canvas)
CMAP_SEQ = LinearSegmentedColormap.from_list(
    "paper_seq", ["#FBF7F0", "#BFD3EE", "#5C8BD6", "#1F5FBF", "#0E2F66"])

# Diverging: crimson <- cream -> blue (residuals, deltas)
CMAP_DIV = LinearSegmentedColormap.from_list(
    "paper_div", ["#C03546", "#E8B0B6", "#FBF7F0", "#A8C4E8", "#1F5FBF"])

# ----------------------------------------------------------------------------
# Figure size presets (inches)  — width x height
# ----------------------------------------------------------------------------
SIZES = {
    "doc_full":   (6.5, 3.8),   # full-width figure in Word / HTML report
    "doc_half":   (3.1, 2.6),   # half-column figure
    "doc_tall":   (6.5, 5.0),   # multi-panel
    "slide":      (9.0, 4.8),   # PowerPoint 16:9 content area
    "slide_half": (4.4, 4.4),   # two-up on a slide
    "square":     (4.5, 4.5),   # confusion matrices, heatmaps
}


def apply_style() -> None:
    """Apply the light paper aesthetic globally. Call once before plotting."""
    mpl.rcParams.update({
        # Canvas
        "figure.facecolor": COLORS["cream"],
        "axes.facecolor":   COLORS["paper"],
        "savefig.facecolor": COLORS["cream"],

        # Typography
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica Neue", "Arial", "DejaVu Sans"],
        "text.color":       COLORS["ink"],
        "axes.titlesize": 13, "axes.titleweight": "semibold",
        "axes.titlecolor": COLORS["ink"],
        "axes.labelsize": 11, "axes.labelcolor": COLORS["ink_soft"],
        "xtick.labelsize": 10, "ytick.labelsize": 10,
        "xtick.color": COLORS["ink_soft"], "ytick.color": COLORS["ink_soft"],
        "legend.fontsize": 9.5,

        # Geometry
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.edgecolor": COLORS["spine"], "axes.linewidth": 1.0,
        "axes.grid": True, "grid.color": COLORS["grid"],
        "grid.linewidth": 0.7, "grid.alpha": 1.0,
        "axes.axisbelow": True,

        # Lines & markers
        "lines.linewidth": 1.8,
        "lines.markersize": 5,
        "axes.prop_cycle": mpl.cycler(color=PALETTE),

        # Legend
        "legend.frameon": True, "legend.framealpha": 0.9,
        "legend.facecolor": COLORS["paper"],
        "legend.edgecolor": COLORS["grid"],

        # Export
        "figure.dpi": 110,
        "savefig.dpi": 200,
        "savefig.bbox": "tight",
        "svg.fonttype": "none",   # keep text as text in SVG (editable, crisp)
    })


def save_fig(fig, path, target: str = "doc") -> Path:
    """
    Export a figure for its destination.
      target='doc'   -> SVG (Word/HTML embedding)
      target='slide' -> PNG @ 200 dpi (PowerPoint)
      target='quick' -> PNG @ 150 dpi (preview)
    """
    path = Path(path)
    if target == "doc":
        path = path.with_suffix(".svg")
        fig.savefig(path)
    elif target == "slide":
        path = path.with_suffix(".png")
        fig.savefig(path, dpi=200)
    else:
        path = path.with_suffix(".png")
        fig.savefig(path, dpi=150)
    return path


if __name__ == "__main__":
    # Smoke test: render a sample figure with the style applied.
    import numpy as np
    apply_style()
    t = np.linspace(0, 4 * np.pi, 400)
    fig, ax = plt.subplots(figsize=SIZES["doc_full"])
    for i, ph in enumerate([0, 0.6, 1.2]):
        ax.plot(t, np.sin(t - ph) * np.exp(-0.08 * t), label=f"Signal {i+1}")
    ax.set_title("Style smoke test — damped responses")
    ax.set_xlabel("Time [s]"); ax.set_ylabel("Amplitude [-]")
    ax.legend()
    out = save_fig(fig, "/tmp/style_smoke_test", target="quick")
    print(f"Wrote {out}")
