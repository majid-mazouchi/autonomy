"""
multisignal.py — Aligned multi-signal stacks with event markers and mode lanes.
"""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

_here = Path(__file__).resolve()
sys.path.insert(0, str(_here.parents[2] / "plot-style-guide" / "scripts"))
sys.path.insert(0, str(_here.parent))
from style_setup import COLORS, PALETTE, SIZES  # noqa: E402
from downsample import auto_decimate  # noqa: E402


def plot_signal_stack(df, time_col, signal_units, mode_col=None,
                      events=None, title="", size="doc_tall",
                      target_points=4000):
    """
    df: DataFrame with a time column and signal columns.
    signal_units: ordered dict/list of (column, unit_str).
    mode_col: optional enum/state column rendered as a bottom step lane.
    events: optional list of (t, label) vertical markers.
    """
    items = list(signal_units.items() if isinstance(signal_units, dict)
                 else signal_units)
    n = len(items) + (1 if mode_col else 0)
    ratios = [1] * len(items) + ([0.35] if mode_col else [])
    fig, axes = plt.subplots(n, 1, figsize=SIZES[size], sharex=True,
                             constrained_layout=True,
                             gridspec_kw={"height_ratios": ratios})
    axes = np.atleast_1d(axes)
    t = df[time_col].to_numpy()

    for ax, (col, unit), color in zip(axes, items, PALETTE):
        td, yd = auto_decimate(t, df[col].to_numpy(), target_points)
        ax.plot(td, yd, color=color, lw=1.0)
        ax.set_ylabel(f"{col}\n[{unit}]", fontsize=9.5)

    if mode_col:
        axm = axes[-1]
        codes, uniques = df[mode_col].factorize() if hasattr(df[mode_col], "factorize") \
            else (np.asarray(df[mode_col]), np.unique(df[mode_col]))
        axm.step(t, codes, where="post", color=COLORS["slate"], lw=1.0)
        axm.set_yticks(range(len(uniques)), [str(u) for u in uniques],
                       fontsize=8)
        axm.set_ylabel(mode_col, fontsize=9.5)

    mark_events(axes, events or [])
    axes[-1].set_xlabel(f"{time_col} [s]")
    axes[0].set_title(title)
    return fig, axes


def mark_events(axes, events):
    """Vertical event markers spanning all axes; labels in the top axes."""
    axes = np.atleast_1d(axes)
    ytop = axes[0].get_ylim()[1]
    for tev, label in events:
        for ax in axes:
            ax.axvline(tev, color=COLORS["fail"], ls=":", lw=1.0, zorder=1)
        axes[0].text(tev, ytop, f" {label}", rotation=90, va="top",
                     fontsize=8.5, color=COLORS["fail"])


if __name__ == "__main__":
    import pandas as pd
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    n = 400_000
    t = np.linspace(0, 120, n)
    df = pd.DataFrame({
        "time": t,
        "MotSpd": 2500 + 800 * np.sin(0.1 * t) + rng.normal(0, 15, n),
        "IqAct": 50 + 8 * np.cos(0.1 * t) + rng.normal(0, 1, n),
        "InvTemp": 55 + 0.12 * t + rng.normal(0, 0.2, n),
        "Mode": np.where(t < 20, "Init", np.where(t < 95, "Drive", "Derate")),
    })
    df.loc[n * 3 // 4, "IqAct"] = 140  # spike to prove decimation keeps it
    fig, _ = plot_signal_stack(
        df, "time",
        [("MotSpd", "rpm"), ("IqAct", "A"), ("InvTemp", "degC")],
        mode_col="Mode",
        events=[(95.0, "DTC P0A78 set")],
        title="Demo — 400k-sample log, decimated stack")
    print("Wrote", save_fig(fig, "/tmp/tele_stack", "quick"))
