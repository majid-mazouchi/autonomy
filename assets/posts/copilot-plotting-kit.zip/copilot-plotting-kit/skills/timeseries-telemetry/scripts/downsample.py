"""
downsample.py — Decimation that preserves diagnostic features.

minmax_decimate: keeps per-bucket min AND max -> preserves spikes/envelope.
  Use for raw telemetry, residuals, anything where outliers matter.
lttb: Largest-Triangle-Three-Buckets -> best visual shape for smooth trends.
  Use for slow trends (temperatures, SOC) where envelope is not the story.

NEVER use naive striding (x[::n]) on diagnostic data.
"""
import numpy as np


def minmax_decimate(t, y, target_points=4000):
    """
    Min-max decimation: split into buckets, keep (t_min,y_min),(t_max,y_max)
    per bucket in time order. Output <= 2 * target_points/2 points.
    """
    t = np.asarray(t); y = np.asarray(y)
    n = t.size
    nbuck = max(1, target_points // 2)
    if n <= 2 * nbuck:
        return t, y
    edges = np.linspace(0, n, nbuck + 1, dtype=int)
    ti, yi = [], []
    for a, b in zip(edges[:-1], edges[1:]):
        seg = y[a:b]
        if seg.size == 0:
            continue
        i_min, i_max = np.argmin(seg) + a, np.argmax(seg) + a
        for i in sorted((i_min, i_max)):
            ti.append(t[i]); yi.append(y[i])
    return np.asarray(ti), np.asarray(yi)


def lttb(t, y, target_points=2000):
    """Largest-Triangle-Three-Buckets downsampling (smooth trends)."""
    t = np.asarray(t, dtype=float); y = np.asarray(y, dtype=float)
    n = t.size
    if n <= target_points or target_points < 3:
        return t, y
    out_i = [0]
    every = (n - 2) / (target_points - 2)
    a = 0
    for i in range(target_points - 2):
        lo = int(np.floor((i + 0) * every) + 1)
        hi = int(np.floor((i + 1) * every) + 1)
        hi = min(hi, n - 1)
        nlo = int(np.floor((i + 1) * every) + 1)
        nhi = min(int(np.floor((i + 2) * every) + 1), n)
        avg_t, avg_y = t[nlo:nhi].mean(), y[nlo:nhi].mean()
        seg_t, seg_y = t[lo:hi], y[lo:hi]
        area = np.abs((t[a] - avg_t) * (seg_y - y[a])
                      - (t[a] - seg_t) * (avg_y - y[a]))
        a = lo + int(np.argmax(area))
        out_i.append(a)
    out_i.append(n - 1)
    idx = np.asarray(out_i)
    return t[idx], y[idx]


def auto_decimate(t, y, target_points=4000, mode="auto"):
    """
    Dispatcher: 'minmax' (default for diagnostics), 'lttb' for smooth
    trends, 'auto' picks minmax when spikiness is detected.
    """
    if mode == "auto":
        y_arr = np.asarray(y, dtype=float)
        if y_arr.size > 10:
            dy = np.abs(np.diff(y_arr))
            spiky = np.percentile(dy, 99) > 8 * (np.median(dy) + 1e-12)
            mode = "minmax" if spiky else "lttb"
        else:
            mode = "minmax"
    return (minmax_decimate if mode == "minmax" else lttb)(t, y, target_points)


if __name__ == "__main__":
    rng = np.random.default_rng(42)
    n = 2_000_000
    t = np.linspace(0, 600, n)
    y = np.sin(0.05 * t) + rng.normal(0, 0.02, n)
    y[1_234_567] = 6.0  # single-sample spike a stride would lose
    td, yd = minmax_decimate(t, y, 4000)
    assert yd.max() > 5.5, "spike lost!"
    print(f"minmax: {n:,} -> {td.size:,} points, spike preserved (max={yd.max():.2f})")
    td2, yd2 = lttb(t, y, 2000)
    print(f"lttb:   {n:,} -> {td2.size:,} points")
