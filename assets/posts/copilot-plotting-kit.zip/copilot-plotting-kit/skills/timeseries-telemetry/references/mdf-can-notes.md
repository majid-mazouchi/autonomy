# MDF / CAN Log Handling Notes

## Loading MF4/MDF with asammdf

```python
from asammdf import MDF

mdf = MDF("run_0142.mf4")
# 1) Inspect channels cheaply
names = sorted(mdf.channels_db)        # dict: name -> (group, index) list
# 2) Pull only what you need, on a common raster (plotting only)
df = mdf.to_dataframe(
    channels=["MotSpd", "IqAct", "IdAct", "InvTemp", "VdcLink"],
    raster=0.01,            # 100 Hz common raster
    time_from_zero=True)
```

- `raster` resamples by interpolation — fine for plotting, NOT for
  event-timing analysis; for that, extract each channel with
  `mdf.get(name)` and keep native timestamps.
- Duplicate channel names across groups are common (multi-bus logs):
  disambiguate with `mdf.get(name, group=g, index=i)` using channels_db.

## DBC-decoded CAN

```python
mdf_dec = mdf.extract_bus_logging(database_files={"CAN": [("powertrain.dbc", 0)]})
```
Then proceed as above on `mdf_dec`. Signal scaling/units come from the DBC;
verify units before labeling axes (don't trust raw factors blindly).

## Memory strategy for multi-GB logs

1. Never `to_dataframe()` the whole file — select channels explicitly.
2. For overview plots, set a coarse raster (0.1 s) first, refine on zoomed
   windows with `mdf.cut(start=t0, stop=t1)`.
3. `MDF(path, memory="minimum")` on older asammdf versions / use the
   default lazy loading on v7+; close files (`mdf.close()`) in batch jobs.

## Raster choice per use

| Use | Raster |
|---|---|
| Drive overview (minutes–hours) | 0.1–1 s |
| Control behavior (mode changes, derates) | 10 ms |
| Current ripple / harmonic content | native rate — and use spectral tools, not time plots |

## Sanity checks before plotting

- Time monotonicity: log concatenation produces time resets; split at
  negative dt and plot segments, or re-base.
- Unit traps: temperatures in 0.1 degC counts, torque in 0.125 Nm/bit —
  check conversion applied (asammdf applies CN conversions by default).
- Fill values: 0xFF/0xFFFF sentinel codes decode to large physical values;
  mask them (`df[df["sig"] > plaus_max] = np.nan`) before decimation, or
  min-max decimation will pin the envelope to the sentinel.
