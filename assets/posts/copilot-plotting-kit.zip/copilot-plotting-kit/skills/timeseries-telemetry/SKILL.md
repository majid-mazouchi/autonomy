---
name: timeseries-telemetry
description: Plot large vehicle telemetry and measurement logs — multi-signal aligned subplot stacks, event/DTC markers, min-max decimation for huge CAN/MDF logs, and dual-axis policy. Use whenever plotting vehicle logs, CAN signals, MF4/MDF measurement files, drive-cycle data, ECU traces, or any time series longer than a few thousand samples, even if the user just says "plot this log".
---

# Time-Series Telemetry

Recipes for plotting vehicle measurement data at scale. Assumes `plot-style-guide` applied; layout via `matplotlib-conventions::stacked()`.

## Layer 2: Core rules

1. Multi-signal logs → vertically stacked, time-aligned axes (`sharex=True`), one physical quantity per axes, units in every y label. Never overlay signals with different units on one axes (twin-axis policy in matplotlib-conventions applies).
2. Decimate before plotting anything above ~200k points using min-max decimation (`downsample.py::minmax_decimate`) — it preserves spikes and envelopes that naive striding (`x[::n]`) destroys. Naive striding is forbidden for diagnostic data.
3. Events (DTC set/clear, mode changes, trips) are vertical markers spanning all stacked axes (`multisignal.py::mark_events`), labeled once in the top axes.
4. State/mode channels (enums like driftmode, gear, inverter state) render as background color bands or a dedicated step-plot lane, not as numeric lines.
5. Time axis: relative seconds from log start by default; absolute timestamps only when correlating across sources. State t0 in the caption.
6. Reading MDF/MF4: use `asammdf` (`MDF(path).to_dataframe(...)`); resample to a common raster only for plotting, never for analysis storage.

## Layer 3: Resources

- `scripts/multisignal.py` — `plot_signal_stack()` (DataFrame → aligned stack with events + mode lane), `mark_events()`.
- `scripts/downsample.py` — `minmax_decimate()` and `lttb()` (largest-triangle-three-buckets) with guidance on when each applies.
- `references/mdf-can-notes.md` — asammdf loading patterns, channel selection, raster choices, DBC decoding notes, memory tips for multi-GB logs.
