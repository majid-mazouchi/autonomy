"""
svg_primitives.py — Minimal SVG diagram builder in the light paper aesthetic.
Boxes, arrows, lanes, labels on a snap grid. Text stays text.
"""
from pathlib import Path

COLORS = {
    "cream": "#FBF7F0", "paper": "#FFFDF8", "ink": "#1F2430",
    "ink_soft": "#4A5160", "grid": "#E4DDD0", "spine": "#C9C1B2",
    "blue": "#1F5FBF", "orange": "#E2711D", "teal": "#0F8B8D",
    "crimson": "#C03546", "violet": "#6B4FBB", "slate": "#52677D",
}
# Tinted fills (accent at ~12% on cream), precomputed for SVG portability
TINTS = {
    "blue": "#E4ECF8", "orange": "#FAEADF", "teal": "#E0F0F0",
    "crimson": "#F6E2E4", "violet": "#ECE7F7", "slate": "#E7EBEF",
}
FONT = "Helvetica Neue, Arial, sans-serif"


class Diagram:
    def __init__(self, width, height, grid=20, title=None):
        self.w, self.h, self.g = width, height, grid
        self.parts = []
        self._defs_done = False
        if title:
            self.parts.append(
                f'<text x="{grid}" y="{int(grid*1.4)}" font-family="{FONT}" '
                f'font-size="15" font-weight="600" fill="{COLORS["ink"]}">'
                f'{title}</text>')

    def snap(self, v):
        return round(v / self.g) * self.g

    def box(self, x, y, w, h, title, subtitle=None, accent="blue", rx=8):
        x, y, w, h = map(self.snap, (x, y, w, h))
        self.parts.append(
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" '
            f'fill="{TINTS[accent]}" stroke="{COLORS[accent]}" stroke-width="1.6"/>')
        cy = y + h / 2 + (0 if subtitle else 4)
        self.parts.append(
            f'<text x="{x + w/2}" y="{cy - (7 if subtitle else 0)}" '
            f'text-anchor="middle" font-family="{FONT}" font-size="13" '
            f'font-weight="600" fill="{COLORS["ink"]}">{title}</text>')
        if subtitle:
            self.parts.append(
                f'<text x="{x + w/2}" y="{cy + 11}" text-anchor="middle" '
                f'font-family="{FONT}" font-size="10.5" '
                f'fill="{COLORS["ink_soft"]}">{subtitle}</text>')
        return {"x": x, "y": y, "w": w, "h": h,
                "right": (x + w, y + h / 2), "left": (x, y + h / 2),
                "top": (x + w / 2, y), "bottom": (x + w / 2, y + h)}

    def arrow(self, p1, p2, label=None, color="ink_soft", dashed=False,
              label_dy=-6, via=None):
        """Straight or polyline arrow p1->p2; via = list of waypoints."""
        pts = [p1] + (via or []) + [p2]
        d = "M " + " L ".join(f"{px},{py}" for px, py in pts)
        dash = ' stroke-dasharray="5,4"' if dashed else ""
        self.parts.append(
            f'<path d="{d}" fill="none" stroke="{COLORS[color]}" '
            f'stroke-width="1.5" marker-end="url(#arrh)"{dash}/>')
        if label:
            mx = (pts[0][0] + pts[-1][0]) / 2
            my = (pts[0][1] + pts[-1][1]) / 2
            self.parts.append(
                f'<text x="{mx}" y="{my + label_dy}" text-anchor="middle" '
                f'font-family="{FONT}" font-size="11" '
                f'fill="{COLORS["ink_soft"]}">{label}</text>')

    def lane(self, x, y, w, h, label, accent="slate"):
        """Labeled container grouping related blocks."""
        x, y, w, h = map(self.snap, (x, y, w, h))
        self.parts.insert(1 if self.parts else 0,  # behind blocks
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" '
            f'fill="none" stroke="{COLORS["grid"]}" stroke-width="1.2" '
            f'stroke-dasharray="2,4"/>')
        self.parts.append(
            f'<text x="{x + 10}" y="{y + 18}" font-family="{FONT}" '
            f'font-size="11" font-weight="600" letter-spacing="0.06em" '
            f'fill="{COLORS[accent]}">{label.upper()}</text>')

    def label(self, x, y, text, size=11, anchor="start", color="ink_soft"):
        self.parts.append(
            f'<text x="{x}" y="{y}" text-anchor="{anchor}" '
            f'font-family="{FONT}" font-size="{size}" '
            f'fill="{COLORS[color]}">{text}</text>')

    def render(self) -> str:
        defs = (f'<defs><marker id="arrh" viewBox="0 0 10 10" refX="9" '
                f'refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
                f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{COLORS["ink_soft"]}"/>'
                f'</marker></defs>')
        body = "\n".join(self.parts)
        return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" '
                f'height="{self.h}" viewBox="0 0 {self.w} {self.h}">'
                f'<rect width="{self.w}" height="{self.h}" fill="{COLORS["cream"]}"/>'
                f'{defs}\n{body}\n</svg>')

    def save(self, path) -> Path:
        path = Path(path).with_suffix(".svg")
        path.write_text(self.render(), encoding="utf-8")
        return path


if __name__ == "__main__":
    # Demo: closed-loop FDI diagram
    d = Diagram(860, 320, title="Demo — model-based FDI loop")
    plant = d.box(80, 80, 160, 70, "Plant", "PMSM + inverter", "blue")
    obs = d.box(80, 200, 160, 70, "Observer", "EKF residual gen.", "teal")
    eva = d.box(360, 200, 170, 70, "Residual eval.", "threshold + CUSUM", "orange")
    dec = d.box(640, 200, 160, 70, "Fault decision", "isolation logic", "crimson")
    d.arrow((plant["right"][0], plant["right"][1]), (820, 115), label="y(t)")
    d.arrow((300, 115), plant["left"], label="u(t)")
    d.arrow((300, 115), (obs["left"][0], obs["left"][1]),
            via=[(300, 235)], label=None)
    d.arrow(plant["bottom"], obs["top"], label="y(t)")
    d.arrow(obs["right"], eva["left"], label="r(t)")
    d.arrow(eva["right"], dec["left"], label="J(r)")
    d.label(820, 100, "to vehicle", anchor="end")
    out = d.save("/tmp/svg_demo")
    print(f"Wrote {out}")
