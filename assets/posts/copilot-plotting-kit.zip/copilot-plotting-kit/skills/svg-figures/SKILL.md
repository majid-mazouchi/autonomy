---
name: svg-figures
description: Hand-crafted SVG diagrams for documents and HTML monographs — block diagrams, signal-flow and control-loop diagrams, system architectures, and pipelines — built from reusable primitives on a layout grid in the light paper aesthetic. Use whenever a conceptual or architectural diagram is needed (not a data chart): signal chains, VHM pipelines, agent architectures, control loops, or whenever the user asks for a "diagram", "architecture figure", or "block diagram".
---

# SVG Figures

Programmatic SVG diagrams. Data charts belong to matplotlib/plotly; this skill is for *conceptual* figures: blocks, arrows, lanes, loops.

## Layer 2: Core rules

1. Build diagrams with `scripts/svg_primitives.py` (`Diagram` class) — boxes, arrows, labels on a snap grid. Never hand-write raw coordinates ad hoc; use the grid (default 20 px) so alignment is automatic.
2. Aesthetic tokens are identical to plot-style-guide: cream canvas, ink text, saturated accents; block fills are tinted versions (12% alpha equivalent) of the accent colors with solid accent strokes.
3. Layout discipline: signal/data flows left→right; feedback paths route below the main flow; group related blocks in labeled containers (lanes). Max ~9 blocks per diagram — beyond that, split into overview + detail figures.
4. Arrows carry labels for the signal/artifact they transport ("Iq*, Id*", "A2L", "residual r(t)"); unlabeled arrows are only allowed when the flow is obvious.
5. Text must remain text (selectable/searchable) — no outlined paths. Font stack: Helvetica Neue/Arial, 13 px block titles, 11 px labels.
6. Output: standalone .svg for documents; for HTML monographs, inline the SVG element so it inherits page fonts and stays crisp.

## Layer 3: Resources

- `scripts/svg_primitives.py` — `Diagram` builder: `box`, `arrow`, `lane`, `label`, auto arrowheads, feedback routing; `__main__` renders a demo control loop.
- `references/svg-patterns.md` — recipes for common diagram types (control loop, FDI pipeline, multi-agent architecture, data pipeline), sizing for Word vs slides vs HTML, and Mermaid-to-SVG escalation guidance.
