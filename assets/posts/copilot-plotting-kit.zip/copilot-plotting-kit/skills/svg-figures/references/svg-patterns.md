# SVG Diagram Patterns

## Sizing per destination

| Destination | Canvas | Notes |
|---|---|---|
| Word full width | 860 × H px (renders ~6.5 in) | H = 60 + 130 per block row |
| Slide | 1100 × 560 px | Larger fonts: titles 15, labels 12 |
| HTML monograph | width="100%" with viewBox | Inline the <svg>, drop width/height attrs |

## Pattern: control loop

Main flow left→right on one row (setpoint → controller → plant → output);
feedback arrow routes BELOW the row via waypoints:
`d.arrow(plant_out, ctrl_in, via=[(x_out, y_below), (x_in, y_below)])`.
Summation junctions: small circle box (w=h=36, rx=18) titled "Σ".

## Pattern: FDI / VHM pipeline

Lanes by processing stage: "Vehicle / Edge" | "Data platform" | "Analytics".
Blocks within lanes; artifacts on arrows (signals, DTCs, features, health
index). Crimson accents reserved for fault/decision blocks only.

## Pattern: multi-agent architecture

- Orchestrator block top-center (violet); agents in a row below (blue/teal);
  tools/data sources in a bottom lane (slate).
- Solid arrows = control flow, dashed = data/context flow; say so in a
  small key (two short labeled arrow samples bottom-right).

## Pattern: data pipeline

Source → ingest → store → transform → serve, one row; cylinders for stores
(rect with rx=h/2 reads as a capsule — acceptable simplification).
Throughput/latency annotations under arrows in 10.5 px ink_soft.

## When to use Mermaid instead

Use Mermaid (flowchart LR) for quick drafts and internal docs where layout
quality is secondary; escalate to this skill when the figure ships in a
deliverable, needs the house aesthetic, or Mermaid's auto-layout fights
the desired arrangement (it usually does for feedback loops).

## Quality bar checklist

- All blocks on the grid; equal gaps in a row; arrows enter/exit at
  midpoints of edges.
- No text overlaps an arrow; no two parallel arrows closer than one grid
  step.
- Every accent color used has a consistent meaning across the document's
  figures (blue=plant/data, teal=estimation, orange=evaluation,
  crimson=fault/decision, violet=orchestration, slate=infrastructure).
