"""
survival.py — Weibull fits, survival curves with Bxx life, hazard curves.
"""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, SIZES  # noqa: E402


def fit_weibull(failures):
    """MLE Weibull fit (complete data). Returns (beta_shape, eta_scale)."""
    from scipy.stats import weibull_min
    beta, _, eta = weibull_min.fit(failures, floc=0)
    return beta, eta


def plot_weibull_survival(failures, title="", size="doc_full", unit="h",
                          b_lives=(10, 50)):
    """
    Empirical survival steps (Kaplan-Meier, complete data) + Weibull fit,
    with Bxx life drop lines.
    """
    x = np.sort(np.asarray(failures, dtype=float))
    n = x.size
    surv_emp = 1 - np.arange(1, n + 1) / n
    beta, eta = fit_weibull(x)
    tt = np.linspace(0, x.max() * 1.15, 400)
    surv_fit = np.exp(-(tt / eta) ** beta)

    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.step(x, surv_emp, where="post", color=COLORS["ink_soft"], lw=1.1,
            label=f"Empirical (n={n})")
    ax.plot(tt, surv_fit, color=COLORS["blue"], lw=1.9,
            label=f"Weibull β={beta:.2f}, η={eta:.0f} {unit}")
    for b in b_lives:
        tb = eta * (-np.log(1 - b / 100)) ** (1 / beta)
        ax.plot([tb, tb, 0], [0, 1 - b / 100, 1 - b / 100],
                color=COLORS["fail"], ls=":", lw=1.1)
        ax.annotate(f"B{b} = {tb:.0f} {unit}", xy=(tb, 1 - b / 100),
                    xytext=(8, 8), textcoords="offset points",
                    fontsize=9, fontweight="semibold", color=COLORS["fail"])
    ax.set_xlabel(f"Time to failure [{unit}]")
    ax.set_ylabel("Survival probability R(t) [-]")
    ax.set_ylim(0, 1.02)
    ax.set_title(title or "Survival with Weibull fit")
    ax.legend(loc="upper right")
    return fig, ax


def plot_hazard(tt, hazard, title="", size="doc_full", unit="h",
                phases=None):
    """
    Hazard rate curve. phases: list of (t0, t1, label) to annotate
    bathtub regions (infant / useful / wear-out).
    """
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.plot(tt, hazard, color=COLORS["blue"], lw=1.9)
    for (t0, t1, lbl) in (phases or []):
        ax.axvspan(t0, t1, color=COLORS["slate"], alpha=0.06, lw=0)
        ax.text((t0 + t1) / 2, ax.get_ylim()[1] * 0.95, lbl, ha="center",
                va="top", fontsize=9, color=COLORS["ink_soft"])
    ax.set_xlabel(f"Time [{unit}]")
    ax.set_ylabel(f"Hazard rate h(t) [1/{unit}]")
    ax.set_title(title or "Hazard rate")
    return fig, ax


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    failures = rng.weibull(2.4, 60) * 1200
    fig, _ = plot_weibull_survival(failures, "Demo — bearing population")
    print("Wrote", save_fig(fig, "/tmp/prog_survival", "quick"))
    tt = np.linspace(1, 2000, 400)
    hz = 0.002 * (tt / 400) ** -0.6 + 0.0008 + 0.004 * (tt / 1500) ** 4
    fig, _ = plot_hazard(tt, hz, "Demo — bathtub hazard",
                         phases=[(0, 250, "Infant"), (250, 1200, "Useful life"),
                                 (1200, 2000, "Wear-out")])
    print("Wrote", save_fig(fig, "/tmp/prog_hazard", "quick"))
