"""
degradation.py — Health-index curves with P-F intervals and fleet spaghetti.
"""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, SIZES  # noqa: E402


def plot_health_index(t, hi, warn_level=0.6, fail_level=0.3,
                      p_point=None, f_point=None, title="",
                      size="doc_full", unit="h"):
    """
    Health index (1=new, 0=failed) with ok/warn/fail background zones and
    optional P-F interval annotation. p_point/f_point: times.
    """
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.axhspan(warn_level, 1.02, color=COLORS["ok"], alpha=0.10, lw=0)
    ax.axhspan(fail_level, warn_level, color=COLORS["warn"], alpha=0.12, lw=0)
    ax.axhspan(-0.02, fail_level, color=COLORS["fail"], alpha=0.10, lw=0)
    ax.plot(t, hi, color=COLORS["blue"], lw=1.9)
    if p_point is not None and f_point is not None:
        for x, lbl in [(p_point, "P — detectable"), (f_point, "F — functional failure")]:
            ax.axvline(x, color=COLORS["ink_soft"], ls=":", lw=1.1)
            ax.text(x, 1.0, f" {lbl}", rotation=90, va="top", fontsize=8.5,
                    color=COLORS["ink_soft"])
        ax.annotate(f"P-F interval = {f_point - p_point:g} {unit}",
                    xy=((p_point + f_point) / 2, fail_level + 0.04),
                    ha="center", fontsize=9.5, fontweight="semibold",
                    color=COLORS["ink"])
        ax.axvspan(p_point, f_point, color=COLORS["warn"], alpha=0.08, lw=0)
    ax.set_ylim(-0.02, 1.05)
    ax.set_xlabel(f"Operating time [{unit}]")
    ax.set_ylabel("Health index [-]")
    ax.set_title(title or "Health index with P-F interval")
    return fig, ax


def plot_fleet_spaghetti(t, fleet_his, highlight_idx=None, title="",
                         size="doc_full", unit="h", band=(10, 90)):
    """
    Fleet degradation traces in neutral grey + percentile band + one
    highlighted unit in blue.
    fleet_his: 2D array [n_units, len(t)].
    """
    H = np.asarray(fleet_his)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    lo, hi = np.percentile(H, band, axis=0)
    ax.fill_between(t, lo, hi, color=COLORS["slate"], alpha=0.15, lw=0,
                    label=f"Fleet P{band[0]}–P{band[1]}")
    for row in H:
        ax.plot(t, row, color=COLORS["neutral"], lw=0.7, alpha=0.5)
    ax.plot(t, np.median(H, axis=0), color=COLORS["ink_soft"], lw=1.4,
            ls="--", label="Fleet median")
    if highlight_idx is not None:
        ax.plot(t, H[highlight_idx], color=COLORS["blue"], lw=2.2,
                label=f"Unit {highlight_idx}")
    ax.set_xlabel(f"Operating time [{unit}]")
    ax.set_ylabel("Health index [-]")
    ax.set_title(title or "Fleet degradation")
    ax.legend(loc="lower left")
    return fig, ax


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    t = np.linspace(0, 1000, 200)
    hi = 1 - 0.0004 * t - 0.35 / (1 + np.exp(-(t - 700) / 50))
    fig, _ = plot_health_index(t, hi, p_point=560, f_point=860,
                               title="Demo — health index, unit 17")
    print("Wrote", save_fig(fig, "/tmp/prog_hi", "quick"))
    fleet = np.array([1 - 0.0004 * t * k - 0.3 / (1 + np.exp(-(t - f0) / 60))
                      for k, f0 in zip(rng.uniform(0.6, 1.5, 25),
                                       rng.uniform(550, 950, 25))])
    fig, _ = plot_fleet_spaghetti(t, fleet, highlight_idx=7,
                                  title="Demo — fleet of 25, unit 7 highlighted")
    print("Wrote", save_fig(fig, "/tmp/prog_fleet", "quick"))
