"""
rul_fan.py — RUL trajectory fans and alpha-lambda accuracy plots.
"""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "plot-style-guide" / "scripts"))
from style_setup import COLORS, SIZES  # noqa: E402


def plot_rul_fan(t, rul_quantiles, true_rul=None, title="",
                 size="doc_full", unit="h"):
    """
    RUL prediction over time with nested uncertainty bands.
    rul_quantiles: dict {q: array} with at least {0.5: ...}; bands are drawn
    for symmetric pairs (0.05/0.95, 0.25/0.75) when present.
    """
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    for lo, hi, a, lbl in [(0.05, 0.95, 0.15, "90% band"),
                           (0.25, 0.75, 0.28, "50% band")]:
        if lo in rul_quantiles and hi in rul_quantiles:
            ax.fill_between(t, rul_quantiles[lo], rul_quantiles[hi],
                            color=COLORS["blue"], alpha=a, lw=0, label=lbl)
    ax.plot(t, rul_quantiles[0.5], color=COLORS["blue"], lw=1.9,
            label="Median RUL")
    if true_rul is not None:
        ax.plot(t, true_rul, color=COLORS["ink"], ls="--", lw=1.2,
                label="True RUL")
    ax.axhline(0, color=COLORS["fail"], ls="--", lw=1.3)
    ax.text(t[0], 0, " End of life", color=COLORS["fail"], fontsize=9,
            va="bottom", fontweight="semibold")
    ax.set_xlabel(f"Operating time [{unit}]")
    ax.set_ylabel(f"Remaining useful life [{unit}]")
    ax.set_title(title or "RUL prediction with uncertainty")
    ax.legend(loc="upper right")
    return fig, ax


def plot_alpha_lambda(lam, rul_pred, rul_true_at_lam, alpha=0.2, title="",
                      size="doc_half", unit="h"):
    """
    Alpha-lambda accuracy plot: predictions vs normalized life fraction
    lambda in [0,1], with the +/- alpha accuracy cone around true RUL.
    """
    lam = np.asarray(lam); rt = np.asarray(rul_true_at_lam)
    fig, ax = plt.subplots(figsize=SIZES[size], constrained_layout=True)
    ax.fill_between(lam, rt * (1 - alpha), rt * (1 + alpha),
                    color=COLORS["ok"], alpha=0.15, lw=0,
                    label=f"±{alpha:.0%} cone")
    ax.plot(lam, rt, color=COLORS["ink"], ls="--", lw=1.2, label="True RUL")
    inside = np.abs(np.asarray(rul_pred) - rt) <= alpha * rt
    ax.plot(lam[inside], np.asarray(rul_pred)[inside], "o", ms=4.5,
            color=COLORS["blue"], label="Pred (in cone)")
    if (~inside).any():
        ax.plot(lam[~inside], np.asarray(rul_pred)[~inside], "o", ms=4.5,
                color=COLORS["fail"], label="Pred (out)")
    ax.set_xlabel("Life fraction λ [-]")
    ax.set_ylabel(f"RUL [{unit}]")
    ax.set_title(title or f"α-λ accuracy ({inside.mean():.0%} in cone)")
    ax.legend(fontsize=8.5)
    return fig, ax


if __name__ == "__main__":
    from style_setup import apply_style, save_fig
    apply_style()
    rng = np.random.default_rng(42)
    t = np.linspace(0, 900, 60)
    true_rul = 1000 - t
    med = true_rul * (1 + rng.normal(0, 0.05, t.size))
    q = {0.5: med, 0.25: med * 0.92, 0.75: med * 1.08,
         0.05: med * 0.78, 0.95: med * 1.25}
    fig, _ = plot_rul_fan(t, q, true_rul, "Demo — bearing RUL fan")
    print("Wrote", save_fig(fig, "/tmp/prog_rul_fan", "quick"))
    lam = np.linspace(0.1, 0.95, 18)
    rt = 1000 * (1 - lam)
    rp = rt * (1 + rng.normal(0, 0.13, lam.size))
    fig, _ = plot_alpha_lambda(lam, rp, rt, title="Demo — α-λ")
    print("Wrote", save_fig(fig, "/tmp/prog_alpha_lambda", "quick"))
