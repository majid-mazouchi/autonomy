# Prognostics Plot Recipes — Guidance

## Uncertainty bands

- Default nested bands: 50% (q25–q75) and 90% (q05–q95). Two bands max.
- Particle-filter / MC outputs: compute quantiles per time step; never
  plot raw particle clouds in deliverables (exploration only).
- If the model is known to be over/under-confident, say so in the caption;
  better, add a calibration plot (predicted coverage vs empirical coverage,
  diagonal = perfect) as a companion half-width figure.

## Alpha-lambda conventions

- α = 0.20 unless a program requirement says otherwise; λ axis from first
  prediction time to 0.95 (predictions at λ≈1 are trivially accurate).
- Headline metric = fraction of predictions inside the cone; put it in
  the title so the figure is self-grading.

## Censoring (survival analysis)

- Suspended/censored units: tick marks on the empirical curve at censor
  times (standard KM convention); state "n failed / n censored" in the
  legend. The provided `fit_weibull` assumes complete data — for censored
  data use `lifelines` (KaplanMeierFitter / WeibullFitter) and keep the
  same visual conventions.

## Fleet views

- Spaghetti is for narrative ("this unit vs the fleet"); for status
  reporting prefer the percentile-band-only version (less ink, same story).
- Fleet health distribution snapshots: horizontal box/violin per vehicle
  group, sorted by median, units on the x axis. Highlight groups crossing
  the warn level.

## P-F interval messaging

- For executives: the P-F window IS the value proposition of prognostics —
  annotate its length in time AND, when known, in money (avoided unplanned
  downtime). Keep the technical curve, add the business number.
- Caption template: "Detection at P gives a NN-day maintenance window
  before functional failure at F; current fleet median window is NN days."

## Numbers worth surfacing in titles/callouts

- B10 life vs requirement (e.g. "B10 = 1,420 h vs 1,000 h target").
- Fraction of fleet below warn level today.
- Detection horizon: median (F − P) across validated cases.
