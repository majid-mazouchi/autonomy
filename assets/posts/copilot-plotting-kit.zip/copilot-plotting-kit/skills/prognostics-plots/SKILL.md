---
name: prognostics-plots
description: Plot recipes for prognostics and health management — RUL trajectories with uncertainty fans, degradation/health-index curves with P-F intervals, hazard and survival curves, and fleet health distributions. Use whenever visualizing remaining useful life, degradation trends, component reliability, Weibull/survival analysis, health indices, or fleet-level health, even if the user only says "show the prognosis" or "plot the health data".
---

# Prognostics Plots

Recipes for RUL, degradation, and reliability visuals. Assumes `plot-style-guide` applied. Uncertainty is the product in prognostics — never plot a bare point estimate of RUL.

## Layer 2: Recipe index

| Need | Script entry point |
|---|---|
| RUL trajectory + uncertainty fan + EOL line | `rul_fan.py::plot_rul_fan` |
| RUL prediction vs ground truth (alpha-lambda) | `rul_fan.py::plot_alpha_lambda` |
| Health index / degradation with P-F window | `degradation.py::plot_health_index` |
| Fleet degradation spaghetti + unit highlight | `degradation.py::plot_fleet_spaghetti` |
| Weibull fit + survival curve + B10 marker | `survival.py::plot_weibull_survival` |
| Hazard rate (bathtub) | `survival.py::plot_hazard` |

Core conventions:
1. RUL fans: central median line + nested quantile bands (e.g. 50% and 90%), same hue with decreasing alpha. End-of-life threshold is a dashed crimson horizontal; predicted-EOL distribution shown as a rug or violin at the threshold crossing.
2. Health index plots carry the ok/warn/fail bands as background shading (green/amber/red zones at alpha 0.12), so state is readable without the legend.
3. P-F interval: mark Potential-failure detection point (P) and Functional-failure point (F); the P-F window is the maintenance opportunity — shade it and annotate its length.
4. Alpha-lambda plots are the standard accuracy view for RUL models — include the ±α accuracy cone (default α=20%).
5. Survival curves: step function (Kaplan-Meier style), B10/B50 life marked with drop lines; report shape β and scale η in the legend for Weibull fits.

## Layer 3: Resources

- `scripts/rul_fan.py`, `scripts/degradation.py`, `scripts/survival.py` — runnable with synthetic demos.
- `references/recipes.md` — quantile band choices, censoring display, fleet percentile bands, calibration plots, and caption language for executive audiences.
