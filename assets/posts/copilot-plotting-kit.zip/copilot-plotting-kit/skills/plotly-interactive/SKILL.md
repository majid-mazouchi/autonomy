---
name: plotly-interactive
description: Build interactive HTML charts with plotly using the house light-paper template — hover-rich time series, zoomable spectra, linked dashboards, and charts embedded in HTML monographs. Use whenever a chart will live in an HTML page or the user wants interactivity (hover, zoom, toggle), and when deciding between static matplotlib and interactive plotly output.
---

# Plotly Interactive

Interactive charts for HTML monographs, dashboards, and exploratory review. Mirrors the light paper aesthetic from `plot-style-guide`.

## Layer 2: Core rules

1. Decision rule — static vs interactive:
   - Word/PowerPoint deliverable, printed report → matplotlib (static)
   - HTML monograph, large telemetry review, fleet dashboards → plotly
   - When in doubt for HTML pages: plotly for data the reader will probe (hover/zoom), inline SVG for conceptual diagrams.
2. Always apply the `paper_light` template from `scripts/plotly_theme.py` (`apply_plotly_theme()`); never default plotly white/dark themes.
3. Embed with `to_embed_html(fig)` → a `<div>` snippet using the CDN bundle (`include_plotlyjs="cdn"`), full_html=False. One CDN script tag per page, charts share it.
4. Hover templates always show units and signal name; disable the trace-name flag bar (`hovermode="x unified"` for time series).
5. Keep file size sane: WebGL traces (`Scattergl`) above ~20k points; decimate before plotting above ~200k points (see timeseries-telemetry skill).

## Layer 3: Resources

- `scripts/plotly_theme.py` — registers the `paper_light` template, palette mapping, `to_embed_html()` and `timeseries()` / `spectrum()` constructors.
- `references/embedding.md` — patterns for embedding multiple charts in a monograph page, responsive sizing CSS, iOS Safari rendering notes, offline (no-CDN) fallback.
