# Embedding Plotly in HTML Monographs

## Page pattern

One CDN script load per page; every chart embedded with
`to_embed_html(fig)` (which uses `include_plotlyjs="cdn"` — plotly.js is
fetched once and cached). Wrap each chart in a figure shell that matches
the monograph CSS:

```html
<figure class="chart">
  <!-- output of to_embed_html(fig) -->
  <figcaption>Fig. 3 — Iq ripple grows 2.1x at driftmode exit.</figcaption>
</figure>
```

```css
figure.chart {
  margin: 2rem 0; padding: 0.5rem 0;
  border-top: 1px solid #E4DDD0; border-bottom: 1px solid #E4DDD0;
}
figure.chart .plotly-graph-div { width: 100% !important; }
figcaption { font-size: 0.85rem; font-style: italic; color: #4A5160; }
```

## Responsive sizing

- Do not hardcode `width` in the figure layout; set
  `fig.update_layout(autosize=True, height=420)` and let the div take 100%
  of the column. Height fixed, width fluid.
- Two-up charts: CSS grid `grid-template-columns: 1fr 1fr; gap: 1rem`, and
  reduce each chart height to ~340 px.

## iOS / Safari notes (file preview path)

- Local `file://` previews on iOS block CDN fetches in some contexts. For
  monographs that must render offline, switch the *first* chart on the page
  to `include_plotlyjs=True` (inlines ~3.5 MB once) and the rest to
  `include_plotlyjs=False`.
- `Scattergl` (WebGL) can fail silently in low-memory Safari tabs at very
  high point counts; cap at ~100k points per trace and decimate upstream.
- `hovermode="x unified"` tooltips can overflow narrow phone columns;
  for mobile-heavy docs use `hovermode="closest"`.

## Performance budget

| Page total points | Strategy |
|---|---|
| < 50k | Plain Scatter traces, no action |
| 50k–500k | Scattergl + min/max decimation (timeseries-telemetry skill) |
| > 500k | Pre-aggregate; offer full-resolution data as download instead |

## Resilient embeds (sandboxed previews / offline)

iOS file previews and sandboxed webviews block CDN scripts entirely — a
plain `include_plotlyjs="cdn"` embed then throws "Script error" and renders
blank. For pages that must survive those contexts, use
`to_resilient_embed(fig, static_svg)` per chart plus ONE copy of
`RESILIENT_LOADER` before `</body>`: the static twin renders everywhere,
and each block upgrades in place to the interactive chart only when
plotly.js actually loads. No uncaught errors in either case.

## Static fallback

Every interactive chart in a formal deliverable needs a static twin for
the Word/PDF version. Generate it from the same data prep code with the
matplotlib path — do not screenshot the plotly chart.
