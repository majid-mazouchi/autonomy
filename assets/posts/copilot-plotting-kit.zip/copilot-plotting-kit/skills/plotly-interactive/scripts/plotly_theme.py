"""
plotly_theme.py — 'paper_light' plotly template matching the house aesthetic,
plus embed helpers for HTML monographs.

Usage:
    from plotly_theme import apply_plotly_theme, timeseries, to_embed_html
    apply_plotly_theme()
"""
import plotly.graph_objects as go
import plotly.io as pio

COLORS = {
    "cream": "#FBF7F0", "paper": "#FFFDF8", "ink": "#1F2430",
    "ink_soft": "#4A5160", "grid": "#E4DDD0", "spine": "#C9C1B2",
    "ok": "#2E8B57", "warn": "#D9A21B", "fail": "#C03546", "neutral": "#9AA0AC",
}
PALETTE = ["#1F5FBF", "#E2711D", "#0F8B8D", "#C03546",
           "#6B4FBB", "#7A8B2F", "#8C5E33", "#52677D"]


def apply_plotly_theme() -> None:
    """Register and activate the paper_light template."""
    pio.templates["paper_light"] = go.layout.Template(
        layout=go.Layout(
            paper_bgcolor=COLORS["cream"],
            plot_bgcolor=COLORS["paper"],
            colorway=PALETTE,
            font=dict(family="Helvetica Neue, Arial, sans-serif",
                      color=COLORS["ink"], size=13),
            title=dict(font=dict(size=17, color=COLORS["ink"]), x=0.02),
            xaxis=dict(gridcolor=COLORS["grid"], linecolor=COLORS["spine"],
                       zeroline=False, ticks="outside",
                       tickcolor=COLORS["spine"],
                       title_font=dict(color=COLORS["ink_soft"])),
            yaxis=dict(gridcolor=COLORS["grid"], linecolor=COLORS["spine"],
                       zeroline=False, ticks="outside",
                       tickcolor=COLORS["spine"],
                       title_font=dict(color=COLORS["ink_soft"])),
            legend=dict(bgcolor="rgba(255,253,248,0.9)",
                        bordercolor=COLORS["grid"], borderwidth=1),
            hovermode="x unified",
            hoverlabel=dict(bgcolor=COLORS["paper"],
                            font=dict(color=COLORS["ink"], size=12),
                            bordercolor=COLORS["spine"]),
            margin=dict(l=60, r=24, t=56, b=48),
        ))
    pio.templates.default = "paper_light"


def timeseries(df, x, ys, units=None, title="", webgl_threshold=20_000):
    """
    Multi-signal time series. `ys` is a list of column names;
    `units` an optional dict {col: unit_str} for hover text.
    """
    units = units or {}
    Trace = go.Scattergl if len(df) > webgl_threshold else go.Scatter
    fig = go.Figure()
    for col in ys:
        u = f" {units.get(col, '')}".rstrip()
        fig.add_trace(Trace(
            x=df[x], y=df[col], mode="lines", name=col,
            hovertemplate=f"%{{y:.3g}}{u}<extra>{col}</extra>"))
    fig.update_layout(title=title, xaxis_title=x)
    return fig


def spectrum(freqs, mag_db, title="", name="Magnitude"):
    """Single spectrum with log frequency axis and dB magnitude."""
    fig = go.Figure(go.Scatter(
        x=freqs, y=mag_db, mode="lines", name=name,
        hovertemplate="%{x:.1f} Hz, %{y:.1f} dB<extra></extra>"))
    fig.update_xaxes(type="log", title="Frequency [Hz]")
    fig.update_yaxes(title="Magnitude [dB]")
    fig.update_layout(title=title)
    return fig


def add_threshold(fig, y, label, kind="fail"):
    """Horizontal alarm/limit line with semantic color."""
    fig.add_hline(y=y, line_dash="dash", line_color=COLORS[kind],
                  line_width=1.5,
                  annotation_text=label, annotation_position="top left",
                  annotation_font_color=COLORS[kind])
    return fig


def to_embed_html(fig, div_id=None) -> str:
    """Snippet for embedding in a monograph page (shares one CDN bundle)."""
    return fig.to_html(full_html=False, include_plotlyjs="cdn", div_id=div_id,
                       config={"displaylogo": False,
                               "modeBarButtonsToRemove": ["lasso2d", "select2d"]})


if __name__ == "__main__":
    import numpy as np, pandas as pd
    apply_plotly_theme()
    rng = np.random.default_rng(42)
    t = np.linspace(0, 60, 3000)
    df = pd.DataFrame({"t": t,
                       "speed": 3000 + 400 * np.sin(0.2 * t) + rng.normal(0, 20, t.size),
                       "iq": 42 + 4 * np.cos(0.2 * t) + rng.normal(0, .5, t.size)})
    fig = timeseries(df, "t", ["speed", "iq"],
                     units={"speed": "rpm", "iq": "A"},
                     title="Demo — interactive telemetry")
    add_threshold(fig, 3500, "Overspeed limit")
    open("/tmp/plotly_demo.html", "w").write(
        "<html><body style='background:#FBF7F0'>" + to_embed_html(fig) + "</body></html>")
    print("Wrote /tmp/plotly_demo.html")

def to_resilient_embed(fig, static_svg: str) -> str:
    """
    Embed block that shows a static SVG twin everywhere and upgrades to the
    interactive chart only if plotly.js loads. Pair with one copy of
    RESILIENT_LOADER per page (see references/embedding.md). Use this for
    pages that must render in offline/file-preview contexts (iOS previews,
    sandboxed webviews) where CDN scripts are blocked.
    """
    return (f'<div class="plotly-up" data-plotly>'
            f'<div class="static-twin">{static_svg}</div>'
            f'<script type="application/json">{fig.to_json()}</script></div>')


RESILIENT_LOADER = """
<script>
(function () {
  "use strict";
  var blocks = document.querySelectorAll("[data-plotly]");
  if (!blocks.length) return;
  var s = document.createElement("script");
  s.src = "https://cdn.plot.ly/plotly-2.35.2.min.js";
  s.async = true;
  s.onload = function () {
    blocks.forEach(function (el) {
      try {
        var spec = JSON.parse(
          el.querySelector('script[type=\"application/json\"]').textContent);
        var div = document.createElement("div");
        el.appendChild(div);
        window.Plotly.newPlot(div, spec.data, spec.layout, {
          displaylogo: false, responsive: true,
          modeBarButtonsToRemove: ["lasso2d", "select2d"]
        }).then(function () {
          var twin = el.querySelector(".static-twin");
          if (twin) twin.hidden = true;
        }).catch(function () { div.remove(); });
      } catch (e) { /* static twin stays visible */ }
    });
  };
  s.onerror = function () { /* offline or CDN blocked: twins stay */ };
  document.head.appendChild(s);
})();
</script>
"""
