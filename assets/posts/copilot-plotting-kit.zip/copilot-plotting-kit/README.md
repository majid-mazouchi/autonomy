# Copilot Plotting Kit

Skills and agents for figures, charts, tables, and diagrams in VHM /
diagnostics / prognostics work. Light paper aesthetic throughout
(warm cream canvas, deep ink text, saturated accents). Three-layer
progressive disclosure: frontmatter description (always loaded) →
SKILL.md body (on trigger) → scripts/references (on demand).

## Layout

```
skills/
  plot-style-guide/      Style tokens, apply_style(), save_fig()  ← root dependency
  matplotlib-conventions/ Figure templates, annotation helpers, layout rules
  plotly-interactive/     paper_light template, embed helpers for HTML monographs
  diagnostics-plots/      Spectra, spectrograms, order maps, residuals,
                          confusion/ROC-PR, fault & DTC heatmaps
  prognostics-plots/      RUL fans, alpha-lambda, health index + P-F,
                          fleet spaghetti, Weibull/survival/hazard
  timeseries-telemetry/   Aligned signal stacks, event markers, min-max/LTTB
                          decimation, asammdf notes
  svg-figures/            Diagram builder (boxes/arrows/lanes) + patterns
  tables-formatting/      Styled HTML tables, status cells, heat columns,
                          KPI cards, Word table recipe
  exec-figure-polish/     Decision-grade final pass + pre-flight checklist
  distributions-stats/    Hist+KDE, ECDF, violins, ridgeline, Q-Q,
                          EWMA/CUSUM control charts
  maps-fields-2d/         Efficiency maps + MTPA, flux surfaces (3D policy
                          + contour twins), dwell hexbin
  ml-insights/            Embedding clusters + hulls, silhouette, clustered
                          correlation, feature importance, calibration
  flows-relations/        Waterfall (ROI), Sankey, layered DAG, parallel
                          coordinates
  geo-fleet/              State choropleth rates, incident point maps
agents/
  figure-builder          Data + intent → styled figure + script
  data-explorer           Profile dataset → visualization plan
  figure-critic           Review code + render against skill rules
  report-illustrator      Whole figure sets with manifest + captions
  diagram-architect       Conceptual/architecture diagrams (SVG/Mermaid)
```

## Dependency graph

`plot-style-guide` is the root: every other skill imports its tokens
(`scripts/style_setup.py`) by relative path
(`skills/plot-style-guide/scripts/`). If you relocate skills into your
204-file kit layout, update the `sys.path.insert` lines at the top of each
script (or install style_setup as a tiny local package).

## Install

- Skills: drop `skills/*` into your kit's skills directory; the frontmatter
  name/description format matches SKILL.md conventions (adapt the
  frontmatter keys if your kit uses a different schema).
- Agents: `agents/*.agent.md` use the VS Code custom agent format
  (name/description/tools frontmatter + instructions). Rename to
  `.chatmode.md` and adjust frontmatter if your kit predates the
  `.agent.md` convention.

## Python dependencies

Core: numpy, matplotlib, scipy, pandas, plotly.
Optional: scikit-learn (classifier_eval, ml-insights), asammdf (MDF logs),
lifelines (censored survival data).

```
pip install numpy matplotlib scipy pandas plotly scikit-learn asammdf
```

## Smoke test

Every script has a `__main__` demo with synthetic data:

```
python skills/plot-style-guide/scripts/style_setup.py
python skills/diagnostics-plots/scripts/spectral.py
python skills/prognostics-plots/scripts/rul_fan.py
python skills/timeseries-telemetry/scripts/multisignal.py
python skills/svg-figures/scripts/svg_primitives.py
python skills/tables-formatting/scripts/styled_tables.py
```
