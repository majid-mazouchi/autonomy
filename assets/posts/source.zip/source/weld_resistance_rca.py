"""
weld_resistance_rca.py
==================================================================
Root-cause analysis of a battery-module manufacturing defect:
elevated tab-to-busbar weld interconnect resistance.

Field/EOL symptom: a fraction of modules show interconnect
resistance above the 80 microohm spec limit; in the field these
run hot and drift further, raising thermal-flag and warranty risk.

Process ground truth (the answer key):
  Tab/busbar joints are made by resistance welding. As the weld
  electrode tip wears between dressings, the contact area degrades
  and the weld nugget shrinks, so joint resistance climbs once wear
  passes a knee. Station B runs a LAX dressing interval (4000 welds
  vs ~1500 on A/C), so it reaches deep wear and produces the
  high-resistance joints.

  Confounder: supplier foil lot L2 was routed mostly to Station B
  (logistics happenstance). L2 therefore correlates with the defect
  without causing it - its foil resistivity is within spec.

Ground-truth chain:
  Station B lax dressing -> high electrode wear -> small weld nugget
  -> high interconnect resistance -> field resistance growth / heat.
  (Station B preferentially fed lot L2 = the red-herring proxy.)

Deps: numpy, scipy.
==================================================================
"""
import numpy as np, csv, json
from scipy import stats

rng = np.random.default_rng(31)
N = 600
USL = 80.0          # upper spec limit on interconnect resistance (microohm)
KNEE = 1200         # electrode wear cycles before resistance starts climbing

# ---------- process / data generation (mockup) ----------
# Station assignment (B is the lax-maintenance line).
station = rng.choice(["A", "B", "C"], size=N, p=[0.34, 0.34, 0.32])
dress_interval = {"A": 1500, "B": 4000, "C": 1700}   # welds between tip dressings

# Per-module electrode wear = welds since that station last dressed the tip.
# Modeled as a uniform draw across the station's dressing interval (a
# sawtooth in production order). Station B's lax interval reaches deep wear.
electrode_cycles = np.array([int(rng.uniform(0, dress_interval[s])) for s in station])

# Supplier foil lot: L2 routed mostly to Station B (the confounding link).
p_L2 = np.where(station == "B", 0.80, 0.12)
supplier_lot = np.where(rng.random(N) < p_L2, "L2",
                 np.where(rng.random(N) < 0.5, "L1", "L3"))

# Decoys.
weld_energy = rng.normal(100, 4, N)                  # % nominal, in control
line_speed  = rng.normal(60, 6, N)                   # modules/hr
plant_humidity = rng.normal(45, 8, N)                # %RH

# ---- physics: resistance climbs super-linearly past the wear knee ----
wear_term = np.maximum((electrode_cycles - KNEE) / 1000.0, 0) ** 1.6
lot_resistivity = np.where(supplier_lot == "L2", 1.0,            # in-spec, tiny
                    np.where(supplier_lot == "L1", 0.0, -0.5))
R = (35.0 + 17.0 * wear_term + 0.05 * (weld_energy - 100)
     + lot_resistivity + rng.normal(0, 4.0, N)).clip(20)
defect = (R > USL).astype(int)

# Field degradation: worse welds drift faster (for the prognosis section).
field_growth = (0.6 + 0.05 * np.maximum(R - 50, 0))  # microohm / service-month

fields = ["serial","station","supplier_lot","electrode_cycles","weld_energy_pct",
          "line_speed_mph","plant_humidity_pct","interconnect_R_uohm","defect",
          "field_growth_uohm_mo"]
def write_csv(path="weld_modules.csv"):
    with open(path,"w",newline="") as fh:
        w=csv.writer(fh); w.writerow(fields)
        for i in range(N):
            w.writerow([f"MOD{i:04d}", station[i], supplier_lot[i], int(electrode_cycles[i]),
                round(float(weld_energy[i]),1), round(float(line_speed[i]),1),
                round(float(plant_humidity[i]),1), round(float(R[i]),1), int(defect[i]),
                round(float(field_growth[i]),3)])
    print(f"wrote {path} ({N} rows)")

# ---------- analysis ----------
stationB = (station == "B").astype(float)
lotL2    = (supplier_lot == "L2").astype(float)
y = R
features = {
    "Electrode wear (cyc)": electrode_cycles.astype(float),
    "Station = B":          stationB,
    "Supplier lot = L2":    lotL2,
    "Weld energy (%)":      weld_energy,
    "Line speed":           line_speed,
    "Plant humidity":       plant_humidity,
}
def pearson(x): r,p=stats.pearsonr(x,y); return round(float(r),3), float(p)
def partial(x,z):
    rx=x-np.polyval(np.polyfit(z,x,1),z); ry=y-np.polyval(np.polyfit(z,y,1),z)
    r,p=stats.pearsonr(rx,ry); return round(float(r),3), float(p)
def reg(cols):
    X=np.column_stack([np.ones(N)]+cols); b,*_=np.linalg.lstsq(X,y,rcond=None)
    r2=1-np.sum((y-X@b)**2)/np.sum((y-y.mean())**2); return b, round(float(r2),3)

raw = {k:pearson(v) for k,v in features.items()}
part_wear = {k:partial(v, electrode_cycles.astype(float)) for k,v in features.items()
             if k!="Electrode wear (cyc)"}
wear_ctrl_lot = partial(electrode_cycles.astype(float), lotL2)
b1,r2_1 = reg([lotL2])
b2,r2_2 = reg([lotL2, stationB])
b3,r2_3 = reg([lotL2, stationB, wear_term])

# ---- Cpk (one-sided, USL) before vs after tighter dressing ----
def cpk(vals): return round(float((USL - vals.mean())/(3*vals.std())), 2)
cpk_before = cpk(R)
defect_before = round(float(defect.mean()), 3)
# "after": cap dressing interval at 1500 on all stations -> wear ~U(0,1500)
cyc_after = rng.uniform(0, 1500, N)
R_after = (35 + 17*np.maximum((cyc_after-KNEE)/1000,0)**1.6 + rng.normal(0,4,N)).clip(20)
cpk_after = cpk(R_after); defect_after = round(float((R_after>USL).mean()),3)

# ---- Pareto: defect counts by station and by lot ----
pareto_station = {s:int(defect[station==s].sum()) for s in ["A","B","C"]}
pareto_lot     = {l:int(defect[supplier_lot==l].sum()) for l in ["L1","L2","L3"]}

# ---- control-chart sawtooth for Station B (production-ordered) ----
# Wear climbs each weld and resets at every dressing -> classic tooling
# sawtooth; resistance tracks it and breaches spec near the top of each ramp.
nseq = 150; step = 4000 / 48          # ~3 dressing cycles across the window
saw_cyc, saw_R, saw_resets = [], [], []
w = 0.0
for k in range(nseq):
    w += step
    if w >= 4000:
        w = 0.0; saw_resets.append(k)
    rr = 35 + 17*max((w-KNEE)/1000,0)**1.6 + rng.normal(0,3)
    saw_cyc.append(round(w)); saw_R.append(round(float(rr),1))
saw = {"cyc":saw_cyc, "R":saw_R, "resets":saw_resets, "step":round(step,1)}

# ---- weld strength vs wear (metallurgical confirmation) ----
cyc_axis = list(range(0, 4001, 250))
pull_strength = [round(float(max(100 - 13*max((c-KNEE)/1000,0)**1.5, 20)),1) for c in cyc_axis]
R_curve = [round(float(35 + 17*max((c-KNEE)/1000,0)**1.6),1) for c in cyc_axis]

# ---- scatter samples ----
idx = rng.choice(N, 220, replace=False)
def stn(s): return {"A":0,"B":1,"C":2}[s]
sc_wear = [[int(electrode_cycles[i]), round(float(R[i]),1), stn(station[i])] for i in idx]
mean_R_lot = {l:round(float(R[supplier_lot==l].mean()),1) for l in ["L1","L2","L3"]}
mean_R_stn = {s:round(float(R[station==s].mean()),1) for s in ["A","B","C"]}

# ---- prognosis ----
# (a) defect escape vs dressing interval
intervals = list(range(800, 4201, 200))
escape = []
for D in intervals:
    c = rng.uniform(0, D, 4000)
    rr = 35 + 17*np.maximum((c-KNEE)/1000,0)**1.6 + rng.normal(0,4,4000)
    escape.append(round(float((rr>USL).mean()),4))
# (b) field thermal-flag probability over service months
def field_pof(screen):
    Reol = R_after.copy() if False else R.copy()
    keep = Reol <= USL if screen else np.ones(N,bool)   # screen removes above-spec
    sub = Reol[keep]; gr = (0.6+0.05*np.maximum(sub-50,0))
    months = list(range(0,49,3)); FLAG=200.0
    pof=[]
    for m in months:
        rf = sub + gr*m + rng.normal(0,5,len(sub))
        pof.append(round(float(np.mean(rf>FLAG)),3))
    return months, pof
months, pof_unscreened = field_pof(False)
_, pof_screened = field_pof(True)

out = {
  "N":N, "USL":USL, "KNEE":KNEE,
  "raw":{k:{"r":v[0],"p":v[1]} for k,v in raw.items()},
  "partial_ctrl_wear":{k:{"r":v[0],"p":v[1]} for k,v in part_wear.items()},
  "wear_ctrl_lot":{"r":wear_ctrl_lot[0],"p":wear_ctrl_lot[1]},
  "reg":{"m1_lot":round(float(b1[1]),3),"m1_r2":r2_1,
         "m2_lot":round(float(b2[1]),3),"m2_stn":round(float(b2[2]),3),"m2_r2":r2_2,
         "m3_lot":round(float(b3[1]),3),"m3_stn":round(float(b3[2]),3),"m3_r2":r2_3},
  "pareto_station":pareto_station, "pareto_lot":pareto_lot,
  "saw":saw, "sat_curve":{"cyc":cyc_axis,"pull":pull_strength,"R":R_curve},
  "scatter_wear":sc_wear, "mean_R_lot":mean_R_lot, "mean_R_stn":mean_R_stn,
  "cpk":{"before":cpk_before,"after":cpk_after,"defect_before":defect_before,
         "defect_after":defect_after},
  "hist_before":None,"hist_after":None,
  "prog":{"intervals":intervals,"escape":escape,"months":months,
          "pof_unscreened":pof_unscreened,"pof_screened":pof_screened},
  "strat":{"B_meanR":mean_R_stn["B"],"AC_meanR":round((mean_R_stn["A"]+mean_R_stn["C"])/2,1),
           "B_defect":round(float(defect[station=='B'].mean()),3),
           "AC_defect":round(float(defect[(station!='B')].mean()),3)},
}
# histograms for Cpk figure
def hist(vals):
    edges=list(range(20,151,10)); h,_=np.histogram(vals,bins=edges)
    return {"edges":edges,"h":[int(x) for x in h]}
out["hist_before"]=hist(R); out["hist_after"]=hist(R_after)

if __name__=="__main__":
    write_csv(); json.dump(out, open("manuf_data.json","w")); print("wrote manuf_data.json\n")
    print("RAW correlation vs interconnect R:")
    for k,(r,p) in raw.items(): print(f"  {k:22s} r={r:+.3f} p={p:.1e}")
    print("\nPARTIAL (controlling for electrode wear):")
    for k,(r,p) in part_wear.items(): print(f"  {k:22s} r={r:+.3f} p={p:.2f}")
    print(f"\nwear controlling for lot: r={wear_ctrl_lot[0]:+.3f} p={wear_ctrl_lot[1]:.1e}")
    print(f"\nReg R^2: lot={r2_1}  +station={r2_2}  +wear={r2_3}")
    print(f"  lot coef:  m1={b1[1]:+.2f} -> m3={b3[1]:+.2f}   stn coef: m2={b2[2]:+.2f} -> m3={b3[2]:+.2f}")
    print(f"\nCpk before={cpk_before} (defect {defect_before:.1%})  after={cpk_after} (defect {defect_after:.1%})")
    print(f"Stratify: Station B meanR={mean_R_stn['B']} (defect {out['strat']['B_defect']:.1%})  "
          f"A/C meanR={out['strat']['AC_meanR']} (defect {out['strat']['AC_defect']:.1%})")
    print(f"Pareto by station: {pareto_station}   by lot: {pareto_lot}")
