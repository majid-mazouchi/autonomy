"""
brake_corrosion_rca.py
==================================================================
Root-cause analysis of a usage/behavior defect: friction-brake
rotor corrosion and "brake performance" complaints in an EV fleet.

Field symptom: complaints of grinding/groaning brake noise, visible
rotor rust, and reduced initial braking bite (until a few hard stops
scrub the rotors clean). Some vehicles flagged for rotor corrosion at
service.

Usage ground truth (the answer key):
  Drivers who use one-pedal / high-regen driving apply the FRICTION
  brakes very rarely, so the rotor faces are never scrubbed and a
  surface rust layer accumulates. Humidity/salt accelerate it, but
  the dominant driver is DISUSE - low friction-brake apply frequency.

  Confounder: rotor supplier lot "Lr" was fitted mostly to the
  Efficiency trim (one-pedal default), so the lot correlates with
  corrosion without causing it - rotor metallurgy is in spec.

Ground-truth chain:
  one-pedal usage -> friction brakes rarely applied -> rotor face not
  scrubbed -> surface corrosion accumulates (x humidity) -> noise /
  reduced bite / service flag.
  (lot Lr fitted to the Efficiency trim = the red-herring proxy.)

Deps: numpy, scipy.
==================================================================
"""
import numpy as np, csv, json
from scipy import stats

rng = np.random.default_rng(53)
N = 500
FLAG = 35.0           # corrosion-index threshold for a brake-service flag
APPLY0 = 3.0          # applies/100km above which rotors stay scrubbed

# ---------- usage / data generation ----------
trim_eff = (rng.random(N) < 0.45).astype(int)        # Efficiency = one-pedal default

# Friction-brake apply frequency (hard applies / 100 km): low for one-pedal.
apply_freq = np.where(trim_eff == 1, rng.normal(0.6, 0.3, N),
                                     rng.normal(2.6, 0.8, N)).clip(0.05)
regen_fraction = np.where(trim_eff == 1, rng.normal(0.85, 0.05, N),
                                         rng.normal(0.55, 0.10, N)).clip(0, 0.98)

# Rotor lot Lr fitted mostly to the Efficiency trim (the confounder link).
p_Lr = np.where(trim_eff == 1, 0.78, 0.20)
rotor_lot = np.where(rng.random(N) < p_Lr, "Lr",
              np.where(rng.random(N) < 0.5, "La", "Lb"))

# Environmental accelerant (humid/coastal) and exposure.
humid = (rng.random(N) < 0.4).astype(int)
humidity_norm = np.where(humid == 1, rng.uniform(0.5, 1.0, N), rng.uniform(0.0, 0.5, N))
annual_km = rng.normal(15000, 4000, N).clip(2000)
# distance since last scrubbing hard stop (long for one-pedal drivers)
km_since_scrub = (np.minimum(100.0/apply_freq, 400) * rng.uniform(0.3, 1.0, N))

# ---- mechanism: rust accumulates when friction brakes are underused ----
deficit = np.maximum(APPLY0 - apply_freq, 0)          # apply-frequency deficit
lotLr = (rotor_lot == "Lr").astype(float)
corrosion = (5 + 16*deficit**1.3*(0.5 + humidity_norm)
             + 0.5*lotLr + rng.normal(0, 3, N)).clip(0, 100)
flag = (corrosion > FLAG).astype(int)

fields = ["vin","trim_efficiency","apply_freq_per100km","regen_fraction","rotor_lot",
          "humidity_norm","annual_km","km_since_scrub","corrosion_index","service_flag"]
def write_csv(path="brake_fleet.csv"):
    with open(path,"w",newline="") as fh:
        w=csv.writer(fh); w.writerow(fields)
        for i in range(N):
            w.writerow([f"VIN{i:04d}", int(trim_eff[i]), round(float(apply_freq[i]),2),
                round(float(regen_fraction[i]),2), rotor_lot[i], round(float(humidity_norm[i]),2),
                int(annual_km[i]), round(float(km_since_scrub[i]),1),
                round(float(corrosion[i]),1), int(flag[i])])
    print(f"wrote {path} ({N} rows)")

# ---------- analysis ----------
y = corrosion
features = {
    "Brake apply freq":   apply_freq,
    "Regen fraction":     regen_fraction,
    "Efficiency trim":    trim_eff.astype(float),
    "Rotor lot = Lr":     lotLr,
    "Humidity":           humidity_norm,
    "Annual km":          annual_km,
}
def pearson(x): r,p=stats.pearsonr(x,y); return round(float(r),3), float(p)
def partial(x,z):
    rx=x-np.polyval(np.polyfit(z,x,1),z); ry=y-np.polyval(np.polyfit(z,y,1),z)
    r,p=stats.pearsonr(rx,ry); return round(float(r),3), float(p)
def reg(cols):
    X=np.column_stack([np.ones(N)]+cols); b,*_=np.linalg.lstsq(X,y,rcond=None)
    r2=1-np.sum((y-X@b)**2)/np.sum((y-y.mean())**2); return b, round(float(r2),3)

raw = {k:pearson(v) for k,v in features.items()}
part_apply = {k:partial(v, apply_freq) for k,v in features.items()
              if k in ("Rotor lot = Lr","Efficiency trim","Humidity")}
apply_ctrl_lot = partial(apply_freq, lotLr)
b1,r2_1 = reg([lotLr])
b2,r2_2 = reg([lotLr, humidity_norm])
b3,r2_3 = reg([lotLr, humidity_norm, deficit])

# ---- Pareto by rotor lot (flag counts) ----
pareto_lot = {l:int(flag[rotor_lot==l].sum()) for l in ["La","Lb","Lr"]}

# ---- corrosion vs apply frequency (binned, humid vs dry) ----
abins = np.linspace(0, 4, 13)
def binned(mask):
    out=[]
    for i in range(len(abins)-1):
        sel=mask&(apply_freq>=abins[i])&(apply_freq<abins[i+1])
        out.append(round(float(corrosion[sel].mean()),1) if sel.sum()>=2 else None)
    return out
apply_curve = {"x":[round((abins[i]+abins[i+1])/2,2) for i in range(len(abins)-1)],
               "humid":binned(humid==1), "dry":binned(humid==0)}

# ---- disuse sawtooth: corrosion vs km since last scrub (Efficiency vehicle) ----
nseq=150; saw_km=[]; saw_c=[]; saw_resets=[]; km=0.0
for k in range(nseq):
    km += rng.uniform(8, 22)
    if rng.random() < 0.06:                # occasional hard stop scrubs the rotor
        km = rng.uniform(0, 10); saw_resets.append(k)
    c = 5 + 0.32*km*(0.5+0.8) + rng.normal(0,2)
    saw_km.append(round(km,1)); saw_c.append(round(float(max(c,3)),1))
saw = {"km":saw_km, "c":saw_c, "resets":saw_resets}

# ---- scatter apply vs corrosion ----
idx = rng.choice(N, 240, replace=False)
sc_apply = [[round(float(apply_freq[i]),2), round(float(corrosion[i]),1), int(trim_eff[i])] for i in idx]

# ---- prognosis ----
ax = list(np.linspace(0.1, 4, 28))
suscept = [round(float(1/(1+np.exp((a-1.4)/0.35))),3) for a in ax]   # P(flag) vs apply freq
def annual(scrub):
    days=365; g=np.random.default_rng(9)
    # low-apply cohort; auto-scrub resets corrosion periodically
    ks=np.zeros(366); flagdays=[]
    cum=[]; c=8.0; flagged=0; months=list(range(0,13))
    series=np.zeros(366)
    for d in range(1,366):
        c += g.normal(0.45,0.1)*(0.5+0.7)        # daily rust accrual (humid-ish)
        if scrub and d % 14 == 0:                # auto brake-scrub every 2 weeks
            c = max(c-30, 5)
        series[d]=c
    for mo in months:
        cum.append(int((series[:int(mo*30.4)+1] > FLAG).sum()))
    return months, cum
months, cum_noscrub = annual(False)
_, cum_scrub = annual(True)

out = {
  "N":N, "FLAG":FLAG, "APPLY0":APPLY0,
  "raw":{k:{"r":v[0],"p":v[1]} for k,v in raw.items()},
  "partial_apply":{k:{"r":v[0],"p":v[1]} for k,v in part_apply.items()},
  "apply_ctrl_lot":{"r":apply_ctrl_lot[0],"p":apply_ctrl_lot[1]},
  "reg":{"m1_lot":round(float(b1[1]),3),"m1_r2":r2_1,
         "m2_lot":round(float(b2[1]),3),"m2_r2":r2_2,
         "m3_lot":round(float(b3[1]),3),"m3_def":round(float(b3[3]),3),"m3_r2":r2_3},
  "pareto_lot":pareto_lot, "apply_curve":apply_curve, "saw":saw, "scatter_apply":sc_apply,
  "prog":{"ax":[round(a,2) for a in ax],"suscept":suscept,
          "months":months,"cum_noscrub":cum_noscrub,"cum_scrub":cum_scrub},
  "strat":{"eff_corr":round(float(corrosion[trim_eff==1].mean()),1),
           "std_corr":round(float(corrosion[trim_eff==0].mean()),1),
           "eff_flag":round(float(flag[trim_eff==1].mean()),3),
           "std_flag":round(float(flag[trim_eff==0].mean()),3),
           "eff_apply":round(float(apply_freq[trim_eff==1].mean()),2),
           "std_apply":round(float(apply_freq[trim_eff==0].mean()),2),
           "flag_rate":round(float(flag.mean()),3)},
}

if __name__=="__main__":
    write_csv(); json.dump(out, open("usage_data.json","w")); print("wrote usage_data.json\n")
    print("RAW correlation vs corrosion:")
    for k,(r,p) in raw.items(): print(f"  {k:20s} r={r:+.3f} p={p:.1e}")
    print("\nPARTIAL (controlling for apply frequency):")
    for k,(r,p) in part_apply.items(): print(f"  {k:20s} r={r:+.3f} p={p:.2f}")
    print(f"\napply-freq controlling for lot: r={apply_ctrl_lot[0]:+.3f} p={apply_ctrl_lot[1]:.1e}")
    print(f"\nReg R^2: lot={r2_1}  +humidity={r2_2}  +apply-deficit={r2_3}")
    print(f"  lot coef: m1={b1[1]:+.2f} -> m3={b3[1]:+.2f}")
    print(f"\nStratify: Efficiency corr={out['strat']['eff_corr']} (flag {out['strat']['eff_flag']:.0%}, apply {out['strat']['eff_apply']})  "
          f"Standard corr={out['strat']['std_corr']} (flag {out['strat']['std_flag']:.0%}, apply {out['strat']['std_apply']})")
    print(f"Pareto by lot: {pareto_lot}")
    print(f"Annual flag-days low-apply: no-scrub={cum_noscrub[-1]}  auto-scrub={cum_scrub[-1]}")
