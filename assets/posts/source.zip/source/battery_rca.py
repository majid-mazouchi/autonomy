"""
battery_rca.py
================================================================
Root-Cause Analysis worked example — EV battery SOH degradation.

Companion code for the monograph "The Anatomy of a Root Cause".
It (1) generates a synthetic 240-vehicle fleet with a KNOWN ground
truth, (2) writes it to fleet.csv as the mockup data source, and
(3) runs the full diagnostic pipeline: correlation screen ->
partial correlation -> regression -> firmware stratification.

Ground-truth causal chain baked into the simulation:

    firmware v3.2.1 bug -> cell balancing fails -> cell voltage
    spread (dV) grows -> weak cell over-volts each charge ->
    accelerated SOH fade.

    The same buggy build also shipped an aggressive DC-charge
    default, so its cars fast-charge MORE. Fast-charging is
    therefore a CONFOUNDED proxy for the firmware bug, not a
    cause of fade. Ambient temperature is a genuine but MODEST
    secondary cause (Arrhenius).

Dependencies: numpy, scipy  (matplotlib optional, for figures).
================================================================
"""

import numpy as np
import csv
from scipy import stats

rng = np.random.default_rng(7)   # fixed seed -> reproducible fleet
N = 240

# === SECTION: data-generation (the mockup data source) ===========
# Each block below is one edge of the ground-truth causal graph.

# Root upstream cause: ~42% of the fleet runs the buggy build v3.2.1.
firmware_buggy = (rng.random(N) < 0.42).astype(int)

# Confounding link: the buggy build also shipped an aggressive DC
# fast-charge default, so those cars fast-charge more often.
# (This is why fast-charging will LOOK guilty but cause nothing.)
fast_charge_pm = np.where(firmware_buggy == 1,
                          rng.normal(15, 3.0, N),
                          rng.normal(6, 2.5, N)).clip(0)

# Ambient temperature: set by the owner's climate, independent of
# firmware. ~40% of owners live in a warm region.
region_warm = (rng.random(N) < 0.40).astype(int)
ambient_C = np.where(region_warm == 1,
                     rng.normal(31, 3.0, N),
                     rng.normal(18, 4.0, N))

# Nuisance / secondary features.
age_months  = rng.uniform(6, 36, N)
cycle_count = age_months * rng.normal(38, 6, N)        # cycles grow with age
soc_dwell   = rng.uniform(5, 60, N)                    # % time parked > 80% SOC

# THE bridging variable: post-charge cell-voltage spread dV (mV).
# Driven almost entirely by the firmware bug; tiny aging term.
cell_imbalance_mV = (
    np.where(firmware_buggy == 1, rng.normal(52, 8, N),
                                  rng.normal(6, 2.5, N))
    + 0.004 * cycle_count
    + rng.normal(0, 2.5, N)
).clip(2)

# OUTCOME: annualized SOH fade rate (%/yr).
# TRUE drivers = dV (dominant) + ambient (modest) + cycling (small).
# NOTE: fast_charge_pm has NO coefficient here -> any correlation it
# shows with fade is pure confounding through the firmware build.
degr_rate = (
    1.8
    + 0.075 * cell_imbalance_mV
    + 0.075 * np.maximum(ambient_C - 20, 0)
    + 0.0010 * cycle_count
    + rng.normal(0, 0.45, N)
).clip(0.5)

# Convenience: SOH after 24 months under the current fade rate.
soh_24mo = (100 - degr_rate * 2.0).clip(60)

# Assemble the table and write the mockup data source to CSV.
fields = ["vin", "firmware_v321", "fast_charge_per_mo", "ambient_C",
          "age_months", "cycle_count", "soc_dwell_pct",
          "cell_imbalance_mV", "fade_rate_pct_yr", "soh_24mo_pct"]

def write_csv(path="fleet.csv"):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(fields)
        for i in range(N):
            w.writerow([
                f"VIN{i:04d}", int(firmware_buggy[i]),
                round(float(fast_charge_pm[i]), 2), round(float(ambient_C[i]), 2),
                round(float(age_months[i]), 1), round(float(cycle_count[i]), 0),
                round(float(soc_dwell[i]), 1), round(float(cell_imbalance_mV[i]), 1),
                round(float(degr_rate[i]), 3), round(float(soh_24mo[i]), 2),
            ])
    print(f"wrote {path}  ({N} rows)")
# === END SECTION: data-generation ================================


# === SECTION: analysis (the diagnostic pipeline) =================
features = {
    "Cell imbalance dV (mV)":  cell_imbalance_mV,
    "Fast-charge events / mo": fast_charge_pm,
    "Ambient temp (C)":        ambient_C,
    "Cycle count":             cycle_count,
    "High-SOC dwell (%)":      soc_dwell,
    "Age (months)":            age_months,
}

def correlation_screen(y):
    """Step 1 - rank candidates by raw Pearson correlation."""
    print("\n[1] RAW correlation vs fade rate")
    for name, x in features.items():
        r, p = stats.pearsonr(x, y)
        print(f"    {name:24s}  r={r:+.3f}  p={p:.1e}")

def partial_corr(x, y, z):
    """corr(x, y) with the linear effect of z removed from both.
    True causes survive this; confounded proxies collapse."""
    rx = x - np.polyval(np.polyfit(z, x, 1), z)   # residual of x | z
    ry = y - np.polyval(np.polyfit(z, y, 1), z)   # residual of y | z
    return stats.pearsonr(rx, ry)

def partial_screen(y, control, control_name):
    print(f"\n[2] PARTIAL correlation (controlling for {control_name})")
    for name, x in features.items():
        if x is control:
            continue
        r, p = partial_corr(x, y, control)
        verdict = "survives" if abs(r) > 0.3 and p < 0.05 else "COLLAPSES"
        print(f"    {name:24s}  r={r:+.3f}  p={p:.2f}   {verdict}")

def regression(y):
    """Step 3 - watch the fast-charge coefficient die when dV enters."""
    def fit(cols):
        X = np.column_stack([np.ones(N)] + cols)
        b, *_ = np.linalg.lstsq(X, y, rcond=None)
        pred = X @ b
        r2 = 1 - np.sum((y - pred)**2) / np.sum((y - y.mean())**2)
        return b, r2
    b1, r2_1 = fit([fast_charge_pm, ambient_C])
    b2, r2_2 = fit([fast_charge_pm, ambient_C, cell_imbalance_mV])
    print("\n[3] REGRESSION")
    print(f"    naive  fade~fc+amb        : fc_coef={b1[1]:+.3f}  R2={r2_1:.3f}")
    print(f"    full   fade~fc+amb+dV     : fc_coef={b2[1]:+.3f}  "
          f"dV_coef={b2[3]:+.3f}  R2={r2_2:.3f}")

def stratify(y):
    """Step 4 - follow the chain upstream to the firmware build."""
    bug = firmware_buggy == 1
    print("\n[4] FIRMWARE STRATIFICATION")
    print(f"    v3.2.1 (buggy) : dV={cell_imbalance_mV[bug].mean():5.1f} mV   "
          f"fade={degr_rate[bug].mean():.2f} %/yr   (n={bug.sum()})")
    print(f"    other builds   : dV={cell_imbalance_mV[~bug].mean():5.1f} mV   "
          f"fade={degr_rate[~bug].mean():.2f} %/yr   (n={(~bug).sum()})")
# === END SECTION: analysis =======================================


# === SECTION: figures (optional, needs matplotlib) ===============
def make_figures():
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib not installed - skipping figures")
        return
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    bug = firmware_buggy == 1
    ax[0].scatter(fast_charge_pm[bug], degr_rate[bug], s=14, alpha=.6, label="v3.2.1")
    ax[0].scatter(fast_charge_pm[~bug], degr_rate[~bug], s=14, alpha=.6, label="other")
    ax[0].set(xlabel="fast-charge / mo", ylabel="fade %/yr",
              title="Confounded: strong but spurious")
    ax[0].legend()
    ax[1].scatter(cell_imbalance_mV[bug], degr_rate[bug], s=14, alpha=.6)
    ax[1].scatter(cell_imbalance_mV[~bug], degr_rate[~bug], s=14, alpha=.6)
    ax[1].set(xlabel="cell dV (mV)", ylabel="fade %/yr",
              title="Causal: survives + has mechanism")
    fig.tight_layout(); fig.savefig("rca_scatters.png", dpi=130)
    print("wrote rca_scatters.png")
# === END SECTION: figures ========================================


# === SECTION: prognosis (Monte Carlo failure prediction) =========
def prognose(mean_rate, soh_now=91.0, eol=80.0, horizon=48,
             npath=4000, rate_sd=1.0, proc=0.15, seed=11):
    """Simulate future SOH paths and predict time-to-failure (RUL).

    Each path draws its own annualized fade rate (parameter
    uncertainty) and accrues monthly fade with process noise, then
    we record when SOH crosses the end-of-life threshold."""
    g = np.random.default_rng(seed)
    rates = g.normal(mean_rate, rate_sd, npath).clip(0.5)
    soh = np.full(npath, soh_now)
    rul = np.full(npath, np.nan)
    for m in range(1, horizon + 1):
        soh = soh - np.maximum(g.normal(rates / 12.0, proc), 0)
        crossed = (soh <= eol) & np.isnan(rul)
        rul[crossed] = m
    rul[np.isnan(rul)] = horizon            # censored at horizon
    return dict(median=float(np.median(rul)),
                ci80=(float(np.percentile(rul, 10)),
                      float(np.percentile(rul, 90))),
                pof_24mo=float(np.mean(rul <= 24)))

def run_prognosis():
    print("\n[5] PROGNOSIS (Monte Carlo, vehicle at 91% SOH)")
    for label, rate in [("no fix ", degr_rate[firmware_buggy == 1].mean()),
                        ("OTA fix", degr_rate[firmware_buggy == 0].mean())]:
        r = prognose(rate, rate_sd=1.1 if "no" in label else 0.7)
        print(f"    {label}: median RUL={r['median']:.0f} mo  "
              f"80% CI=[{r['ci80'][0]:.0f},{r['ci80'][1]:.0f}]  "
              f"P(fail<24mo)={r['pof_24mo']:.0%}")
# === END SECTION: prognosis ======================================


if __name__ == "__main__":
    write_csv()
    correlation_screen(degr_rate)
    partial_screen(degr_rate, cell_imbalance_mV, "cell dV")     # confounder test
    partial_screen(degr_rate, fast_charge_pm, "fast-charge")    # mirror test
    regression(degr_rate)
    stratify(degr_rate)
    run_prognosis()
    make_figures()
