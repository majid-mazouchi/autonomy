"""
isolation_fault_rca.py
==================================================================
Root-cause analysis of intermittent HV isolation-resistance faults
in an EV fleet (Insulation Monitoring Device / IMD trips).

Field symptom: the IMD intermittently reports isolation resistance
(Riso) below the safety threshold, logging an isolation DTC and
sometimes refusing to charge/drive. Faults are transient - they
clear as the day warms - and cluster in humid/coastal regions and
at dawn.

Environmental ground truth (the answer key):
  Overnight radiative cooling drops connector surface temperature
  below the dew point, so a thin moisture film condenses across the
  HV connector creepage path. Coastal salt makes that film ionically
  conductive. The film bridges HV to chassis, dropping Riso below the
  threshold. It is an ENVIRONMENTAL ingress/condensation issue, not a
  component defect.

  Confounder: connector supplier lot "Lc" was allocated mostly to
  coastal dealers, so the lot correlates with the fault without
  causing it - the connector material/resistivity is in spec.

Ground-truth chain:
  humid + coastal -> surface temp < dew point -> condensation film
  + salt -> conductive bridge -> Riso down -> isolation fault.
  (lot Lc shipped to coastal dealers = the red-herring proxy.)

Deps: numpy, scipy.
==================================================================
"""
import numpy as np, csv, json
from scipy import stats

rng = np.random.default_rng(41)
N = 500
THRESH = 0.5          # isolation-fault threshold on Riso (megaohm)

# ---------- environment / data generation ----------
coastal = (rng.random(N) < 0.42).astype(int)

# Connector lot Lc allocated mostly to coastal dealers (the confounder link).
p_Lc = np.where(coastal == 1, 0.75, 0.18)
connector_lot = np.where(rng.random(N) < p_Lc, "Lc",
                  np.where(rng.random(N) < 0.5, "La", "Lb"))

# Weather at the measurement (a morning telematics reading).
RH = np.where(coastal == 1, rng.normal(80, 10, N), rng.normal(58, 13, N)).clip(20, 100)
ambient_C = np.where(coastal == 1, rng.normal(16, 6, N), rng.normal(13, 8, N))
time_of_day = rng.uniform(0, 24, N)            # hour

# Overnight radiative cooling: surface dips below ambient, deepest near dawn.
cooling = 5.0 * np.exp(-((time_of_day - 5.5) ** 2) / (2 * 2.4 ** 2))
surface_C = ambient_C - cooling - rng.normal(0, 0.6, N)

# Dew point (simple Magnus-style approximation) and the key driver: margin.
dewpoint_C = ambient_C - (100 - RH) / 5.0
dewpoint_margin = surface_C - dewpoint_C        # < 0 => condensation

# Salt loading: coastal + winter road salt.
salt_index = (np.where(coastal == 1, rng.uniform(0.4, 1.0, N), rng.uniform(0.0, 0.25, N))
              + rng.normal(0, 0.05, N)).clip(0)

# ---- physics: condensation film bridges the creepage path ----
film = 1.0/(1.0 + np.exp(dewpoint_margin/1.5)) + 0.15*np.maximum((RH-70)/30, 0)
RCLEAN = 20.0                                   # dry isolation resistance (Mohm)
Riso = (RCLEAN / (1 + 60*film*(1 + 1.5*salt_index)) + rng.normal(0, 0.05, N)).clip(0.02)
fault = (Riso < THRESH).astype(int)

field_clears = (dewpoint_margin < 0)            # transient: clears when it dries

fields = ["vin","coastal","connector_lot","RH_pct","ambient_C","surface_C",
          "dewpoint_C","dewpoint_margin_C","salt_index","time_of_day_h",
          "Riso_Mohm","isolation_fault"]
def write_csv(path="isolation_events.csv"):
    with open(path,"w",newline="") as fh:
        w=csv.writer(fh); w.writerow(fields)
        for i in range(N):
            w.writerow([f"VIN{i:04d}", int(coastal[i]), connector_lot[i],
                round(float(RH[i]),1), round(float(ambient_C[i]),1), round(float(surface_C[i]),1),
                round(float(dewpoint_C[i]),1), round(float(dewpoint_margin[i]),2),
                round(float(salt_index[i]),3), round(float(time_of_day[i]),1),
                round(float(Riso[i]),3), int(fault[i])])
    print(f"wrote {path} ({N} rows)")

# ---------- analysis ----------
lotLc = (connector_lot == "Lc").astype(float)
y = Riso
features = {
    "Dewpoint margin (C)": dewpoint_margin,
    "Relative humidity":   RH,
    "Salt index":          salt_index,
    "Connector lot = Lc":  lotLc,
    "Coastal":             coastal.astype(float),
    "Ambient temp (C)":    ambient_C,
}
def pearson(x): r,p=stats.pearsonr(x,y); return round(float(r),3), float(p)
def partial_multi(x, Z):
    Z1=np.column_stack([np.ones(N)]+Z)
    bx,*_=np.linalg.lstsq(Z1,x,rcond=None); rx=x-Z1@bx
    by,*_=np.linalg.lstsq(Z1,y,rcond=None); ry=y-Z1@by
    r,p=stats.pearsonr(rx,ry); return round(float(r),3), float(p)
def reg(cols):
    X=np.column_stack([np.ones(N)]+cols); b,*_=np.linalg.lstsq(X,y,rcond=None)
    r2=1-np.sum((y-X@b)**2)/np.sum((y-y.mean())**2); return b, round(float(r2),3)

raw = {k:pearson(v) for k,v in features.items()}
ENV = [dewpoint_margin, salt_index, RH]                 # the environmental set
part_env = {k:partial_multi(v, ENV) for k,v in features.items()
            if k in ("Connector lot = Lc","Coastal")}
dm_ctrl_lot = partial_multi(dewpoint_margin, [lotLc])
b1,r2_1 = reg([lotLc])
b2,r2_2 = reg([lotLc, RH])
b3,r2_3 = reg([lotLc, RH, dewpoint_margin, salt_index])

# ---- diurnal fault clustering (the signature) ----
hours = list(range(0,24,2))
diurnal = []
for h in hours:
    m = (time_of_day>=h)&(time_of_day<h+2)
    diurnal.append(round(float(fault[m].mean()) if m.sum()>0 else 0.0, 3))

# ---- Riso vs dewpoint margin, coastal vs inland (binned) ----
mbins = np.linspace(-6, 8, 15)
def binned(mask):
    out=[]
    for i in range(len(mbins)-1):
        sel=mask&(dewpoint_margin>=mbins[i])&(dewpoint_margin<mbins[i+1])
        out.append(round(float(Riso[sel].mean()),3) if sel.sum()>=2 else None)
    return out
margin_curve = {"x":[round((mbins[i]+mbins[i+1])/2,2) for i in range(len(mbins)-1)],
                "coastal":binned(coastal==1), "inland":binned(coastal==0)}

# ---- Pareto by connector lot (defect counts) ----
pareto_lot = {l:int(fault[connector_lot==l].sum()) for l in ["La","Lb","Lc"]}

# ---- scatters ----
idx = rng.choice(N, 240, replace=False)
sc_margin = [[round(float(dewpoint_margin[i]),2), round(float(Riso[i]),3), int(coastal[i])] for i in idx]

# ---- prognosis ----
# (a) fault susceptibility vs dewpoint margin (logistic over the fleet)
mx = list(np.linspace(-6,8,29))
suscept = []
for m in mx:
    f = 1.0/(1.0+np.exp(m/1.5)) + 0.12
    rr = RCLEAN/(1+60*f*(1+1.5*0.6))            # coastal-salt reference
    suscept.append(round(float(rr<THRESH)*1.0,3) if False else round(float(1/(1+np.exp((m+1.0)/1.0))),3))
# (b) annual nuisance-fault days: coastal vehicle, unmitigated vs hydrophobic coating
def annual(coat):
    days=365; g=np.random.default_rng(7)
    amb=g.normal(15,7,days); rh=g.normal(78,12,days).clip(20,100)
    cool=g.normal(3.2,2.3,days).clip(0); surf=amb-cool   # clear vs cloudy nights
    dp=amb-(100-rh)/5; marg=surf-dp
    film=1/(1+np.exp(marg/1.5))+0.15*np.maximum((rh-70)/30,0)
    a = 60*(0.25 if coat else 1.0)              # coating cuts film coupling
    riso=RCLEAN/(1+a*film*(1+1.5*0.6))
    flt=riso<THRESH
    # cumulative monthly
    months=list(range(0,13)); cum=[]
    for mo in months:
        cum.append(int(flt[:int(mo*30.4)].sum()))
    return months, cum
months, cum_unmit = annual(False)
_, cum_mit = annual(True)

out = {
  "N":N, "THRESH":THRESH,
  "raw":{k:{"r":v[0],"p":v[1]} for k,v in raw.items()},
  "partial_env":{k:{"r":v[0],"p":v[1]} for k,v in part_env.items()},
  "dm_ctrl_lot":{"r":dm_ctrl_lot[0],"p":dm_ctrl_lot[1]},
  "reg":{"m1_lot":round(float(b1[1]),3),"m1_r2":r2_1,
         "m2_lot":round(float(b2[1]),3),"m2_r2":r2_2,
         "m3_lot":round(float(b3[1]),3),"m3_dm":round(float(b3[3]),3),"m3_r2":r2_3},
  "diurnal":{"hours":hours,"rate":diurnal},
  "margin_curve":margin_curve, "pareto_lot":pareto_lot, "scatter_margin":sc_margin,
  "prog":{"mx":[round(v,2) for v in mx],"suscept":suscept,
          "months":months,"cum_unmit":cum_unmit,"cum_mit":cum_mit},
  "strat":{"coastal_fault":round(float(fault[coastal==1].mean()),3),
           "inland_fault":round(float(fault[coastal==0].mean()),3),
           "coastal_meanR":round(float(Riso[coastal==1].mean()),2),
           "inland_meanR":round(float(Riso[coastal==0].mean()),2),
           "fault_rate":round(float(fault.mean()),3)},
}

if __name__=="__main__":
    write_csv(); json.dump(out, open("env_data.json","w")); print("wrote env_data.json\n")
    print("RAW correlation vs Riso:")
    for k,(r,p) in raw.items(): print(f"  {k:22s} r={r:+.3f} p={p:.1e}")
    print("\nPARTIAL (controlling for environment dm,salt,RH):")
    for k,(r,p) in part_env.items(): print(f"  {k:22s} r={r:+.3f} p={p:.2f}")
    print(f"\ndewpoint-margin controlling for lot: r={dm_ctrl_lot[0]:+.3f} p={dm_ctrl_lot[1]:.1e}")
    print(f"\nReg R^2: lot={r2_1}  +RH={r2_2}  +dewpoint/salt={r2_3}")
    print(f"  lot coef: m1={b1[1]:+.2f} -> m3={b3[1]:+.2f}")
    print(f"\nFault rate: coastal={out['strat']['coastal_fault']:.1%}  inland={out['strat']['inland_fault']:.1%}  overall={out['strat']['fault_rate']:.1%}")
    print(f"Pareto by lot: {pareto_lot}")
    print(f"Annual fault-days coastal: unmitigated={cum_unmit[-1]}  coated={cum_mit[-1]}")
