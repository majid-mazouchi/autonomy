---
name: literature-survey
description: Build a cited literature survey on a research topic by seeding, snowballing citations, de-duplicating, ranking, clustering by theme, and writing prose with a BibTeX appendix. Use when the user names a topic and wants related work, a state of the art, or a structured reading list.
---

Purpose
Turn a research topic into a structured, fully cited literature survey. This skill assumes the research-harness MCP tools are available for retrieval and that you do the synthesis.

When to use
Use this when the user names a research topic and wants the related work, the current state of the art, or a curated reading list. Do not use it for looking up a person.

Inputs
A topic, ideally with a time window and a sense of scope. If the scope is vague, ask one clarifying question, then proceed.

Procedure
Scope. Fix the topic, the year range, and what counts as related. Restate this in one line before any search.
Seed. Call research_search_papers with a focused query. Keep ten to twenty strong anchors. Note their DOIs or arXiv IDs.
Snowball. Call research_snowball_citations on the anchors in both directions. Backward references are the foundations. Forward citations are the recent work. Running only one direction biases the survey toward history or hype.
De-duplicate. Collapse repeats on DOI or arXiv ID before counting or ranking. Prefer papers found in more than one source.
Rank and cluster. Sort by the returned score. Keep the top set. Group into themes. Each theme becomes a section.
Optional code and media. For a leading paper, you may call research_search_code for its implementation, or research_search_video for a talk that explains a difficult method.
Write. Compose each theme in prose. Open with scope and method, then the themes, then open problems.

Outputs
A Markdown document by default, with sections per theme and a references list that includes a BibTeX block. Produce an HTML monograph in the light paper aesthetic only on request. Byline: By Majid Mazouchi . Drafted with Claude.

Guardrails
Cite only retrieved metadata. Never fabricate a DOI, an author, or a citation. If a claim has no source, omit it or label it unverified. Report any source that errored or returned nothing rather than papering over the gap.
