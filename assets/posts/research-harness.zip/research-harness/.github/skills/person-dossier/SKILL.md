---
name: person-dossier
description: Assemble a professional profile of a named person from public sources (ORCID, OpenAlex, USPTO patents, GitHub, web), with identity disambiguation. Use when the user names a person and wants their professional background. Does not query LinkedIn.
---

Purpose
Assemble a structured professional profile of a named person from compliant public sources. Identity disambiguation is the central task, not an afterthought.

When to use
Use this when the user names a person and wants their professional background, for a legitimate professional purpose such as vetting an author, a collaborator, or a candidate. Do not use it to profile private individuals.

Inputs
A full name, plus any disambiguator the user can give: an affiliation, a field, or an ORCID iD. More disambiguators mean a cleaner result.

Procedure
Gather candidates. Call research_lookup_person with the name and any disambiguator. It returns ORCID candidates, OpenAlex author candidates, and patents matched by surname.
Disambiguate. Anchor on a unique identifier where one exists, an ORCID iD or an OpenAlex author ID. Then confirm each other hit by matching affiliation, field, and co-authors. Do not merge a record into the profile until it is confirmed.
Enrich. For the confirmed person, you may call research_search_code for their public repositories and use web search for a homepage, talks, or a company bio.
Patents. Treat surname patent matches as unconfirmed. Promote a patent into the profile only after the inventor affiliation or co-inventors line up with the confirmed identity.
Assemble. Produce one profile only for the confirmed individual. List unresolved candidates separately so the user can choose.

Outputs
A Markdown profile with sections for identity, affiliations, scholarship, patents, and code, plus a confidence note describing how identity was confirmed and what remains uncertain. Byline: By Majid Mazouchi . Drafted with Claude.

Guardrails
Confirm before you merge. Attributing a stranger's work to the subject is the people search version of double counting.
Do not query LinkedIn through any tool or scraper. It has no compliant people search API. Note it as a manual step for the user.
Cite the source of every claim. Mark anything unverified as unverified. Keep the scope to public professional records.
