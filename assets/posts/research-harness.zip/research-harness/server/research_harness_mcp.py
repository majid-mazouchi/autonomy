"""Research Harness MCP server.

A local, read-only Model Context Protocol server that gives a coding agent a
multi-source research stack: scholarly papers, citation snowballing, code,
video, US patents, and people lookup. Retrieval lives here; synthesis lives in
the agent skill that calls these tools.

All tools are read-only and hit public APIs. Keys are read from environment
variables and every source degrades gracefully when a key is absent.

Run locally over stdio:
    python server/research_harness_mcp.py

By Majid Mazouchi . Drafted with Claude.
"""

from __future__ import annotations

import json
import math
import os
import re
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

import httpx
from pydantic import BaseModel, ConfigDict, Field

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("research_harness_mcp")

# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #

OPENALEX_BASE = "https://api.openalex.org"
S2_BASE = "https://api.semanticscholar.org/graph/v1"
GITHUB_BASE = "https://api.github.com"
YOUTUBE_BASE = "https://www.googleapis.com/youtube/v3"
ORCID_BASE = "https://pub.orcid.org/v3.0"
# PatentsView Search API. Note: USPTO is migrating this to data.uspto.gov
# (Open Data Portal). Override with USPTO_BASE if the endpoint moves.
USPTO_BASE = os.environ.get("USPTO_BASE", "https://search.patentsview.org/api/v1")

# Environment variable names for credentials.
ENV_MAILTO = "OPENALEX_MAILTO"      # email for the OpenAlex polite pool
ENV_S2_KEY = "S2_API_KEY"           # optional, raises Semantic Scholar limits
ENV_GH_TOKEN = "GITHUB_TOKEN"       # required for code search
ENV_YT_KEY = "YOUTUBE_API_KEY"      # required for video search
ENV_USPTO_KEY = "USPTO_API_KEY"     # required for patent search

HTTP_TIMEOUT = 30.0
USER_AGENT = "research-harness-mcp/1.0"

# Relevance weights, matching the field guide: similarity, citations, recency,
# off topic penalty. Tune these to taste.
W_PAPER = {"sim": 0.40, "cit": 0.20, "rec": 0.30, "off": 0.30}
W_REPO = {"sim": 0.40, "stars": 0.25, "rec": 0.25, "stale": 0.10}

CIT_NORM = 2000.0     # citation count that maps to a near-maximum signal
STARS_NORM = 50000.0  # star count that maps to a near-maximum signal
RECENCY_HORIZON_YEARS = 10.0

_NOW = datetime.now(timezone.utc)
_THIS_YEAR = _NOW.year

# --------------------------------------------------------------------------- #
# Shared HTTP and scoring helpers (extracted to avoid duplication)
# --------------------------------------------------------------------------- #


def _headers(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    base = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if extra:
        base.update(extra)
    return base


async def _get_json(
    client: httpx.AsyncClient,
    url: str,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
) -> Any:
    resp = await client.get(url, params=params, headers=_headers(headers))
    resp.raise_for_status()
    return resp.json()


async def _post_json(
    client: httpx.AsyncClient,
    url: str,
    payload: Dict[str, Any],
    headers: Optional[Dict[str, str]] = None,
) -> Any:
    resp = await client.post(url, json=payload, headers=_headers(headers))
    resp.raise_for_status()
    return resp.json()


def _handle_api_error(source: str, e: Exception) -> Dict[str, Any]:
    """Return an actionable error payload rather than raising."""
    if isinstance(e, httpx.HTTPStatusError):
        code = e.response.status_code
        if code == 401 or code == 403:
            msg = f"{source}: authentication failed. Check the API key environment variable."
        elif code == 404:
            msg = f"{source}: resource not found. Verify the identifier."
        elif code == 429:
            msg = f"{source}: rate limit exceeded. Wait and retry, or add a key to raise limits."
        else:
            msg = f"{source}: request failed with status {code}."
        return {"error": msg, "status": code}
    if isinstance(e, httpx.TimeoutException):
        return {"error": f"{source}: request timed out. Retry."}
    return {"error": f"{source}: unexpected error {type(e).__name__}: {e}"}


_TOKEN_RE = re.compile(r"[a-z0-9]+")


def _tokens(text: Optional[str]) -> set:
    if not text:
        return set()
    return set(_TOKEN_RE.findall(text.lower()))


def _lexical_sim(query: str, text: Optional[str]) -> float:
    """Fraction of query terms present in the candidate text. Range 0 to 1."""
    q = _tokens(query)
    if not q:
        return 0.0
    return len(q & _tokens(text)) / len(q)


def _recency(year: Optional[int]) -> float:
    if not year:
        return 0.0
    age = max(0, _THIS_YEAR - int(year))
    return max(0.0, 1.0 - age / RECENCY_HORIZON_YEARS)


def _log_norm(value: float, norm: float) -> float:
    return min(1.0, math.log(max(0.0, value) + 1.0) / math.log(norm + 1.0))


def _score_paper(query: str, title: str, abstract: str, citations: int, year: Optional[int]) -> float:
    sim = max(_lexical_sim(query, title), _lexical_sim(query, abstract))
    off = 1.0 - sim
    score = (
        W_PAPER["sim"] * sim
        + W_PAPER["cit"] * _log_norm(citations, CIT_NORM)
        + W_PAPER["rec"] * _recency(year)
        - W_PAPER["off"] * off
    )
    return round(score, 4)


def _days_since(iso_ts: Optional[str]) -> Optional[float]:
    if not iso_ts:
        return None
    try:
        dt = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
        return (_NOW - dt).total_seconds() / 86400.0
    except ValueError:
        return None


def _score_repo(query: str, text: str, stars: int, pushed_at: Optional[str]) -> float:
    sim = _lexical_sim(query, text)
    days = _days_since(pushed_at)
    rec = 1.0 if days is None else max(0.0, 1.0 - days / 730.0)  # two year horizon
    stale = 0.0 if days is None else min(1.0, days / 1825.0)     # five year staleness
    score = (
        W_REPO["sim"] * sim
        + W_REPO["stars"] * _log_norm(stars, STARS_NORM)
        + W_REPO["rec"] * rec
        - W_REPO["stale"] * stale
    )
    return round(score, 4)


def _norm_title(title: Optional[str]) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (title or "").lower()).strip()


def _dedup_key(doi: Optional[str], arxiv: Optional[str], title: Optional[str]) -> str:
    if doi:
        return "doi:" + doi.lower().replace("https://doi.org/", "")
    if arxiv:
        return "arxiv:" + arxiv.lower()
    return "title:" + _norm_title(title)


# --------------------------------------------------------------------------- #
# Source clients (one function per upstream API, returning normalized records)
# --------------------------------------------------------------------------- #


async def _openalex_works(client: httpx.AsyncClient, query: str, limit: int, from_year: Optional[int]) -> List[Dict[str, Any]]:
    params: Dict[str, Any] = {"search": query, "per-page": min(limit, 50)}
    mailto = os.environ.get(ENV_MAILTO)
    if mailto:
        params["mailto"] = mailto
    if from_year:
        params["filter"] = f"publication_year:>{from_year - 1}"
    data = await _get_json(client, f"{OPENALEX_BASE}/works", params=params)
    out: List[Dict[str, Any]] = []
    for w in data.get("results", []):
        ids = w.get("ids", {}) or {}
        out.append(
            {
                "title": w.get("title"),
                "year": w.get("publication_year"),
                "doi": (w.get("doi") or "").replace("https://doi.org/", "") or None,
                "arxiv_id": None,
                "citations": w.get("cited_by_count", 0),
                "tldr": None,
                "authors": [a.get("author", {}).get("display_name") for a in w.get("authorships", [])][:8],
                "url": (w.get("primary_location") or {}).get("landing_page_url") or ids.get("openalex"),
                "source": "openalex",
            }
        )
    return out


async def _s2_search(client: httpx.AsyncClient, query: str, limit: int) -> List[Dict[str, Any]]:
    headers = {}
    key = os.environ.get(ENV_S2_KEY)
    if key:
        headers["x-api-key"] = key
    fields = "title,year,externalIds,citationCount,tldr,authors,openAccessPdf,url"
    params = {"query": query, "limit": min(limit, 50), "fields": fields}
    data = await _get_json(client, f"{S2_BASE}/paper/search", params=params, headers=headers)
    out: List[Dict[str, Any]] = []
    for p in data.get("data", []) or []:
        ext = p.get("externalIds", {}) or {}
        oa = p.get("openAccessPdf") or {}
        out.append(
            {
                "title": p.get("title"),
                "year": p.get("year"),
                "doi": ext.get("DOI"),
                "arxiv_id": ext.get("ArXiv"),
                "citations": p.get("citationCount", 0),
                "tldr": (p.get("tldr") or {}).get("text"),
                "authors": [a.get("name") for a in p.get("authors", [])][:8],
                "url": oa.get("url") or p.get("url"),
                "source": "semantic_scholar",
            }
        )
    return out


def _merge_papers(query: str, *batches: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    for batch in batches:
        for rec in batch:
            key = _dedup_key(rec.get("doi"), rec.get("arxiv_id"), rec.get("title"))
            if key in merged:
                cur = merged[key]
                cur["sources"] = sorted(set(cur["sources"] + [rec["source"]]))
                # prefer the richer record for tldr and citations
                if not cur.get("tldr") and rec.get("tldr"):
                    cur["tldr"] = rec["tldr"]
                cur["citations"] = max(cur.get("citations", 0), rec.get("citations", 0))
                for field in ("doi", "arxiv_id", "url", "year"):
                    if not cur.get(field) and rec.get(field):
                        cur[field] = rec[field]
            else:
                clean = dict(rec)
                clean["sources"] = [clean.pop("source")]
                merged[key] = clean
    results = list(merged.values())
    for r in results:
        r["score"] = _score_paper(
            query, r.get("title") or "", r.get("tldr") or "", r.get("citations", 0), r.get("year")
        )
    results.sort(key=lambda x: x["score"], reverse=True)
    return results


# --------------------------------------------------------------------------- #
# Pydantic input models
# --------------------------------------------------------------------------- #


class ResponseFormat(str, Enum):
    JSON = "json"
    MARKDOWN = "markdown"


class _Base(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")


class PaperSearchInput(_Base):
    query: str = Field(..., description="Topic query, e.g. 'sensorless control of PMSM'.", min_length=2, max_length=300)
    limit: int = Field(default=20, description="Max papers to return after dedup.", ge=1, le=50)
    from_year: Optional[int] = Field(default=None, description="Only papers published in or after this year.", ge=1900, le=2100)


class SnowballInput(_Base):
    seed_ids: List[str] = Field(..., description="Seed paper IDs. Accepts 'DOI:10.x', 'ARXIV:1234.5678', or a Semantic Scholar paper ID.", min_length=1, max_length=10)
    direction: str = Field(default="both", description="'backward' for references, 'forward' for citing papers, or 'both'.")
    limit_per_seed: int = Field(default=15, description="Max related papers per seed per direction.", ge=1, le=50)


class CodeSearchInput(_Base):
    query: str = Field(..., description="Topic to find repositories for. The agent should pass expanded terms.", min_length=2, max_length=300)
    limit: int = Field(default=15, description="Max repositories to return.", ge=1, le=50)
    language: Optional[str] = Field(default=None, description="Optional language filter, e.g. 'python'.")


class VideoSearchInput(_Base):
    query: str = Field(..., description="Topic to find talks or lectures for.", min_length=2, max_length=300)
    limit: int = Field(default=10, description="Max videos to return.", ge=1, le=25)
    with_transcript: bool = Field(default=False, description="Fetch transcripts for returned videos when available.")


class PatentSearchInput(_Base):
    inventor_last: Optional[str] = Field(default=None, description="Inventor family name to search by.")
    inventor_first: Optional[str] = Field(default=None, description="Inventor given name to narrow results.")
    query: Optional[str] = Field(default=None, description="Optional keywords matched against the patent title.")
    limit: int = Field(default=25, description="Max patents to return.", ge=1, le=100)


class PersonLookupInput(_Base):
    name: str = Field(..., description="Full name of the person, e.g. 'Jane Q. Researcher'.", min_length=2, max_length=120)
    affiliation: Optional[str] = Field(default=None, description="Known affiliation to help disambiguate.")
    field: Optional[str] = Field(default=None, description="Known research field to help disambiguate.")
    orcid: Optional[str] = Field(default=None, description="ORCID iD if known, e.g. '0000-0002-1825-0097'. Skips name search.")


def _fmt(payload: Any, fmt: ResponseFormat = ResponseFormat.JSON) -> str:
    return json.dumps(payload, indent=2, ensure_ascii=False)


# --------------------------------------------------------------------------- #
# Tools
# --------------------------------------------------------------------------- #


@mcp.tool(
    name="research_search_papers",
    annotations={"title": "Search scholarly papers", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def research_search_papers(params: PaperSearchInput) -> str:
    """Search OpenAlex and Semantic Scholar for a topic, merge and de-duplicate
    results, and rank them by the field guide relevance score.

    Use this for the seed search step of a literature survey. Pass a focused
    query. Returns the strongest anchor papers across both sources.

    Returns:
        str: JSON list of papers. Each item has: title, year, doi, arxiv_id,
        citations, tldr, authors (list), url, sources (list of the databases it
        was found in), and score (float, higher is more relevant).
    """
    async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
        batches: List[List[Dict[str, Any]]] = []
        errors: List[Dict[str, Any]] = []
        for name, coro in (
            ("openalex", _openalex_works(client, params.query, params.limit, params.from_year)),
            ("semantic_scholar", _s2_search(client, params.query, params.limit)),
        ):
            try:
                batches.append(await coro)
            except Exception as e:  # noqa: BLE001 - normalize to actionable payload
                errors.append(_handle_api_error(name, e))
        merged = _merge_papers(params.query, *batches)[: params.limit]
        return _fmt({"count": len(merged), "papers": merged, "errors": errors})


@mcp.tool(
    name="research_snowball_citations",
    annotations={"title": "Snowball citations from seed papers", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def research_snowball_citations(params: SnowballInput) -> str:
    """Expand a seed set by walking the Semantic Scholar citation graph.

    Backward gives the references a seed is built on (foundations). Forward
    gives papers that cite the seed (recent developments). This is the step
    that turns a search result list into a survey. Run both directions unless
    you specifically want only foundations or only recent work.

    Returns:
        str: JSON with 'backward' and 'forward' lists. Each related paper has:
        title, year, doi, citations, authors, url, from_seed (the seed it came
        from). De-duplicate against your existing set before ranking.
    """
    headers = {}
    key = os.environ.get(ENV_S2_KEY)
    if key:
        headers["x-api-key"] = key
    fields = "title,year,externalIds,citationCount,authors,url"
    want_back = params.direction in ("backward", "both")
    want_fwd = params.direction in ("forward", "both")

    def _shape(node: Dict[str, Any], seed: str) -> Dict[str, Any]:
        p = node or {}
        ext = p.get("externalIds", {}) or {}
        return {
            "title": p.get("title"),
            "year": p.get("year"),
            "doi": ext.get("DOI"),
            "arxiv_id": ext.get("ArXiv"),
            "citations": p.get("citationCount", 0),
            "authors": [a.get("name") for a in p.get("authors", [])][:6],
            "url": p.get("url"),
            "from_seed": seed,
        }

    backward: List[Dict[str, Any]] = []
    forward: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
        for seed in params.seed_ids:
            try:
                if want_back:
                    d = await _get_json(
                        client, f"{S2_BASE}/paper/{seed}/references",
                        params={"fields": fields, "limit": params.limit_per_seed}, headers=headers,
                    )
                    backward += [_shape(item.get("citedPaper"), seed) for item in d.get("data", []) if item.get("citedPaper")]
                if want_fwd:
                    d = await _get_json(
                        client, f"{S2_BASE}/paper/{seed}/citations",
                        params={"fields": fields, "limit": params.limit_per_seed}, headers=headers,
                    )
                    forward += [_shape(item.get("citingPaper"), seed) for item in d.get("data", []) if item.get("citingPaper")]
            except Exception as e:  # noqa: BLE001
                errors.append(_handle_api_error(f"semantic_scholar(seed={seed})", e))
    return _fmt({"backward": backward, "forward": forward, "errors": errors})


@mcp.tool(
    name="research_search_code",
    annotations={"title": "Search code repositories", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def research_search_code(params: CodeSearchInput) -> str:
    """Search GitHub repositories and rank by a blend of text match, stars, and
    commit recency rather than raw relevance.

    GitHub search is keyword based, not semantic. Pass an expanded query with
    synonyms and acronyms for best coverage. Requires GITHUB_TOKEN in the
    environment.

    Returns:
        str: JSON list of repositories. Each has: full_name, description, url,
        stars, language, pushed_at, topics (list), score (float).
    """
    token = os.environ.get(ENV_GH_TOKEN)
    if not token:
        return _fmt({"error": f"Set {ENV_GH_TOKEN} to search code.", "repos": []})
    q = params.query
    if params.language:
        q += f" language:{params.language}"
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            data = await _get_json(
                client, f"{GITHUB_BASE}/search/repositories",
                params={"q": q, "sort": "stars", "order": "desc", "per_page": params.limit}, headers=headers,
            )
    except Exception as e:  # noqa: BLE001
        return _fmt({**_handle_api_error("github", e), "repos": []})
    repos: List[Dict[str, Any]] = []
    for r in data.get("items", []):
        text = " ".join(filter(None, [r.get("name"), r.get("description"), " ".join(r.get("topics", []) or [])]))
        repos.append(
            {
                "full_name": r.get("full_name"),
                "description": r.get("description"),
                "url": r.get("html_url"),
                "stars": r.get("stargazers_count", 0),
                "language": r.get("language"),
                "pushed_at": r.get("pushed_at"),
                "topics": r.get("topics", []),
                "score": _score_repo(params.query, text, r.get("stargazers_count", 0), r.get("pushed_at")),
            }
        )
    repos.sort(key=lambda x: x["score"], reverse=True)
    return _fmt({"count": len(repos), "repos": repos})


@mcp.tool(
    name="research_search_video",
    annotations={"title": "Search talks and lectures", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def research_search_video(params: VideoSearchInput) -> str:
    """Search YouTube for talks and lectures on a topic. The value is in the
    transcript, not the title, so set with_transcript to read what was said.

    Requires YOUTUBE_API_KEY. Transcripts require the optional
    youtube-transcript-api package. A search costs about 100 quota units of a
    10000 per day default, so search sparingly.

    Returns:
        str: JSON list of videos. Each has: video_id, title, channel,
        published_at, url, and transcript (string or null when unavailable).
    """
    key = os.environ.get(ENV_YT_KEY)
    if not key:
        return _fmt({"error": f"Set {ENV_YT_KEY} to search video.", "videos": []})
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            data = await _get_json(
                client, f"{YOUTUBE_BASE}/search",
                params={"part": "snippet", "type": "video", "q": params.query, "maxResults": params.limit, "key": key},
            )
    except Exception as e:  # noqa: BLE001
        return _fmt({**_handle_api_error("youtube", e), "videos": []})
    videos: List[Dict[str, Any]] = []
    for item in data.get("items", []):
        vid = (item.get("id") or {}).get("videoId")
        sn = item.get("snippet", {}) or {}
        transcript = None
        if params.with_transcript and vid:
            transcript = _fetch_transcript(vid)
        videos.append(
            {
                "video_id": vid,
                "title": sn.get("title"),
                "channel": sn.get("channelTitle"),
                "published_at": sn.get("publishedAt"),
                "url": f"https://www.youtube.com/watch?v={vid}" if vid else None,
                "transcript": transcript,
            }
        )
    return _fmt({"count": len(videos), "videos": videos})


def _fetch_transcript(video_id: str) -> Optional[str]:
    """Best effort transcript via the optional youtube-transcript-api package."""
    try:
        from youtube_transcript_api import YouTubeTranscriptApi  # type: ignore

        chunks = YouTubeTranscriptApi.get_transcript(video_id)
        text = " ".join(c.get("text", "") for c in chunks)
        return text[:8000] if text else None
    except Exception:  # noqa: BLE001 - transcript is optional
        return None


@mcp.tool(
    name="research_search_patents",
    annotations={"title": "Search US patents", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def research_search_patents(params: PatentSearchInput) -> str:
    """Search US patents through the PatentsView Search API, by inventor name
    and/or title keywords. Inventor names are disambiguated upstream.

    Requires USPTO_API_KEY. Note USPTO is migrating PatentsView to the Open Data
    Portal at data.uspto.gov, which requires a USPTO.gov account from June 18,
    2026. Override the endpoint with the USPTO_BASE environment variable.

    Returns:
        str: JSON list of patents. Each has: patent_id, title, date,
        inventors (list), assignees (list), url.
    """
    key = os.environ.get(ENV_USPTO_KEY)
    if not key:
        return _fmt({"error": f"Set {ENV_USPTO_KEY} to search patents.", "patents": []})
    if not (params.inventor_last or params.query):
        return _fmt({"error": "Provide inventor_last and/or query.", "patents": []})

    clauses: List[Dict[str, Any]] = []
    if params.inventor_last:
        clauses.append({"inventors.inventor_name_last": params.inventor_last})
    if params.inventor_first:
        clauses.append({"inventors.inventor_name_first": params.inventor_first})
    if params.query:
        clauses.append({"_text_any": {"patent_title": params.query}})
    q = clauses[0] if len(clauses) == 1 else {"_and": clauses}
    payload = {
        "q": q,
        "f": ["patent_id", "patent_title", "patent_date", "inventors.inventor_name_first", "inventors.inventor_name_last", "assignees.assignee_organization"],
        "o": {"size": params.limit},
    }
    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
            data = await _post_json(client, f"{USPTO_BASE}/patent/", payload, headers={"X-Api-Key": key})
    except Exception as e:  # noqa: BLE001
        return _fmt({**_handle_api_error("patentsview", e), "patents": []})
    patents: List[Dict[str, Any]] = []
    for p in data.get("patents", []) or []:
        inv = [" ".join(filter(None, [i.get("inventor_name_first"), i.get("inventor_name_last")])) for i in p.get("inventors", []) or []]
        asg = [a.get("assignee_organization") for a in p.get("assignees", []) or [] if a.get("assignee_organization")]
        pid = p.get("patent_id")
        patents.append(
            {
                "patent_id": pid,
                "title": p.get("patent_title"),
                "date": p.get("patent_date"),
                "inventors": inv,
                "assignees": asg,
                "url": f"https://patents.google.com/patent/US{pid}" if pid else None,
            }
        )
    return _fmt({"count": len(patents), "patents": patents})


@mcp.tool(
    name="research_lookup_person",
    annotations={"title": "Assemble a person dossier", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True},
)
async def research_lookup_person(params: PersonLookupInput) -> str:
    """Assemble a professional profile of a named person from public sources:
    ORCID for identity, OpenAlex for scholarship, USPTO for patents.

    Identity disambiguation is the hard part. This tool returns candidate
    matches with their distinguishing signals (affiliation, field, co-authors).
    You must confirm the right person by matching affiliation and field before
    treating the merged profile as that one individual. LinkedIn is not queried;
    it has no compliant people search API and must be checked by hand.

    Returns:
        str: JSON with: orcid_candidates (list), openalex_candidates (list with
        works_count, citations, top works, institutions), patents (list by
        surname), and a disambiguation_note. Surname patent matches are NOT
        confirmed to be the same person until you verify.
    """
    orcid_candidates: List[Dict[str, Any]] = []
    openalex_candidates: List[Dict[str, Any]] = []
    patents: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    surname = params.name.split()[-1] if params.name.split() else params.name

    async with httpx.AsyncClient(timeout=HTTP_TIMEOUT) as client:
        # ORCID
        try:
            if params.orcid:
                rec = await _get_json(client, f"{ORCID_BASE}/{params.orcid}/record", headers={"Accept": "application/json"})
                person = (rec.get("person") or {}).get("name") or {}
                orcid_candidates.append({
                    "orcid": params.orcid,
                    "name": " ".join(filter(None, [(person.get("given-names") or {}).get("value"), (person.get("family-name") or {}).get("value")])),
                    "affiliations": [],
                })
            else:
                d = await _get_json(client, f"{ORCID_BASE}/expanded-search/", params={"q": params.name, "rows": 5}, headers={"Accept": "application/json"})
                for r in d.get("expanded-result", []) or []:
                    orcid_candidates.append({
                        "orcid": r.get("orcid-id"),
                        "name": " ".join(filter(None, [r.get("given-names"), r.get("family-names")])),
                        "affiliations": r.get("institution-name", []),
                    })
        except Exception as e:  # noqa: BLE001
            errors.append(_handle_api_error("orcid", e))

        # OpenAlex authors
        try:
            params_oa: Dict[str, Any] = {"search": params.name, "per-page": 5}
            mailto = os.environ.get(ENV_MAILTO)
            if mailto:
                params_oa["mailto"] = mailto
            d = await _get_json(client, f"{OPENALEX_BASE}/authors", params=params_oa)
            for a in d.get("results", []) or []:
                insts = [i.get("display_name") for i in a.get("last_known_institutions", []) or []]
                openalex_candidates.append({
                    "openalex_id": a.get("id"),
                    "name": a.get("display_name"),
                    "orcid": (a.get("ids") or {}).get("orcid"),
                    "works_count": a.get("works_count"),
                    "citations": a.get("cited_by_count"),
                    "institutions": insts,
                    "top_concepts": [c.get("display_name") for c in a.get("x_concepts", [])[:5]],
                })
        except Exception as e:  # noqa: BLE001
            errors.append(_handle_api_error("openalex", e))

        # Patents by surname (unconfirmed)
        key = os.environ.get(ENV_USPTO_KEY)
        if key:
            try:
                payload = {
                    "q": {"inventors.inventor_name_last": surname},
                    "f": ["patent_id", "patent_title", "patent_date", "inventors.inventor_name_first", "inventors.inventor_name_last", "assignees.assignee_organization"],
                    "o": {"size": 20},
                }
                d = await _post_json(client, f"{USPTO_BASE}/patent/", payload, headers={"X-Api-Key": key})
                for p in d.get("patents", []) or []:
                    patents.append({
                        "patent_id": p.get("patent_id"),
                        "title": p.get("patent_title"),
                        "date": p.get("patent_date"),
                        "assignees": [a.get("assignee_organization") for a in p.get("assignees", []) or [] if a.get("assignee_organization")],
                    })
            except Exception as e:  # noqa: BLE001
                errors.append(_handle_api_error("patentsview", e))

    note = (
        "Confirm identity before merging. Anchor on an ORCID iD where present, then "
        "match affiliation and field across candidates. Patent matches are by surname "
        "only and are not confirmed to be this person. LinkedIn was not queried."
    )
    if params.affiliation:
        note += f" Filter candidates whose institutions mention '{params.affiliation}'."
    return _fmt({
        "query": {"name": params.name, "affiliation": params.affiliation, "field": params.field},
        "orcid_candidates": orcid_candidates,
        "openalex_candidates": openalex_candidates,
        "patents_by_surname": patents,
        "disambiguation_note": note,
        "errors": errors,
    })


if __name__ == "__main__":
    mcp.run()
