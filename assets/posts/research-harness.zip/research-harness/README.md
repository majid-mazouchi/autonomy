# Research Harness for Copilot

A drop-in research stack for a VS Code Copilot agent. It adds multi-source retrieval (papers, citations, code, video, US patents, people) as MCP tools, plus a custom agent and two skills that turn those tools into a cited literature survey or a person dossier.

The design follows one split: tools retrieve, a skill synthesizes. Keep those two layers apart and the rest follows.

## What is in the box

```
research-harness/
  server/research_harness_mcp.py        retrieval tools (FastMCP, read-only)
  .vscode/mcp.json                      registers the server with VS Code
  .github/agents/
    scientific-researcher.agent.md      the orchestrating agent
  .github/skills/
    literature-survey/SKILL.md          topic to survey
    person-dossier/SKILL.md             name to profile
  requirements.txt
```

## The tools

| Tool | What it does | Sources | Key |
|---|---|---|---|
| research_search_papers | seed search, de-duplicated and scored | OpenAlex, Semantic Scholar | none (email recommended) |
| research_snowball_citations | backward references and forward citations | Semantic Scholar | optional |
| research_search_code | repositories ranked by match, stars, recency | GitHub | required |
| research_search_video | talks and lectures, optional transcripts | YouTube | required |
| research_search_patents | patents by inventor or title | USPTO PatentsView | required |
| research_lookup_person | ORCID, OpenAlex, patent candidates | ORCID, OpenAlex, USPTO | partial |

## Install

1. Install dependencies.

   ```
   pip install -r requirements.txt
   ```

2. Copy the four folders into your repo: `server/`, `.vscode/`, and the two trees under `.github/`. If you already have a `.vscode/mcp.json`, merge the `servers` block instead of overwriting.

3. Set the keys you want (see below) as environment variables, then reload VS Code. In Copilot agent mode the server appears as research-harness and its tools become callable. Pick the scientific-researcher agent, or let Copilot select the survey or dossier skill by description.

## Keys and where to get them

| Variable | Needed for | Where |
|---|---|---|
| OPENALEX_MAILTO | faster OpenAlex (polite pool) | your email address |
| S2_API_KEY | higher Semantic Scholar limits | semanticscholar.org api |
| GITHUB_TOKEN | code search | GitHub personal access token, read-only public scope |
| YOUTUBE_API_KEY | video search | Google Cloud, YouTube Data API v3 |
| USPTO_API_KEY | patent search | data.uspto.gov account |

Every source degrades gracefully. With no keys at all you still get papers and citation snowballing, which is the core of a survey.

## Quotas to respect

OpenAlex is roughly 100k calls per day, generous. Semantic Scholar is low without a key. arXiv asks for about one request every three seconds. GitHub search is capped near thirty per minute. YouTube is the binding constraint: one search costs about 100 units of a 10000 per day default, so search sparingly and only fetch transcripts for keepers. Cache results and back off on 429 responses.

## The pipeline the agent runs

Scope the question. Seed search. Snowball backward and forward. De-duplicate on DOI or arXiv ID. Rank by score and cluster into themes. Optionally pull code and video for hard methods. Synthesize in prose and attach BibTeX. The agent cites only what the tools returned and never invents a reference.

## Two things to keep on your radar

USPTO migration. PatentsView is moving to the Open Data Portal at data.uspto.gov, which requires a USPTO.gov account from June 18, 2026. If the endpoint changes, point the server at it with the USPTO_BASE environment variable.

LinkedIn is out of scope by design. There is no compliant people search API, and scraping violates its terms. The dossier flow treats LinkedIn as a manual lookup for you, not an automated source. Do not bolt a scraper onto this harness.

## Tuning

Relevance weights live at the top of the server in W_PAPER and W_REPO. They match the field guide defaults. Adjust them to your corpus rather than trusting the starting values.

By Majid Mazouchi . Drafted with Claude.
