/* bms_balance.c  --  passive cell-balancing scheduler  (ECU: BMS, fw 4.2.1) */
/* High trust for CAPABILITY, silent on OCCURRENCE.                          */

#define BAL_TMAX_dC   450   /* hot cutoff:  45.0 C in deci-degrees           */
#define BAL_TMIN_dC    50   /* cold cutoff:  5.0 C -- do not balance below   */
#define BAL_THRESH_mV  18   /* bleed a cell this far above pack minimum      */

void balance_step(Pack *p) {
    int16_t t = p->temp_dC;            /* pack temp, signed deci-degrees C    */

    if (t > BAL_TMAX_dC) return;       /* hot guard: OK                       */

    /* BUG (fw 4.2.0): negative temps cast to unsigned wrap high, so the cold */
    /* guard never fires below 0 C and balancing runs cold.                   */
    if ((uint16_t)t < BAL_TMIN_dC)     /* -84 -> 65452, NOT < 50  => no skip  */
        return;

    for (int i = 0; i < p->n; i++)
        if (p->cell_mV[i] - p->min_mV > BAL_THRESH_mV)
            bleed_on(i);               /* drain high cell -- over-discharges   */
}                                      /* the weakest cell during cold charge  */
