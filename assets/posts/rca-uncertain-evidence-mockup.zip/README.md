# Mockup inputs - RCA Under Uncertain, Heterogeneous Evidence (battery case)

Fabricated inputs for the worked example. Each stands in for a real artifact class,
tagged with its field trust tier:

  dtc_freeze_frame.json   DTC status bits + text      HIGH / LOW
  bms_balance.c           ECU C source                HIGH (capability)
  fleet_telemetry.csv     measurements                MED-HIGH
  customer_complaints.md  dealer/customer testimony   LOW
  service_history.csv     maintenance/repair history  MEDIUM

Ground truth: a signed/unsigned cast bug in the cold balancing guard (fw 4.2.0) lets
passive balancing run during cold fast-charge, over-discharging the weakest cell ->
accelerated internal-resistance rise. Affected = fw>=4.2 AND cold AND high cold-
fastcharge count. The marginal "fast-charging causes damage" correlation is an
IMPOSTOR that collapses under partial correlation conditioned on climate x firmware.
