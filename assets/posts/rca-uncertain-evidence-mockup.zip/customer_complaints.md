# Dealer / customer symptom reports  (LOW trust: high recall, low precision)

- 2026-01-09 - EV-017 - "Range dropped a lot this winter and it charges slower
  at the fast charger than it did in the fall."
- 2026-02-11 - EV-201 - "Battery warning light came on right after a cold-morning
  fast charge. Light is still on."
- 2026-02-27 - EV-044 - "Loses noticeable range when it's freezing. Better on warm days."
- 2026-04-30 - EV-205 - "Dealer cleared a battery code last month, came back."

Common thread: cold + fast charging. Use for ONSET DATING and HYPOTHESIS GENERATION
only -- never for confirmation.
