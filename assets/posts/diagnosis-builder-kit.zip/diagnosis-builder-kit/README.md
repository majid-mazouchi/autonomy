# Diagnosis Builder Kit

Harnesses for **GitHub Copilot in VS Code** that help you **build the product** from
*From Method to Product: Architecting an Agentic Fleet-Diagnosis System* — the multi-agent,
tool-using, memory-backed system that diagnoses a fleet at scale.

Where the **diagnosis-copilot-kit** teaches Copilot to *run the method*, this kit teaches it to
*build the system that runs the method*. Same principle throughout:
**agents propose · deterministic tools verify · humans commit.**

## What's inside
```
.github/
  copilot-instructions.md            # architecture doctrine (auto-applied)
  instructions/                      # per-plane rules (applyTo globs)
    agents.instructions.md  tools-mcp.instructions.md
    data-plane.instructions.md  evals.instructions.md
  prompts/                           # /slash build skills
    scaffold-architecture  new-agent  new-tool  add-detector  wire-orchestrator
    design-eval  cost-check  threat-review  trace-case
  agents/
    system-architect.agent.md        # plan & design the architecture
    agent-tool-builder.agent.md       # implement agents / tools / evals
scaffold/                            # a RUNNABLE reference skeleton to build into
  ARCHITECTURE.md  requirements.txt  .vscode/mcp.json.example
  core/   case · orchestrator · agents · analyst · memory · detection
  tools/  stats_server.py (MCP)
  evals/  synthetic_fleet · grader · run_evals  (runs end-to-end, prints metrics)
```

## Install — add the harnesses to your Copilot
1. Copy the kit's **`.github/`** folder into the root of the repo where you are building the system.
   VS Code Copilot auto-detects: `copilot-instructions.md` (every chat), `instructions/*` (by file glob),
   `prompts/*.prompt.md` (as `/scaffold-architecture`, `/new-agent`, …), and `agents/*.agent.md`
   (the **System Architect** and **Agent/Tool Builder** modes in the chat picker).
2. Drop **`scaffold/`** into your project (or run `/scaffold-architecture` to generate it), then:
   ```
   cd scaffold && python -m venv .venv && . .venv/bin/activate   # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   python -m evals.run_evals        # runs the whole pipeline on synthetic fleets, prints metrics + CI gate
   ```
3. Wire the stats MCP server from `scaffold/.vscode/mcp.json.example` (see the diagnosis-copilot-kit too).
4. Open the **System Architect** agent on Opus 4.8 and say *"plan the data plane"* — or open
   **Agent/Tool Builder** and say *"implement the de-mix analyst with a real LLM call."*

## How to use it
- The scaffold is **deterministic and runnable today** — the worker agents are simple stubs so the eval
  harness produces real metrics with no API keys. The prompt-files and agents then help you **replace each
  stub with a real LLM-backed agent**, one at a time, keeping the eval green at every step.
- That is the whole philosophy of post 10: ship the skeleton, prove it with evals, earn autonomy in phases.

## Safety
- Build the eval harness first; never automate a step the harness can't measure.
- Read tools are open; write/actuator tools must pass a human gate.
- Treat ingested text (service notes, bulletins) as untrusted input, never as instructions.
