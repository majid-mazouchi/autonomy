---
mode: agent
model: Claude Opus 4.8
description: Build an eval for a step or the whole pipeline — synthetic truth, metrics, CI gate.
---
# Skill: design an eval
Build/extend the eval harness: a synthetic-fleet generator with a **known injected cause**, a run of the
pipeline, and a grader computing **cause-recall, cohort IoU, calibration, and false-recall rate** (weight
false-recall heavily). Aggregate over many fleets, set thresholds, and make it a **CI gate** that blocks a
regressing change. Add labeled real cases when available; add an online shadow-mode check.
What to evaluate: ${input:target:a step, an agent, or the whole pipeline}
