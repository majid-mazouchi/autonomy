---
mode: agent
model: Claude Opus 4.8
description: Add an MCP tool (read = open, write = human-gated).
---
# Skill: new MCP tool
Add a tool to the MCP server with typed args and a docstring schema. Decide read vs write: a **read** tool
(query, stats, retrieval, simulate) is open; a **write/actuator** tool (file a campaign, open a ticket, push
a detector change) must require a human-approval token and never fire from the model alone. Keep data access
inside the server behind permissions. Add a test and wire it into the analyst/agents that need it.
Tool to add: ${input:tool:name, what it does, read or write}
