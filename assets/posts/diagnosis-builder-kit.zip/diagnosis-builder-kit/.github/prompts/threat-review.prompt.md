---
mode: agent
model: Claude Opus 4.8
description: Review code/design for the security & guardrail rules.
---
# Skill: threat review
Review the selection (or the whole repo) against the guardrails: (1) does the model compute any statistic
itself instead of calling a tool? (2) can any write/actuator fire without a human gate? (3) is ingested text
(service notes, docs) treated as untrusted, or could it inject instructions? (4) is data access behind
permissions and out of prompts? (5) is per-tenant isolation preserved? Report findings with fixes, severity-ranked.
