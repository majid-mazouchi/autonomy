---
mode: agent
model: Claude Opus 4.8
description: Run or inspect one case end-to-end and produce the audit trace.
---
# Skill: trace a case
Run `diagnose_case` on one case (or a synthetic one) and produce the end-to-end trace across the lanes:
detection → orchestrator plan → perceive/ground → hypothesize → analyst (tool calls + results) → critic gate →
human gate → act → verify. Show what each step read/wrote on the Case, which tools were called with what
numbers, and the final chain · confidence · kill-switch. This is the audit artifact.
Case: ${input:case:a case id or "generate a synthetic one"}
