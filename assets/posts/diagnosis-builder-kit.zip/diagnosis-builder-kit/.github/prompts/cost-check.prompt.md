---
mode: agent
model: Claude Opus 4.8
description: Estimate the cost of a design — detection per car-day vs reasoning per case.
---
# Skill: cost check
Estimate the running cost: detection cost per car-day × fleet size (grows gently with cars) + reasoning cost
per case × real cases/month (grows with real problems, not fleet size). Flag any design that runs an LLM per
datapoint instead of per case. Estimate model-routing savings (cheap model for easy steps). Output a small
table: monthly detection cost, reasoning cost, and the naïve-design comparison.
Assumptions: ${input:assumptions:fleet size, cases/month, per-case token cost}
