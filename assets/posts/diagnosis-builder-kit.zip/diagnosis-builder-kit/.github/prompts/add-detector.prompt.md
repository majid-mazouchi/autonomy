---
mode: agent
model: Claude Opus 4.8
description: Add an always-on detector that opens a Case (cheap, per-cohort).
---
# Skill: new detector
Add a cheap, always-on monitor (CUSUM / change-point / anomaly / drift) that runs **per build cohort** and,
when it trips, calls `open_case` with a triage score (safety × spread × cost). It must be deterministic and
inexpensive — this plane runs on everything, so the agent reasoning can run only on the cases it opens. Add a
test on a synthetic rate series and confirm it alarms early.
Detector: ${input:detector:what signal, what shift to catch}
