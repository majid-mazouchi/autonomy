---
mode: agent
model: Claude Opus 4.8
description: Wire or extend the orchestrator loop (plan → workers → critic gate → human gate → act → verify).
---
# Skill: wire the orchestrator
Implement/extend `diagnose_case`: plan (which workers, budget) → perceive → ground → hypothesize →
analyze (tools) → critic gate (INCONCLUSIVE loops to collect, INCOHERENT loops to re-frame) → synthesize →
**human gate** → act (gated) → schedule verify. Make it resumable (durable execution) so it can pause at a
gate. Add a budget governor and a model router (cheap model for routing/summarizing, frontier for hard steps).
Keep it green against the eval harness.
