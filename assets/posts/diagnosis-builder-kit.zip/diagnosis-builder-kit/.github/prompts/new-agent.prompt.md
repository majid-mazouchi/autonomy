---
mode: agent
model: Claude Opus 4.8
description: Add a typed worker agent that reads/writes the Case blackboard.
---
# Skill: new worker agent
Create a worker agent with a typed input/output contract that does ONE job and writes its result to the Case.
Start as a deterministic stub (so evals stay green), then offer the LLM-backed version behind the same
contract. The worker must not call other workers directly (the orchestrator routes). If it produces numbers,
it must delegate to a tool, not compute them. Add it to the orchestrator plan and to the eval coverage.
Which worker: ${input:role:e.g. grounder / hypothesizer / critic — and its job}
