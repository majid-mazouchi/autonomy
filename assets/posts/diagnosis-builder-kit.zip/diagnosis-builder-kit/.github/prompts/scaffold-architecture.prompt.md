---
mode: agent
model: Claude Opus 4.8
description: Scaffold the seven-plane fleet-diagnosis architecture as a runnable repo skeleton.
---
# Skill: scaffold the architecture
Generate (or reconcile with) the repo skeleton for the fleet-diagnosis system: `core/` (case, orchestrator,
agents, analyst, memory, detection), `tools/` (an MCP server), `evals/` (synthetic_fleet, grader, run_evals),
plus `ARCHITECTURE.md`, `requirements.txt`, and `.vscode/mcp.json`. Keep worker agents as **deterministic
stubs** so the eval harness runs with no API keys, and leave clear TODOs where an LLM call replaces a stub.
Honor the doctrine: typed orchestrator + blackboard, tools compute the numbers, writes gated, evals first.
Target / context: ${input:target:Where to scaffold, and any existing structure}
