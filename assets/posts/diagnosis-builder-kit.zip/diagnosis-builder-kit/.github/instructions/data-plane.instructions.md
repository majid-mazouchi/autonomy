---
applyTo: "**/data/**,**/*.sql,**/dbt/**,**/pipelines/**"
---
# Data plane
- The target of all transforms is **one row per vehicle** (gold) plus shared lookups (feature/vector/graph).
- Resolve identity on the **VIN spine**; align every event to a common clock (usually in-service date).
- Put rate/cohort/prevalence definitions in a **semantic layer** so humans and agents compute them identically.
- Track lineage and data contracts; treat missingness as informative and biased (selection/survivorship).
- Buy the lakehouse/stream tech; build the entity-resolution and semantic layer.
