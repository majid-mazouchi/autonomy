---
applyTo: "**/agents/**,**/orchestrator*,**/core/agents*,**/core/orchestrator*"
---
# Agent & orchestrator code
- Use an **orchestrator over typed workers + a shared blackboard (the Case)** — not a free-form agent loop.
- Each worker has a typed input/output contract and does ONE job (perceive, ground, hypothesize, analyze,
  critic-gate, synthesize). It reads and writes the Case; it does not call other workers directly.
- The **analyst** is the only worker that produces numbers, and it does so by calling tools — never by
  computing in the prompt.
- The **critic** runs the sufficiency/impostor/confounding checks and can return INCONCLUSIVE (collect more)
  or INCOHERENT (re-frame) — the orchestrator loops accordingly.
- A **gatekeeper** stops the loop for a human before any irreversible step. Make the loop resumable
  (durable execution) so it can pause for a human and continue.
- When replacing a deterministic stub with an LLM call, keep the same typed contract and keep the eval green.
