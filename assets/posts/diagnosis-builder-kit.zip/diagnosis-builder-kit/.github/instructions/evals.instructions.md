---
applyTo: "**/evals/**,**/eval/**,**/*eval*,**/tests/**"
---
# Evals (the most important code in the repo)
- Grade the **whole pipeline against known truth**: synthetic fleets with injected causes + labeled past cases.
- Track the metrics that matter: **cause-recall**, **cohort overlap (IoU)**, **confidence calibration**, and
  the all-important **false-recall rate** (urging a campaign with no real fault — weight it heavily).
- Run **offline** (synthetic + labeled) before release and **online** in shadow mode (agreement with humans;
  did the verified fix hold?).
- Make evals a **CI gate**: a prompt/model/tool change that regresses any key metric must not merge.
- Build the harness BEFORE automating a step. You can only remove a human from a loop you can measure.
