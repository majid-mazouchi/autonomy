---
applyTo: "**/tools/**,**/mcp/**,**/*mcp*,**/*_server.py"
---
# Tools (MCP)
- Expose every capability as an MCP tool with a clear name, typed args, and a docstring (used as the schema).
- **Reads are open; writes are gated.** A tool that files a campaign, opens a ticket, or changes a detector
  must require a human approval token — never fire it from the model alone.
- Deterministic tools (statistics, queries, simulators) are preferred wherever a computed answer exists; the
  model must not reproduce their work.
- Keep data access (telemetry, warranty, DTC catalogs) inside the server, behind permissions — never inline
  in prompts. Rate-limit and per-tenant allow-list.
