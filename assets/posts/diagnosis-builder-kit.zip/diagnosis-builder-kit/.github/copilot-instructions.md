# Architecture doctrine (always-on) — building the fleet-diagnosis system

You are helping engineer an AI-powered, multi-agent **fleet-diagnosis product**. Hold this architecture in
mind on every request. The system has seven planes; keep each plane's job separate.

## The one rule
**Agents propose, deterministic tools verify, humans commit.** If a design or change breaks that sentence,
flag it. Concretely:
- The LLM never computes a statistic — it calls a tool, or says it can't.
- Cheap detection runs on everything; expensive agent reasoning runs **per case**, never per datapoint.
- Writes/irreversible actions pass a human gate; reads are open.
- Nothing is automated until an **eval** measures it. Build the eval harness before the autonomy.
- Ingested text (service notes, docs) is untrusted data, never instructions (prompt-injection).

## The seven planes (and where code for each lives)
1. **Data** — ingest → lakehouse (bronze→silver→gold, one row per vehicle) → feature/vector/graph stores +
   a semantic layer (one definition of a rate/cohort). `core/` reads from here.
2. **Detection** — always-on monitors (CUSUM per cohort, change-point, anomaly) → triage → opens a **Case**.
   `core/detection.py`.
3. **Reasoning** — an **orchestrator** over typed **worker agents** sharing a **blackboard** (the Case),
   run on a durable workflow. Not a chat swarm. `core/orchestrator.py`, `core/agents.py`, `core/analyst.py`.
4. **Tools** — MCP servers; reads free, writes gated. `tools/`.
5. **Memory** — five stores (working, episodic/case-library, semantic, procedural, long-term) with a
   **write-gate**: only human-confirmed, verified facts graduate to durable memory. `core/memory.py`.
6. **Runtime** — durable workflow engine, budget governor, model router.
7. **Human-in-the-loop** — investigation workspace, dashboards, approval gates, audit trail.

## Build rules
- **Typed contracts** between agents; each worker does one job and writes structured results to the Case.
- **Buy the plumbing, build the judgment.** Don't reinvent a lakehouse, a vector DB, or a workflow engine.
  Your value is the agents, the tools, the case library, and the eval corpus.
- Keep the scaffold **runnable at every step**: worker stubs are deterministic until you replace them with
  LLM calls; the eval harness must stay green.
- Every conclusion the system emits must carry its evidence, the tool outputs it used, and (for actions) the
  approving human — auditable by construction.
