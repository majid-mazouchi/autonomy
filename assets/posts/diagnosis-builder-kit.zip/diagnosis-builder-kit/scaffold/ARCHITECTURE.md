# Architecture — folder ↔ plane map

| Plane | Folder / file | Status in this scaffold |
|-------|---------------|--------------------------|
| Data | (your lakehouse/dbt) → feeds dicts | mocked by `evals/synthetic_fleet.py` |
| Detection | `core/detection.py` | runnable CUSUM + `open_case` |
| Reasoning — orchestrator | `core/orchestrator.py` | runnable `diagnose_case` loop |
| Reasoning — workers | `core/agents.py` | **deterministic stubs → replace with LLM** |
| Reasoning — analyst (tools) | `core/analyst.py` | real de-mix + cohort-boundary stats |
| Tools (MCP) | `tools/stats_server.py` | runnable MCP stats server |
| Memory | `core/memory.py` | 5 stores + write-gate |
| Eval harness | `evals/` | **runs end-to-end, prints metrics + CI gate** |

## Run it
```
python -m evals.run_evals
```
It generates synthetic fleets with a KNOWN injected cause, runs the pipeline, grades the result, and gates on
the metrics (cause-recall, cohort IoU, false-recall, calibration). Replace one stub agent at a time with a real
LLM call and keep this green.
