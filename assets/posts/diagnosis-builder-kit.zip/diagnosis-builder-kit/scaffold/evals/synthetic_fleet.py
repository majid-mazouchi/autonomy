"""Generate a fleet with a KNOWN injected cause so the grader can score the pipeline.
Same idea as the diagnosis sample-evidence pack, returned as code + ground truth."""
import random, datetime

def generate(seed: int = 0, n: int = 240):
    rng = random.Random(seed)
    cars, gt_firmware, gt_connector = [], set(), set()
    base = datetime.date(2025, 1, 6)
    for i in range(1, n + 1):
        vin = f"VIN{seed:02d}{i:04d}"
        plant = rng.choice(["A", "B"])
        firmware = "5.1.2" if rng.random() < (0.70 if plant == "A" else 0.35) else "4.1.0"
        build_week = rng.randint(1, 30)
        connector_lot = "B" if rng.random() < 0.22 else rng.choice(["A", "C"])
        climate = rng.choice(["cold", "temperate"])
        cold_fc = max(0, int(rng.gauss(28 if climate == "cold" else 6, 10)))
        new_fw = firmware.startswith("5.1")
        cause1 = new_fw and climate == "cold" and cold_fc >= 20        # firmware cold-throttle
        cause2 = connector_lot == "B" and 12 <= build_week <= 18       # bad connector lot
        code, ttemp, cause = 0, None, None
        if cause1:                       # firmware dominates if both
            code, ttemp, cause = 1, round(rng.gauss(-6, 3), 1), "firmware"; gt_firmware.add(vin)
        elif cause2:
            code, ttemp, cause = 1, round(rng.gauss(26, 4), 1), "connector"; gt_connector.add(vin)
        elif rng.random() < 0.01:        # tiny baseline noise (a real, unexplained third thing)
            code, ttemp, cause = 1, round(rng.gauss(10, 12), 1), "noise"
        cars.append(dict(vin=vin, plant=plant, build_week=build_week, firmware=firmware,
                         connector_lot=connector_lot, climate=climate,
                         cold_fastcharge_count=cold_fc, throttle_temp_C=ttemp, code=code, _cause=cause))
    ground_truth = [
        {"name": "firmware cold-throttle", "members": gt_firmware},
        {"name": "connector lot B wk12-18", "members": gt_connector},
    ]
    return cars, ground_truth
