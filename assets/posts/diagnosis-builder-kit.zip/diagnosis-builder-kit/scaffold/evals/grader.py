"""Grade a diagnosis against known ground truth. The metrics that matter (post 10, Table 3)."""
def _iou(a: set, b: set) -> float:
    if not a and not b: return 1.0
    u = len(a | b)
    return 0.0 if u == 0 else len(a & b) / u

def grade(diagnosis: list[dict], ground_truth: list[dict]) -> dict:
    true_sets = [g["members"] for g in ground_truth if g["members"]]
    # best IoU each TRUE cause gets from any diagnosed cluster
    recalls = []
    for t in true_sets:
        best = max((_iou(d["selected"], t) for d in diagnosis), default=0.0)
        recalls.append(best)
    cause_recall = sum(1 for r in recalls if r >= 0.5) / len(true_sets) if true_sets else 0.0
    mean_iou = sum(recalls) / len(recalls) if recalls else 0.0
    # false recalls: diagnosed clusters that match NO true cause
    false = 0; pairs = []
    for d in diagnosis:
        best = max((_iou(d["selected"], t) for t in true_sets), default=0.0)
        correct = 1 if best >= 0.5 else 0
        pairs.append((d.get("confidence", 0.0), correct))
        if not correct:
            false += 1
    false_recall_rate = false / len(diagnosis) if diagnosis else 0.0
    return {"cause_recall": cause_recall, "mean_iou": mean_iou,
            "false_recall_rate": false_recall_rate, "_pairs": pairs}
