"""Run the whole pipeline on many synthetic fleets, grade it, and gate on the metrics (a CI gate).
    python -m evals.run_evals      # exit 0 = pass, 1 = regression
"""
import sys
from core.case import Case
from core.orchestrator import diagnose_case
from evals.synthetic_fleet import generate
from evals.grader import grade

K = 24
THRESHOLDS = {"cause_recall": 0.90, "mean_iou": 0.70, "false_recall_rate": 0.10, "brier": 0.20}

def main() -> int:
    cr = iou = frr = 0.0; pairs = []
    for seed in range(K):
        cars, gt = generate(seed)
        case = Case(case_id=f"case-{seed}", code="P0AE0", cars=cars)
        diagnosis = diagnose_case(case)
        m = grade(diagnosis, gt)
        cr += m["cause_recall"]; iou += m["mean_iou"]; frr += m["false_recall_rate"]; pairs += m["_pairs"]
    cr, iou, frr = cr / K, iou / K, frr / K
    brier = sum((c - y) ** 2 for c, y in pairs) / len(pairs) if pairs else 1.0

    rows = [("cause-recall", cr, ">=", THRESHOLDS["cause_recall"]),
            ("cohort IoU", iou, ">=", THRESHOLDS["mean_iou"]),
            ("false-recall rate", frr, "<=", THRESHOLDS["false_recall_rate"]),
            ("calibration (Brier)", brier, "<=", THRESHOLDS["brier"])]
    ok = True
    print(f"\n  eval over {K} synthetic fleets")
    print("  " + "-" * 52)
    for name, val, op, thr in rows:
        passed = val >= thr if op == ">=" else val <= thr
        ok = ok and passed
        print(f"  {name:22s} {val:6.3f}  {op} {thr:<5}  {'PASS' if passed else 'FAIL'}")
    print("  " + "-" * 52)
    print(f"  CI GATE: {'PASS ✓ (ship it)' if ok else 'REGRESSION ✗ (blocked)'}\n")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
