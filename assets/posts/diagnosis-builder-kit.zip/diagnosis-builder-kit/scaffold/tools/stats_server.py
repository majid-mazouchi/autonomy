"""diagnosis-stats MCP server (compact). Reads only. Run:  python tools/stats_server.py
The analyst calls these so the model never computes a statistic. (Full version in the diagnosis-copilot-kit.)"""
import math
try:
    from mcp.server.fastmcp import FastMCP
except Exception:
    FastMCP = None

if FastMCP:
    mcp = FastMCP("diagnosis-stats")

    @mcp.tool()
    def chi2_2x2(a: int, b: int, c: int, d: int) -> dict:
        """Chi-square test for a 2x2 cohort split [[a,b],[c,d]]; returns statistic + p (df=1)."""
        n = a + b + c + d
        if min(a + b, c + d, a + c, b + d) == 0:
            return {"error": "zero margin"}
        chi2 = n * (a * d - b * c) ** 2 / ((a + b) * (c + d) * (a + c) * (b + d))
        return {"chi2": round(chi2, 3), "p_value": math.erfc(math.sqrt(chi2 / 2))}

    @mcp.tool()
    def cusum(rates: list[float], baseline: float, slack: float = 0.0, threshold: float = 0.0) -> dict:
        """One-sided CUSUM for early warning; returns the first alarm index or null."""
        s = 0.0
        for i, r in enumerate(rates):
            s = max(0.0, s + (r - baseline - slack))
            if threshold and s > threshold:
                return {"alarm_index": i}
        return {"alarm_index": None}

    if __name__ == "__main__":
        mcp.run()
else:
    if __name__ == "__main__":
        print("Install 'mcp' (pip install mcp) to run this server.")
