# Scaffold — a runnable fleet-diagnosis skeleton

A minimal, **runnable** version of the seven-plane architecture. The worker agents are deterministic stubs,
so the eval harness produces real metrics with no API keys. Replace stubs with real LLM agents one at a time,
keeping the eval green.

## Run
```
python -m evals.run_evals
```
Generates synthetic fleets with a known injected cause, runs `diagnose_case`, grades it (cause-recall,
cohort IoU, false-recall, calibration), and prints a CI gate.

## Map
See `ARCHITECTURE.md` for folder ↔ plane. Start by replacing `core/agents.py` stubs (perceive/ground/
hypothesize/critic/synthesize) with LLM-backed agents behind the same contracts; keep `core/analyst.py`
calling tools for every number; wire `tools/stats_server.py` as an MCP server.
