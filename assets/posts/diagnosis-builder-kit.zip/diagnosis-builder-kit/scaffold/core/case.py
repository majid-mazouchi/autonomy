"""The Case = the shared blackboard a single investigation reads and writes."""
from dataclasses import dataclass, field
from typing import Any

@dataclass
class Case:
    case_id: str
    code: str                       # the DTC that opened the case, e.g. "P0AE0"
    cars: list[dict]                # the cohort's per-vehicle rows (the gold table slice)
    board: dict[str, Any] = field(default_factory=dict)   # workers write findings here
    status: str = "open"            # open | confirmed | inconclusive | incoherent

    @property
    def affected(self) -> list[dict]:
        return [c for c in self.cars if c.get("code")]
