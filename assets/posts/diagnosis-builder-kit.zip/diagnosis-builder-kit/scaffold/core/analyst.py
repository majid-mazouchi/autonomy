"""The analyst: the only worker that produces numbers — by 'calling tools' (here, plain functions).
Replace these with MCP tool calls; never let an LLM compute them."""

def _f1(selected: set, target: set) -> float:
    if not selected and not target: return 1.0
    if not selected or not target: return 0.0
    tp = len(selected & target)
    prec = tp / len(selected); rec = tp / len(target)
    return 0.0 if prec + rec == 0 else 2 * prec * rec / (prec + rec)

def de_mix(affected: list[dict], key: str = "throttle_temp_C") -> list[list[dict]]:
    """Split a mixture into sub-populations by the largest gap in a 1-D signature (stand-in for BIC)."""
    pts = sorted((c for c in affected if c.get(key) is not None), key=lambda c: c[key])
    if len(pts) < 4:
        return [pts] if pts else []
    gaps = [(pts[i + 1][key] - pts[i][key], i) for i in range(len(pts) - 1)]
    gap, idx = max(gaps)
    if gap < 8:                      # one tight cluster, not a real mixture
        return [pts]
    return [pts[: idx + 1], pts[idx + 1:]]

# candidate cohort boundaries (build attributes). A real system discovers these.
CANDIDATES = {
    "firmware>=5.1 & cold & many cold-FC":
        lambda c: str(c.get("firmware", "")).startswith("5.1") and c.get("climate") == "cold"
                  and c.get("cold_fastcharge_count", 0) >= 20,
    "connector lot B, build wk 12-18":
        lambda c: c.get("connector_lot") == "B" and 12 <= c.get("build_week", 0) <= 18,
    "firmware>=5.1": lambda c: str(c.get("firmware", "")).startswith("5.1"),
    "plant A": lambda c: c.get("plant") == "A",
    "climate cold": lambda c: c.get("climate") == "cold",
}

def cohort_boundary(cluster: list[dict], all_cars: list[dict]) -> dict:
    """Find the build attribute that best separates this cluster from the rest (the cause's rule)."""
    members = {c["vin"] for c in cluster}
    best = {"rule": None, "selected": set(), "confidence": 0.0}
    for name, pred in CANDIDATES.items():
        selected = {c["vin"] for c in all_cars if pred(c)}
        f1 = _f1(selected, members)
        if f1 > best["confidence"]:
            best = {"rule": name, "selected": selected, "confidence": round(f1, 3)}
    return best
