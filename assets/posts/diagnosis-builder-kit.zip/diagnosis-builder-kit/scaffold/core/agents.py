"""Worker agents. These are DETERMINISTIC STUBS so the eval harness runs with no API keys.
Replace each with a real LLM-backed agent behind the SAME contract, one at a time, keeping evals green."""
from core.case import Case

def perceive(case: Case) -> list[dict]:
    """Pull the affected cohort. (Real: an LLM agent that assembles signals + freeze-frames.)"""
    return case.affected

def ground(case: Case) -> dict:
    """Retrieve memory + docs (RAG / KG / case library). Stub returns nothing."""
    return {}

def hypothesize(case: Case, affected: list[dict]) -> list[str]:
    """Frame causal chains. Stub names the two known families. (Real: an LLM proposes chains.)"""
    return ["firmware cold-throttle?", "connector lot?"]

def critic_gate(diagnosis: list[dict], bar: float = 0.6) -> str:
    """Sufficiency / impostor / confounding check. (Real: an adversarial LLM + the stats tools.)"""
    if not diagnosis:
        return "INCOHERENT"
    return "CONFIRMED" if all(d["confidence"] >= bar for d in diagnosis) else "INCONCLUSIVE"

def synthesize(diagnosis: list[dict]) -> list[dict]:
    """Verdict: chain · confidence · kill-switch. Stub passes the diagnosed causes through."""
    return diagnosis
