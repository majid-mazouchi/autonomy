"""The orchestrator: the typed loop over workers, sharing the Case blackboard.
Mirrors Algorithm 2 in the post. Resumable/human-gated in production (here the gate auto-approves)."""
from core.case import Case
from core import agents, analyst

def human_gate(verdict, auto_approve=True) -> bool:
    """In production this pauses for a person (durable workflow). Demo auto-approves."""
    return auto_approve

def diagnose_case(case: Case, max_loops: int = 2) -> list[dict]:
    affected = agents.perceive(case)
    agents.ground(case)
    agents.hypothesize(case, affected)
    diagnosis = []
    for _ in range(max_loops):
        clusters = analyst.de_mix(affected)                         # de-mix the mixture
        diagnosis = [analyst.cohort_boundary(cl, case.cars) for cl in clusters]  # name each cause
        state = agents.critic_gate(diagnosis)                       # sufficiency gate
        if state == "CONFIRMED":
            break
        # INCONCLUSIVE/INCOHERENT → a real system collects more or re-frames; demo just stops
    verdict = agents.synthesize(diagnosis)
    case.status = "confirmed"
    if human_gate(verdict):                                         # --- human commits ---
        case.board["verdict"] = verdict                            # act(gated) + verify would follow
    return verdict
