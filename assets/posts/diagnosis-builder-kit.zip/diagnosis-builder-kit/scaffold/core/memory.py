"""Five memory stores with a write-gate: only human-confirmed, verified facts graduate to durable memory."""
working: dict = {}        # the case blackboard (ephemeral)
episodic: list = []       # case library (every outcome, with provenance)
semantic: dict = {}       # knowledge graph + doctrine (durable)
long_term: list = []      # confirmed causes & fixes (durable) → feeds detection priors

def remember(fact: dict):
    working.setdefault(fact.get("case_id"), []).append(fact)
    if fact.get("kind") == "case_outcome":
        episodic.append(fact)                                  # always grow the case library
    if fact.get("human_confirmed") and fact.get("verified"):
        long_term.append(fact)                                 # ONLY confirmed facts graduate
        # update_detection_priors(fact)   # closes the loop
    # else: stays episodic with provenance + TTL — never trust an unconfirmed guess
