"""Detection plane: cheap, always-on monitors that OPEN CASES. Runs on everything; agents run per case."""
def cusum(rates, baseline, slack=0.0, threshold=0.0):
    """One-sided CUSUM. Returns (alarm_index or None). Catches a small persistent shift early."""
    s = 0.0
    for i, r in enumerate(rates):
        s = max(0.0, s + (r - baseline - slack))
        if threshold and s > threshold:
            return i
    return None

def open_case(cohort, signals, safety, spread_rate, cost_exposure):
    """Triage: score and open a case. Agents pull cases by score — never run on raw data."""
    score = safety * spread_rate * cost_exposure
    return {"cohort": cohort, "signals": signals, "score": score, "status": "queued"}
