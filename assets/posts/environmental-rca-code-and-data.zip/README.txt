HV isolation-fault environmental RCA — code & data
==================================================
isolation_fault_rca.py : condensation-physics generator of the 500-event
                         fleet (isolation_events.csv) + full diagnostic
                         pipeline: fault Pareto, correlation screen,
                         partial-correlation confounder test, staged
                         regression, diurnal signature, Riso vs dew-point
                         margin, and prognosis (susceptibility curve +
                         annual fault-day forecast with/without coating).
                         Run:  python isolation_fault_rca.py
isolation_events.csv   : the generated mockup dataset (one row per event).
Deps: numpy, scipy.
